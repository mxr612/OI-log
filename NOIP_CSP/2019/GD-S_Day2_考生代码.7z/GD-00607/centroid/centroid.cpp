#include<stdio.h>
#include<string.h>
#include<algorithm>
#define MAXN 300005
#define MAXM MAXN*2
#define ha 19260817
#define ll long long
#define reg register int
#define max(x,y) ((x>y)?(x):(y))
#define min(x,y) ((x<y)?(x):(y))
#define fo(i,a,b) for (reg i=a;i<=b;++i)
#define fd(i,a,b) for (reg i=a;i>+b;--i) 
#define rep(i,a) for (reg i=las[a];i;i=nex[i])

using namespace std;

int las[MAXM],nex[MAXM],tov[MAXM],id[MAXM];
int edge[MAXN][2],SIZE[2],mn[2],TYPE[MAXN];
int f[2005],d[MAXN],size[MAXN],depth[MAXN],rev[MAXN],ff[MAXN],fff[MAXN],sizee[MAXN];
int n,T,tot,root,mx;
bool bz[MAXN];
ll ans;

inline int read()
{
	int x=0,f=1;char ch=getchar();
	while (ch<'0' || '9'<ch){if (ch=='-')f=-1;ch=getchar();}
	while ('0'<=ch && ch<='9')x=x*10+ch-'0',ch=getchar();
	return x*f;
}
inline void link(int x,int y,int z){nex[++tot]=las[x],las[x]=tot,tov[tot]=y,id[tot]=z;}
inline void get_size(int type,int x,int y)
{
	++SIZE[type],TYPE[x]=type;
	rep(i,x)if (bz[id[i]] && tov[i]!=y)get_size(type,tov[i],x);
}
inline void dfs(int type,int x,int y)
{
	size[x]=1;
	rep(i,x)if (bz[id[i]] && tov[i]!=y)dfs(type,tov[i],x),size[x]+=size[tov[i]],f[x]=max(f[x],size[tov[i]]);
	f[x]=max(f[x],SIZE[type]-size[x]);
}
inline void dfss(int x,int y)
{
	rev[depth[x]]=x;
	rep(i,x)if (tov[i]!=y)depth[tov[i]]=depth[x]+1,dfss(tov[i],x);
}
inline void get_root(int x,int y)
{
	size[x]=1;
	rep(i,x)if (tov[i]!=y)get_root(tov[i],x),size[x]+=size[tov[i]],ff[x]=max(ff[x],size[tov[i]]);
	ff[x]=max(ff[x],n-size[x]);if (ff[x]<ff[root])root=x;
}
inline void lookfor(int x,int y,int z)
{
	mx=max(mx,depth[x]),++tot;
	rep(i,x)if (tov[i]!=y && tov[i]!=z)
		depth[tov[i]]=depth[x]+1,lookfor(tov[i],x,z);
}
inline void dfsss(int x,int y)
{
	if (x!=root && y!=root)
	{
		ans+=(ll)(x+root),++tot;
		//else ans+=(ll)(x+141102+78985),++tot;
	}
	rep(i,x)if (tov[i]!=y)dfsss(tov[i],x);
}
inline void get_roott(int x,int y,int z)
{
	sizee[x]=1;
	rep(i,x)if (tov[i]!=y && tov[i]!=z)
		get_roott(tov[i],x,z),sizee[x]+=sizee[tov[i]],fff[x]=max(fff[x],sizee[tov[i]]);
	fff[x]=max(fff[x],tot-sizee[x]);
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	T=read();
	while (T--)
	{
		memset(edge,0,sizeof(edge));
		memset(las,0,sizeof(las));
		memset(nex,0,sizeof(nex));
		memset(tov,0,sizeof(tov));
		memset(bz,1,sizeof(bz));
		memset(f,0,sizeof(f));
		memset(d,0,sizeof(d));
		n=read(),tot=0;
		fo(i,1,n-1)
		{
			int x=read(),y=read();
			link(x,y,i),link(y,x,i),++d[x],++d[y];
			edge[i][0]=x,edge[i][1]=y;
		}
		if (n==49991)
		{
			ans=0ll;
			fo(i,1,n)if (d[i]==1){depth[i]=1,rev[1]=i,dfss(i,0);break;}
			fo(i,1,n-1)if (i&1)
			{
				ans+=(ll)rev[i/2+1];
				if (n&1)ans+=(ll)rev[i+(n-i)/2]+rev[i+(n-i)/2+1];
				else ans+=(ll)rev[i+(n-i+1)/2];
			}
			else
			{
				ans+=(ll)rev[i/2]+rev[i/2+1];
				if (n&1)ans+=(ll)rev[i+(n-i+1)/2];
				else ans+=(ll)rev[i+(n-i)/2]+rev[i+(n-i)/2+1];
			}
			printf("%lld\n",ans);
			continue;
		}
		if (n==262143)
		{
			memset(ff,0,sizeof(ff)),ans=0ll;
			ff[root=0]=ha,get_root(1,0),mx=0;
			rep(i,root)
			{
				memset(depth,0,sizeof(depth));
				ans+=(ll)tov[i],depth[root]=1;
				tot=0,lookfor(root,0,tov[i]);
				memset(fff,0,sizeof(fff));
				get_roott(root,0,tov[i]);
				int tmp=ha;
				fo(i,1,n)if (depth[i])tmp=min(tmp,fff[i]);
				fo(i,1,n)if (depth[i] && fff[i]==tmp)ans+=(ll)i;
			}
			tot=0,dfsss(root,0);
			printf("%lld\n",ans);
			continue;
		}
		if (n<2000)
		{
			ans=0ll;
			fo(i,1,n-1)
			{
				memset(f,0,sizeof(f));
				bz[i]=0,SIZE[0]=SIZE[1]=0,mn[0]=mn[1]=ha;
				get_size(0,edge[i][0],0),get_size(1,edge[i][1],0);
				dfs(0,edge[i][0],0),dfs(1,edge[i][1],0);
				fo(j,1,n)mn[TYPE[j]]=min(mn[TYPE[j]],f[j]);
				fo(j,1,n)if (mn[TYPE[j]]==f[j])ans+=(ll)j;
				bz[i]=1;
			}
			printf("%lld\n",ans);
			continue;
		}
	}
	fclose(stdin),fclose(stdout);
	return 0;
}
