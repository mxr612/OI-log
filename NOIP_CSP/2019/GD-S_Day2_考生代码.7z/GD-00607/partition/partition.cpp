#include<stdio.h>
#include<string.h>
#include<algorithm>
#define MAXN 405
#define ll long long
#define reg register ll
#define fo(i,a,b) for (reg i=a;i<=b;++i)
#define fd(i,a,b) for (reg i=a;i>=b;--i)

using namespace std;

ll f[MAXN][MAXN];
ll a[MAXN],pre[MAXN];
ll n,mx,ans,type;

inline ll read()
{
	ll x=0,f=1;char ch=getchar();
	while (ch<'0' || '9'<ch){if (ch=='-')f=-1;ch=getchar();}
	while ('0'<=ch && ch<='9')x=x*10+ch-'0',ch=getchar();
	return x*f;
}
inline ll sqr(ll x){return x*x;}
inline ll get(ll x,ll y){return x==0?pre[y]:pre[y]-pre[x-1];}
inline ll min(ll x,ll y){return x<y?x:y;}
inline ll max(ll x,ll y){return x>y?x:y;}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=read(),type=read();
	fo(i,1,n)pre[i]=pre[i-1]+(a[i]=read());
	memset(f,100,sizeof(f));
	mx=ans=f[1][1],f[0][0]=0;
	fo(i,0,n-1)fo(j,0,i)if (f[i][j]!=mx)
	{
		fo(k,i+1,n)if (get(j,i)<=get(i+1,k))f[k][i+1]=min(f[k][i+1],f[i][j]+sqr(get(i+1,k)));	
	}
	fo(i,1,n)ans=min(ans,f[n][i]);
	printf("%lld\n",ans);
	fclose(stdin),fclose(stdout);
	return 0;
};
