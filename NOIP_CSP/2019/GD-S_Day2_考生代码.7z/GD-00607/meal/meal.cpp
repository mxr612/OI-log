#include<stdio.h>
#include<string.h>
#include<algorithm>
#include<queue>
#define MAXN 105
#define MAXM 2005
#define ha 998244353
#define ll long long
#define reg register ll
#define fo(i,a,b) for (reg i=a;i<=b;++i)
#define fd(i,a,b) for (reg i=a;i>=b;--i)

using namespace std;

ll a[MAXN][MAXM],f[MAXN][MAXM];
ll col[2005];
ll n,m,ans;

struct node
{
	bool bz[MAXN];
	ll col[MAXM],mx,tot,ans;
}tmp;
queue<node>q;

inline ll read()
{
	int x=0,f=1;char ch=getchar();
	while (ch<'0' || '9'<ch){if (ch=='-')f=-1;ch=getchar();}
	while ('0'<=ch && ch<='9')x=x*10+ch-'0',ch=getchar();
	return x*f;
}
inline void dfs(ll x,ll y,ll z,ll target)
{
	if (x>n)
	{
		if (y==target)
		{
			bool flag=1;
			fo(i,1,m)if (col[i]>y/2){flag=0;break;}
			if (flag)(ans+=z)%=ha;
		}
		return;
	}
	if (y==target){dfs(x+1,y,z,target);return;}
	dfs(x+1,y,z,target);
	fo(i,1,m)++col[i],dfs(x+1,y+1,z*a[x][i]%ha,target),--col[i];
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read(),m=read();
	fo(i,1,n)fo(j,1,m)a[i][j]=read();
	if (n<=10)
	{
		fo(i,2,n)dfs(1,0,1,i);
		printf("%lld\n",ans);
		return 0;
	}
	fclose(stdin),fclose(stdout);
	return 0;
}
