#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>

#include <bitset>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <set>
#include <map>

using namespace std;


const int N = 300010, M = 600010;


struct edge
{
	int from, to;
	edge() { }
	edge(int _1, int _2) : from(_1), to(_2) { }
} edges[M];

int head[N], nxt[M], tot;

inline void init()
{
	memset(head, -1, sizeof(head));
	tot = 0;
}

inline void add_edge(int x, int y)
{
	edges[tot] = edge(x, y);
	nxt[tot] = head[x];
	head[x] = tot++;
	edges[tot] = edge(y, x);
	nxt[tot] = head[y];
	head[y] = tot++;
}


int n;

int siz[N], maxsize[N];
long long Ans;

void dfs_size(int x, int fa, int id)
{
	siz[x] = 1;
	maxsize[x] = 0;
	for (int i = head[x]; ~i; i = nxt[i])
	{
		edge & e = edges[i];
		if (e.to != fa && i != id && (i ^ 1) != id)
		{
			dfs_size(e.to, x, id);
			maxsize[x] = max(maxsize[x], siz[e.to]);
			siz[x] += siz[e.to];
		}
	}
}


void get(int x, int fa, int id, int size)
{
	if (maxsize[x] <= size / 2 && size - siz[x] <= size / 2)
		Ans += x;
	for (int i = head[x]; ~i; i = nxt[i])
	{
		edge & e = edges[i];
		if (e.to != fa && i != id && (i ^ 1) != id)
			get(e.to, x, id, size);
	}
}


int deg[N];


namespace Subtask2
{
	int p[N];
	
	void dfs(int x, int fa, int depth)
	{
		p[depth] = x;
		for (int i = head[x]; ~i; i = nxt[i])
		{
			edge & e = edges[i];
			if (e.to != fa)
				dfs(e.to, x, depth + 1);
		}
	}

	void solve()
	{
		int st = 0;
		for (int i = 1; i <= n; i++)
			if (deg[i] == 1) { st = i; break; }
		
		dfs(st, 0, 1);
		
		for (int i = 1; i < n; i++)
		{
			if (i & 1)
				Ans += p[i / 2 + 1];
			else
				Ans += p[i / 2] + p[i / 2 + 1];
			if ((n - i) & 1)
				Ans += p[i + (n - i) / 2 + 1];
			else
				Ans += p[i + (n - i) / 2] + p[i + (n - i) / 2 + 1];
		}
	}
}


int main()
{
	freopen("centroid.in", "r", stdin);
	freopen("centroid.out", "w", stdout);
	
	int T;
	cin >> T;
	
	while (T--)
	{
		cin >> n;
		
		init();
		memset(deg, 0, sizeof(deg));
		for (int i = 1; i < n; i++)
		{
			int x, y;
			scanf("%d %d", &x, &y);
			add_edge(x, y);
			deg[x]++;
			deg[y]++;
		}
		
		int cnt1 = 0, cnt2 = 0;
		for (int i = 1; i <= n; i++)
			if (deg[i] == 1) cnt1++;
			else if (deg[i] == 2) cnt2++;
		
		Ans = 0;
		
		if (n <= 2000)
		{
			for (int i = 0; i < tot; i += 2)
			{
				int x = edges[i].from;
				int y = edges[i].to;
				dfs_size(x, 0, i);
				get(x, 0, i, siz[x]);
				dfs_size(y, 0, i);
				get(y, 0, i, siz[y]);
			}
		}
		else if (cnt1 == 2 && cnt2 == n - 2)
			Subtask2::solve();
		
		cout << Ans << endl;
	}
	
	return 0;
}
