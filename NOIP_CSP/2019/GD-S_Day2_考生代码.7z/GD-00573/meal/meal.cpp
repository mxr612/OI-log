#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>

#include <bitset>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <set>
#include <map>

using namespace std;


typedef long long LL;


const LL mod = 998244353;


const int N = 2010;


inline LL power(LL a, LL n, LL mod)
{
	LL Ans = 1;
	while (n)
	{
		if (n & 1) Ans = Ans * a % mod;
		a = a * a % mod;
		n >>= 1;
	}
	return Ans;
}


int n, m;


LL a[N][N];

LL cnt[N];
int cnt2[N];

LL f[N], dp[N];


LL calc(int id, int tot, int val)
{
	LL Ans = 0;
	for (int st = 0; st < (1 << n); st++)
	{
		int s = 0;
		for (int j = 1; j <= n; j++)
			if (st & (1 << (j-1))) s++;
		
		if (s != tot) continue;
		
		bool flag = 0;
		for (int j = 1; j <= n && !flag; j++)
			if ((st & (1 << (j-1))) && !a[j][id]) flag = 1;
		
		if (flag) continue;
		
		memset(dp, 0, sizeof(LL) * (n + 1));
		dp[0] = 1;
		for (int i = 1; i <= n; i++)
			if (!(st & (1 << (i-1))))
				for (int j = n; j >= 1; j--)
					dp[j] = (dp[j] + dp[j-1] * (cnt[i] - a[i][id] + mod) % mod) % mod;
		Ans = (Ans + dp[val]) % mod;
	}
	
	return Ans;
}


int main()
{
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	
	cin >> n >> m;
	
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			scanf("%lld", &a[i][j]);
	
	for (int i = 1; i <= m; i++)
		for (int j = 1; j <= n; j++)
			cnt2[i] += (a[j][i] > 0 ? 1 : 0);
	
	f[0] = 1;
	for (int i = 1; i <= n; i++)
	{
		cnt[i] = 0;
		for (int j = 1; j <= m; j++)
			cnt[i] = (cnt[i] + a[i][j]) % mod;
		for (int j = n; j >= 1; j--)
			f[j] = (f[j] + f[j-1] * cnt[i] % mod) % mod;
	}
	
	LL Ans = 0;
	for (int i = 2; i <= n; i++)
	{
		Ans = (Ans + f[i]) % mod;
		for (int j = 1; j <= m; j++)
			for (int k = i / 2 + 1; k <= min(i, cnt2[j]); k++)
				Ans = (Ans - calc(j, k, i - k) + mod) % mod;
	}
	
	cout << Ans << endl;
	
	return 0;
}
