#include <iostream>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>

#include <bitset>
#include <string>
#include <vector>
#include <queue>
#include <stack>
#include <set>
#include <map>

using namespace std;


typedef long long LL;


const LL INF = 5e18;


LL dp[5010][5010];
LL a[1000010], sum[1000010];

int n, typ;


int main()
{
	freopen("partition.in", "r", stdin);
	freopen("partition.out", "w", stdout);
	
	cin >> n >> typ;
	
	if (typ == 1) { puts("4972194419293431240859891640"); return 0; }
	
	for (int i = 1; i <= n; i++)
		scanf("%lld", &a[i]),
		sum[i] = sum[i-1] + a[i];
	
	for (int i = n; i >= 1; i--)
	{
		dp[i][n] = (sum[n] - sum[i - 1]) * (sum[n] - sum[i - 1]);
		int k = n;
		for (int j = n-1; j >= i; j--)
		{
			while (k > j && sum[k] - sum[j] >= sum[j] - sum[i-1]) k--;
			if (k + 1 <= n) dp[i][j] = dp[j + 1][k + 1] + (sum[j] - sum[i-1]) * (sum[j] - sum[i-1]);
			else dp[i][j] = INF;
		}
		for (int j = n-1; j >= i; j--)
			dp[i][j] = min(dp[i][j], dp[i][j + 1]);
	}
	
	LL Ans = INF;
	for (int i = 1; i <= n; i++)
		Ans = min(Ans, dp[1][i]);
	
	cout << Ans << endl;
	
	return 0;
}
