#include <cstdio>
#include <iostream>
#include <vector>
#include <cctype>
#include <cstring>
#include <algorithm>
using namespace std;

const int MAX_N = 107, MAX_M = 2007, MAX_A = 1007;
const int mod = 998244353;
int n, m, a[MAX_N][MAX_M];
// subtask I
int cnt[MAX_M], tk;
long long gcnt = 0;
void dfs_01(int ni, int nk) { // a = 0/1
	if (nk == tk) {
		gcnt = (gcnt + 1) % mod;
		return;
	}
	
	if (ni > n) return;
	
	for (int j = 1; j <= m; j++) {
		if (a[ni][j] != 0 && cnt[j] + 1 <= (tk / 2)) {
			cnt[j] += 1;
			dfs_01(ni + 1, nk + 1);
			cnt[j] -= 1;
		}
	}
	dfs_01(ni + 1, nk);
}

// C[i][j] == {i \choose j};
long long C[MAX_A][MAX_N];
void init_C(int a_max, int n) {
	
	for (int i = 0; i <= a_max; i++)
		C[i][0] = 1;
	
	for (int i = 1; i <= a_max; i++) {
		for (int j = 1; j <= min(n, i); j++) {
			C[i][j] = (C[i-1][j] + C[i-1][j-1]) % mod;
		}
	}
}

//struct Res {
//	int i, j, a, chs;
//};
//vector<Res> v;

int chs[MAX_N][MAX_M];
void big_dfs(int ni, int nk) {
	if (nk == tk) {
		
//		printf("DEBUG: ");
//		for (size_t i = 0; i < v.size(); i++)
//			printf("(%d %d %d %d), ", v[i].i, v[i].j, v[i].a, v[i].chs);
//		printf("\n");
		
		long long t = 1;
//		printf("DEBUG: ");
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= m; j++) {
				t = (t * (C[ a[i][j] ][ chs[i][j] ])) % mod;
//				if (chs[i][j] != 0) printf("%d(%d,%d) ", chs[i][j], i, j);
			}
		}
//		printf("\n");
		gcnt = (gcnt + t) % mod;
		return;
	}	
	
	if (ni > n) return;
	
	for (int j = 1; j <= m; j++) {
		for (int cc = 1; cc <= min(tk / 2, a[ni][j]); cc++) {
			if (cnt[j] + cc <= (tk / 2)) {
				cnt[j] += cc; chs[ni][j] = cc;
//				v.push_back((Res) { ni, j, a[ni][j], cc });
				big_dfs(ni + 1, nk + cc);
//				v.pop_back();
				cnt[j] -= cc; chs[ni][j] = 0;
			}
		}
	}
	big_dfs(ni + 1, nk);
}

int main() {
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	scanf("%d %d", &n, &m);
	bool is_01 = true;
	int max_a = 0;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= m; j++) {
			scanf("%d", &(a[i][j]));
			if (a[i][j] >= 2)
				is_01 = false;
			if (a[i][j] > max_a)
				max_a = a[i][j];
		}
	}
	if (is_01) { // subtask I: 24%
		for (int k = 2; k <= n; k++) {
			tk = k;
			dfs_01(1, 0);
		}
		cout << gcnt % mod;	
	} else {
		init_C(max_a, n);
		for (int k = 2; k <= n; k++) {
			tk = k;
			big_dfs(1, 0);
		}
		cout << gcnt % mod;
	}

	
	return 0;
}
/*
5 5
1 0 0 1 1
0 1 0 1 0
1 1 1 1 0
1 0 1 0 1
0 1 1 0 1
*/
