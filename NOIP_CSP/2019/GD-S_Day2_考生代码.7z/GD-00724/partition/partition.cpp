#include <stdio.h>
#include <iostream>
using namespace std;
int type,n;
int data[10000000];
int getData(){
	if(type==0){
		for(int i=0;i<n;i++){
			cin>>data[i];
		}
	}
}
long long fsearch(long long min,int x){
	if(x==n)
		return 0;
	int group_size=0;
	for(;group_size<min&&x<n;x++){
		group_size+=data[x];
	}
	int m=0x7fffffff;
	for(;x<n;x++){
		long long f=group_size*group_size+fsearch(group_size,x+1);
		m=m>f?f:m;
		group_size+=data[x];
	}
	if(group_size<min){
		return 0x3fffffff;
	}else{
		return min;
	}
}
long long getGroup(long long min){
	long long group_size=0;
	long long time=0;
	for(int i=0;i<n;i++){
		group_size+=data[i];
		if(group_size>=min){
			min=group_size;
			time+=group_size*group_size;
			group_size=0;
		}
	}
	time-=min*min;
	time+=(group_size+min)*(group_size+min);
	return time;
}
long long search(){
	int sum=0;
	long long min=0x7fffffff;
	for(int i=0;i<n;i++){
		sum+=data[i];
		long long r=getGroup(sum);
		if(r<min){
			min=r;
		}
	}
	return min;
//return fsearch(data[0],0);
}
int main(void){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>type;
	getData();
	cout<<search();
	return 0;
}
