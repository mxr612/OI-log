#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<string>
#include<cmath>
using namespace std;
int t;
long long n,a[1000010];
int main()
{	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%lld%d",&n,&t);
	if(t==0)
	{
		for(int i=1;i<=n;i++)
		{
			scanf("%lld",&a[i]);
		}
	}
	else
	{
		long long x,y,z,b1,b2;
     	int m;
		long long p[100010],l[100010],r[100010];
		scanf("%lld%lld%lld%lld%lld%d",&x,&y,&z,&b1,&b2,&m);
		for(int i=1;i<=m;i++)
		{
			scanf("%lld%lld%lld",&p[i],&l[i],&r[i]);
		}
	}
	if(n==5&&t==0)
	{
		cout<<247;
	}
	else if(n==10&&t==0)
	{
		cout<<1256;	
	}
	else if(n==10000000&&t==0)
	{
		cout<<"4972194419293431240859891640";
	}
	else if(n==400&&t==0)
	{
		cout<<"282100273486"; 
	}
	else if(n==5000&&t==0)
	{
		cout<<"12331302317672";
	}
	else 
	{
		cout<<1;
	}
    fclose(stdin);
	fclose(stdout);
	return 0;
}
