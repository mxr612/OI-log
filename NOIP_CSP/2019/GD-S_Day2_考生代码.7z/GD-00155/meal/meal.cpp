#include<cstdio>
#include<fstream>
using namespace std;
typedef long long ll;
int read(){
	char ch=getchar();int num=0,f=1;
	while(ch<'0' || '9'<ch){if(ch=='-'){f=-1;ch=getchar();break;}ch=getchar();}
	while('0'<=ch && ch<='9'){num=num*10+ch-'0';ch=getchar();}
	return num*f;
}
const ll mod=998244353;
int N,M,num[102][2002];
ll f[42][42][42];//f(i,j,k)��ʾǰi�����õ�һ��ʳ�ĵ���a�֣��õڶ���ʳ�ĵ���b�ֵķ����� 
ll g[42][42][42][42];//ͬf��ֻ��������һ��ʳ�� 
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	N=read();M=read();
	for(int i=1;i<=N;i++)
		for(int j=1;j<=M;j++)
			num[i][j]=read();
	if(M==2){
		f[0][0][0]=1;
		for(int i=1;i<=N;i++)
			for(int a=0;a<=i;a++)
				for(int b=0;a+b<=i;b++){
					f[i][a][b]=f[i-1][a][b];
					if(a)f[i][a][b]=(f[i][a][b]+f[i][a-1][b]*num[i][1]%mod)%mod;
					if(b)f[i][a][b]=(f[i][a][b]+f[i][a][b-1]*num[i][2]%mod)%mod;
				}
		ll ans=0;
		for(int i=1;i<=N;i++)
			ans=(ans+f[N][i][i])%mod;
		printf("%lld",ans); 
	}else if(M==3){
		g[0][0][0][0]=1;
		ll ans=0;
		for(int i=1;i<=N;i++)
			for(int a=0;a<=i;a++)
				for(int b=0;a+b<=i;b++)
					for(int c=0;a+b+c<=i;c++){
						g[i][a][b][c]=g[i-1][a][b][c];
						if(a)g[i][a][b][c]=(g[i][a][b][c]+g[i-1][a-1][b][c]*num[i][1]%mod)%mod;
						if(b)g[i][a][b][c]=(g[i][a][b][c]+g[i-1][a][b-1][c]*num[i][2]%mod)%mod;
						if(c)g[i][a][b][c]=(g[i][a][b][c]+g[i-1][a][b][c-1]*num[i][3]%mod)%mod;
						if(a+b+c>=1 && i==N && a<=((a+b+c)>>1) && b<=((a+b+c)>>1) && c<=((a+b+c)>>1))
							ans=(ans+g[i][a][b][c])%mod;
					}
		printf("%lld",ans);
	}
	return 0;
}
