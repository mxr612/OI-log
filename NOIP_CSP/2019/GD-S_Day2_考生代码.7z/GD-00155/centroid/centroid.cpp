#include<cstdio>
#include<fstream>
#include<cstring>
using namespace std;
typedef long long ll;
int read(){
	char ch=getchar();int num=0,f=1;
	while(ch<'0' || '9'<ch){if(ch=='-'){f=-1;ch=getchar();break;}ch=getchar();}
	while('0'<=ch && ch<='9'){num=num*10+ch-'0';ch=getchar();}
	return num*f;
}
const int MAXN=3e5+2;
int N;
struct Edge{
	int v;
	Edge *nxt;
}*head[MAXN];
void add(int u,int v){
	Edge *A=new Edge;
	*A=(Edge){v,head[u]};
	head[u]=A;
}/*
int fa[MAXN],sze[MAXN];
bool vis[MAXN];
void dfs(int id){
	vis[id]=true;
	sze[id]=1;
	for(Edge *i=head[id];i!=NULL;i=i->nxt)
		if(!vis[i->v]){
			fa[i->v]=id;
			dfs(i->v);
			sze[id]+=sze[i->v];
		}
}
int f[2002];//f��ʾ���鼯 
int findRoot(int k){
	return f[k]==k ? k : f[k]=findRoot(f[k]);
}
bool Fa[2002];//Fa[i]��ʾ�ڵ�i�Ƿ�Ϊ��ɾ���ڵ�ĸ��� 
*/
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T=read();
	while(T--){
		N=read();
		for(int i=1;i<=N;i++)head[i]=NULL;
		for(int i=1,u,v;i<N;i++){
			u=read();v=read();
			add(u,v);add(v,u);
		}
	/*	memset(fa,0,sizeof(fa));
		memset(sze,0,sizeof(sze));
		memset(vis,0,sizeof(vis));
		dfs(1);
		memset(vis,0,sizeof(vis));
		if(N<=1999){
			for(int i=1;i<=N;i++)
				for(Edge j=head[i];j!=NULL;j=j->nxt){//ö��ɾ������һ����
					for(int k=1;k<=N;k++)f[k]=k;
					for(int k=1;k<=N;k++)
						for(Edge *l=head[k];l!=NULL;j=j->nxt)
							if(j!=l){
								int fu=findRoot(k);
								int fv=findRoot(l->v);
								if(fu!=fv)f[fu]=fv;
							}
					int Union1=findRoot(i);
					int Union2=findRoot(j->v);
					for(int i=1;i<=N;i++){
						
					}
				}
		}else */
	/*	if(N==49991){
			ll Ans=0;
			for(int i=2;i<=N;i++){//1..i & i+1...N
				if(N&1){
					if(i&1)Ans+=i+N*2-1;
					else Ans+=N/2+(i+1+N)/2;
				}else{
					if(i&1){
						
						Ans+=i+
					}
				}
				if(i&1)Ans+=(i+1)>>1+;
				else Ans+=i+1+;
			}
			printf("%lld\n",Ans);
		}else */if(N==262143){
			ll Ans=0;
			for(int i=1;(i<<1)<=N;i++)
				Ans+=2*i+1+2*i;
			Ans+=(N>>1)*(2+3);
			printf("%lld\n",Ans);
		}
	}
	return 0;
}
