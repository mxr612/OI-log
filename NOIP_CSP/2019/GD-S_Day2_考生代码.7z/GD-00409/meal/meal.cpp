#include<bits/stdc++.h>
using namespace std;
const long long mod=998244353;
int m,n;
long long a[110][2100];

int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++) {
		for (int j=1;j<=m;j++){
			scanf("%lld",&a[i][j]);
		}
	}
	if (m==2){
		long long ans=0;
		for (int i=1;i<=n;i++) {      
			for (int x=i+1;x<=n;x++){
			for (int j=1;j<=m;j++) {
					for (int y=1;y<=m;y++){
						if (y==j) continue;
						ans=(ans+(a[i][j]*a[x][y]%mod))%mod;
					}
				}
			}
		}
		printf("%lld",ans);
		return 0;
	}
	else if (m==3){
		long long ans=0;
		for (int i=1;i<=n-1;i++) {      
			for (int x=i+1;x<=n;x++){
				for (int j=1;j<=m;j++){
					for (int y=1;y<=m;y++){
						if (y==j) continue;
						ans=(ans+(a[i][j]*a[x][y]%mod))%mod;
					}
				}
			}
		}	
		for (int i=1;i<=n-2;i++) {
			for (int x=i+1;x<=n-1;x++){
				for (int p=x+1;p<=n;p++){
					for (int j=1;j<=m;j++){
						for (int y=1;y<=m;y++){
							if (y==j) continue;
							for (int q=1;q<=m;q++){
								if (q==j||q==y) continue;
								ans=(ans+(a[i][j]*a[x][y]%mod)*a[p][q]%mod)%mod;
							}
						}
					}
				}
			}
		}	
		printf("%lld",ans);
		return 0;
	}
	
	return 0;
}
