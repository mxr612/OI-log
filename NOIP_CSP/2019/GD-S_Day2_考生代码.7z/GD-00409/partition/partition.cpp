#include<bits/stdc++.h>
using namespace std;
int a[550000],t[4000000],cut[550000],n;

void build(int l,int r,int o){
	if (l==r) {t[o]=a[l];return;}
	int mid=(l+r)>>1;
	build(l,mid,o<<1);
	build(mid+1,r,o<<1|1);
	t[o]=t[o<<1]+t[o<<1|1];
}
bool check(int k){
	int l=1,sum=0;
	int x=t[1]/(k+1);
	for (l=1;sum<x;l++){
		sum+=a[l];
	}
	if (l==1) return false;
	int cnt=1;
	cut[cnt]=l-1;
	l--;
	sum-=a[l+1];
	int i=l+1,tot=0;
	while (i<=n){
		tot+=a[i];
		if (tot>=sum) {
			sum=tot;
			tot=0;
			cut[++cnt]=i;
			if (cnt==k) return true;
		}
		i++;
	}
	if (cnt<k) return false;
	else return true;
}
unsigned long long ans;
void query(int l,int r,int o,int x,int y){
	if (l>=x&&r<=y) {ans+=t[o];return;}
	int mid=(l+r)>>1;
	if (x<=mid) query(l,mid,o<<1,x,y);
	if (y>mid) query(mid+1,r,o<<1|1,x,y);
}

int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int type;
	scanf("%d%d",&n,&type);
	if (!type){
		for (int i=1;i<=n;i++) {
			scanf("%d",&a[i]);
		}
		build(1,n,1);
		unsigned long long ttime=(t[1]*t[1]);
		int k=1;
		while (k<n){
			if (!check(k)){
				printf("%lld",ttime);
				return 0;
			}
			unsigned long long tmp=0;
			cut[0]=0;
			for (int i=1;i<=k;i++){
				ans=0;
				query(1,n,1,cut[i-1]+1,cut[i]);
				tmp+=(ans*ans);
			}
			ttime=min(ttime,tmp);
			k++;
		}
		printf("%lld",ttime);
	}
}
