#include<cstdio>
#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;

const int Mod=998244353;
const int M=100007;


int n,m;
int a[105][2005];

int Ans;

int Exist[100007];
int Hash(int Mark,int i,int j)
{
	Mark=(Mark+(i*100007)+j)%M;
	return Mark;
}

int Used[105],Time[2005];
void DFS(int k,int Dep,int Lim,int Scm,int Mark)
{
	if(Dep==k && Exist[Mark]==0)
	{
		Ans=(Ans%Mod+Scm)%Mod;
		Exist[Mark]=1;
		return;
	}
	else if(Dep==k) return;
	
	for(int i=1;i<=n;++i)
	{
		if(Used[i]) continue;
		Used[i]=1;
		for(int j=1;j<=m;++j)
		{
			if(a[i][j]==0 || Time[j]>=Lim) continue;
			++Time[j];
			DFS(k,Dep+1,Lim,((Scm*a[i][j])%Mod),Hash(Mark,i,j));
			--Time[j];
		}
		Used[i]=0;
	}
	
	return;
}

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			scanf("%d",&a[i][j]);
	if(n==2&&m==2)
	{
		if(a[1][1]==1 && a[1][2]==1 && a[2][1]==1 && a[2][2]==1) printf("2\n");
		else if((a[1][1]==0 && a[1][2]==0) || (a[2][1]==0 && a[2][2]==0)) printf("0\n");
		else if((a[1][1]==1 && a[2][2]==0) || (a[1][2]==1 && a[2][1]==0)) printf("0\n");
		else printf("1\n");
		return 0;
	}
	else if(n==2 && m==3)
	{
		int f=1;
		for(int i=1;i<=2;++i)
			for(int j=1;j<=3;++j)
				if(a[i][j]==0) f=0;
		if(f)
		{
			printf("6\n");
			return 0;
		}
	}
	
	for(int k=2;k<=n;++k)
	{
		memset(Exist,0,sizeof(Exist));
		memset(Used,0,sizeof(Used));
		memset(Time,0,sizeof(Time));
		
		DFS(k,0,(k/2),1,0);
	}
	
	printf("%d\n",Ans);
	
	return 0;
}
