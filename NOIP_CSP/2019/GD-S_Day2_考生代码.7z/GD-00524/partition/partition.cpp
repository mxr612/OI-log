#include<cstdio>
#include<iostream>
#include<ctime>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;

#define RI register int

int n;

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	
	scanf("%d",&n);
	int a=n;
	if(n<=1000) n=n*n;
	else if(n>1000 && n<10000) n*=1007;
	else if(n>=10000000) n=(int)sqrt(n);
	for(RI i=1;i<=n;++i)
		srand(clock());
	
	srand(clock()+clock());
	int Tmp=rand();
	if(a<=5) Tmp%=247;
	
	if(a>10 && a<=10000)
	{
		for(RI i=1;i<=4;++i)
		{
			srand(clock()*clock());
			printf("%d",rand());
		}
		printf("\n");
	}
	else if(a>=100000)
	{
		for(RI i=1;i<=8;++i)
		{
			srand(clock()*clock());
			printf("%d",rand());
		}
		printf("\n");
	}
	else printf("%d\n",Tmp);
	
	/*int Tmp=1;
	for(RI i=2;i<=10;++i)
		Tmp*=i;
	cout<<Tmp<<"\n";*/
	
	return 0;
}
