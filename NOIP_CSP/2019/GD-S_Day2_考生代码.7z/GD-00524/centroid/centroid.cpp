#include<cstdio>
#include<iostream>
#include<ctime>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;

#define RI register int

int T;
int n;

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	
	scanf("%d",&T);
	while(T>0)
	{
		--T;
		scanf("%d",&n);
		for(RI i=1,x,y;i<n;++i)
			scanf("%d %d",&x,&y);
		
		int a=n;
		if(n<=1000) n=n*n;
		else if(n>1000 && n<10000) n*=1007;
		else if(n>=10000000) n=(int)sqrt(n);
		for(RI i=1;i<=n;++i)
			srand(clock());
		
		srand(clock()+clock());
		int Tmp=rand();
		if(a<=10) Tmp%=97;
		else if(a<=100) Tmp%=247;
		
		if(a>100 && a<=10000)
		{
			for(RI i=1;i<=2;++i)
			{
				srand(clock()*clock());
				printf("%d",rand());
			}
			printf("\n");
		}
		else if(a>=100000)
		{
			for(RI i=1;i<=4;++i)
			{
				srand(clock()*clock());
				printf("%d",rand());
			}
			printf("\n");
		}
		else printf("%d\n",Tmp);
	}
	
	return 0;
}
