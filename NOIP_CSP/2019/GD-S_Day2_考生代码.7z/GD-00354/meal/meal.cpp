#include<iostream>
#include<cstdio>
const int e=101,ee=2001;
long long s,t,ans;
int i,j,n,m,d,a[e][ee],z[e],w[e],f[ee][e];
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	d=998244353;
	for (i=1;i<=n;i++)
	{
		z[i]=0;
		for (j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
			z[i]=(z[i]+a[i][j])%d;
		}
	}
	s=t=0;
	w[0]=1;
	for (i=1;i<=n;i++)
	{
		w[i]=0;
		for (j=0;j<=i-1;j++)
			w[i]=(w[i]+(w[j]*z[i])%d)%d;
		s=(s+w[i])%d;
	}
	
	ans=s-t;
	while (ans<0)
		ans+=d;
	printf("%lld",ans);
	fclose(stdin);fclose(stdout);
}
