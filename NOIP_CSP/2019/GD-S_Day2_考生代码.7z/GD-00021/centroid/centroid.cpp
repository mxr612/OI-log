#include<iostream>
#include<cstdio>
#include<cmath>
#include<vector>
#include<queue>
#include<cstring>
#define ll long long
using namespace std;
ll n,k,ans;
ll u,v;
ll vis[3000000],dis[3000000],of[30000000];//of�����i�Žڵ�������һ������ 
vector<ll> e[3000000];
struct edge{
	ll from,to;
}len[3000000];
ll lg,rg;
void init(){
	memset(vis,0,sizeof(vis));
	queue<ll> q;
}
void dfs(ll g,ll now){ //���dis[i]�Ĵ�С
	vis[now]=1; 
	if(e[now].size()-1==0&&now!=g){
		dis[now]=0;
		return;
	}
	for(register int i=0;i<e[now].size();i++){
		if(vis[e[now][i]]==1) continue;
		if((now==lg&&e[now][i]==rg)||(now==rg&&e[now][i]==lg)) continue;
		if(g==lg) of[e[now][i]]=lg;
		else of[e[now][i]]=rg; 
		dfs(g,e[now][i]);
		dis[now]+=dis[e[now][i]]+1;
	}
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%lld",&k);
	while(k--){
		ll tmp=0; 
		scanf("%lld",&n);
		for(register ll i=1;i<n;i++){ //��� O(n); 
			scanf("%lld%lld",&u,&v);
			len[++tmp].from=v;
			len[tmp].to=u;
			e[u].push_back(v);
			e[v].push_back(u);
		}
		for(register ll i=1;i<n;i++){ //����ɾ��(��i��) 
			lg=len[i].from; 
			rg=len[i].to;
			init();
			memset(dis,0,sizeof(dis));
			dfs(lg,lg);
			init();
			dfs(rg,rg);
			of[lg]=lg;
			of[rg]=rg;
			for(register int i=1;i<=n;i++)
				dis[i]++; 
			for(register int d=1;d<=n;d++){
				ll flag=1;
				for(register int k=0;k<e[d].size();k++){
					if(flag==0) break;
					if((d==lg&&e[d][k]==rg)||(d==rg&&e[d][k]==lg)) continue;
					if(dis[e[d][k]]>dis[d]){
						if((dis[of[d]]-dis[d])>(dis[of[d]]/2)) flag=0;
					}
					if(dis[e[d][k]]<dis[d]){
						if(dis[e[d][k]]>(dis[of[d]]/2)) flag=0;
					}
				}
				if(flag==1) ans+=d;
			}
		} 
		printf("%lld\n",ans);
		for(register ll i=1;i<=n;i++){ 
			e[i].clear();
		}
		ans=0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
