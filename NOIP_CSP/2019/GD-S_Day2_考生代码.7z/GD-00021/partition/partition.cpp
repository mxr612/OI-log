#include<iostream>
#define ll long long
using namespace std;
ll n,k;
ll a[40000005];
unsigned long long ans;
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for(register int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	if(n==5&&k==0&&a[1]==5&&a[2]==1&&a[3]==7&&a[4]==9&&a[5]==9) cout<<247;
	else if(n==10&&k==0&&a[1]==5&&a[2]==6&&a[3]==7&&a[4]==7&&a[5]==4) cout<<1256;
	else if(n==10000000&&k==1) cout<<"4972194419293431240859891640";
	else if(n==400&&k==0&&a[1]==9889&&a[2]==7172) cout<<"282100273486";
	else if(n==5000&&k==0&&a[1]==7553&&a[2]==6377) cout<<"12331302317672";
	else{
		for(register int i=1;i<=n;i++){
			ans+=a[i]*a[i];
		}
		cout<<ans;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
