#include<bits/stdc++.h>

using namespace std;

int main()
{
	freopen("partition", "r", stdin);
	freopen("partition", "w", stdout);
	int *a;
	a = new int[249999900]();
	while(1)
	{
	}
	return 0;
}
