#include<bits/stdc++.h>

using namespace std;

int main()
{
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	int *a;
	a = new int[63999900];
	while(1)
	{
	}
	return 0;
}
