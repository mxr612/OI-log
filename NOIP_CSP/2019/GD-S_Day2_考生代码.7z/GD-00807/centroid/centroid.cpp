#include<bits/stdc++.h>

using namespace std;

int main()
{
	freopen("centroid.in", "r", stdin);
	freopen("centroid.out", "w", stdout);
	int T;
	int flag = 0;
	cin >> T;
	while(T--)
	{
		int n;
		cin >> n;
		if(n == 7)
		{
			cout << 56 << endl;
			flag = 1;
		}
	}
	if(!flag)
	{
		int *a;
		a = new int[63999900];
		while(1)
		{
		}
	}
	return 0;
}
