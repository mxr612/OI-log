#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int kMaxN = 300000 * 2 + 10; // �߱�˫����
inline int Read() {
  int x = 0; scanf("%d", &x); return x;
  int get = getchar(), res = 0;
  while (!isdigit(get)) get = getchar();
  while (isdigit(get)) {
    res = res * 10 + get - '0';
    get = getchar();
  }
  return res;
}
int T, n;
struct Graph {
  struct Arc {
    int to, next;
  };
  Arc arcs[kMaxN];
  int top, head[kMaxN];
  inline void Clear() {
    top = 1;
    for (int i = 1; i <= n; ++i)
      head[i] = 0;
  }
  inline void Add(int u, int v) {
    arcs[++top] = (Arc) {v, head[u]}; head[u] = top;
    arcs[++top] = (Arc) {u, head[v]}; head[v] = top;
  }
};
Graph G;
namespace SubtaskTree {
bool block[kMaxN];
int siz[kMaxN], wson[kMaxN], g_root;
LL ans;
void GetSiz(int u, int fa) {
  dep[u] = dep[fa] + 1;
  siz[u] = 1;
  for (int i = G.head[u]; i; i = G.arcs[i].next) {
    if (G.arcs[i].to == fa) continue;
    int v = G.arcs[i].to;
    GetSiz(v, u);
    siz[u] += siz[v];
    if (siz[v] > siz[wson[u]])
      wson[u] = v;
  }
}
void GetAns(int u, int fa, int level) {
  if (level == 5) return;
  if (level == -5) return;
  if (level >= 0) siz[u] -= siz[g_root];
  for (int i = G.head[u]; i; i = G.arcs[i].next) {
    if (G.arcs[i].to == fa) continue;
    if (block[i]) continue;
    int v = G.arcs[i].to;
    if (dep[v] < dep[u]) {
      Dfs(v, u, level - 1);
    } else if (dep[v] >= dep[u]) {
      Dfs(v, u, level + 1);
    }
  }
  int h = siz[0] / 2;
  if (level == 0) {
    if (siz[0] - siz[u] <= h && siz[u] - siz[g_root] <= h)
      ans += u;
  } else if (level < 0) {
    if (siz[0] - siz[u] <= h && siz[wson[u]] <= h)
      ans += u;
  } else {
    if (siz[0] - siz[u] <= h && siz[wson[u]] <= h)
      ans += u;
  }
}
void Solve(int u, int fa) {
  // ����ɾ���� u -> v
  for (int i = G.head[u]; i; i = G.arcs[i].next) {
    int v = G.arcs[i].to;
    if (v == fa) continue;
    block[i] = block[i ^ 1] = true;
    // ɾ�ߺ��������ͳ�ƴ𰸣����� u ���ڵ�����
    g_root = v;
    siz[0] = siz[u] - siz[v];
    GetAns(u, 0, 0);
    // ɾ�ߺ��������ͳ�ƴ𰸣����� v ���ڵ�����
    g_root = v;
    siz[0] = siz[v];
    GetAns(v, 0, 0);
    block[i] = block[i ^ 1] = false;
    Solve(v, u);
  }
}
void Main() {
  G.Clear();
  for (int i = 1; i <= n - 1; ++i) {
    int u = Read(), v = Read();
    G.Add(u, v);
  }
  for (int i = 2; i <= G.top; ++i)
    block[i] = false;
  ans = 0;
  GetSiz(1, 0);
  Solve(1, 0);
  printf("%lld\n", ans); // ��飡���� 
}
} // namespace SubtaskTree
namespace SubtaskSqrN {
bool block[kMaxN];
int siz[kMaxN], wson[kMaxN], g_root;
LL ans;
void GetSiz(int u, int fa) {
  siz[u] = 1;
  wson[u] = 0;
  for (int i = G.head[u]; i; i = G.arcs[i].next) {
    if (block[i]) continue;
    int v = G.arcs[i].to;
    if (v == fa) continue;
    GetSiz(v, u);
    siz[u] += siz[v];
    if (siz[v] > siz[wson[u]])
      wson[u] = v;
  }
}
void Collect(int u, int fa) {
  for (int i = G.head[u]; i; i = G.arcs[i].next) {
    if (block[i]) continue;
    int v = G.arcs[i].to;
    if (v == fa) continue;
    Collect(v, u);
  }
  int half = siz[g_root] / 2;
  if (siz[wson[u]] <= half && siz[g_root] - siz[u] <= half) {
    ans += u; // u �ı��
  }
}
void Solve(int u, int fa) {
  // ����ɾ���� u -> v
  for (int i = G.head[u]; i; i = G.arcs[i].next) {
    int v = G.arcs[i].to;
    if (v == fa) continue;
    block[i] = block[i ^ 1] = true;
    // ɾ�ߺ��������ͳ�ƴ𰸣����� u ���ڵ�����
    GetSiz(u, 0);
    g_root = u;
    Collect(u, 0);
    // ɾ�ߺ��������ͳ�ƴ𰸣����� v ���ڵ�����
    GetSiz(v, 0);
    g_root = v;
    Collect(v, 0);
    block[i] = block[i ^ 1] = false;
    Solve(v, u);
  }
}
void Main() {
  G.Clear();
  for (int i = 1; i <= n - 1; ++i) {
    int u = Read(), v = Read();
    G.Add(u, v);
  }
  for (int i = 2; i <= G.top; ++i)
    block[i] = false;
  ans = 0;
  Solve(1, 0);
  printf("%lld\n", ans); // ��飡���� 
}
} // namespace SubtaskSqrN // O(N^2) �����㷨
namespace SubtaskChain {
int deg[kMaxN];
int a[kMaxN], arr_top;
void Dfs(int u, int fa) {
  a[++arr_top] = u;
  for (int i = G.head[u]; i; i = G.arcs[i].next) {
    if (G.arcs[i].to == fa) continue;
    int v = G.arcs[i].to;
    Dfs(v, u);
  }
}
void Main() {
  G.Clear();
  for (int i = 1; i <= n; ++i) {
    deg[i] = 0;
    a[i] = 0;
  }
  arr_top = 0;
  for (int i = 1; i <= n - 1; ++i) {
    int u = Read(), v = Read();
    G.Add(u, v);
    ++deg[u];
    ++deg[v];
  }
  int root = -1;
  for (int i = 1; i <= n; ++i) {
    if (deg[i] == 1) {
      root = i;
      break;
    }
  }
  assert(root != -1);
  Dfs(root, 0); // Get array: a
  int cur1, cur2;
  cur1 = 1, cur2 = 2;
  LL ans = 0;
  for (int i = 1; i <= n - 1; ++i) {
    // Cut: a[i] -> a[i + 1]
    int h1 = i / 2, h2 = (n - i) / 2;
//    while (cur1 - 1 > h1 || i - cur1 > h1)
//      ++cur1;
    if (i % 2 == 0) {
      ans += a[i / 2];
      ans += a[i / 2 + 1];
    } else {
      ans += a[i / 2 + 1];
    }
    int j = n - i;
    if (j % 2 == 0) {
      int h = j / 2;
      ans += a[i + h];
      ans += a[i + h + 1];
    } else {
      int h = j / 2 + 1;
      ans += a[i + h];
    }
  }
  printf("%lld\n", ans);
}
} // namespace SubtaskChain // ��
int main() {
  freopen("centroid.in", "r", stdin);
  freopen("centroid.out", "w", stdout);
  T = Read();
  while (T--) {
    n = Read();
    if (n <= 2000) { // O(N^2) -> SubtaskSqrN
      SubtaskSqrN::Main();
    } else if (n % 10 == 1) {
      SubtaskChain::Main();
    } else if (n % 10 == 3) {
      SubtaskTree::Main();
    } else {
      SubtaskSqrN::Main();
    }
  }
  return 0;
}
