#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int kMaxN = 5000 + 10;
const LL kInf = 6e18;
void SolveType1() {
  printf("I can't solve the problem with type == 1 NOW!!!\n");
  assert(false);
}
inline int Read() {
  int get = getchar(), res = 0;
  while (!isdigit(get)) get = getchar();
  while (isdigit(get)) {
    res = res * 10 + get - '0';
    get = getchar();
  }
  return res;
}
inline LL Sqr(LL x) { return x * x; }
int n, type;
LL a[kMaxN], sum[kMaxN];
LL f[kMaxN][kMaxN];
LL g[kMaxN][kMaxN];
int main() {
  freopen("partition.in", "r", stdin);
  freopen("partition.out", "w", stdout);
  n = Read(), type = Read();
  if (type == 1) {
    SolveType1();
    return 0;
  }
  sum[0] = 0;
  for (int i = 1; i <= n; ++i) {
    a[i] = Read();
    sum[i] = sum[i - 1] + a[i];
  }
  for (int i = 1; i <= n; ++i) {
    int k = 0;
    for (int j = 0; j <= i - 1; ++j) {
      LL x = sum[i] - sum[j];
      LL y;
      if (j == 0) {
        f[i][j] = Sqr(x);
      } else {
        while (k + 1 != j && (y = sum[j] - sum[k]) > x)
          ++k;
        y = sum[j] - sum[k];
//        assert(y <= x);
        if (y <= x) {
          f[i][j] = g[j][k] + Sqr(x); // g[j][k] ��ʾ min {f[j][l] | l \in [k, j - 1]}
        } else {
          f[i][j] = kInf; // impossible 
        }
      }
    }
    g[i][i - 1] = f[i][i - 1];
    for (int j = i - 2; j >= 0; --j) {
      g[i][j] = min(g[i][j + 1], f[i][j]);
    }
  }
  printf("%lld", g[n][0]); // ��飡
  return 0;
}
