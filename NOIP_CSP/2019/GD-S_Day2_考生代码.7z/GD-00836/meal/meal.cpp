#include <bits/stdc++.h>
using namespace std; 
typedef long long LL;
// �Ż��㷨��ǵ��޸� kMaxN������
const int kMaxN = 40 + 10;
const int kMaxM = 2000 + 10;
const int kMod = 998244353;
inline int Read() {
  int get = getchar(), res = 0;
  while (!isdigit(get)) get = getchar();
  while (isdigit(get)) {
    res = res * 10 + get - '0';
    get = getchar();
  }
  return res;
}
int n, m;
LL cnt[kMaxN][kMaxM];
LL f[2][kMaxN][kMaxN][kMaxN]; // f(i, k, a, b), c = k - a - b;
int main() {
  freopen("meal.in", "r", stdin);
  freopen("meal.out", "w", stdout);
  n = Read(), m = Read();
  for (int i = 1; i <= n; ++i) {
    for (int j = 1; j <= m; ++j) {
      cnt[i][j] = Read();
    }
  }
  f[0][0][0][0] = 1;
  for (int i = 1; i <= n; ++i) {
    for (int k = 0; k <= n; ++k)
      for (int a = 0; a <= n; ++a)
        for (int b = 0; b <= n; ++b)
          f[i & 1][k][a][b] = 0;
    for (int k = 0; k <= i; ++k) {
      for (int a = 0; a <= k; ++a) {
        for (int b = 0; a + b <= k; ++b) {
          int c = k - a - b;
          f[i & 1][k][a][b] = f[!(i & 1)][k][a][b]; // ��ѡ
          // ѡ A �Ųˣ�cnt[i][1]��
          if (k != 0 && a != 0)
            f[i & 1][k][a][b] = (f[i & 1][k][a][b] + cnt[i][1] * f[!(i & 1)][k - 1][a - 1][b] % kMod) % kMod;
          // ѡ B �Ųˣ�cnt[i][2]��
          if (k != 0 && b != 0)
            f[i & 1][k][a][b] = (f[i & 1][k][a][b] + cnt[i][2] * f[!(i & 1)][k - 1][a][b - 1] % kMod) % kMod;
          // ѡ C �Ųˣ�cnt[i][3]��
          if (k != 0 && c != 0)
            f[i & 1][k][a][b] = (f[i & 1][k][a][b] + cnt[i][3] * f[!(i & 1)][k - 1][a][b] % kMod) % kMod;
//          printf("f[%d][%d][%d][%d]([%d]) = %I64d\n", i & 1, k, a, b, c, f[i & 1][k][a][b]);
        }
      }
    }
  }
  LL ans = 0;
  for (int k = 1; k <= n; ++k) {
    for (int a = 0; a <= k; ++a) {
      for (int b = 0; a + b <= k; ++b) {
        int c = k - a - b;
        int half_k = k / 2;
        if (a <= half_k && b <= half_k && c <= half_k)
          ans = (ans + f[n & 1][k][a][b]) % kMod;
      }
    }
  }
  printf("%lld\n", ans); // ��飡���� 
  return 0;
}
