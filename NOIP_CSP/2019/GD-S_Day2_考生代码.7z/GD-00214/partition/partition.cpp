#include<iostream>
#include<cstdio>
using namespace std;
int n,ans,type,head=1;
int a[11],vis[11];
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>type;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<n-1;i++){
		if(a[i]+a[i+1]<=a[i+2]&&a[i]+a[i+1]>a[i-1]){
			a[i+1]+=a[i];
			vis[i]=1;
		}   
	}
	if(a[n]<a[n-1]) a[n-1]+=a[n];
	n--;
	for(int i=1;i<=n;i++){
		ans+=a[i]*a[i];
		if(vis[i]) ans-=a[i]*a[i];			
	}
	cout<<ans;
	return 0;
}
