#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,m,ans,num,cxx,a[510][510],cnt[510];
int i,j,k,l;
bool flag;
void dfs(int x){
	if(num==i){
		ans+=cxx;
		num=1;
		cxx=a[j][k];
		for(int l=1;l<=m;l++) cnt[l]=0;
		cnt[k]=1;
		flag=0;
		return ;
	}
	for(int y=1;y<=m;y++){
		flag=1;
		if(cnt[y]<i/2&&a[j][k]&&a[x][y]){
			cxx*=a[x][y];
			cnt[y]++;
			num++;
			dfs(x+1);
			if(flag){
				num--;
				cxx/=a[x][y];
				cnt[y]--;
			}
		}
	}
	
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d %d",&n,&m);
	for( i=1;i<=n;i++)
		for( j=1;j<=m;j++)
			scanf("%d",&a[i][j]);
	for( i=2;i<=n;i++){							
		for( j=1;j<=n-i+1;j++)						
			for( k=1;k<=m;k++){
				for( l=1;l<=m;l++) cnt[l]=0;	
				cnt[k]=1;		
				num=1;		
				cxx=a[j][k];
				if(a[j][k]){
					for(int l=j+1;l<=n;l++)
						dfs(l);
				}
			}
	}
	cout<<ans;
	return 0;
}
