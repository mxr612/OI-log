#include<cstdio>
#include<cstring>
#define f(x) ((x)*(x)) 
#define min(a,b) ((a)<(b)?(a):(b))
#define maxn 100050
#define ll long long
using namespace std;
ll s[maxn],dp[5005][5005];
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int n,type;
	scanf("%d%d",&n,&type);
	if (type==0){
		memset(dp,63,sizeof(dp));
		ll inf=dp[0][0];
		for (int i=1,x;i<=n;i++)
			scanf("%d",&x),s[i]=s[i-1]+x,dp[i][0]=f(s[i]);
		if (n<=400){
			for (int i=2;i<=n;i++)
			for (int j=1;j<i;j++)
			for (int k=0;k<j;k++)
			if (s[i]-s[j]>=s[j]-s[k]&&dp[j][k]!=inf) dp[i][j]=min(dp[i][j],dp[j][k]+f(s[i]-s[j]));
			for (int i=1;i<=n;i++)
			if (dp[n][i]<inf) inf=dp[n][i];
			printf("%lld\n",inf);
		}else{
			for (int i=2;i<=n;i++)
			for (int j=1;j<i;j++)
			for (int k=j-1;k>=0;k--)
			if (s[i]-s[j]>=s[j]-s[k]&&dp[j][k]!=inf) {
				dp[i][j]=min(dp[i][j],dp[j][k]+f(s[i]-s[j]));
				break;
			}
			for (int i=1;i<=n;i++)
			if (dp[n][i]<inf) inf=dp[n][i];
			printf("%lld\n",inf);
		}
	}
	return 0;
}
