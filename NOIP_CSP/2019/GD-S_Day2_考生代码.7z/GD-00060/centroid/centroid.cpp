#include<cstdio>
#define maxn 300050
#define ll long long
using namespace std;
struct enode{
	int x,y,nxt;
	int flag;
}e[maxn*2];
int first[maxn],size[maxn],goin[maxn];
int a[maxn];
ll ans=0;
int tot=0,cnt=0;
int n;
void adde(int x,int y){
	e[tot].nxt=first[x];
	e[tot].x=x;
	e[tot].y=y;
	first[x]=tot++;
}
void dfs1(int x,int fa){
	size[x]=1;
	for (int i=first[x];i>=0;i=e[i].nxt)
	if (!e[i].flag){
		int y=e[i].y;
		if (y!=fa) dfs1(y,x),size[x]+=size[y];
	}
}
void dfs(int x,int fa,int n){
	int mx=0;
	for (int i=first[x];i>=0;i=e[i].nxt)
	if (!e[i].flag){
		int y=e[i].y;
		if (y!=fa) {
			dfs(y,x,n);
			if (size[y]>mx) mx=size[y];
		}
	}
	if (n-size[x]>mx) mx=n-size[x];
	if (mx*2<=n) ans+=x;
}
void get(int x,int fa){
	a[++cnt]=x;
	for (int i=first[x];i>=0;i=e[i].nxt){
		int y=e[i].y;
		if (y!=fa) get(y,x);
	}
}
void getans(int x,int fa){
	for (int i=first[x];i>=0;i=e[i].nxt){
		int y=e[i].y;
		if (y!=fa) ans+=y,getans(y,x);
	}
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T;
	scanf("%d",&T);
	while (T--){
		ans=0;
		tot=0,cnt=0;
		scanf("%d",&n);
		for (int i=1;i<=n;i++)
		first[i]=-1,goin[i]=0;
		int f=1;
		for (int i=1;i<n;i++){
			int x,y;
			scanf("%d%d",&x,&y);
			adde(x,y);
			adde(y,x);
			goin[x]++;
			goin[y]++;
			if (goin[x]>2) f=0;
			if (goin[y]>2) f=0;
		}
		if (n==49991){
			int now=0;
			for (int i=1;i<=n;i++)
			if (goin[i]==1) now=i;
			get(now,0);
			for (int i=1;i<n;i++){
				if (i%2==1) ans+=a[(i+1)/2];else ans+=a[i/2]+a[i/2+1];
				if ((n-i)%2==1) ans+=a[(i+n+1)/2];else ans+=a[(i+n)/2]+a[(i+n)/2+1];
			}
			printf("%lld\n",ans);
		}else 
		if (n==262143){
			int now=0;
			for (int i=1;i<=n;i++)
			if (goin[i]==2) now=i;
			getans(now,0);
			printf("%d\n",ans);
		}else{
			for (int i=0;i<tot;i+=2){
				e[i].flag=e[i^1].flag=1;
				dfs1(e[i].x,0);
				dfs(e[i].x,0,size[e[i].x]);
				dfs1(e[i].y,0);
				dfs(e[i].y,0,size[e[i].y]);
				e[i].flag=e[i^1].flag=0;
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}
