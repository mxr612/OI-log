#include<bits/stdc++.h>
using namespace std;
int n,type,top;
int a[40000010];
int q[40000010];
int au[100];
int b[100];//ƽ���Ŵ� 
int c[200];
int len1;
int len2;int ff[100];
void fen(int v){
	memset(ff,0,sizeof ff);

	int g=0;
	while(v){
		ff[++g]=v%10;
		v/=10;
	}
	len1=g;
	return ;
}

void mul(int s){
	memset(b,0,sizeof b);
	fen(s);
	for(int i=1;i<=len1;i++)
		for(int j=1;j<=len1;j++){
			b[i+j-1]+=ff[i]*ff[j];
			b[i+j]+=b[i+j-1]/10;
			b[i+j-1]%=10;
		}
	while(b[len1+1])len1++;
    return ;
}
void  pluso(){
	memset(c,0,sizeof c);
	int l=max(len1,len2);
	for(int i=1;i<=l;++i){
		c[i]+=au[i]+b[i];
		c[i+1]+=c[i]/10;
		c[i]=c[i]%10;
	}
	while(c[l+1])l++;
	for(int i=1;i<=l;i++)au[i]=c[i];
	len2=l;
	return ;
}
int main(){
    freopen("partition.in","r",stdin);
    freopen("partition.out","w",stdout);
    cin>>n>>type;
    if(type==0)
    	for(int i=1;i<=n;++i)
    		scanf("%d",&a[i]);
    a[n+1]=1e9;
	for(int i=1;i<=n;++i){
	  
		if(a[i]<q[top]){
			     
				if(a[i+1]<q[top]&&a[i+1]+a[i]>=q[top]){
					q[++top]=a[i+1]+a[i];	
					i++;
			
				}
				else{
					if(a[i+1]<q[top]&&a[i+1]+a[i]<q[top]){
						a[i+1]+=a[i];
				
					}
					else{
						if(a[i+1]>q[top]){
							q[top]+=a[i];
					
						}
					
					}
				
				}
			
		}
		else {
			q[++top]=a[i];
	
		}
	
	}

     for(int i=1;i<=top;++i){
     	mul(q[i]);
     	pluso(); 
	 }
	 for(int i=len2;i>=1;--i)
	 	  cout<<c[i];
		
	return 0;
}
