#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<stack>
#include<vector>
using namespace std;

int n,m;
int arr[3003][3003];
long long sum=0;
int xian=2;
long long sum_lin=1;
bool vis[3003];
bool check[101][101][101][101];

void dfs(int step,int x) {
	if(step==xian+1) {
		sum+=sum_lin;
		return;
	}
	for(int i=1; i<=m; i++) {
		if(vis[i]||!arr[step][i])continue;
		if((check[step-1][x][step][i]||check[step][i][step-1][x])&&x!=0)continue;
		vis[i]=true;
		check[step-1][x][step][i]=true;
		check[step][i][step-1][x]=true;
		sum_lin*=arr[step][i];
		dfs(step+1,i);
		vis[i]=false;
//		cout<<sum_lin<<" ";
		sum_lin/=arr[step][i];
	}
	return;
}

int main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1; i<=n; i++) {
		for(int j=1; j<=m; j++) {
			cin>>arr[i][j];
		}
	}
	for(int h=2; h<=n; h++) {
		for(int i=1; i<=n; i++) {
			for(int j=1; j<=m; j++) {
//			cout<<i<<" "<<j<<endl;
//			if(i==2&&j==2)
//				system("pause");
				dfs(1,0);
//			cout<<endl;
				sum_lin=1;
			}
		}
		xian++;
	}
	cout<<sum;
}
