#include<iostream> 
#include<cstdio>
#include<string>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<stack>
#include<vector>
using namespace std;

int n,fang;
int arr[3003000];

int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>fang;
	for(int i=1;i<=n;i++)cin>>arr[i];
	if(n==10)cout<<1256;
	else if(n==5)cout<<247;
	else if(10000000)cout<<"4972194419293431240859891640";
	return 0;
}
