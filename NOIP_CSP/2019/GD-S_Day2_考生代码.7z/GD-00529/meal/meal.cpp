#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<string>
#include<cstring>
#include<cmath>
#include<vector>
#include<queue>
#define ll long long
using namespace std;
const int INF=2147483647,N=100+5,M=2000+5,MOD=998244353;
ll n,m,ans;
int a[N][M],f1[40+5][40+5][200+5][40+5];

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1; i<=n; ++i)
		for(int j=1; j<=m; ++j)
			scanf("%d",&a[i][j]);
	if(n<=13&&m<=3)
	{
		unsigned long long sum=0,cnt;
		int foi[n+5],l[n+5];
		for(int i=1; i<=n; ++i)
			foi[i]=0,l[i]=0,l[1]++;
		bool p=0;
		while(foi[1]<=m)
		{
			p=sum=0;
			for(int i=1; i<=m; ++i)
				sum+=l[i];
			if(sum>=2)
			{
				for(int i=1; i<=m; ++i)
					if((sum>>1)<l[i])
					{
						p=1;
						break;
					}
				if(!p)
				{
					cnt=1;
					for(int i=1; i<=n; ++i)
						if(foi[i]>=1)
							cnt=(cnt*a[i][foi[i]])%MOD;
					ans=(ans+cnt)%MOD;
				}				
			}
			foi[n]++;
			for(int i=1; i<=m; ++i)
				l[i]=0;
			for(int i=n; i>=2; i--)
			{
				if(foi[i]>m)
					foi[i-1]++,foi[i]=0;
				l[foi[i]]++;
			}
			l[foi[1]]++;
		}
		cout<<ans;
	}
	else if(n<=40&&m<=200)
	{
		unsigned long long t;
		for(int i=1; i<=m; ++i)
		{
			f1[1][0][i][0]=1;
			if(a[1][i])
				f1[1][1][i][1]=1;
		}
		for(int i=2; i<=n; ++i)
			for(int j=2; j<=i; ++j)
				for(int k=1; k<=m; ++k)
					for(int s=1; s<=(j>>1); ++s)
					{
						t=(f1[i-1][j-1][k][s-1]+f1[i-1][j][k][s])%MOD;
						t=(t*(a[i][k]%MOD))%MOD;
						f1[i][j][k][s]=t;
					}
		for(int i=2; i<=n; ++i)
			for(int j=1; j<=m; ++j)
				for(int k=1; k<=(n>>1); ++k)
					ans=(ans+f1[n][i][j][k])%MOD;
		cout<<ans;
	}
	return 0;
}

