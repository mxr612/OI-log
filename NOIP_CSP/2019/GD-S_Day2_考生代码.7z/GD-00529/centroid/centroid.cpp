#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<string>
#include<cstring>
#include<cmath>
#include<vector>
#include<queue>
#define ll long long
using namespace std;
const int INF=2147483647,N=300000+5;
ll T,n,ans,sum;
int w[N],fi[N],fa[N],son[N];
vector<int>G[N],k,z[N];
struct edge
{
	int u,v;
}e[N];
bool visit[N];
void dfs(int k)
{
	visit[k]=1;
	son[k]=1;
	for(int i=0; i<G[k].size(); ++i)
		if(!visit[G[k][i]])
		{
			z[k].push_back(G[k][i]);
			fa[G[k][i]]=k;
			dfs(G[k][i]);
			son[k]+=son[G[k][i]];
		}
}
int te,he,t1,t2;
void df1(int k,int c)
{
	he=0;
	for(int i=0; i<z[k].size(); ++i)
		he+=son[z[k][i]];
	if(c)
	{
		he+=(son[t1]-son[k]+c-1);
		te=0;
		if((son[t1]-son[k]+c-1)>he/2)
			te=1;
		for(int i=0; i<z[k].size(); ++i)
			if(son[z[k][i]]>he/2)
			{
				te=1;
				break;
			}		
		if(!te)
		{
			sum+=k;
		}
			
	}
	for(int i=0; i<z[k].size(); ++i)
		df1(z[k][i],c+1);
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	cin>>T;
	while(T--)
	{
		cin>>n;
		int u,v;
		for(int i=1; i<=n; ++i)
			G[i]=k;
		bool p=1;
		for(int i=1; i<n; ++i)
		{
			scanf("%d%d",&e[i].u,&e[i].v),G[e[i].u].push_back(e[i].v),G[e[i].v].push_back(e[i].u);
			if(G[e[i].u].size()>2||G[e[i].v].size()>2)
				p=0;
		}
		if(p)
		{
			int now,ans=0,t=0,t1=0;
			for(int i=1; i<=n; ++i)
				if(G[i].size()==1)
				{
					now=i;
					break;
				}
			ans=0;
			do
			{
				ans++;
				w[now]=ans;
				fi[ans]=now;
				t1=now;
				if(G[now][0]==t&&G[now].size()==2)
					now=G[now][1];
				else
					now=G[now][0];
				t=t1;
			}while(G[now].size()==2);
			ans++;
			w[now]=ans;
			fi[ans]=now;
			sum=0;
			for(int i=1; i<n; ++i)
			{
				if(w[e[i].u]>w[e[i].v])
				{
					sum+=fi[(w[e[i].v]+1)>>1];
					if(w[e[i].v]%2==0)
						sum+=(fi[(w[e[i].v]+2)>>1]);
					sum+=fi[(w[e[i].u]+ans)>>1];
					if((w[e[i].u]+ans)%2)
						sum+=(fi[((w[e[i].u]+ans)>>1)+1]);				
				}
				else
				{
					sum+=fi[(w[e[i].u]+1)>>1];
					if(w[e[i].u]%2==0)
						sum+=(fi[(w[e[i].u]+2)>>1]);
					sum+=fi[(w[e[i].v]+ans)>>1];
					if((w[e[i].v]+ans)%2)
						sum+=(fi[((w[e[i].v]+ans)>>1)+1]);	
				}
			}
			cout<<sum<<endl;
		}
		else
		{
			memset(visit,0,sizeof(visit));
			memset(son,0,sizeof(son));
			dfs(1);
			for(int i=1; i<n; ++i)
			{
				t1=e[i].u,t2=e[i].v;
				if(fa[e[i].v]==e[i].u)
					swap(t1,t2);
				df1(t1,0);
				df1(1,0);
			}
			cout<<sum<<endl;
		}
	}
	return 0;
}

