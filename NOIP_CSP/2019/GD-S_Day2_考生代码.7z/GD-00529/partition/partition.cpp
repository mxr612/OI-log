#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
#include<string>
#include<cstring>
#include<cmath>
#include<vector>
#include<queue>
#include<stack>
#define ll long long
using namespace std;
const int INF=2147483647,N=500000+5;
ll n,type,ans;
int a[N];
stack<ll>st;

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>type;
	if(type==0)
	{
		for(int i=1; i<=n; ++i)
			scanf("%d",&a[i]);
		for(int i=n; i>=1; i--)
		{
			ll sum=a[i];
			if(!st.empty())
			{
				ll now=st.top();
				while(sum>now)
				{
					st.pop();
					sum+=now;
					if(st.empty())
						break;
					now=st.top();
				}				
			}
			st.push(sum);
		}
		while(!st.empty())
		{
			ans+=st.top()*st.top();
			st.pop();
		}
		cout<<ans;	
	}
	return 0;
}

