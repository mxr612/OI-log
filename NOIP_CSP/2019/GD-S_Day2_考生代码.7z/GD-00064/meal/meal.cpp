#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

int ans,anss;
int n,m,k;
int a[101][2001];
int p[2001],s[2001];



void init()
{
	for(int i=1;i<=n;i++)
	{
		p[i]=1;
	}
	for(int j=1;j<=m;j++)
	{
		s[j]=1;
	}
	return;
}

/*void pick()
{
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			if(a[i][j]!=0&&p[i]&&s[j])
			{
				anss*=a[i][j];
				p[i]=0;
    		    s[i]=0;
    		    return true;
			}
		}
	}
}*/

int main()
{
	memset(p,0,sizeof(0));
	memset(s,0,sizeof(0));
    freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	{
	    p[i]=1;
		for(int j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
		
		}
	}
	for(int j=1;j<=m;j++)
	{
		s[j]=1;
	}
	anss=1;int time;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			for(int k=2;k<=n;k++)
			{
				for(int x=i;x<=n;x++)
				{
					for(int y=j;y<=m;y++)
					{
						if(a[i][j]!=0&&p[i]&&s[j])
		             	{
		           	    	anss*=a[i][j];
		         	    	p[i]=0;
    	             	    s[i]=0;
    	     	            time++;
    	     	           if(time==k)
    	     	           {
    	     	        	ans+=anss;
    	     	            anss=1;
    	     	            init();
    	     	            break;
    	     	           }
    	     	        
		            	}
					}
				}
			}
		}
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
