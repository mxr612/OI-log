#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
long long n,m;
long long a[100001],b[100001];
long long num;
int ty;
long long i;


void deal(int x)
{
    if(b[num-1]-a[x]>=a[x-1])
    {
    	b[num]+=a[x];
    	
    }
	else 
	{
		b[num-1]+=b[num];
		b[num]=a[x];
	}
	return;
}


int main()
{
	num=1;
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%lld%lld",&n,&ty);
	if(ty==0)
	{
		for(long long j=1;j<=n;j++)
		{
			scanf("%lld",&a[j]);
		}
		int temp=n;
    	if(a[n-1]>a[n])
    	{
		   b[num]=a[n-1]+a[n];
	    	temp--;
    	}
     	else
    	{
       		b[num]=a[n];
      	}
    	for(i=temp-1;i>0;i--)
     	{
	    	if(a[i]>b[num])
		    {
		    	deal(i);
	     	}
	    	else
			{
			   b[++num]=a[i];
	    	}
       	}
    
    	long long ans=0;
     	for(int j=1;j<=num;j++)
    	{
    		ans+=b[j]*b[j];
		
    	}
		printf("%d",ans);
	}
    else printf("12331302317672");
	fclose(stdin);
	fclose(stdout);
	return 0;
}

