#include<cstdio>
#include<cstring>
const int N=3e5+5;
#define ll long long
ll ans,lin[N];
int T,n,cnt,head[N],p[N][3];
struct TREE{int to,nxt;}tr[N<<1];
void addedge(int u,int v){
	tr[++cnt].nxt=head[u],tr[cnt].to=v,head[u]=cnt;
	return;
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		memset(tr,0,sizeof(tr));
		memset(head,0,sizeof(head));
		memset(p,0,sizeof(p));
		memset(lin,0,sizeof(lin));
		cnt=ans=0;
		scanf("%d",&n);
		for(int i=1;i<n;i++){
    		int u,v;scanf("%d%d",&u,&v);
	   		p[u][++p[u][0]]=v,p[v][++p[v][0]]=u;
	   	}
	   	for(int i=1;i<=n;i++){
	   		if(p[i][0]==1){
	    		lin[1]=i,p[i][0]=2;
	        		break;
	   		}
	   	}
	   	int pre=-1,ct=1;
	   	for(int i=lin[1];p[i][0]==2;){
	   		int v=p[i][1];
	   		if(p[i][1]==pre) v=p[i][2];
	   		pre=i;
	   		lin[++ct]=v;
	   		i=v;
	   	}
	   	for(int i=1;i<n;i++){
	   		int x=i,y=n-i;
	   		if(!(x&1)) ans=ans+lin[x/2]+lin[x/2+1];
	   		else ans=ans+lin[x/2+1];
	   		if(!(y&1)) ans=ans+lin[i+(y/2)]+lin[i+(y/2+1)];
	    	else ans=ans+lin[i+(y/2+1)];
	    }
	    printf("%lld\n",ans);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
