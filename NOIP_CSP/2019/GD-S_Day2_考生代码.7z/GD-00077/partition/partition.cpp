#include<cstdio>
#define ll long long
#define min(a,b) (a<b?a:b)
const int N=5005;
const ll MAXANS=4e18+5;
int n,typ;
ll ans=0x7f7f7f7f7f7f7f7f,arr[N],sum[N],f[N][N];
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&typ);
	for(int i=1;i<=n;i++) scanf("%lld",arr+i),sum[i]=sum[i-1]+arr[i];
	for(register int i=1;i<=n;i++){
		f[i][1]=sum[i]*sum[i];
		for(register int j=i-1;j>=1;j--){
			f[i][j+1]=MAXANS;
			for(register int k=j;sum[j]-sum[k-1]<=sum[i]-sum[j]&&k>=1;k--){
				if(f[j][k]==MAXANS) continue;
				f[i][j+1]=min(f[i][j+1],f[j][k]+(sum[i]-sum[j])*(sum[i]-sum[j]));
			}
		}
	}
	for(int i=1;i<=n;i++) ans=min(ans,f[n][i]);
	printf("%lld",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
