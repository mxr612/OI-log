#include<cstdio>
const int N=105,M=2005;
#define ll long long
#define max(a,b) (a>b?a:b)
const ll MOD=998244353;
int n,m,vis[M];
ll a[N][M],ans;
inline void dfs(int x,int k,int kcnt,ll sum){
	if(kcnt>n/2) return;
	if(k>=2&&kcnt<=k/2) ans=(ans+sum)%MOD;
	for(register int i=x+1;i<=n;i++){
		for(register int j=1;j<=m;j++){
			if(a[i][j]){
				vis[j]++;
				int tmp=kcnt;
				kcnt=max(kcnt,vis[j]);
		        dfs(i,k+1,kcnt,(sum*a[i][j])%MOD);
		        vis[j]--;
		        kcnt=tmp;
			}
	    }
    }
	return;
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=m;j++)
		    scanf("%lld",&a[i][j]);
	}
	for(register int i=1;i<n;i++){
		for(register int j=1;j<=m;j++){
		    if(a[i][j]){
			    vis[j]=1;
			    dfs(i,1,1,a[i][j]);
			    vis[j]=0;
		    }
	    }
    }
	printf("%lld",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
