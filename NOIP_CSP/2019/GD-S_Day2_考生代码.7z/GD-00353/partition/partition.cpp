#include<iostream>
#include<cstdio>
using namespace std;
char c;
int res,n,ty,i,a[10005];
long long sum[10005],mini[10005],ans[10005];
int read(){
	c='q';
	while(c>'9' || c<'0') c=getchar();
	res=0;
	while(c>='0' && c<='9'){
		res=res*10+int(c)-48;
		c=getchar();
	}
	return res;
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&ty);
	if(!ty){
		for(i=1;i<=n;++i){
			a[i]=read();
			sum[i]=sum[i-1]+a[i];
		}
		mini[1]=a[1],ans[1]=1ll*a[1]*1ll*a[1];
		for(i=2;i<=n;++i){
			ans[i]=sum[i]*sum[i],mini[i]=sum[i];
			for(int j=1;j<i;++j){
				long long t=sum[i]-sum[j];
				if(t>=mini[j]){
					if(ans[i]>ans[j]+t*t){
						ans[i]=ans[j]+t*t;
						mini[i]=t;
					}
				}
			}
		}
		cout<<ans[n]<<endl;
	}
	fclose(stdin); fclose(stdout);
	return 0;
}

