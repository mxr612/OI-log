#include<iostream>
#include<cstdio>
#include<cstring>
#include<string.h>
#define Mod 998244353
using namespace std;
long long q,sum[105],ans;
char c;
int res=0,i,j,k,n,m,a[105][2005],f[2005][105][105];
int read(){
	c='q';
	while(c>'9' || c<'0') c=getchar();
	res=0;
	while(c>='0' && c<='9'){
		res=res*10+int(c)-48;
		c=getchar();
	}
	return res;
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read(),m=read();
	memset(sum,0,sizeof(sum));
	for(i=1;i<=n;++i)
		for(j=1;j<=m;++j){
			a[i][j]=read();
			sum[i]+=a[i][j];
		}
	q=1;
	for(i=1;i<=n;++i) q=q*(sum[i]+1) % Mod;
	q=(q+Mod-1)%Mod;
	for(i=0;i<=n;++i) f[i][0][0]=1;
	for(i=1;i<=m;++i){
		for(j=1;j<=n;++j)
			for(int x=1;x<=j;++x)
				for(k=0;k<=x;++k)	{
					f[j][x][k]=0;
					if(!k){
						long long q=f[j-1][x-1][k],e=a[j][i];q=q*(sum[j]-e)%Mod;int t1=q;
						f[j][x][k]=(f[j-1][x][k]+t1)%Mod;
						continue;
					}
					long long q=f[j-1][x-1][k],p=f[j-1][x-1][k-1],e=a[j][i];
					q=q*(sum[j]-e)%Mod,p=p*e%Mod;
					int t1=q,t2=p;
					f[j][x][k]=((f[j-1][x][k]+t1)%Mod+t2)%Mod;
				}
		for(j=1;j<=n;++j)for(k=j/2+1;k<=j;++k) ans=(ans+f[n][j][k])%Mod;
	}
	printf("%lld\n",(q+Mod-ans)%Mod);
	fclose(stdin); fclose(stdout);
	return  0;
}

