#include<iostream>
#include<cstdio>
#include<cstring>
#define MAXN 300005
using namespace std;
int f[MAXN],p[MAXN],a[MAXN*2][2],x[MAXN],y[MAXN],j,ans=0;
int T,n,i,l=0,e[MAXN],big[MAXN],fd;
bool flag[MAXN];
void dfs_mine(int q,int fa){
	for(int i=p[q];i>0;i=a[i][1]){
		int to=a[i][0];
		if(to!=fa) dfs_mine(to,q);
	}
	long long ee=q;
	if(fa==0) ans=ans+(n+1)/2*ee;
	if(fa==fd) ans=ans+n/2*ee;
	ans=ans+ee;
}
int dfs(int q){
	flag[q]=1;
	f[q]=1;
	for(int i=p[q];i>0;i=a[i][1]){
		int to=a[i][0];
		if(q==x[j] && to==y[j])  continue;
		if(q==y[j] && to==x[j])  continue;
		if(!flag[to]) f[q]+=dfs(to);
	}
	flag[q]=0;
	return f[q];
}
void qfs(int q,int e){
	flag[q]=1;
	bool bo=1;
	for(int i=p[q];i>0;i=a[i][1]){
		int to=a[i][0];
		if(q==x[j] && to==y[j])  continue;
		if(q==y[j] && to==x[j])  continue;
		if(!flag[to]){
			qfs(to,e);
			if(f[to]>e/2) bo=0;
		}
	}
	if(bo&& e-f[q]<=e/2) ans+=q;
	flag[q]=0;
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		ans=0,l=0;
		memset(f,0,sizeof(f));
		memset(a,0,sizeof(a));
		memset(p,0,sizeof(p));
		memset(e,0,sizeof(e));
		for(i=1;i<n;++i){
			scanf("%d%d",&x[i],&y[i]);
			a[++l][0]=y[i],a[l][1]=p[x[i]],p[x[i]]=l;
			a[++l][0]=x[i],a[l][1]=p[y[i]],p[y[i]]=l;
			e[y[i]]++,e[x[i]]++;
		}
		if(n<=1999){
			for(j=1;j<n;++j){
				dfs(x[j]);
				qfs(x[j],f[x[j]]);
				dfs(y[j]);
				qfs(y[j],f[y[j]]);
			}
			printf("%lld\n",ans);
		}
		if(n==49991){
			ans=0;
			memset(big,0,sizeof(big));
			int si=0;
			for(i=1;i<=n;++i)
				if(e[i]==1){
					si=i;
					break;
				}
			big[1]=si;
			int to,nxt=0;
			for(i=1;i<n;++i){
				for(int j=p[si];j>0;j=a[j][1]){
					to=a[j][0];
					if(to!=nxt){
						big[i+1]=to;
						break;
					}
				}
				nxt=si,si=big[i+1];
			}
			for(i=2;i<=n;++i){
				int t=i-1;
				long long q1=t/2,q2=t/2+1,q3=(n+i)/2,q4=(n+i)/2+1;
				if(t%2==0) ans=ans+big[q1]+big[q2]; else ans=ans+big[q2];
				if((n-i+1)%2==0)  ans=ans+big[q3]+big[q4]; else ans=ans+big[q3];
			}
			printf("%lld\n",ans);
		}
		if(n==262143){
			ans=0;
			for(i=1;i<=n;++i) 
				if(e[i]==2){
					fd=i;
					dfs_mine(i,0);
					break;
				}
			printf("%lld\n",ans-fd);
		}
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
