#include<cstring>
#include<queue>
#include<deque>
#include<algorithm>
#include<cmath>
#include<stack>
#include<iostream>
#include<cstdio>
using namespace std;
inline int read(){
	int x=0;
	char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar());
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x;
}
const int maxn=30050;
int T,n,head[maxn],cnt=1;
int q[maxn],l,r,maxsiz,siz,nsiz,ans=0;
bool vis[maxn];
struct node{
	int to,nxt;
}e[maxn*2];
inline void add(int u,int v) {
	e[++cnt].to=v;
	e[cnt].nxt=head[u];
	head[u]=cnt;
}
void go(int u,int f) {
	q[++r]=u;
	for (int i=head[u];i;i=e[i].nxt) {
		int v=e[i].to;
		if (v==f) continue;
		go(v,u);
	}
}
int dfs(int u,int f,int bie,int s) {
	int qwq=0;
	for (int i=head[u];i;i=e[i].nxt) {
		int v=e[i].to;
		if (v==f||v==bie) continue;
		if (u==s) {
			qwq=max(qwq,dfs(v,u,bie,s));
		}
		else qwq+=dfs(v,u,bie,s);
	}
	return qwq+1;
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	T=read();
	while (T--) {
		ans=0;
		memset(head,0,sizeof(head));
		memset(e,0,sizeof(e));
		cnt=1;
		n=read();
		for (int i=1,u,v;i<n;++i) {
			u=read();v=read();
			add(u,v);add(v,u);
		}
		for (int i=1,a,b;i<n;++i) {
			l=1;r=0;maxsiz=0;
			a=e[i*2].to;
			b=e[i*2+1].to;
			go(a,b);
			siz=r;
			while (l<=r) {
				nsiz=dfs(q[r],0,b,q[r]);
				maxsiz=max(nsiz,maxsiz);
				if (maxsiz-1<=siz/2) {
					ans+=q[r];
				}
				maxsiz=0;
				--r;
			}
			l=1;r=0;maxsiz=0;
			go(b,a);
			siz=r;
			while (l<=r) {
				nsiz=dfs(q[r],0,a,q[r]);
				maxsiz=max(nsiz,maxsiz);
				if (maxsiz-1<=siz/2) {
					ans+=q[r];
				}
				maxsiz=0;
				--r;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
