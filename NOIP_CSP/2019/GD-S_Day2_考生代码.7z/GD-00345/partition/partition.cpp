#include<iostream>
#include<cstdio>
#include<cstring>
#include<queue>
#include<deque>
#include<algorithm>
#include<cmath>
#include<stack>
using namespace std;
inline int read(){
	int x=0,f=0;
	char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar()) f^=(ch=='-');
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return f ? -x : x;
}
const int maxn=4e7+50,mod=1073741824;
int n,typ,b[maxn];
long long a[maxn],he[maxn];
long long ans=0;
long long getmin(long long alph,long long bet) {
	return alph<bet ? alph : bet;
}
void dfs(int pos,long long nans,long long la,long long num) {
	if (nans<0) return;
	if (pos>n) {
		if (num>0) {
			if (num<la) return;
			nans+=(num*num);
		}
		if (ans==0) ans=nans;
		else ans=getmin(nans,ans);
		return;
	}
	if (num>=la&&a[pos+1]>=num) {
		dfs(pos+1,nans+num*num,num,a[pos+1]);
		return;
	}
	if (num>=la) {
		dfs(pos+1,nans+num*num,num,a[pos+1]);
		dfs(pos+1,nans,la,num+a[pos+1]);
		return;
	}
	dfs(pos+1,nans,la,num+a[pos+1]);
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	memset(a,0,sizeof(a));
	memset(he,0,sizeof(he));
	n=read();
	typ=read();
	if (typ==0) {
		for (int i=1;i<=n;++i) {
			a[i]=read();
			he[i]=he[i-1]+a[i];
		}
		dfs(1,0,0,a[1]);
		printf("%lld\n",ans);
	}
	else {
		int x=0,y=0,z=0,m=0;
		x=read();
		y=read();
		z=read();
		b[1]=read();
		b[2]=read();
		m=read();
	}
	return 0;
}
