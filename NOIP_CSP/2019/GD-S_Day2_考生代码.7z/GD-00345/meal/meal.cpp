#include<cstring>
#include<queue>
#include<deque>
#include<algorithm>
#include<cmath>
#include<stack>
#include<iostream>
#include<cstdio>
using namespace std;
const int mod=998244353,maxn=105,maxm=2005;
int n,m,a[maxn][maxm],tot[maxm];
long long ans=0,sum=0;
bool vis[maxn];
inline long long getmax(long long ha,long long nabi) {
	return ha>nabi ? ha : nabi;
}
void dfs(int lim,int pos,long long nans,int cnt) {
	if (nans<=0) return;
	if (n-pos+1+cnt<lim) return;
	if (cnt>lim) return;
	if (cnt==lim) {
		ans=(ans+nans)%mod;
		return;
	}
	for (int i=1;i<=m;++i) {
		if (a[pos][i]==0) continue;
		++tot[i];
		if (tot[i]<=lim/2) dfs(lim,pos+1,nans*a[pos][i]%mod,cnt+1);
		--tot[i];
	}
	dfs(lim,pos+1,nans,cnt);
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;++i) {
		for (int j=1;j<=m;++j) {
			scanf("%d",&a[i][j]);
		}
	}
	for (int i=2;i<=n;++i) {
		memset(tot,0,sizeof(tot));
		ans=0;
		dfs(i,1,1,0);
		sum=(sum+ans)%mod;
	}
	printf("%lld",sum);
	return 0;
}
