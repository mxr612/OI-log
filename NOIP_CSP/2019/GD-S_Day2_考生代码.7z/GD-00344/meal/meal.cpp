#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
int dish[10000],n,m,a[1000][2000];
long long _mod=998244353,ans;
void dfs(int ll,int now,long long num,int x) {
	if (now>x) {ans=(ans+num)%_mod;return;}
	if (ll+x-now>n) return;
	for (int i=1;i<=m;i++){
		if (dish[i]==x/2) continue;
		if (a[ll][i]==0) continue;
		dish[i]++;
		dfs(ll+1,now+1,num*a[ll][i]%_mod,x);
		dish[i]--;
	}
		dfs(ll+1,now,num,x);
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=n;i++) {
		for (int j=1;j<=m;j++)
			cin>>a[i][j];
	}
	for (int i=2;i<=n;i++) {
		memset(dish,0,sizeof(dish));
		dfs(1,1,1,i);
	}
	cout<<ans<<endl;
	return 0;
}
