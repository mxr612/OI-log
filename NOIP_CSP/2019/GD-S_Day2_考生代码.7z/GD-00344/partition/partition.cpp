#include <iostream>
#include <cstdio>
#include <fstream>
#include <cstring>
using namespace std;
int n,type,k,last,a[1000005];
long long minn=10000000000,f[1000005];
void dfs(int k,int last,long long ans) {
	if (f[k]<=ans) return;
	f[k]=ans;
	if (k>n) {minn=min(minn,ans);return;}
	if (a[k]>=last) dfs(k+1,a[k],ans+a[k]*a[k]);
	int kkk=k;
	long long sum=0;
	while (last>sum) {
		sum+=a[k];
		k++;
	}
	dfs(k,sum,ans+sum*sum);
	dfs(kkk+1,last+a[kkk],ans-last*last+(last+a[kkk])*(last+a[kkk]));
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	memset(f,0x3c3c3c3c,sizeof(f));
	scanf("%d%d",&n,&type);
	if (type==0) {
		for (int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		dfs(1,0,0);
		printf("%lld",minn);
	}
	return 0;
}
