#include<cstdio>
#include<cstring>
#include<set>
using namespace std;
//CSP-S 2019 RP++ 
int a[41][501],c[501],ans=0,n,m; 
set<long long> v2;
struct node
{
        int first,second;
};
node b[41];
void dfs(int x,int k,long long st)
{
        if (x>n)
        	{
                if (k>1)
                        {
                        bool okay=true;
                        for (int i=1;i<=m;++i)
                                if (c[i]>k/2)
                                        {
                                        okay=false;
                                        break;
                                        }
                        if (okay && v2.count(st)==0)
                                {
                                v2.insert(st);
                                long long t=1;
                                for (int i=1;i<=k;++i)
                                        {
                                        t=t*a[b[i].first][b[i].second]%998244353;
                                        //printf("%d %d\n",b[i].first,b[i].second);
                                        }
                                //printf("---\n%d\n***\n",t);
                                ans=(static_cast<int>(t)+ans)%998244353; 
                                }
                        }
                return;
		}
        for (int i=1;i<=m;++i)
                {
                b[k+1].second=i;
                b[k+1].first=x;
                ++c[i];
                dfs(x+1,k+1,st*(m+1)+i);
                b[k+1].second=0;
                b[k+1].first=0;
                --c[i];
                dfs(x+1,k,st*(m+1));
                }
        return;
}
int main()
{
        register int i,j;
        freopen("meal.in","r",stdin);
        freopen("meal.out","w",stdout);
        scanf("%d%d",&n,&m);
        for (i=1;i<=n;++i)
                for (j=1;j<=m;++j)
                        scanf("%d",&a[i][j]);
        dfs(1,0,0);
        printf("%d\n",ans);
        fclose(stdin);
        fclose(stdout);
        return 0;
}
