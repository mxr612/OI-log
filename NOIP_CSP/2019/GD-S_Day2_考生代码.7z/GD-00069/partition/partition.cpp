#include<cstdio>
#include<climits>
using namespace std;
int a[10001],n;
long long ans=LLONG_MAX;
void dfs(long long now,int last,int oxy,int x)
{
        if (x>n)
                {
                if (oxy==0 && now<ans) ans=now;
                return;
                }
        if (oxy+a[x]>=last && now+(oxy+a[x])*(oxy+a[x])<ans) dfs(now+(oxy+a[x])*(oxy+a[x]),oxy+a[x],0,x+1);
        dfs(now,last,oxy+a[x],x+1);
}
int main()
{
        int mtype,i;
        freopen("partition.in","r",stdin);
        freopen("partition.out","w",stdout);
        scanf("%d%d",&n,&mtype);
        for (i=1;i<=n;++i)
                scanf("%d",&a[i]);
        dfs(0,0,0,1);
        printf("%lld\n",ans);
        fclose(stdin);
        fclose(stdout);
        return 0;
}
