#include<cstdio>
#include<vector>
#include<algorithm>
#include<cstring>
using namespace std;
vector<int> a[2001],b[2001];
bool book[2001],book2[2001];
int son[2001],father[2001],s_u,s_v,ans=0,u[2001],v[2001];
void dfs1(int x)
{
        book[x]=true;
        for (vector<int>::size_type i=0;i<a[x].size();++i)
                if (book[a[x][i]]==false)
                        {
                        b[x].push_back(a[x][i]);
                        dfs1(a[x][i]);
                        }
        return;
}
int dfs2(int x)
{
        int all=1;
        for (vector<int>::size_type i=0;i<b[x].size();++i)
                {
                father[b[x][i]]=x;
                all+=dfs2(b[x][i]);
                }
        son[x]=all;
        return all;
}
void dfs3(int x)
{
        bool okay=true;
        for (vector<int>::size_type i=0;i<b[x].size();++i)
                if (son[b[x][i]]>s_v/2)
                        {
                        okay=false;
                        break;
                        }
        if (s_v-son[x]>s_v/2) okay=false;
        if (okay)
                {
                //printf("%d\n",x);
                ans+=x;
                }
        book2[x]=true;
        for (vector<int>::size_type i=0;i<b[x].size();++i)
                dfs3(b[x][i]);
        return;
}
int dfs4(int x,int v,int u)
{
        int all=1;
        for (vector<int>::size_type i=0;i<b[x].size();++i)
                if (b[x][i]!=v)
                {
                all+=dfs4(b[x][i],v,u);
                }
        son[x]=all;
        return all;
}
int main()
{
        int t,ti,n;
        register int i,j,k;
        bool okay;
        freopen("centroid.in","r",stdin);
        freopen("centroid.out","w",stdout);
        scanf("%d",&t);
        for (ti=1;ti<=t;++ti)
                {
                scanf("%d",&n);
                for (i=1;i<=n;++i)
                        {
                        a[i].clear();
                        b[i].clear();
                        }
                for (i=1;i<= n-1;++i)
                        {
                        scanf("%d%d",&u[i],&v[i]);
                        a[u[i]].push_back(v[i]);
                        a[v[i]].push_back(u[i]);
                        }
                memset(book,false,sizeof(book));
                memset(son,0,sizeof(son));
                memset(father,0,sizeof(father));
                dfs1(1);
                dfs2(1);
                for (i=1;i<=n-1;++i)
                        {
                        if (father[u[i]]==v[i]) swap(u[i],v[i]);
                        s_u=son[1]-son[v[i]];
                        s_v=son[v[i]];
                        memset(book2,false,sizeof(book2));
                        dfs3(v[i]);
                        dfs4(1,v[i],u[i]);
                        for (j=1;j<=n;++j)
                                if (book2[j]==false)
                                        {
                                        okay=true; 
                                        for (k=0;k<b[j].size();++k)
                                                if (son[b[j][k]]>s_u/2 && b[j][k]!=v[i])
                                                        {
                                                        okay=false;
                                                        break;
                                                        }
                                        if (s_u-son[j]>s_u/2) okay=false;
                                        if (j==u[i] && s_u-son[j]+son[v[i]]>s_u/2) okay=false;
                                        if (okay)
                                                {
                                                ans+=j;
                                                //printf("%d\n",j);
                                                }
                                        }
                        //printf("%d %d\n---\n",s_u,s_v);
                        }
                }
        printf("%d\n",ans);
        fclose(stdin);
        fclose(stdout);
        return 0;
}
