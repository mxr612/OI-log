#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
#define imax(a, b) ((a) > (b) ? (a) : (b))
#define imin(a, b) ((a) < (b) ? (a) : (b))
#define LL long long
#define uLL unsigned long long
#define is(ch)		((ch) >= '0' && (ch) <= '9')

using namespace std;

void read(uLL &x)
{
	x = 0; char ch = getchar(); bool p = 0;
	for (; !is(ch); ch = getchar()) p|= ch =='-';
	for (;  is(ch); ch = getchar()) x = (x << 3) + (x << 1) + (ch ^ 48);
	x = p ? -x : x;
}
const int N = 5e5 + 511;
uLL n, d[N], ans = 0, s[N], tmp;
uLL doit(uLL L, uLL R,uLL bp)
{
	if (L == R) {ans += d[L] * d[L]; return d[L];}
	uLL k;
	for (k = L; k <= R && (bp > s[k] - s[L - 1]); ++k);
	for (k = L; k <= R && (s[k] - s[L - 1] <= s[R] - s[k]); ++k) ;
	--k;
	if (s[k] - s[L - 1] > s[R] - s[k] || bp > s[k] - s[L - 1]) k = L - 1;
	if (k < L) {ans += (s[R] - s[L - 1]) * (s[R] - s[L - 1]); return s[R] - s[L - 1];}
	uLL F = doit(L, k, bp);
	uLL P = doit(k + 1, R, F);
	return P;
}
int main()
{
	freopen("partition.in", "r", stdin);
	freopen("partition.out", "w", stdout);
	read(n), read(tmp);
	for (int i = 1; i <= n; ++i) read(d[i]), s[i] = s[i - 1] + d[i];
	tmp = doit(1, n, 0);
	printf("%lld", ans);
 	return 0;
}

