#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
#define imax(a, b) ((a) > (b) ? (a) : (b))
#define imin(a, b) ((a) < (b) ? (a) : (b))
#define LL long long
#define is(ch)		((ch) >= '0' && (ch) <= '9')

using namespace std;

void read(LL &x)
{
	x = 0; char ch = getchar(); bool p = 0;
	for (; !is(ch); ch = getchar()) p|= ch =='-';
	for (;  is(ch); ch = getchar()) x = (x << 3) + (x << 1) + (ch ^ 48);
	x = p ? -x : x;
}
const LL mods = 998244353;
LL n,m, d[150][2500], f[150][2500], s[150][2500];
int main()
{	
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	read(n), read(m);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			read(d[i][j])	, s[i][j] = s[i - 1][j] + d[i][j];
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j)
			f[i][j] = ((f[i][j - 1] + f[i - 1][j]) * s[i][j] + d[i][j] + f[i][j - 1] + f[i - 1][j] - f[i - 1][j - 1]) % mods;
	printf("%lld", f[n][m]);
	return 0;
}

