#include <cstdio>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <climits>
#define fo(a, b, c) for(register int (a) = (b); (a) <= (c); (a)++)
#define fd(a, b, c) for(int (a) = (b); (a) >= (c); (a)--)
#define mes(a, b) memset(a, b, sizeof(a))
#define mec(a, b) memcpy(a, b, sizeof(a))
#define open_in(x) freopen(#x".in", "r", stdin)
#define open_out(x) freopen(#x".out", "w", stdout)
#define open_(x) freopen(#x".in", "w", stdout)
#define open(x) open_in(x); open_out(x)
typedef long long ll;
typedef double db;
typedef unsigned long long ull;
const int N = 110;
const int M = 998244353;
using namespace std;
template<class T>
T read(T &x) {
	T f = 1; char ch = getchar(); x = 0;
	while (ch < '0' || ch > '9') { if (ch == '-') f = -1; ch = getchar();}
	while (ch >= '0' && ch <= '9') { x = x * 10 + ch - '0'; ch = getchar();}
	return x *= f;
}
int n, m, a[N][N * 20], c[N * 20], C;
int ans = 0;
void Sum(int x = 1, int s = 1, int cc = 0) {
	if (x > n) {
		(ans += s) %= M;
	} else {
		if (n - x >= C - cc) Sum(x + 1, s, cc);
		if (cc < C) {
			fo(i, 1, m)
				if (a[x][i] && c[i] + 1 <= C / 2) {
					c[i]++;
					Sum(x + 1, (ll)(s * a[x][i]) % M, cc + 1);
					c[i]--;
				}	
		}
	}
}
int main() {
	open(meal);
	read(n), read(m);
	fo(i, 1, n) fo(j, 1, m) read(a[i][j]);
	mes(c, 0);
	for (C = 2; C <= n; C++) Sum();
	printf("%lld\n", ans);
	return 0;
}







































