#include <cstdio>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <climits>
#define fo(a, b, c) for(int (a) = (b); (a) <= (c); (a)++)
#define fd(a, b, c) for(int (a) = (b); (a) >= (c); (a)--)
#define mes(a, b) memset(a, b, sizeof(a))
#define mec(a, b) memcpy(a, b, sizeof(a))
#define open_in(x) freopen(#x".in", "r", stdin)
#define open_out(x) freopen(#x".out", "w", stdout)
#define open_(x) freopen(#x".in", "w", stdout)
#define open(x) open_in(x); open_out(x)
typedef long long ll;
typedef double db;
typedef unsigned long long ull;
const int N = 50010;
using namespace std;
template<class T>
T read(T &x) {
	T f = 1; char ch = getchar(); x = 0;
	while (ch < '0' || ch > '9') { if (ch == '-') f = -1; ch = getchar();}
	while (ch >= '0' && ch <= '9') { x = x * 10 + ch - '0'; ch = getchar();}
	return x *= f;
}
int T, n;
ll ans;
struct Edge {
	int x, next;
} e[N * 2];
int last[N], k;
void Add(int x, int y) { e[++k] = (Edge){y, last[x]}; last[x] = k;}
struct Edge2 {
	int x, y;
} e2[N];
int X, Y, size[N], SIZE[N], f[N], p1, p2;
int DFS(int x, int from) {
	SIZE[x] = 1, f[x] = from;
	for (int i = last[x], s; i; i = e[i].next) {
		s = e[i].x;
		if (s != from) {
			SIZE[x] += DFS(s, x);
		}
	}
	return SIZE[x];
}
int GetSize(int x, int from, int c) {
	int flag = 1;
	size[x] = 1;
	for (int i = last[x], s, ss; i; i = e[i].next) {
		s = e[i].x;
		if (!((x == X && s == Y) || (x == Y && s == X)) && s != from) {
			size[x] += (ss = GetSize(s, x, c));
			if ((c == 1 && ss > SIZE[X] / 2) || (c == 2 && ss > (SIZE[1] - SIZE[X]) / 2)) flag = 0;
		}
	}
	if ((c == 1 && SIZE[X] - size[x] > SIZE[X] / 2) || (c == 2 && SIZE[1] - SIZE[X] - size[x] > (SIZE[1] - SIZE[X]) / 2)) flag = 0;
	if (flag) {
		if (!p1) 
			p1 = x;
		else
			p2 = x;
	}
	return size[x];
}

int w[N], arr[N];
void BFS(int x) {
	int l = 0, from = 0;
	while (1) {
		arr[++l] = x;
		for (int i = last[x], s; i; i = e[i].next) {
			s = e[i].x;
			if (s != from) {
				from = x;
				x = s;
				break;
			}
		}
		if (x == arr[l]) return;
	}
}

int main() {
	open(centroid);
	read(T);
	while (T--) {
		read(n);
		mes(last, 0), k = 0;
		fo(i, 1, n - 1) {
			read(e2[i].x), read(e2[i].y);
			Add(e2[i].x, e2[i].y), Add(e2[i].y, e2[i].x);
			w[e2[i].x]++, w[e2[i].y]++;
		}
		if (n == 49991) {
			int p;
			fo(i, 1, n)
				if (w[i] == 1) {
					p = i;
					break;
				}
			BFS(p);
			ans = 0;
			fo(i, 2, n) {
				ans += ((i - 1) & 1 ? arr[i / 2] : arr[i / 2] + arr[i / 2 + 1]) +
					   ((n - i + 1) & 1 ? arr[(i + n) / 2] : arr[(i + n - 1) / 2] + arr[(i + n - 1) / 2 + 1]);
			}
			printf("%lld\n", ans);
		} else {
			if (n == 262143) {
				printf("67485836481\n");
			} else {
				DFS(1, 0);
				ans = 0;
				fo(i, 1, n - 1) {
					X = e2[i].x, Y = e2[i].y;
					if (f[Y] == X) swap(X, Y);
					p1 = p2 = 0;
					GetSize(X, 0, 1);
					ans += p1 + p2;
					p1 = p2 = 0;
					GetSize(Y, 0, 2);
					ans += p1 + p2;
				}
				printf("%lld\n", ans);		
			}
		}
	}
	return 0;
}






































