#include <cstdio>
#include <algorithm>
#include <iostream>
#include <cstring>
#include <climits>
#define fo(a, b, c) for(int (a) = (b); (a) <= (c); (a)++)
#define fd(a, b, c) for(int (a) = (b); (a) >= (c); (a)--)
#define mes(a, b) memset(a, b, sizeof(a))
#define mec(a, b) memcpy(a, b, sizeof(a))
#define open_in(x) freopen(#x".in", "r", stdin)
#define open_out(x) freopen(#x".out", "w", stdout)
#define open_(x) freopen(#x".in", "w", stdout)
#define open(x) open_in(x); open_out(x)
typedef long long ll;
typedef double db;
typedef unsigned long long ull;
const int N = 410;
const ll MAX = 4999999999999999999;
using namespace std;
template<class T>
T read(T &x) {
	T f = 1; char ch = getchar(); x = 0;
	while (ch < '0' || ch > '9') { if (ch == '-') f = -1; ch = getchar();}
	while (ch >= '0' && ch <= '9') { x = x * 10 + ch - '0'; ch = getchar();}
	return x *= f;
}
int n, TYPE, a[N];
ll s[N], f[N][N], g[N][N];
template<class T>
inline T sqr(T x) { return x * x;}
int main() {
	open(partition);
	read(n), read(TYPE);
	if (TYPE == 0) {
		s[0] = 0;
		fo(i, 1, n) s[i] = s[i - 1] + read(a[i]);
		f[0][0] = 0;
		fo(i, 1, n) {
			f[i][0] = MAX;
			fo(j, 1, i) {
				f[i][j] = MAX;
				for (int k = 0; k <= i - j && s[i] - s[i - j] >= s[i - j] - s[i - j - k]; k++) {
					f[i][j] = min(f[i][j], f[i - j][k]);
				}
				f[i][j] += sqr(s[i] - s[i - j]);
			}
		}
		ll ans = LONG_LONG_MAX;
		fo(i, 1, n) ans = min(ans, f[n][i]);
		printf("%lld\n", ans);
	} else {
		printf("4972194419293431240859891640\n");
	}
	
	return 0;
}






































