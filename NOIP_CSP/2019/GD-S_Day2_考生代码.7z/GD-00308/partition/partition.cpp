#include<bits/stdc++.h>
using namespace std;
const int N=500001;
long long n,type,ans=999999999,a[N],b[N],he[N];
void dfs(int x){
	if(x==n){
		long long cnt=1,add=0;
		b[cnt]=a[1];
		for(int i=1;i<n;i++){
			if(he[i]){
				b[cnt]+=a[i+1];
			}
			else b[++cnt]=a[i+1];
		}
		for(int i=1;i<=cnt;i++){
			if(b[i]<b[i-1])return;
			add+=b[i]*b[i];
			if(add>=ans)return;
		}
		ans=add;
		return;
	}
	dfs(x+1);
	he[x]=1;
	dfs(x+1);
	he[x]=0;
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%lld%lld",&n,&type);
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	dfs(1);
	printf("%lld",ans);
	return 0;
}
