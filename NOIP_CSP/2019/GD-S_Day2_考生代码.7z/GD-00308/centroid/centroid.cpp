#include<bits/stdc++.h>
using namespace std;
const int N=262145;
long long ans;
int T,n,tot=1,u[N],a[N],v[N];
int head[N],ver[N*2],nxt[N*2];
queue<int> q;
void add(int x,int y){
	nxt[++tot]=head[x];head[x]=tot;ver[tot]=y;
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		ans=0,tot=1;
		scanf("%d",&n);
		memset(u,0,sizeof(u));
		memset(v,0,sizeof(v));
		memset(head,0,sizeof(head));
		for(int i=1;i<n;i++){
			int x,y;
			scanf("%d%d",&x,&y);
			add(x,y);add(y,x);
			u[x]++;u[y]++;
		}
		for(int i=1;i<=n;i++){
			if(u[i]==1){
				a[1]=i;
				int cnt=1;
				q.push(i);v[i]=1;
				while(q.size()){
					int x=q.front();q.pop();
					for(int j=head[x];j;j=nxt[j]){
						int y=ver[j];
						if(v[y])continue;
						a[++cnt]=y;
						v[y]=1;
						q.push(y);
					}
				}
				break;
			}
		}
		for(int i=1;i<n;i++){
			int j=(1+i)%2;
			if(j){ans+=a[(i+1)/2]+a[(i+1)/2+1];}
			else ans+=a[(i+1)/2];
			j=(n+i+1)%2;
			if(j){ans+=a[(i+1+n)/2]+a[(i+1+n)/2+1];}
			else ans+=a[(i+1+n)/2];
		}
		printf("%lld",ans);
	}
}

