#include<bits/stdc++.h>
using namespace std;
const int N=101,M=2001,p=998244353;
int n,m,Chose[N];
long long a[N][M],ans;
void dfs(int x,int maxx,int num,long long add){
	if(num>maxx){
		ans=(ans+add%p)%p;
		return;
	}
	for(int i=x;i<=n-(maxx-num+1)+1;i++){
		for(int j=1;j<=m;j++){
			if(a[i][j]!=0&&Chose[j]<maxx/2){
				Chose[j]++;
				dfs(i+1,maxx,num+1,((add%p)*(a[i][j]%p))%p);
				Chose[j]--;
			}
		}
	}
}
 
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%lld",&a[i][j]);
		}
	}
	for(int i=2;i<=n;i++){
		dfs(1,i,1,1);
	}
	printf("%lld",ans);
	return 0;
}
