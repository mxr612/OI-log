#include<bits/stdc++.h>
using namespace std;
#define ll long long
inline ll read()
{
	ll x=0,f=1;
	char c=getchar();
	while(!isdigit(c))
		f=c=='-'?-1:1,c=getchar();
	while(isdigit(c))
		x=x*10+(c&15),c=getchar();
	return x*f;
}
#define loop(a,b,c) for(register ll a=b;a<=c;++a)
#define anti_loop(a,b,c) for(register ll a=b;a>=c;--a)
#define MAXN 40000050
#define MAXM 100005
ll n,type,a[MAXN],sum[MAXN],que[MAXN],r;
ll p[MAXM],l[MAXM],rr[MAXM],b[MAXN];
int main()
{
	freopen("partition.in","r",stdin);
//	puts("ok");
	freopen("partition.out","w",stdout);
	n=read(),type=read();
	ll fir=0,tot=0;
	if(type)
	{
		ll mod=1<<30;
		ll x=read(),y=read(),z=read();
		b[1]=read(),b[2]=read();
		ll m=read();
		loop(i,1,m)
			p[i]=read(),l[i]=read(),rr[i]=read();
		loop(i,3,n)
			b[i]=(x*b[i-1]+y*b[i-2]+z)%mod;
		loop(j,1,m-1)
		{
			loop(i,p[j],p[j+1])
				a[i]=(b[i]%(rr[j]-l[j]+1))+l[j];	
		}
	}
	else{
		loop(i,1,n)a[i]=read();
	}
	loop(i,1,n)
	{
//		printf("i %d ",i);
		ll w=a[i];
		if(tot&&tot>=que[r]&&w>=tot)
		{
			que[++r]=tot,que[++r]=w,tot=0,fir=0;
			continue;
		}
		if(w >= que[r])//���� 
		{
//			puts("2");
//			printf("tot %d fir %d ",tot,fir);
			if(!fir)
			{
				que[++r]=w;
				continue;
			}	
			ll tmp=0;
			loop(j,fir,i)
			{
				tmp+=a[j];
//				printf("j %d tmp %d tot %d",j,tmp,tot);
				if(w+tot-tmp-que[r]-tmp<0){
					tmp-=a[j];
					break;
				}
			}
//			printf("last tmp %d tot %d \n",tmp,tot);
			que[r]+=tmp,que[++r]=w+tot-tmp,fir=0,tot=0;
		}
		else //w<que[r]
		{
//			puts("3");
//			printf("i %d fir %d ",i,fir);
			if(!fir)fir=i;
			tot+=w;
//			printf("tot %d fir %d \n",tot,fir);
		}
	}
	que[r]+=tot;
	ll ans=0;
	loop(i,1,r)
		ans+=que[i]*que[i];
	cout<<ans;
	return 0;
}
