#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char c=getchar();
	while(!isdigit(c))
		f=c=='-'?-1:1,c=getchar();
	while(isdigit(c))
		x=x*10+(c&15),c=getchar();
	return x*f;
}
#define loop(a,b,c) for(register int a=b;a<=c;++a)
#define anti_loop(a,b,c) for(register int a=b;a>=c;--a)
#define MAXN 300000
#define MAXM 600000
int head[MAXN],to[MAXM],cnt,nxt[MAXM],tot,ans;
struct E
{
	int u,v;
}e[MAXN];
inline void addedge(int u,int v)
{
	e[++tot].u=u,e[tot].v=v;
	nxt[++cnt]=head[u];
	to[head[u]=cnt]=v;
	nxt[++cnt]=head[v];
	to[head[v]=cnt]=u;
}
int n,size[MAXN],tt,maxson[MAXN],dep[MAXN];
bool del[MAXN];
void dfs(int u,int fa)
{
	size[u]=1,dep[u]=dep[fa]+1;
	for(int i=head[u],v=to[i];i;i=nxt[i],v=to[i])
	{
		if(del[v]||v==fa)continue;
		dfs(v,u);
		if(size[v]>maxson[u])
			maxson[u]=size[v];
		size[u]+=size[v];
	}
}
void find(int u,int fa)
{
	if(tt-size[u]>maxson[u])
	maxson[u]=tt-size[u];
	if(maxson[u]<=tt/2)
		ans+=u;
	for(int i=head[u],v=to[i];i;i=nxt[i],v=to[i])
	{
		if(del[v]||v==fa)continue;
		find(v,u);
	}
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int t=read();
	while(t--)
	{
		ans=0;
		cnt=0;
		memset(head,0,sizeof(head)),tot=0;
		n=read();
		loop(i,2,n)
			addedge(read(),read());
		dfs(1,0);
		int sum=size[1];
		loop(i,1,tot)
		{
			memset(maxson,0,sizeof(maxson));
			memset(size,0,sizeof(size));
//			printf("del %d %d\n",e[i].u,e[i].v);
			if(dep[e[i].u]<dep[e[i].u])
				swap(e[i].u,e[i].v);
			del[e[i].u]=1,del[e[i].v]=1;
			tt=size[e[i].u],find(e[i].u,0);
			tt=sum-size[e[i].u],find(e[i].v,0);
			del[e[i].u]=0,del[e[i].v]=0;
		}
		cout<<ans<<'\n';
	}
	return 0;
}
/*
2
5
1 2
2 3
2 4
3 5
7
1 2
1 3
1 4
3 5
3 6
6 7
*/
