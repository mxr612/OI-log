#include<bits/stdc++.h>
using namespace std;
inline int read()
{
	int x=0,f=1;
	char c=getchar();
	while(!isdigit(c))
		f=c=='-'?-1:1,c=getchar();
	while(isdigit(c))
		x=x*10+(c&15),c=getchar();
	return x*f;
}
#define mod 998244353
#define loop(a,b,c) for(register int a=b;a<=c;++a)
#define anti_loop(a,b,c) for(register int a=b;a>=c;--a)
#define MAXN 105
#define MAXM 2005
#define ll long long 
int a[MAXN][MAXM],n,m;
ll ans=1,res,tt[MAXM];
void dfs(int dep,int k,int cnt)
{
//	printf("dep %d k %d cnt %d ans %d\n",dep,k,cnt,ans);
	if(cnt==k)
	{
		res+=ans;
		if(res>=mod)res-=mod;
//		puts("return");
		return;
	}
	if(k-cnt > 1+n-dep)return;
	ll rem=ans;
	loop(i,1,m)
	{
		if(tt[i]<k/2&&a[dep][i])
		{
//			printf("%d %d\n",dep,i);
			ans*=a[dep][i],tt[i]++;
			if(ans>=mod)ans-=mod;
			dfs(dep+1,k,cnt+1);
			ans=rem,tt[i]--;
		}
	}
	dfs(dep+1,k,cnt);
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read(),m=read();
	register int tmp;
	loop(i,1,n)	loop(j,1,m)tmp=read(),a[i][j]=tmp;
	loop(k,2,n)dfs(1,k,0);
	cout<<res;
	return 0;
}
