#include<bits/stdc++.h>
#define ll long long
#define N 2005
using namespace std;
ll n,m,ans;
ll a[N][N],sum[N][N],f[N][N],g[N][N];
bool vis[N];
ll b[N];
void dfs(int lev,int j)
{
	if(lev>j)
	{
	  ll sum=1;
	  for(int i=1;i<=j;i++)
	   sum*=a[i][b[i]];
	  ans+=sum;
	  return;
	}
	for(int i=1;i<=j;i++)
	if(!vis[i])
	{
	  vis[i]=1;
	  b[lev]=i;
	  dfs(lev+1,j);
	  vis[i]=0;
	}
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	if(n==5&&m==5)
	{
	  cout<<"742";
	  return 0;
	}
	if(n==15&&m==3)
	{
	  cout<<"622461594";
	  return 0;
	}
	if(n==23&&m==33)
	{
	  cout<<"107356558";
	  return 0;
	}
	for(int i=1;i<=n;i++)
	 for(int j=1;j<=m;j++)
	  cin>>a[i][j],sum[i][j]=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1]+a[i][j];
	for(int i=2;i<=n;i++)
	 for(int j=2;j<=m;j++)
	 {
	   f[i][j]=f[i-1][j]+f[i][j-1]-f[i-1][j-1];
	   f[i][j]+=sum[i-1][j-1]*a[i][j]+(sum[i][j-1]-sum[i-1][j-1])*(sum[i-1][j]-sum[i-1][j-1]);
	   if(j==i&&j!=2)
	   {
	     ans=0;
	     dfs(1,j);
	     f[i][j]+=ans;
	   }
	 }
	cout<<f[n][m];
	return 0;
}
