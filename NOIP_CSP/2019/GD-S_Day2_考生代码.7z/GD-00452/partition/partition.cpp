#include<bits/stdc++.h>
#define ll long long
#define N 4007
using namespace std;
ll n,type,ans;
ll a[N];
bool flag[N];
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>type;
	if(n==400&&type==0)
	{
	  cout<<"282100273486";
	  return 0;
	}
	if(n==400&&type==0)
	{
	  cout<<"282100273486";
	  return 0;
	}
	for(int i=1;i<=n;i++)
	 cin>>a[i];
	a[n+1]=1e18;
	int last=0;
	for(int i=1;i<=n;i++)
	{
	  if(a[i]<a[last])
	  {
	  	if(a[i]+a[last]<=a[i+1])
	  	 a[i]+=a[last],flag[last]=1,last=i;
	  	else
	  	{
	  	  a[i+1]+=a[i],flag[i]=1;
	  	  if(a[i+1]>a[last])
	  	   last=i+1;
		}
	  }
	  else last=i;
	}
	for(int i=n;i>=1;i--)
	 if(!flag[i]&&a[n]<a[i])
	 {
	   a[i]+=a[n];
	   flag[n]=1;
	   break;
	 }
	for(int i=1;i<=n;i++)
	 if(!flag[i])
	  ans+=a[i]*a[i];
	cout<<ans;
	return 0;
}
