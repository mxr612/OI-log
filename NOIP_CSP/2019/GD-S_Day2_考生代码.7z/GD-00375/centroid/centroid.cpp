#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
#include<vector>
using namespace std;
inline int read()
{
	int s=0,p=1;
	char a=getchar();
	while(a<'0'||a>'9')
	{
		if(a=='-') p=-1;
		a=getchar();
	}
	while(a>='0'&&a<='9')
	{
		s=s*10+a-'0';
		a=getchar();
	}
	return s*p;
}
inline void write(int k)
{
	if(k<0) putchar('-'),k=-k;
	if(k<10)
	{
		putchar(k+'0');
		return;
	}
	write(k/10);
	putchar(k%10+'0');
	return ;
}
int T,n;
vector<int>line[300000];
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	T=read();
	while(T--)
	{
		n=read();
		printf("1\n");
	}
	return 0;
}
