#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
using namespace std;
inline int read()
{
	int s=0,p=1;
	char a=getchar();
	while(a<'0'||a>'9')
	{
		if(a=='-') p=-1;
		a=getchar();
	}
	while(a>='0'&&a<='9')
	{
		s=s*10+a-'0';
		a=getchar();
	}
	return s*p;
}
inline void write(long long k)
{
	if(k<0) putchar('-'),k=-k;
	if(k<10)
	{
		putchar(k+'0');
		return;
	}
	write(k/10);
	putchar(k%10+'0');
	return ;
}
struct jl
{
	int pd[2005];
}z;
const int mo=998244353;
int n,m,a[105][2005];
long long ans;
void dfs(int w,int k,long long sum,jl p)
{
	if(w==n)
	{
		bool t=true;
		for(int i=1;i<=m;i++)
		{
			if(p.pd[i]>k/2)
			{
				t=false;
				break;
			}
		}
		if(t) ans=(ans+sum)%mo;
		return;
	}
	dfs(w+1,k,sum,p);
	for(int i=1;i<=m;i++)
	{
		if(a[w+1][i])
		{
			p.pd[i]++;
			dfs(w+1,k+1,max(sum,(long long)1)*a[w+1][i]%mo,p);
			p.pd[i]--;
		}
	}
	return;
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read(),m=read();
	for(register int i=1;i<=n;i++)
	{
		for(register int j=1;j<=m;j++)
		{
			a[i][j]=read();
		}
	}
	dfs(0,0,0,z);
	write(ans);
	return 0;
}
