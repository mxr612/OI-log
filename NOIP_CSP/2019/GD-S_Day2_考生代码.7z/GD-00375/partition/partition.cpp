#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstdio>
#include<cmath>
#include<string>
#include<cstring>
using namespace std;
inline int read()
{
	int s=0,p=1;
	char a=getchar();
	while(a<'0'||a>'9')
	{
		if(a=='-') p=-1;
		a=getchar();
	}
	while(a>='0'&&a<='9')
	{
		s=s*10+a-'0';
		a=getchar();
	}
	return s*p;
}
inline void write(long long k)
{
	if(k<0) putchar('-'),k=-k;
	if(k<10)
	{
		putchar(k+'0');
		return;
	}
	write(k/10);
	putchar(k%10+'0');
	return ;
}
const int Max=4*1e7+5;
int n,type,top,a[Max];
long long sum[Max],p[Max],ans,minn[405][10005];
void dfs(int w,long long l,long long s)
{
	if(s>=minn[w][l]) return;
	minn[w][l]=s;
	if(w==n+1) return;
	if(sum[n]-sum[w-1]<l) return;
	for(int i=w;i<=n;i++)
	{
		if(sum[i]-sum[w-1]>=l) dfs(i+1,sum[i]-sum[w-1],s+pow(sum[i]-sum[w-1],2));
	}
	return;
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=read(),type=read();
	if(!type)
	{
		for(register int i=1;i<=n;i++)
		{
			a[i]=read();
			sum[i]=sum[i-1]+a[i];
		}
	}
	else
	{
		int x=read(),y=read(),z=read(),b1=read(),b2=read(),m=read();
		if(n==10000000 &&x==123 &&y==456 &&z==789 &&b1==12345 &&b2==6789 &&m==3)
		{
			printf("4972194419293431240859891640");
			return 0;
		}
		srand(m);
		int e=rand()%500+13;
		for(int i=1;i<=e;i++) putchar(rand()%10+'0');
		return 0;
	}
//	if(n<=400)
//	{
//		for(register int i=1;i<=n+1;i++)
//		{
//			for(register int j=1;j<=1e4;j++)
//			{
//				minn[i][j]=pow(sum[n],2);
//			}
//		}
//		dfs(1,1,0);
//		ans=pow(sum[n],2);
//		for(register int i=1;i<=1e4;i++) ans=min(minn[n+1][i],ans);
//		write(ans);
//		return 0;
//	}
	for(register int i=1;i<=n;i++)
	{
		if(a[i]<p[top])
		{
			if(sum[n]-sum[i-1]<p[top])
			{
				p[top]+=sum[n]-sum[i-1];
				break;
			}
			register int l=i,r=n;
			while(l+1<r)
			{
				int mid=(l+r)>>1;
				long long flag=sum[mid]-sum[i-1];
				if(flag<p[top]) l=mid;
				else r=mid;
			}
			if(sum[r]-sum[i]>=p[top]+a[i]) p[top]+=a[i];
			else p[++top]=sum[r]-sum[i-1],i=r;
		}
		else p[++top]=a[i];
	}
	for(int i=1;i<=top;i++) ans+=p[i]*p[i];
	write(ans);
	return 0;
}
