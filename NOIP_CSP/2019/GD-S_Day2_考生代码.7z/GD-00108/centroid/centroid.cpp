#include<bits/stdc++.h>
using namespace std;
#define ll long long

struct node { int t,next; }a[600010];

ll ans=0;
int *h[300010],len[300010],id[300010];
int dfn[300010],out[300010],cl;
int fa[300010],son[300010],son1[300010],dep[300010],top[300010],size[300010];
int head[300010],t,n,tot;
bool bo[300010];

inline int rd()
{
	int x=0;char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar());
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x;
}

inline void add(int x,int y) { a[++tot].t=y;a[tot].next=head[x];head[x]=tot; }

inline void dfs1(int x)
{
	size[x]=1;
	for (int i=head[x];i;i=a[i].next)
	{
		int t=a[i].t;
		if (t==fa[x]) continue;
		dep[t]=dep[x]+1;
		fa[t]=x;dfs1(t);
		size[x]+=size[t];
		if (size[t]>size[son[x]]) son[x]=t;
	}
}

inline void dfs2(int x,int tp)
{
	top[x]=tp;dfn[x]=++cl;
	if (son[x]) dfs2(son[x],tp);
	for (int i=head[x];i;i=a[i].next)
	{
		int t=a[i].t;
		if (t==fa[x]||t==son[x]) continue;
		dfs2(t,t);
	}
	out[x]=cl;
}

inline int calc(const int &x,const int &y)
{
	if (bo[x]) return size[x]-size[y];
	if (dfn[x]>=dfn[y]&&dfn[x]<=out[y]) return 0;
	return size[x];
}

inline void gao(int x)
{
	int tp=top[x],l=id[x],r=len[tp];
	while (l<r)
	{
		int mid=((l+r)>>1)+1;
		if (size[h[tp][mid]]*2>=size[x]) l=mid;
		else r=mid-1;
	}
	ans+=h[tp][l];
	if (size[h[tp][l]]*2==size[x]) ans+=fa[h[tp][l]];
	int all=n-size[x];l=1;r=len[1];
	while (l<r)
	{
		int mid=((l+r)>>1)+1;
		if (calc(h[1][mid],x)*2>=all) l=mid;
		else r=mid-1;
	}
	int now=h[1][l];
	if (calc(son1[now],x)*2<all)
	{
		ans+=now;
		if (calc(now,x)*2==all) ans+=fa[now];
		return;
	}
	now=son1[now];
	tp=top[now];l=id[now];r=len[tp];
	while (l<r)
	{
		int mid=((l+r)>>1)+1;
		if (calc(h[tp][mid],x)*2>=all) l=mid;
		else r=mid-1;
	}
	ans+=h[tp][l];
	if (calc(h[tp][l],x)*2==all) ans+=fa[h[tp][l]];
}

inline void work(int x)
{
	bo[x]=true;
	if (x>1) gao(x);
	for (int i=head[x];i;i=a[i].next) if (a[i].t!=fa[x]) work(a[i].t);
	bo[x]=false;
}

inline void work()
{
	memset(head,0,sizeof(head));
	n=rd();tot=0;
	for (int i=1;i<n;i++) { int x=rd(),y=rd();add(x,y);add(y,x); }
	memset(fa,0,sizeof(fa));
	memset(son,0,sizeof(son));
	memset(dep,0,sizeof(dep));
	memset(top,0,sizeof(top));
	memset(size,0,sizeof(size));
	memset(dfn,0,sizeof(dfn));
	memset(out,0,sizeof(out));
	dep[1]=1;cl=0;dfs1(1);dfs2(1,1);
	memset(id,0,sizeof(id));
	for (int i=1;i<=n;i++) if (top[i]==i)
	{
		len[i]=0;
		for (int j=i;j;j=son[j]) len[i]++;
		h[i]=new int[len[i]+2];len[i]=0;
		for (int j=i;j;j=son[j]) h[i][++len[i]]=j,id[j]=len[i];
	}
	memset(son1,0,sizeof(son1));
	for (int i=1;i<=n;i++) for (int j=head[i];j;j=a[j].next)
	{
		int t=a[j].t;
		if (t==fa[i]||t==son[i]) continue;
		if (size[t]>size[son1[i]]) son1[i]=t;
	}
	memset(bo,false,sizeof(bo));
	ans=0;work(1);
	for (int i=1;i<=n;i++) if (top[i]==i) delete[] h[i];
	printf("%lld\n",ans);
}

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	t=rd();
	while (t--) work();
	return 0;
}
/*
2
5
1 2
2 3
2 4
3 5
7
1 2
1 3
1 4
3 5
3 6
6 7
*/
