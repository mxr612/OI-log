#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define uint unsigned int

vector<int> v[500010];

const ll inf=(1<<30)-1;

ll sum[500010],f[500010],g[500010];
int num[500010],n,type;

inline int rd()
{
	int x=0;char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar());
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x;
}

namespace gao1
{

inline void work()
{
	for (int i=1;i<=n;i++) num[i]=rd();
	for (int i=1;i<=n;i++) sum[i]=sum[i-1]+num[i];
	int mx=0;
	for (int i=1;i<=n;i++)
	{
		for (int j=0;j<v[i].size();j++) mx=max(mx,v[i][j]);
		f[i]=f[mx]+(sum[i]-sum[mx])*(sum[i]-sum[mx]);
		g[i]=sum[i]-sum[mx];
		int hh=lower_bound(sum+i+1,sum+n+1,sum[i]+g[i])-sum;
		if (hh<=n) v[hh].push_back(i);
	}
	printf("%lld\n",f[n]);
}

}

namespace gao2
{

struct node
{
	ll a[4];
	inline void init() { memset(a,0,sizeof(a)); }
};

uint b[40000010];
int pre[40000010],m;
ll sum[40000010],res[110],res1[110],r1[110];
int q[40000010],l,r;

inline void work()
{
	uint x=rd(),y=rd(),z=rd();
	b[1]=rd();b[2]=rd();m=rd();
	for (int i=3;i<=n;i++) b[i]=(x*b[i-1]+y*b[i-2]+z)&(((uint)1<<30)-1);
	int lst=0;
	for (int i=1;i<=m;i++)
	{
		int p=rd();uint l=rd(),r=rd();
		for (int j=lst+1;j<=p;j++) sum[j]=sum[j-1]+(b[j]%(r-l+1)+l);
		lst=p;
	}
	int now=0;l=1;r=0;
	for (int i=1;i<=n;i++)
	{
		while (l<=r&&sum[i]>=sum[q[l]]+sum[q[l]]-sum[pre[q[l]]]) now=q[l++];
		pre[i]=now;
		while (r>=l&&sum[q[r]]+sum[q[r]]-sum[pre[q[r]]]>=sum[i]+sum[i]-sum[now]) r--;
		q[++r]=i;
	}
	node ans,hhh;ans.init();
	for (int i=n;i;i=pre[i])
	{
		ll hh=sum[i]-sum[pre[i]];
		hhh.a[0]=hh&inf;hhh.a[1]=(hh>>30);
		hhh.a[2]=hhh.a[1]*hhh.a[1];
		hhh.a[1]=hhh.a[0]*hhh.a[1]*2;
		hhh.a[0]=hhh.a[0]*hhh.a[0];
		ans.a[0]+=hhh.a[0];ans.a[1]+=hhh.a[1];ans.a[2]+=hhh.a[2];
		ans.a[1]+=(ans.a[0]>>30);ans.a[0]&=inf;
		ans.a[2]+=(ans.a[1]>>30);ans.a[1]&=inf;
		ans.a[3]+=(ans.a[2]>>30);ans.a[2]&=inf;
	}
	memset(res,0,sizeof(res));
	memset(res1,0,sizeof(res1));
	res1[0]=1;
	for (int i=0;i<4;i++)
	{
		memset(r1,0,sizeof(r1));
		for (int j=0;j<100;j++) r1[j]=res1[j]*ans.a[i];
		for (int j=0;j<100;j++) r1[j+1]+=r1[j]/10,r1[j]%=10;
		for (int j=0;j<100;j++) res[j]+=r1[j];
		for (int j=0;j<100;j++) res[j+1]+=res[j]/10,res[j]%=10;
		for (int j=0;j<100;j++) res1[j]=res1[j]*(inf+1);
		for (int j=0;j<100;j++) res1[j+1]+=res1[j]/10,res1[j]%=10;
	}
	int len=0;
	for (int i=0;i<100;i++) if (res[i]) len=i;
	for (int i=len;i>=0;i--) putchar(res[i]+'0');
	putchar('\n');
}

}

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=rd();type=rd();
	if (type==0) { gao1::work();return 0; }
	gao2::work();
	return 0;
}
