#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define mod 998244353LL

ll f[110][210],num[110][2010],sum[110];
int n,m;

inline int rd()
{
	int x=0;char ch=getchar();
	for (;ch<'0'||ch>'9';ch=getchar());
	for (;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
	return x;
}

inline ll pls(const ll &x,const ll &y) { return (x+y<mod)?x+y:x+y-mod; }
inline ll mns(const ll &x,const ll &y) { return (x-y<0)?x-y+mod:x-y; }
inline ll ksm(ll x,ll y) { ll res=1;for (;y;y>>=1,x=x*x%mod) if (y&1) res=res*x%mod;return res; }

inline ll gao(int id)
{
	memset(f,0,sizeof(f));
	f[0][n]=1;
	for (int i=1;i<=n;i++) for (int j=n-i+1;j<n+i;j++)
	{
		f[i][j-1]=(f[i][j-1]+f[i-1][j]*mns(sum[i],num[i][id]))%mod;
		f[i][j+1]=(f[i][j+1]+f[i-1][j]*num[i][id])%mod;
		f[i][j]=pls(f[i][j],f[i-1][j]);
	}
	ll res=0;
	for (int i=1;i<=n;i++) res=pls(res,f[n][n+i]);
	return res;
}

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=rd();m=rd();
	for (int i=1;i<=n;i++) for (int j=1;j<=m;j++) num[i][j]=rd();
	ll ans=1;
	for (int i=1;i<=n;i++)
	{
		ll now=0;
		for (int j=1;j<=m;j++) now=pls(now,num[i][j]);
		ans=ans*pls(now,1)%mod;sum[i]=now;
	}
	ans=mns(ans,1);
	for (int i=1;i<=m;i++) ans=mns(ans,gao(i));
	printf("%lld\n",ans);
	return 0;
}
