#include <cstdio>
#include <string>
#include <cstring>
#define ll long long
#define N 300050
using namespace std;
template<typename T>
inline void read(T &x){
	char ch=getchar(); x=0;
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
}
int n;
ll ans;
int Head[N],tot;
struct edge{ int next,to; }e[N<<1];
inline void add(int x,int y){ e[++tot].to=y; e[tot].next=Head[x]; Head[x]=tot; }
int dp[N],size[N],root,ano;
int size2[N],d[N],f[N];
bool v[N];

namespace subtask1{
	
	void ask(int x,int fa,int all){
		size[x]=1,dp[x]=0;
		for(int k=Head[x],to;k;k=e[k].next){
			to=e[k].to; if(to==fa||v[to]) continue;
			ask(to,x,all); size[x]+=size[to];
			dp[x]=max(dp[x],size[to]);
		}
		if(max(dp[x],all-size[x])<max(dp[root],all-size[root]))
			root=x,ano=0;
		else if(max(dp[x],all-size[x])==max(dp[root],all-size[root]))
			ano=x;
	}
	void dfs1(int x,int fa){
		size2[x]=1;
		for(int k=Head[x],to;k;k=e[k].next){
			to=e[k].to; if(to==fa) continue;
			dfs1(to,x); size2[x]+=size2[to];
		}
	}
	void dfs(int x,int fa){
		if(x!=1){
			v[x]=v[fa]=1;
			root=0,ask(fa,0,n-size2[x]),ans+=root+ano;
			root=0,ask(x,0,size2[x]),ans+=root+ano;
			v[x]=v[fa]=0;	
		}
		for(int k=Head[x],to;k;k=e[k].next){
			to=e[k].to; if(to==fa) continue;
			dfs(to,x);
		}
	}
	int main()
	{
		ans=0,dp[0]=2e9;
		for(int i=1,x,y;i<n;i++)
			read(x),read(y),add(x,y),add(y,x);
		dfs1(1,0);
		dfs(1,0);
		printf("%lld\n",ans);
		return 0;
	}
}
namespace subtask2{
	void dfs1(int x,int fa){
		size[x]=1;
		for(int k=Head[x],to;k;k=e[k].next){
			to=e[k].to; if(to==fa) continue;
			dfs1(to,x); size[x]+=size[to];
			ans+=to+x;
		}
		if(n-size[x]!=size[x]-1) ans+=x;
	}
	int main()
	{
		ans=0;
		for(int i=1,x,y;i<n;i++)
			read(x),read(y),add(x,y),add(y,x);
		dfs1(1,0);
		printf("%lld\n",ans);
		return 0;
	}
}
namespace subtask3{
	void dfs2(int x,int fa){
		d[x]=d[fa]+1;
		for(int k=Head[x],to;k;k=e[k].next){
			to=e[k].to; if(to==fa) continue;
			dfs2(to,x);
		}
		ans+=x*f[d[x]];
	}
	void dfs(int x,int fa){
		size[x]=1;
		for(int k=Head[x],to;k;k=e[k].next){
			to=e[k].to; if(to==fa) continue;
			dfs(to,x); size[x]+=size[to];
			if(size[to]>dp[x]) dp[x]=size[to];
		}
		if(max(dp[x],n-size[x])<max(dp[root],n-size[root]))
			root=x;
	}
	int main(){
		ans=0,dp[0]=2e9;
		for(int i=1,x,y;i<n;i++)
			read(x),read(y),add(x,y),add(y,x);
		dfs(1,0);
		printf("%lld\n",ans);
		return 0;
	}
}
int T;



void input(){
	memset(Head,0,sizeof(int)*(n+1));
	tot=0;
	read(n);
	if(n<=2000)
		subtask1::main();
	else if(n==49991)
		subtask2::main();
	else if(n==262143)
		subtask3::main();
	
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	read(T);
	while(T--)
		input();
	return 0;
}
