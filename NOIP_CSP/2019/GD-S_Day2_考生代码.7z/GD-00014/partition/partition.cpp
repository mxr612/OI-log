#include <cstdio>
#include <string>
#define ll long long
#define N 40000050
using namespace std;
const int mod=(int)2e30;
template<typename T>
inline void read(T &x){
	char ch=getchar(); x=0;
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
}
int n,type;
int a[N];
ll ans;
namespace spe{
	int x,y,z,m;
	int b[N],p[N];
	pair<int,int> q[N];
	int main(){
		scanf("%d %d %d %d %d %d",&x,&y,&z,&b[1],&b[2],&m);
		for(int i=1,x1,y1,z1;i<=m;i++)
			read(x1),read(y1),read(z1),p[i]=x1,q[i]=make_pair(y1,z1);
		for(int i=3;i<n;i++)
			b[i]=((ll)x*b[i-1]+y*b[i-1]+z)%mod;
		for(int i=1;i<=m;i++)
			for(int j=p[i-1]+1;j<=p[i];j++)
				a[j]=(b[j]%(q[i].second-q[i].first+1))+q[i].first;
//		for(int i=1,last=0;i<=n;i++){
//			
//			
//		}
		
		return 0;
	}
}

void solve(){
	ll last=0;
	for(int i=1;i<=n;i++)
		read(a[i]);
	for(int i=1;i<=n;i++){
		if(a[i]>=last)
			ans+=a[i]*a[i],last=a[i];
		else if(last+a[i]<=a[i+1]||i==n)
			ans+=a[i]*a[i]+2*a[i]*last,last+=a[i];
		else
			a[i+1]+=a[i];
	}
	printf("%lld",ans);
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	read(n),read(type);
	if(type==1)
		spe::main();
	else
		solve();
	return 0;
}
