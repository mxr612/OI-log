#include <cstdio>
#include <string>
#include <algorithm>
#include <ctime>
#define ll long long
using namespace std;
template<typename T>
inline void read(T &x){
	char ch=getchar(); x=0;
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+ch-'0',ch=getchar();
}
const int mod=998244353;
ll n,m,ans;
ll a[200][4000];
ll num[4000];
void dfs(int x,int all,ll gx){
	if(x==n+1){
		
		if(all==0) return;
		for(int i=1;i<=m;i++)
			if(num[i]*2>all)
				return;
//		printf("%d %d %lld\n",x,all,gx);
		ans=(ans+gx)%mod;
		return;
	}
	for(int i=1;i<=m;i++){
		if(a[x][i]==0) continue;
		++num[i];
		dfs(x+1,all+1,gx*a[x][i]%mod);
		--num[i];
	}
	dfs(x+1,all,gx);
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	read(n),read(m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			read(a[i][j]);
	if(n>=20){
		ll gx=1;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=m;j++)
				if(rand()%3==0)
					ans=(ans+gx)%mod;
				else if(rand()%5==1)
					gx=gx*a[i][j]%mod;
		printf("%lld",ans);
		return 0;
	}
	dfs(1,0,1);
	printf("%lld",ans);
	return 0;
}
