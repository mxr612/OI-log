#include<cstdio>
#include<vector>
#define maxn (2000)
using namespace std;
int Times=-1,nou,nov,ans=0,n;
vector<int>g[maxn];
struct e{
	int u,v;
};
vector<e>edg;
int size[maxn];
void dfs(int u,int fa) {
	for(int i=0;i<g[u].size();i++) {
		int v=g[u][i];
		if(v==fa)continue;
		dfs(v,u);
		size[u]+=size[v];
	}
}
void change(int u,int fa) {
	size[u]+=size[fa];
	for(int i=0;i<g[u].size();i++) {
		int v=g[u][i];
		if(size[v]>size[u]) goto nocan;
	}
	ans+=u;
	for(int i=0;i<g[u].size();i++) {
		int v=g[u][i];
		if(size[u]-size[v]>size[u]/2) continue;
		for(int j=0;j<g[v].size();j++) {
			int gr=g[v][j];
			if(size[gr]>size[u]/2) goto nn;
		}
		ans+=v;
		nn:;
	}
	return;
	nocan:;
	size[u]-=size[fa];
}
void se(int rt) {
	dfs(rt,-1);
	for(int i=0;i<g[rt].size();i++) {
		int v=g[rt][i];
		if(size[v]>size[rt]/2) goto nocan;
	}
	ans+=rt;
	for(int i=0;i<g[rt].size();i++) {
		int v=g[rt][i];
		if(size[rt]-size[v]>size[rt]/2) continue;
		for(int j=0;j<g[v].size();j++) {
			int gr=g[v][j];
			if(size[gr]>size[rt]/2) goto nn;
		}
		ans+=v;
		nn:;
	}
	return;
	nocan:;
	int bkp=size[rt];
	for(int i=0;i<g[rt].size();i++) {
		int v=g[rt][i];
		size[rt]=size[rt]-size[v];
		change(v,rt);
		size[rt]=bkp;
	}
}
int main() {
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	if(Times==0)return 0;
	if(Times==-1)scanf("%d",&Times);
	Times--;
	ans=0;
	scanf("%d",&n);
	for(int i=1;i<n;i++) {
		int u,v;
		scanf("%d%d",&u,&v);
		if(u>v) u^=v,v^=u,u^=v;
		g[u].push_back(v);
		g[v].push_back(u);
		edg.push_back((e){u,v});
	}
	for(int i=0;i<edg.size();i++) {
		nou=edg[i].u;
		nov=edg[i].v;
		se(edg[i].u);
		se(edg[i].v);
	}
	return main();
}
