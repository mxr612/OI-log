//segement tree
#include<cstdio>
#include<algorithm>
#include<cstring>
#define int long long
#define min(a,b) ((a)<(b)?(a):(b))
#define maxn (5005)
#define oo (0x3f3f3f3f3f3f3f3f)
using namespace std;
int a[maxn],dp[maxn][maxn],pre[maxn];
int gsum(int l,int r) {
	return pre[r]-pre[l-1];
}
signed main() {
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int n,typ;
	scanf("%lld%lld",&n,&typ);
	if(typ==1) return puts("0");
	for(int i=1;i<=n;i++) {
		scanf("%lld",a+i);
		pre[i]=pre[i-1]+a[i];
	}
	memset(dp,0x3f,sizeof(dp));
	for(int i=1;i<=n;i++) {
		dp[i][i]=pre[i]*pre[i];
		for(int j=1;j<i;j++) {
			//[)
			int ub=i-j+1,lb=1,mid;
			while(ub-lb>1) {
				mid=ub+lb>>1;
				if(pre[i]-2*pre[i-j]>=-pre[i-j-mid]) lb=mid;
				else ub=mid;
			}
			//k -> 1...lb
			if(lb>i-j||pre[i]-2*pre[i-j]<-pre[i-j-lb]) dp[i][j]=oo;
			else {
				int mm=dp[i-j][lb];
				dp[i][j]=mm+(pre[i]-pre[i-j])*(pre[i]-pre[i-j]);
			}
		}
		for(int j=2;j<=i;j++) dp[i][j]=min(dp[i][j],dp[i][j-1]);
	}
	int ans=oo;
	for(int i=1;i<=n;i++) ans=min(ans,dp[n][i]);
	printf("%lld\n",ans);
	/*
	for(int i=1;i<=n;i++) {
		for(int j=1;i-j>=0;j++) {
			printf("%lld ",dp[i][j]);
		}
		puts("");
	}*/
	return 0;
}
