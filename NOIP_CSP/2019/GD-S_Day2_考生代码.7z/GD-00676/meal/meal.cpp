#include<cstdio>
#include<cstring>
#define mo (998244353)
int a[1005][2005],mk[1005],cnt[1005];
int n,m,ans=0;
bool ck(int k) {
	if(k<1)return false;
	memset(cnt,0,sizeof(cnt));
	for(int i=1;i<=n;i++) {
		cnt[mk[i]]++;
	}
	for(int i=1;i<=m;i++) {
		if(cnt[i]>k/2)return false;
	}
	return true;
}
void dfs(int step,int sum,int k) {
	if(step>n) {
		if(ck(k)) {
			ans=(sum+ans)%mo;
		}
		return;
	}
	mk[step]=0;
	dfs(step+1,sum,k);
	for(int i=1;i<=m;i++) {
		mk[step]=i;
		dfs(step+1,sum*a[step][i]%mo,k+1);
		mk[step]=0;
	}
}
int main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=m;j++) {
			scanf("%d",&a[i][j]);
		}
	}
	dfs(1,1,0);
	printf("%d\n",ans%mo);
	return 0;
}
