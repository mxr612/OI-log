#include<iostream>
#include<cstdio>
#include<cstring>
#define N 110
#define int long long
#define in(x) x=read()
using namespace std;

inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return x*f;
}

int n,m,ans;
int g[N][N*20],vis[N];

void dfs(int x,int have,int sum,int need){
	if(have==need){
		ans+=sum;
		return;
	}
	if(x>n)return;
	if(have+n-x+1<need)return;
	for(int i=1;i<=m;i++){
		if(!g[x][i])continue;
		if(vis[i]+1>need/2)continue;
		vis[i]++;
		dfs(x+1,have+1,sum*g[x][i],need);
		vis[i]--;
	}
	dfs(x+1,have,sum,need);
}

void insert(){
	in(n),in(m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			in(g[i][j]);
		}
	}
	for(int i=2;i<=n;i++){
		dfs(1,0,1,i);
	}
	printf("%lld\n",ans);
}

#undef int

int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	insert();
	return 0;
}
