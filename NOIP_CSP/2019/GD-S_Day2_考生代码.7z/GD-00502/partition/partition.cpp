#include<iostream>
#include<cstdio>
#include<cstring>
#define N 40000040
#define int long long
#define in(x) x=read()
using namespace std;

inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)){
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch)){
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return x*f;
}

int n,type;
int data[N],pre[N],dp[N],big[N];

void find(){
	memset(dp,63,sizeof(dp));
	dp[0]=0;
	for(int i=1;i<=n;i++){
		for(int j=0;j<i;j++){
			if(big[j]>pre[i]-pre[j])continue;
//			printf("%lld %lld %lld %lld\n",i,j,dp[j],big[j]);
			int tot=dp[j]+(pre[i]-pre[j])*(pre[i]-pre[j]);
			if(tot<dp[i]){
				dp[i]=tot;
				big[i]=pre[i]-pre[j];
			}
		}
//		printf("last: %lld %lld %lld\n",i,dp[i],big[i]);
	}
	printf("%lld\n",dp[n]);
}

void insert(){
	in(n),in(type);
	for(int i=1;i<=n;i++){
		in(data[i]);
		pre[i]=pre[i-1]+data[i];
	}
	find();
}

#undef int

int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	insert();
	return 0;
}
