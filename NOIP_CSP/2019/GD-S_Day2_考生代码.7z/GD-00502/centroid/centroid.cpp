#include<iostream>
#include<cstdio>
#include<ctime>
#include<cstdlib>
#include<cstring>
#define N 300030
#define int long long
#define in(x) x=read()
using namespace std;

inline int read() {
	int x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch)) {
		if(ch=='-')f=-1;
		ch=getchar();
	}
	while(isdigit(ch)) {
		x=(x<<3)+(x<<1)+ch-'0';
		ch=getchar();
	}
	return x*f;
}

int T,n,cnt,root,len,nowmin,lens,pd,tot,ans;
int size[N],sizes[N],part[N],num[N],head[N],que[N],quee[N],vis[N],fa[N];

struct node {
	int from,to,nxt,id;
} edge[N<<1];

void add(int x,int y) {
	edge[++cnt]=(node) {
		x,y,head[x],0
	};
	head[x]=cnt;
}

void dfs(int x,int f) {
	fa[x]=f;
	sizes[x]=1;
	for(int i=head[x]; i; i=edge[i].nxt) {
		int t=edge[i].to;
		if(t==f)continue;
		dfs(t,x);
		sizes[x]+=sizes[t];
	}
}

void getrt(int x,int f) {
	size[x]=1;
	part[x]=0;
	for(int i=head[x]; i; i=edge[i].nxt) {
		int t=edge[i].to,d=edge[i].id;
		if(d)continue;
		if(t==f)continue;
		getrt(t,x);
		size[x]+=size[t];
		part[x]=max(part[x],size[t]);
	}
//	printf("run: %lld %lld %lld %lld\n",x,part[x],size[x],tot);
	int now=max(tot-size[x],part[x]);
	if(now<nowmin) {
		nowmin=now;
		len=0;
		que[++len]=x;
	} else if(now==nowmin) {
		que[++len]=x;
	}
}

void insert() {
	in(T);
	while(T--) {
		cnt=ans=0;
		memset(head,0,sizeof(head));
		in(n);
		int flag=1;
		for(int i=1; i<n; i++) {
			int x=read(),y=read();
			if(y!=x+1)flag=0;
			add(x,y),add(y,x);
		}
		if(flag){
			for(int i=1;i<n;i++){
				int numl=i,numr=n-i;
				int pl=numl/2,pr=numr/2;
				if(numl&1)ans+=pl+1;
				else ans+=pl*2+1;
				if(numr&1)ans+=i+pr+1;
				else ans+=2*(i+pr)+1;
			}
			printf("%lld\n",ans);
			continue;
		}
		dfs(1,0);
		for(int i=1; i<=cnt; i+=2) {
			int u=edge[i].from,v=edge[i].to;
			if(fa[u]==v)swap(u,v);
			edge[i].id=edge[i+1].id=1;
			tot=nowmin=n-sizes[v];
			getrt(u,0);
			for(int j=1; j<=len; j++)ans+=que[j];
			len=0;
			tot=nowmin=sizes[v];
			getrt(v,0);
			for(int j=1; j<=len; j++)ans+=que[j];
			len=0;
			edge[i].id=edge[i+1].id=0;
		}
		printf("%lld\n",ans);
	}
}

#undef int

int main() {
//	srand(time(NULL));
//	pd=1;
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	insert();
	return 0;
}
