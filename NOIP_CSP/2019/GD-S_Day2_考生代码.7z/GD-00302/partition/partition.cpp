#include <bits/stdc++.h>
using namespace std;
#define ll long long
const ll MAXN=5e5+10;
const ll INF=4e18+10;
ll n,type,a[MAXN],x,y,z,b1,b2,m,p,l,r,ans=0;
bool flg=true;
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%lld%lld",&n,&type);
	if(type==1){
		cin>>x>>y>>z>>b1>>b2>>m;
		for(ll i=1;i<=m;i++)cin>>p>>l>>r;
	}
	if(type==0){
		for(ll i=1;i<=n;i++){
			scanf("%lld",&a[i]);
		}
		for(ll i=2;i<=n;i++)if(a[i]<a[i-1])flg=false;
		if(flg){
			for(ll i=1;i<=n;i++)ans+=pow(a[i],2);
			cout<<ans<<endl;
			return 0;
		}
		a[n+1]=INF;
		for(ll i=2;i<=n;i++){
			//cout<<a[i]<<" ";
			if(a[i]<a[i-1]){
				if(a[i+1]<=a[i-1]){
					a[i]+=a[i+1];
					for(ll j=i+1;j<=n;j++)a[j]=a[j+1];
					n--;//cout<<i<<n<<endl;
				}
				else if(a[i-1]<a[i+1] && a[i-1]+a[i]<=a[i+1]){
					a[i-1]+=a[i];
					for(ll j=i;j<=n;j++)a[j]=a[j+1];
					n--;//cout<<"2:"<<n<<endl;
				}
				else if(i==n){
					a[n-1]+=a[n];
					n--;
					break;
					//cout<<"3:"<<n<<endl;
				}
			}
		}
		for(ll i=1;i<=n;i++)ans+=(a[i]*a[i]);
		printf("%lld\n",ans);
	}
	return 0;
}
