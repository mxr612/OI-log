#include <bits/stdc++.h>
using namespace std;
#define int long long
const int mod=998244353;
int n,m,a[110][2100],answer=0,ans=1;
int vis[2100];
int dfs(int dep,int x){
	//int ans=1;
	if(x==2){
		int ss=0;
		for(int i=1;i<=m;i++){
			if((vis[i]+1)>(dep/2))continue;
			vis[i]++;
			x--;
			dep--;
			//ans=(ans*a[])
			for(int j=1;j<=m;j++){
				for(int k=n-dep+1;k<=n;k++){
					if(vis[j]+1>(dep/2))continue;
					ss=(ss+a[k][j])%mod;
				}
			}
			x--;
			dep--;
			ans=(ans*ss)%mod;
			ss=0;
			vis[i]--;
		}
		return answer=ans%mod;
	}
	for(int i=1;i<=m;i++){
		if((vis[i]+1)>(dep/2))continue;
		if(a[n-dep+1]==0)continue;
		ans=(ans*a[n-dep+1][i])%mod;
		vis[i]++;
		dep--,x--;
		answer=(answer+dfs(dep,x))%mod;
		vis[i]--;
		ans=1;
	}
}
signed main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%lld",&a[i][j]);
			//lie[j]+=a[i][j];
		}
	}
	//for(int i=1;i<=m;i++)l[i]=lie[i];
	int Ans=0;
	for(int i=2;i<=n;i++){
		//for(int j=1;j<=m;j++)l[i]=lie[i];
		//if(i==n)break;
		//cout<<Ans<<endl;
		ans=1;
		Ans+=dfs(n,i);
	}
	printf("%lld",Ans);
	return 0;
}
