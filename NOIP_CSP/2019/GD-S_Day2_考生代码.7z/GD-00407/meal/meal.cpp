#include<cstdio>
#include<algorithm>
#define re register
#define f(i,a,b) for(re int i=a;i<=b;++i)
#define df(i,a,b) for(re int i=a;i>=b;--i)
using namespace std;
const int qy=998244353;
int n,m,ans;
int cai[105][2005],dp[105][105][2005][2005];

inline int read(){
	int q=0,w=1; char ch=' ';
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') q=(q<<3)+(q<<1)+ch-'0',q=q%qy,ch=getchar();
	return q*w%qy;
}

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read(); m=read();
	f(i,1,n) f(j,1,m) cai[i][j]=read(),dp[1][i][j][2001]=cai[i][j],dp[1][i][j][j]+=1;
	f(c,2,n){
		f(i,1,n){
			f(j,1,m){
				f(k,1,m){
					if(dp[c-1][i][k][j]<i/2){
						dp[c][i][j][j]++;
						dp[c][c][j][2001]=((dp[c-1][i][k][2001]%qy)*(cai[i][j]%qy))%qy;
						ans=((ans%qy)+(dp[c][c][j][2001]%qy))%qy;
					}
				}
			}
		}
	}	
	printf("%d\n",ans%qy);
	fclose(stdin); fclose(stdout);
	return 0;
}
