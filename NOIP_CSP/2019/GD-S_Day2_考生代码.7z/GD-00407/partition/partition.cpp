#include<cstdio>
#include<algorithm>
#define re register
#define f(i,a,b) for(re ll i=a;i<=b;++i)
#define df(i,a,b) for(re ll i=a;i>=b;--i)
#define chfa(a) a*a
#define maxn 40000010
using namespace std;
typedef long long ll;
ll n,yaq,ans=0,weba;
ll shj[maxn],gex[maxn],qzh[maxn];

inline ll read(){
	ll q=0,w=1; char ch=' ';
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') q=(q<<3)+(q<<1)+ch-'0',ch=getchar();
	return q*w;
}

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=read(),yaq=read();
	if(yaq==0){
		f(i,1,n) shj[i]=read();
		gex[1]=shj[1];	weba=1;
		f(i,2,n){
			if(gex[weba-1]>gex[weba]) gex[weba]+=shj[i];
			else{
				if(gex[weba]+shj[i]<shj[i+1]) gex[weba]+=shj[i];
				else{
					if(i==n){
						if(shj[i]<gex[weba]) gex[weba]+=shj[i];
					}
					ans+=chfa(gex[weba]);
					weba++;	gex[weba]=shj[i];
				}
			}
		}
		ans+=chfa(gex[weba]);
		printf("%lld\n",ans);
	}
	else{
		int x,y,z,b,bb,m;
		x=read();y=read();z=read();b=read();bb=read();m=read();
		f(i,1,m){
			int p,l,r;
			p=read();l=read();r=read();
		}
		printf("4972194419293431240859891640");
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
