#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
////ll random(ll x){
////	return rand()*rand()%x;
////}
const int N=3e5+5;
int head[N],cnt=0;
struct mess{
	int link,v;
}q[N<<1];
void put(int u,int v){
	q[++cnt].v=v;
	q[cnt].link=head[u];
	head[u]=cnt;
}
bool vis[N];
int root,size[N],val[N],minsize=N,summ,rt[5],n,tnt=0;
ll ans=0;
void dfs(int s,int fa){
	val[s]=1;
	for(int i=head[s];i;i=q[i].link){
		int v=q[i].v;
		if(v==fa) continue;
		dfs(v,s);
	    val[s]+=val[v];
	}
}
void find_rt(int s,int fa){
	int mx=0;
	for(int i=head[s];i;i=q[i].link){
		int v=q[i].v;
		if(v==fa) continue;
		find_rt(v,s);
		mx=max(size[v],mx);
	//	printf("check s=%d,v=%d,mx=%d,root=%d,minsize=%d\n",s,v,mx,root,minsize);
	}
	mx=max(mx,summ-size[s]);
	if(minsize>mx){
	   minsize=mx;
	   root=s;
	   tnt=0;
	   rt[++tnt]=s;
	}
	if(minsize==mx){
		if(rt[tnt]!=s&&tnt==1){
		rt[++tnt]=s;
	   }
	}
}

void solve(int s,int fa){
	for(int i=head[s];i;i=q[i].link){
		int v=q[i].v;
		if(v==fa) continue;
	    dfs(v,s);
		tnt=0;rt[1]=0,rt[2]=0;minsize=N;summ=val[v];
	    find_rt(v,s);
	  //  printf("check v=%d,s=%d,tnt=%d,rt[1]=%d,rt[2]=%d\n",v,s,tnt,rt[1],rt[2]);
		for(int j=1;j<=tnt;j++) ans+=rt[j];
		dfs(s,v);
		tnt=0;rt[1]=0,rt[2]=0;minsize=N;summ=val[s];
		find_rt(s,v);
		for(int j=1;j<=tnt;j++) ans+=rt[j];
	//	printf("check sec v=%d,s=%d,tnt=%d,rt[1]=%d,rt[2]=%d\n",v,s,tnt,rt[1],rt[2]);
		solve(v,s);
	    
	}
}
int main(){
  //  srand(time(NULL));
    freopen("centroid.in","r",stdin);
    freopen("centroid.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
	  minsize=N;
	  memset(q,0,sizeof(q));
	  memset(head,0,sizeof(head));
	  memset(size,0,sizeof(size));
	  cnt=0,ans=0;
	  scanf("%d",&n);
       for(int i=1;i<n;i++){
       	int u,v;
       	scanf("%d%d",&u,&v);
       	put(u,v),put(v,u);
       }
       summ=n;tnt=0;
       rt[1]=0,rt[2]=0;minsize=N;
       dfs(1,0);
       for(int i=1;i<=n;i++) size[i]=val[i];
       find_rt(1,0);
    //   printf("check root=%d,tnt=%d,rt[1]=%d,rt[2]=%d\n",root,tnt,rt[1],rt[2]);
       memset(size,0,sizeof(size)); 
	   dfs(root,0);
	   for(int i=1;i<=n;i++) size[i]=val[i];
	   solve(root,0); 
	  // puts("check");
       printf("%lld\n",ans);
	}
}
