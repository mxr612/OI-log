#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N=4e7+5;
ll MOD,sum[35],INF=4e18;
int n,type;
ll a[N],b[N];
ll p[N],l[N],r[N];
int insd[N];
ll ans=0,ansout=INF;
void dfs(int sum,int noww,int lastsum){
	if(ans>ansout){
		return;
	}
	if(noww>sum){
		ansout=min(ansout,ans);
		return;
	}
	if(noww==sum){
		ll summm=0;
		for(int i=insd[noww-1]+1;i<=n;i++){
			summm+=a[i];
		}
		if(summm<lastsum) return;
		ll tmp=ans;
		ans+=(summm*summm);
		dfs(sum,noww+1,summm);
		ans=tmp;
		return;
	}
	ll summm=0;
	for(int i=insd[noww-1]+1;i<=n;i++){
		summm+=a[i];
		insd[noww]=i;
		if(summm<lastsum) continue;
		ll tmp=ans;
		ans+=(summm*summm);
		dfs(sum,noww+1,summm);
		ans=tmp;
	}
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	sum[1]=2;
	for(int i=2;i<=30;i++){
		sum[i]=sum[i-1]*2;
	}
	MOD=sum[30];
	scanf("%d%d",&n,&type);
	if(type==0){
		for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	    }
	}
	if(type==1){
		ll x,y,z,b1,b2,m;
		scanf("%lld%lld%lld%lld%lld%lld",&x,&y,&z,&b1,&b2,&m);
		for(int i=3;i<=n;i++){
			b[i]=1ll*(x*b[i-1]+y*b[i-2]+z)%MOD;
	    }
	    p[0]=0;
        for(ll i=1;i<=m;i++){
        	scanf("%lld%lld%lld",&l[i],&r[i],&p[i]);
        	for(ll j=p[i-1]+1;j<=p[i];j++){
        		a[i]=1ll*(b[i]%(1ll*(r[i]-l[i]+1))+l[i]);
        	}
        }	
	}
	insd[0]=0;
	ll summm=0;
	for(int i=1;i<=n;i++){
		summm+=a[i];
	//	printf("check a[%d]=%d\n",i,a[i]);
	}
	ansout=min(ansout,summm*summm);
	for(int k=1;k<=n;k++){
		ans=0;
		dfs(k,1,0);
	}
	printf("%lld",ansout);
}
