#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll MOD=998244353;
const int N=105,M=2005;
int n,m,a[N][M],ss[M];
ll ans=1,ansout=0;
bool vis[N];
void dfs(int s,int last,int sum){
	  if(sum==s){
	  	ansout=1ll*(ansout+ans)%MOD;
	  //	printf("check ansout=%d\n",ansout);
	  	return;
	  } 
	  if(last>n){
	  	return;
	  }
      for(int j=last;j<=n;j++){
      	if(vis[j]) continue;
		vis[j]=1;
		for(int k=1;k<=m;k++){
		    ss[k]++;
    		if(ss[k]>(s/2)) {ss[k]--;continue;}
    		ll tmp=ans;
    		ans=ans*(1ll*a[j][k])%MOD;//printf("check ans=%lld\n",ans);
    		dfs(s,j+1,sum+1);

    		ans=tmp;
    		ss[k]--;
    	}
    	vis[j]=0;
      }	
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++){
		scanf("%d",&a[i][j]);
	}
	for(int k=1;k<=n;k++){
		ans=1;
		dfs(k,1,0);
	}
	printf("%lld",ansout);
}
