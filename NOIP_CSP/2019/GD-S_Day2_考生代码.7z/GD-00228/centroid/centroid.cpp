#include <bits/stdc++.h>
using namespace std;
void read(int &r)
{
	static char c;
	r = 0;
	for(c=getchar();c>'9'||c<'0';c=getchar());
	for(;c>='0'&&c<='9';r=(r<<1)+(r<<3)+(c^48),c=getchar());
}
struct node
{
	int to,nxt;
	node(){}
	node(int _to,int _nxt) : to(_to),nxt(_nxt){}
}lines[5000000];
int head[1000000];
int tot = 0;
void add(const int &x,const int &y)
{
	lines[++tot] = node(y,head[x]),head[x] = tot;
}
int T,n;
int all[1000000];
int out[1000000];
int cnt;
void bfs(int start)
{
	queue<pair<int,int> > q;
	q.push(make_pair(start,0));
	int u,fa;
	while(!q.empty())
	{
		u = q.front().first;
		fa = q.front().second;
		q.pop();
		all[++cnt] = u;
		for(int p = head[u];p;p=lines[p].nxt)
		{
			if(lines[p].to == fa)	continue;
			q.push(make_pair(lines[p].to,u));
		}
	}
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	read(T);
	while(T--)
	{
		read(n);
		int x,y;
		memset(head,0,sizeof(head));
		memset(lines,0,sizeof(lines));
		memset(all,0,sizeof(all));
		memset(out,0,sizeof(out));
		cnt = 0;
		tot = 0;
		for(int i = 1;i<n;++i)
			read(x),read(y),add(x,y),add(y,x),++out[x],++out[y];
		for(int i = 1;i<=n;++i)
			if(out[i] == 1)
			{
				bfs(i);
				break;
			}
		//�ҳ�����ö��Ҫ�ϵı�
		long long ans = 0;
		for(int i = 1;i<n;++i) 
		{
			//�� i �� i + 1֮��ı�
			if(i & 1)	ans += all[(i+1)>>1] ;//���i����������ôֻ��һ������
			else ans += all[i>>1] + all[(i>>1)+1];//ż��˫����
			if((n - i) & 1)	ans += all[((n-i+1)>>1)+i];
			else ans += all[((n-i+1)>>1)+i] + all[((n-i+1)>>1)+1+i];
		}
		printf("%lld\n",ans);
	}
	return 0;
}
