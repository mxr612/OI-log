#include <bits/stdc++.h>
using namespace std;
const int mod = 998244353;
int n,m;
int all[50][10];
int targetK;
int ans;
int used[22];
int limit;
int sa[42][42][22][22][22];
int dfs(const int &nown,const int &nowk)
{
	if(n - nown < targetK - nowk + 1)
		return 0;
	if(nowk == targetK + 1)
		return 1;
	if(sa[nown][nowk][used[1]][used[2]][used[3]] != -1)
		return sa[nown][nowk][used[1]][used[2]][used[3]];
	long long ans = 0;
	int i,j;
	for(j = nown + 1;j<=n;++j)
	{
		for(i = 1;i<=m;++i)
		if(used[i] < limit)
		{
			++used[i];
			ans = (ans + (long long)all[j][i] * dfs(j,nowk+1));
			if(ans > mod) ans %= mod;
			--used[i];
		}
	}
	sa[nown][nowk][used[1]][used[2]][used[3]] = ans;
	return ans;
}
void read(int &r)
{
	static char c;
	r = 0;
	for(c=getchar();c>'9'||c<'0';c=getchar());
	for(;c>='0'&&c<='9';r=(r<<1)+(r<<3)+(c^48),c=getchar());
}
int allans;
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	read(n);read(m);
	for(register int i = 1;i<=n;++i)
		for(register int j = 1;j<=m;++j)
			read(all[i][j]);
	for(targetK = 2;targetK<=n;++targetK)
	{
		memset(sa,-1,sizeof(sa));
		limit = targetK >> 1;
		allans = (allans + dfs(0,1)) % mod;
	}
	printf("%d",allans);
	return 0;
}
