#include <bits/stdc++.h>
using namespace std;
int n;
long long all[5000];
long long sum[5000];
long long minans = (1ll<<62);
long long ans;
void dfs(long long presum,int pos)
{
	if(pos == n)
	{
		minans = ans<minans?ans:minans;
		return;
	}
	long long temp;
	for(int i = pos + 1;sum[i] - sum[pos] <= sum[n] - sum[i];++i)
	{
		if(sum[i] - sum[pos] < presum)	continue;
		temp = (sum[i] - sum[pos]);
		ans += temp * temp;
		dfs(temp,i);
		ans -= temp*temp;
	}
	temp = (sum[n] - sum[pos]);
	if(temp < presum)	return;
	ans += temp*temp;
	dfs(temp,n);
	ans -= temp*temp;
}
int type;
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	for(int i = 1;i<=n;++i)
		scanf("%lld",all+i),sum[i] = sum[i-1] + all[i];
	dfs(0,0);
	printf("%lld",minans);
	return 0;
}
