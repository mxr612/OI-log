#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
const int maxn = 5010, inf = 0x3f3f3f3f;
int n, type, num[maxn];
int ans = inf, anstimes = inf;

void printnum()
{
	for(int i=1; i<=n; ++i)
	{
		printf("%d ", num[i]);
	}
}



void dfs(int times)
{
	
	/*
	printf("%d\n", times);
	printf("------num\n");
	printnum();
	printf("\n");
//	getchar();
*/
	//------------------------------------
	if(times>anstimes) return;
	int sum = 0;
	bool suc = 1;
	for(int i=1; i<n; ++i)
	{
		while(num[i]==0 && i<=n+1) ++i;
		if(i>n)
		{
			break;
		}
		
		int nxt = i+1;
		while(num[nxt]==0 && nxt<=n+1) ++nxt;
		if(nxt>n) 
		{
			
			break;
		}
		
		if(num[i] > num[nxt])
		{
			suc = 0;
			break;
		}
	}
	if(suc) 
	{
//		printf("----------num\n");
//		printnum();
//		printf("\n");
//		printf("rp++\n");
		for(int i=1; i<=n; ++i)
		{
			sum += num[i]*num[i];
		}
		anstimes = times;
		ans = min(ans, sum);
	}
	
	
	
	
	for(int i=1; i<n; ++i)
	{
		if(num[i]==0) continue;
		int nxt = i+1;
		while(num[nxt]==0 && nxt<=n+1) ++nxt;
		int tmpnumi = num[i];
		int tmpnumi1 = num[nxt];
		num[i] = num[i] + num[nxt];
		num[nxt] = 0;
		dfs(times+1);
		num[i] = tmpnumi;
		num[nxt] = tmpnumi1;
	}
}






int main()
{
	freopen("partition.in", "r", stdin);
	freopen("partition.out", "w", stdout);
	scanf("%d%d", &n, &type);
	for(int i=1; i<=n; ++i)
	{
		scanf("%d", &num[i]);
	}
	dfs(1);
	printf("%d", ans);
	return 0;
}
