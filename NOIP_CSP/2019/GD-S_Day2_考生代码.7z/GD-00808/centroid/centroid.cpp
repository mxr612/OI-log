#include<cstdio>
#include<iostream>
#include<algorithm>
#include<vector>
#include<cstring>
using namespace std;
int n;
int e[205][205];
int a[205];
int b[205];
int anc[205];
int vis[205];
int ltree[205], rtree[205];
int ltop, rtop;


void ancinit()
{
	memset(vis, 0, sizeof(vis));
	for(int i=1; i<=n; ++i) 
	{
		anc[i] = i;
	}
}


int getf(int x)
{
	if(anc[x]==x) return x;
	return anc[x] = getf(anc[x]);
}




int main()
{
	freopen("centroid.in", "r", stdin);
	freopen("centroid.out", "w", stdout);
	int t;
	scanf("%d", &t);
	while(t--)
	{
		scanf("%d", &n);
		for(int i=1, u, v; i<n; ++i)
		{
			scanf("%d%d", &u, &v);
			e[u][v] = e[v][u] = 1;
			a[i] = u;
			b[i] = v;
 		}
 		
 		for(int i=1; i<n; ++i)
 		{
 			
 			int firj;
 			ancinit();
 			for(int j=1; j<n; ++j)
 			{
 				if(j==i) continue;
 				firj = j;
 				
 				
 				anc[getf(a[j])] = getf(b[j]);
 			}
 			
 			
 			
 			int l = getf(a[firj]);
 			for(int j=1; j<=n; ++j)
 			{
 				if(getf(j)==l) 
 				{
 					ltree[++ltop] = j;
 				}
 				else
 				{
 					rtree[++rtop] = j;
 				}
 			}
 			ancinit();
 			int lans, rans;
 			
 			for(int j=1; j<=ltop; ++j)
 			{
 				for(int k=1; k<=ltop; ++k)
 				{
 					if(j==k) continue;
 					for(int x=1; x<=n; ++x)
 					{
 						if(x==ltree[j]) continue;
 						if(e[ltree[k]][x]) anc[getf(ltree[k])] = getf(x);
 					}
 				}
 				bool suc = 1;
 				for(int k=1; k<=n; ++k)
 				{
 					vis[getf(k)]++;
 					if(vis[getf(k)] > ltop/2) 
					{
					 	suc = 0;
					 	break;
					}
					
 				}
 				if(suc) lans = j;
 			}
 			
 			
 			
 			
 			ancinit();
 			for(int j=1; j<=rtop; ++j)
 			{
 				for(int k=1; k<=rtop; ++k)
 				{
 					if(j==k) continue;
 					for(int x=1; x<=n; ++x)
 					{
 						if(e[rtree[k]][x]) anc[getf(rtree[k])] = getf(x);
 					}
 				}
 				bool suc = 1;
 				for(int k=1; k<=n; ++k)
 				{
 					vis[getf(k)]++;
 					if(vis[getf(k)] > rtop/2)
					{
					 	suc = 0;
					 	break;
					}
					
 				}
 				if(suc) rans = j;
 			}
 			
 			printf("%d\n", lans+rans);
 			
 			
 			
 			
 		}
 		
 		
 		
 		
 		
 		
 		
 		
	}
	
	
	return 0;
	
	
	
	
}
