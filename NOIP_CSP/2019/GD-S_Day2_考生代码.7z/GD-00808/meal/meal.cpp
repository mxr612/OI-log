#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
const long long maxn = 110, maxm = 2010, P = 998244353, inf = 0x3f3f3f3f;
long long n, m;
long long a[maxn][maxm];
long long vis[maxm], cnt;
long long ans;
long long box[maxn];


void printvis()
{
	for(register long long i=1; i<=m; ++i)
	{
		printf("%lld ", vis[i]);
	}
}


void printbox()
{
	for(long long i=1; i<=n; ++i)
	{
		printf("%lld ", box[i]);
	}
}


void dfs(long long x)
{
	
	if(x==n+1) 
	{
		bool suc = 1;
		if(cnt==0) suc=0;
		
		if(suc)
		for(register long long i=1; i<=m; ++i)
		{
			if(vis[i]>cnt/2)
			{
				suc = 0;
				break;
			}
		}
		
		if(suc)
		{
//			printf("--------cnt  %lld   ans  %lld\n", cnt, ans);
//			printf("vis  \n");
//			printvis();
//			printf("\n");
			
//			printf("box  \n");
//			printbox();
//			printf("\n");
			++ans;
			ans%=P;
	//		ans%=P;h
		}
		return;
	}
	
	dfs(x+1);
	for(register long long i=1; i<=m; ++i)
	{
			
		++vis[i];
		++cnt;
		box[x] = i;
		long long tmpans = ans;
		dfs(x+1);
		tmpans = ans-tmpans;
		ans+=(a[x][i]-1)%P*(tmpans%P)%P;
		ans%=P;
		box[x] = 0;
		--vis[i];
		--cnt;
		
	
		
	}
}





int main()
{
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	scanf("%lld%lld", &n, &m);
	for(register long long i=1; i<=n; ++i)
	{
		for(register long long j=1; j<=m; ++j)
		{
			scanf("%lld", &a[i][j]);
		}
	}
	dfs(1);
	printf("%lld", ans);
	return 0;
	
}

