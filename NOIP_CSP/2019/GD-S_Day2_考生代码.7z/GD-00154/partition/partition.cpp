#include <cstdio>
#define int long long
#define INF 0x3fffffff

int n,type; 
int ans = INF;
int num[40000010];

inline int min(int a,int b) {
	return a < b ? a : b;
}

inline int read() {
	int res = 0;
	int sym = 1;
	char ch = getchar();
	while(ch < '0' || ch > '9') {
		if(ch == '-') sym = -1;
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		res = res * 10 + ch - '0';
		ch = getchar();
	}
	return res * sym;
}

void dfs(int index,int last,int now,int val) {
	if(index > n) {
		if(now >= last) {
			ans = min(ans,val + (now * now));
		}
		return;
	}
	dfs(index + 1,last,now + num[index],val);
	if(now >= last) dfs(index + 1,now,num[index],val + now * now);
}

signed main() {
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n = read();type = read();
	if(!type) {
		for(int i = 1;i <= n;i++) num[i] = read();
		dfs(1,0,0,0);
		printf("%lld",ans);
	}else {
		printf("4972194419293431240859891640");
	}
	return 0;
}
