#include <cstdio>
#define int long long
#define MOD 998244353

int n,m,flag,ans;
int menu[110][2010];
int tag[2010];
int tree[110];

inline int lowbit(int x) {
	return x & (-x);
}

inline int read(){
	int res = 0;
	int sym = 1;
	char ch = getchar();
	while(ch < '0' || ch > '9') {
		if(ch == '-') sym = -1;
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		res = res * 10 + ch - '0';
		ch = getchar();
	}
	return res * sym;
}

void dfs(int step,int k,int sum,int made) {
	if(made == k) {
		ans += sum;
		return;
	}
	if(step > n) return;
	if(made + n - step + 1 < k) return;
	for(int i = 1;i <= m;i++) {
		if(menu[step][i] && tag[i] + 1 <= k / 2 && made < k) {
			tag[i] += 1;
			int p = (sum != 0) ? sum * menu[step][i] : menu[step][i];
			p %= MOD;
			dfs(step + 1,k,p,made + 1);
			tag[i] -= 1;
		}
	}
	dfs(step + 1,k,sum,made);
}

signed main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n = read();m = read();
	for(int i = 1;i <= n;i++) {
		for(int j = 1;j <= m;j++) {
			menu[i][j] = read();
		}
	}
	int res = 0;
	for(int i = 2;i <= n;i++) {
		ans = 0;
		dfs(1,i,0,0);
		res += ans;
		res %= MOD;
	}
	printf("%lld",res);
	return 0;
}
