#include <cstdio>
#include <cstring>
#define INF 0x3fffffff

int T;
int n,edge_tot,Size,ans,nowbest = INF;
int d[100010];
int p[100010];
int size[100010];
struct ed{
	int next;
	int to;
} edge[100010];
struct tmp {
	int a,b;
} e[100010];
int head[100010];
int t[2010][2010];

inline int max(int a,int b) {
	return a > b ? a : b;
}

inline int read() {
	int res = 0;
	int sym = 1;
	char ch = getchar();
	while(ch < '0' || ch > '9') {
		if(ch == '-') sym = -1;
		ch = getchar();
	}
	while(ch >= '0' && ch <= '9') {
		res = res * 10 + ch - '0';
		ch = getchar();
	}
	return res * sym;
}

inline void addedge(int from,int to) {
	edge_tot += 1;
	edge[edge_tot].next = head[from];
	edge[edge_tot].to = to;
	head[from] = edge_tot;
}

void dfs(int x,int fa) {
	Size += 1;
	for(int i = head[x];i;i = edge[i].next) {
		int v = edge[i].to;
		if(v == fa || t[x][v]) continue;
		dfs(v,x);
	}
}

void dfs2(int x,int fa) {
	size[x] = 1;int maxpart = 0;
	for(int i = head[x];i;i = edge[i].next) {
		int v = edge[i].to;
		if(v == fa || t[x][v]) continue;
		dfs2(v,x);
		size[x] += size[v];
		maxpart = max(maxpart,size[v]);
	}
	maxpart = max(maxpart,Size - size[x]);
	if(maxpart < nowbest) {
		nowbest = maxpart;
		ans = x;
	}else if(maxpart == nowbest) {
		ans += x;
	}
}

int search(int x) {
	p[1] = x;
	int fa = 0;
	int index = 1;
	while(true) {
		int tmp = x;index++;
		for(int i = head[x];i;i = edge[i].next) {
			int v = edge[i].to;
			if(v == fa) continue;
			x = v;
			fa = x;
		}
		if(x == tmp) break;
		p[index] = x;
	}
	int res = 0;
	for(int i = 1;i < n;i++) {
		if(n + i & 1) {
			res += p[(n + i) / 2 + 1];
		}else {
			res += p[(n + i) / 2] + p[(n + i) / 2 + 1];
		}
		if(i & 1) {
			res += p[i / 2 + 1];
		}else {
			res += p[i / 2] + p[i / 2 + 1];
		}
	}
	return res;
}

int main() {
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	T = read();
	while(T--) {
		int flag = 1;
		edge_tot = 0;
		memset(head,0,sizeof(head));
		n = read();
		for(int i = 1;i < n;i++) {
			int tmp1,tmp2;
			tmp1 = read();tmp2 = read();
			e[i].a = tmp1,e[i].b = tmp2;
			d[tmp1] += 1;d[tmp2] += 1;
			if(d[tmp1] > 2 || d[tmp2] > 2) flag = 0;
			addedge(tmp1,tmp2);
			addedge(tmp2,tmp1);
		}
		if(flag) {
			int start;
			for(int i = 1;i <= n;i++) {
				if(d[i] == 1) {
					start = i;
					break;
				}
			}
			printf("%d\n",search(start));
			continue;
		}
		int tot = 0;
		for(int i = 1;i < n;i++) {
			int n1 = e[i].a;int n2 = e[i].b;
			t[n1][n2] = t[n2][n1] = 1;
			Size = 0;nowbest = INF;ans = 0;
			dfs(n1,0);dfs2(n1,0);tot += ans;
			Size = 0;nowbest = INF;ans = 0;
			dfs(n2,0);dfs2(n2,0);tot += ans;
			t[n1][n2] = t[n2][n1] = 0;
		}
		printf("%d\n",tot);
	}
	return 0;
}
