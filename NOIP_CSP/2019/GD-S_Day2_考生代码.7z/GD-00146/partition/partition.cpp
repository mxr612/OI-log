#include<cstdio>
#include<algorithm>
#include<cstring>
#define fo(i,a,b) for (int (i)=(a);(i)<=(b);(i)++)
#define fd(i,b,a) for (int (i)=(b);(i)>=(a);(i)--)
using namespace std;
typedef long long ll;
const int N=5e5+5;
ll s[N],t[N],d[N];
int n,type,a[N];
ll ans,now,sum;
ll f[5005][5005],h[5005],g[5005];
void R(int &x){
	int t=0; char ch;
	for (ch=getchar();!('0'<=ch&&ch<='9');ch=getchar()) ;
	for (;('0'<=ch&&ch<='9');ch=getchar()) t=t*10+ch-'0';
	x=t;
}
bool pd(int x,int y){
	return s[x]-s[y-1]>=now;
}
void solve(){
	ans=t[n];
	fo(i,1,n) f[i][1]=t[i];
	fo(i,2,n) {
		f[i][1]=t[i];
		fo(j,2,i) fo(k,1,j-1) {
			if (s[i]-s[j-1]>=s[j-1]-s[k-1]) {
				f[i][j]=min(f[i][j],f[j-1][k]+t[i]-t[j-1]-2ll*(s[i]-s[j-1])*(s[j-1]));
			}
		}
	}
	fo(i,1,n) if (f[n][i])
		ans=min(ans,f[n][i]);
	printf("%lld",ans);
}
void solve2(){
	fo(i,1,n) g[i]=4000000000000000000;
	g[1]=t[1]; h[1]=s[1];
	fo(i,2,n) {
		if (a[i]>h[i-1]) {
			g[i]=a[i]*a[i]+g[i-1];
			h[i]=a[i];
		}
		fo(j,1,i-1) {
			if (s[i]-s[j]>h[j]) {
				if (g[j]+t[i]-t[j-1]-2*(s[i]-s[j-1])*(s[j-1]) >g[i]) {
					g[i]=g[j]+t[i]-t[j-1]-2*(s[i]-s[j-1])*(s[j-1]);
					h[i]=a[i]-a[j];
				}
			}
		}
	}
//	fo(i,1,n) printf("%d",);
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d %d",&n,&type);

	fo(i,1,n) R(a[i]);
	fo(i,1,n) {
		s[i]=s[i-1]+(ll)a[i];
		t[i]=s[i]*s[i];
	}
	fd(i,n,1) d[i]+=d[i+1]+a[i];
	if (n<=400){
		fo(i,1,n) fo(j,1,n) f[i][j]=4000000000000000000;
		solve(); return 0;
	}	
//	if (n<=5000){
//		solve2(); return 0;
//	}
	ans=t[n];
		fo(st,1,n-1) {
			if (s[st]>d[st+1]) continue;
			sum=t[st],now=s[st];
			int i=st+1;
			while (i<=n){
				int l=i,r=n+1;
				while (l<r) {
					int mid=l+r>>1;
					if (pd(mid,i)) 
						r=mid;
					else 
						l=mid+1;
				}
				now=s[l]-s[i-1];
				if (now>d[l+1] && l!=n) {
					sum+=t[n]-t[i-1]-2ll*(s[n]-s[i-1])*(s[i-1]);
					break;
				}
				else{
					sum+=(t[l]-t[i-1]-2ll*(s[l]-s[i-1])*(s[i-1]) );
				}
				i=l+1;
			}
			ans=min(ans,sum);
		}
		printf("%lld",ans);
	
	return 0;
}
