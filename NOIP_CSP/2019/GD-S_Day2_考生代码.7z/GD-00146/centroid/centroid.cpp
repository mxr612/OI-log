#include<cstdio>
#include<algorithm>
#include<cstring>
#define fo(i,a,b) for (int (i)=(a);(i)<=(b);(i)++)
using namespace std;
const int N=1000;
int head[N],to[N*2],nex[N*2],tot=1;
int n,ans,s[N],x,y,wh[N],num1,num2,cnt;
bool vis[N*2],pd[N];
void add(int x,int y){
	to[++tot]=y; nex[tot]=head[x]; head[x]=tot;
}
void dfs(int x,int y){
	s[x]=1;
	pd[x]=1;
	wh[x]=cnt;
	for (int i=head[x];i;i=nex[i]){
		if (vis[i]) continue;
		int v=to[i];
		if (v==y) continue;
		dfs(v,x);
		s[x]+=s[v];
	}
}
void dg(int x,int y){
	pd[x]=1;
	bool flag=1;
	for (int i=head[x];i;i=nex[i]){
		if (vis[i]) continue;
		int v=to[i];
		if (v==y) continue;
		if (wh[x]==1 && s[v]>num1/2) flag=0;
		if (wh[x]==2 && s[v]>num2/2) flag=0;
		dg(v,x);
	}
	if (wh[x]==1 && (num1-s[x])>num1/2 ) flag=0;
	if (wh[x]==2 && (num2-s[x])>num2/2 ) flag=0;
	if (flag) ans+=x;
}
void work(){
	memset(s,0,sizeof(s));
	memset(pd,0,sizeof(pd));
	cnt=0; num1=0; num2=0;
	fo(i,1,n){
		if (!pd[i]) {
			++cnt; dfs(i,0);
		}
	}
	fo(i,1,n) if (wh[i]==1) num1++;
	else num2++;
	memset(pd,0,sizeof(pd));
	fo(i,1,n) {
		if (!pd[i]) dg(i,0);
	}
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T;
	scanf("%d",&T);
	while (T--){
		scanf("%d",&n);
		ans=0;
		memset(head,0,sizeof(head));
		memset(s,0,sizeof(s));
		tot=1;
		fo(i,1,n-1){
			scanf("%d %d",&x,&y); add(x,y); add(y,x);
		}
		for (int i=2;i<=tot;i+=2){
			vis[i]=vis[i^1]=1;
			work();
			//printf("\n");
			vis[i]=vis[i^1]=0;
		}
		printf("%d\n",ans);
	}
	return 0;
}

