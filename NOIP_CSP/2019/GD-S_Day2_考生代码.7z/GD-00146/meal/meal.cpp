#include<cstdio>
#include<algorithm>
#define fo(i,a,b) for (int (i)=(a);(i)<=(b);(i)++)
using namespace std;
const int N=45;
const int M=2005;
typedef long long ll;
const ll mo=998244353;
ll a[N][M],f[N][N][N][N],g[N][N][N];
int n,m;
void add(ll &x,ll y){
	x=(x+y)%mo;
}
void solve1(){
	g[0][0][0]=1ll;
	fo(i,1,n){
		fo(j,0,n-1) fo(k,0,n-1) {
			if (a[i][1]) add(g[i][j+1][k],g[i-1][j][k]*a[i][1]%mo);
			if (a[i][2]) add(g[i][j][k+1],g[i-1][j][k]*a[i][2]%mo);
			add(g[i][j][k],g[i-1][j][k]);
		}
	}
	ll ans=0;
	int s;
	fo(j,0,n) fo(k,0,n) {
		s=j+k;
		if (!s) continue;
		if (j>s/2 || k>s/2) continue;
		add(ans,g[n][j][k]);
	}
	printf("%lld",ans);
}
void solve2(){
	f[0][0][0][0]=1ll;
	fo(i,1,n){
		fo(j,0,n-1) fo(k,0,n-1) fo(l,0,n-1){
			if (a[i][1]) add(f[i][j+1][k][l],f[i-1][j][k][l]*a[i][1]%mo);
			if (a[i][2]) add(f[i][j][k+1][l],f[i-1][j][k][l]*a[i][2]%mo);
			if (a[i][3]) add(f[i][j][k][l+1],f[i-1][j][k][l]*a[i][3]%mo);
			add(f[i][j][k][l],f[i-1][j][k][l]);
		}
	}
	ll ans=0;
	int s;
	fo(j,0,n) fo(k,0,n) fo(l,0,n){
		s=j+k+l;
		if (!s) continue;
		if (j>s/2 || k>s/2 || l>s/2) continue;
		add(ans,f[n][j][k][l]);
	}
	printf("%lld",ans);
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d %d",&n,&m);
	fo(i,1,n) {
		fo(j,1,m) 
			scanf("%lld",&a[i][j]);
	}
//	if (m==2) {
//		solve1(); return 0;
//	}
	if (m<=3){
		solve2(); return 0;
	}
	return 0;
} 
