#include<cstdio>
#include<cctype>
#define ull unsigned long long
const int mod=998244353;
const int maxn=105;
const int MAXN=505;
inline int min(int a,int b){return a<b? a:b;}
inline int max(int a,int b){return a>b? a:b;}
inline int R(){
	int r=0;char c=getchar();
	while(!isdigit(c)) c=getchar();
	while(isdigit(c)) r=(r<<1)+(r<<3)+(c^48),c=getchar();
	return r;
}
int n,m,f[maxn][maxn],a[maxn][MAXN],ans,g[MAXN][maxn][maxn],sum[maxn];
int help[MAXN][maxn];//��i��ʳ�Ĳ�����j�� 
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(register int i=1;i<=n;i++)
		for(register int j=1;j<=m;j++) a[i][j]=R(),sum[i]+=a[i][j];
	for(register int i=1;i<=m;i++){
		g[i][1][1]=a[1][i];g[i][1][0]=1;
		help[i][1]=a[1][i];help[i][0]=1;
		for(register int j=2;j<=n;j++){
			g[i][j][0]=1;
			for(register int k=n;k>=1;k--)
			g[i][j][k]=(1ull*help[i][k-1]*a[j][i])%mod,help[i][k]+=g[i][j][k];
		}
	}
	for(register int q=2;q<=n;q++){
	f[0][0]=1;f[1][1]=sum[1];f[1][0]=1;	
		for(register int i=2;i<=n;i++){
			f[i][0]=1;
			for(register int j=1;j<=i;j++){
				ull flag=0;
				for(register int k=1;k<=m;k++)
				if(a[i][k]!=0) flag=flag+1ull*g[k][i][q/2+1]%mod;
				if(j>q/2) f[i][j]=(1ull*f[i-1][j-1]*sum[i]-flag+f[i-1][j])%mod;
				else f[i][j]=(1ull*f[i-1][j-1]*sum[i]+f[i-1][j])%mod;
			}
		}
		ans=(1ull*ans+f[n][q])%mod;
	}
	printf("%d\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
