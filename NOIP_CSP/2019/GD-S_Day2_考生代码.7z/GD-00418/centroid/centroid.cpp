#include<cstdio>
#include<cctype>
#include<cstring>
const int maxn=70005;
inline int R(){
	int r=0;char c=getchar();
	while(!isdigit(c)) c=getchar();
	while(isdigit(c)) r=(r<<1)+(r<<3)+(c^48),c=getchar();
	return r;
}
struct node{
	int to,next;
}edge[maxn*2];
int t,n,head[maxn],tot,du[maxn];
inline void add(int from,int to){
	edge[++tot].next=head[from];
	edge[tot].to=to;
	head[from]=tot;
	return ;
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&t);
	for(register int qwq=1;qwq<=t;qwq++){
		n=R();
		int flag=1;
		memset(edge,0,sizeof(edge));
		memset(du,0,sizeof(du));
		for(register int i=1;i<n;i++){
			int a=R(),b=R();
			add(a,b);add(b,a);
			du[a]++;du[b]++;
		}
		for(register int i=1;i<=n;i++) if(du[i]!=1 && du[i]!=2) flag=0;
		if(flag){
			int k;
			for(register int i=1;i<=n;i++){
				if(du[i]==1){
					k=i;
					break;
				}
			}
			int dl[maxn];
			dl[1]=k;du[k]=3;
			for(register int i=2;i<=n;i++){
				for(register int j=head[dl[i-1]];j;j=edge[j].next){
					if(du[edge[j].to]==3) continue;
					dl[i]=edge[j].to;
					du[edge[j].to]=3;
				}
			}
			unsigned long long ans=0;
			for(register int i=1;i<n;i++){
				if(i%2==1){
					ans+=dl[i/2+1];
				}
				else{
					ans+=1ull*dl[i/2]+dl[i/2+1];
				}
				if((n-i)%2==1){
					ans+=dl[(n-i)/2+1+i];
				}
				else{
					ans+=1ull*dl[(n-i)/2+1+i]+dl[(n-i)/2+i];
				}
			}
			printf("%llu\n",ans);
			continue;
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
