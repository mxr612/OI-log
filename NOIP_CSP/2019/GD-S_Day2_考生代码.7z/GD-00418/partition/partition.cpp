#include<cstdio>
#include<cctype>
inline int R(){
	int r=0;char c=getchar();
	while(!isdigit(c)) c=getchar();
	while(isdigit(c)) r=(r<<1)+(r<<3)+(c^48),c=getchar();
	return r;
}
unsigned long long type,n,a[5005],f[5005],ma[5005];
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%llu%llu",&n,&type);
	for(register int i=1;i<=n;i++) a[i]=R();
	ma[1]=a[1]*a[1];f[1]=a[1];
	for(register int i=2;i<=n;i++){
		unsigned long long tot=0;
		f[i]=ma[i]=999999999999999999;
		for(register int j=i;j>=1;j--){
			tot+=a[j];
			if(f[j-1]>tot) continue;
			if(tot*tot+ma[j-1]<=ma[i]){
				f[i]=tot;
				ma[i]=tot*tot+ma[j-1];
			}
		}
	}
	printf("%llu\n",ma[n]);
	fclose(stdin);fclose(stdout);
	return 0;
}
