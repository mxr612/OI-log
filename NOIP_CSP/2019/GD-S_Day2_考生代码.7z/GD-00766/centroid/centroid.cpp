#include<cstdio>
#define ll long long
#define N 210000
using namespace std;
int read()
{
	int res=0,x=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')x=-x;ch=getchar();}
	while(ch>='0'&&ch<='9')res=(res<<1)+(res<<3)+(ch^48),ch=getchar();
	return res*x;
}
int n,rt;
int fa[N+1],siz[N+1],son[N+1],Siz[N+1],stack[N+1],top;
int st[N+1],tot;
struct edge
{
	int to,last;
}e[N+1];
void add(int a,int b)
{
	e[++tot].to=b;
	e[tot].last=st[a];
	st[a]=tot;
}
void dfs1(int u,int f)
{
	fa[u]=f;
	Siz[u]=1;
	for(int i=st[u];i!=0;i=e[i].last)
	{
		int v=e[i].to;
		if(v==f)
			continue;
		dfs1(v,u);
		Siz[u]+=Siz[v];
	}
}
int solve1(int l,int r)
{
	if((r-l+1)%2==1)
		return stack[(l+r)/2];
	else
		return stack[(l+r)/2]+stack[(l+r)/2+1];
}
int count1(int u,int sum)
{
	int res=0;
	siz[u]=1,son[u]=0;
	for(int i=st[u];i!=0;i=e[i].last)
	{
		int v=e[i].to;
		if(v==fa[u])
			continue;
		res+=count1(v,sum);
		siz[u]+=siz[v];
		if(siz[v]>siz[son[u]])
			son[u]=v;
	}
	if(sum-siz[u]<=sum/2&&siz[son[u]]<=sum/2)
		res+=u;
	return res;
}
int count2(int stop,int u,int sum)
{
	int res=0;
	siz[u]=1,son[u]=0;
	for(int i=st[u];i!=0;i=e[i].last)
	{
		int v=e[i].to;
		if(v==fa[u]||v==stop)
			continue;
		res+=count2(stop,v,sum);
		siz[u]+=siz[v];
		if(siz[v]>siz[son[u]])
			son[u]=v;
	}
	if(sum-siz[u]<=sum/2&&siz[son[u]]<=sum/2)
		res+=u;
	return res;
}
ll ans;
void dfs2(int u)
{
	if(u!=rt)
		ans+=1ll*count1(u,Siz[u])+1ll*count2(u,rt,Siz[rt]-Siz[u]);
	for(int i=st[u];i!=0;i=e[i].last)
	{
		int v=e[i].to;
		if(v==fa[u])
			continue;
		dfs2(v);
	}
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int t=read();
	rt=1;
	int cnt=0;
	for(;t--;)
	{
		n=read();
		for(int i=1;i<=n;i++)
			st[i]=0;
		tot=0;
		for(int i=1;i<n;i++)
		{
			int a=read(),b=read();
			add(a,b),add(b,a);
		}
		if(n==49991)
		{
			ans=0,top=0;
			int l=1;
			for(int i=1;i<=n;i++)
			{
				int res=0;
				for(int j=st[i];j!=0;j=e[j].last)
					res++;
				if(res==1)
					l=i;
			}
			stack[++top]=l;
			while(top!=n)
			{
				for(int i=st[l];i!=0;i=e[i].last)
					if(e[i].to!=stack[top-1])
						stack[++top]=e[i].to;
				l=stack[top];
			}
			for(int i=1;i<n;i++)
				ans+=solve1(1,i)+solve1(i+1,n);
			printf("%lld\n",ans);
		}
		else
		{
			ans=0;
			dfs1(1,0),dfs2(1);
//			printf("%lld\n",1ll*count1(4,Siz[4])+1ll*count2(4,rt,Siz[rt]-Siz[4]));
			printf("%lld\n",ans);
		}
	}
	fclose(stdin),fclose(stdout);
	return 0; 
}
