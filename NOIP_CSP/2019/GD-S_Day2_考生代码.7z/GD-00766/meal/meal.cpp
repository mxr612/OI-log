#include<cstdio>
#define ll long long
using namespace std;
int readi()
{
	int res=0,x=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')x=-x;ch=getchar();}
	while(ch>='0'&&ch<='9')res=(res<<1)+(res<<3)+(ch^48),ch=getchar();
	return res*x;
}
ll readl()
{
	ll res=0,x=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')x=-x;ch=getchar();}
	while(ch>='0'&&ch<='9')res=res*10+(ch^48),ch=getchar();
	return res*x;
}
const ll mod=998244353;
int n,m;
ll a[45][45],f[45][45][45][45];
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=readi(),m=readi();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			a[i][j]=readl();
	f[0][0][0][0]=1;
	if(m==1)
	{
		printf("0");
		return 0;
	}
	if(m==2)
	{
		for(int i=1;i<=n;i++)
			for(int j=0;j<=n;j++)
				for(int k=0;k<=n;k++)
				{
					f[i][j][k][0]=f[i-1][j][k][0];
					if(j>=1)
						f[i][j][k][0]=(f[i][j][k][0]+f[i-1][j-1][k][0]*a[i][1]%mod)%mod;
					if(k>=1)
						f[i][j][k][0]=(f[i][j][k][0]+f[i-1][j][k-1][0]*a[i][2]%mod)%mod;
				}
		ll ans=0;
		for(int j=0;j<=n;j++)
			for(int k=0;k<=n;k++)
				if(((j+k)>>1)>=j&&((j+k)>>1)>=k)
					ans=(ans+f[n][j][k][0])%mod;
		printf("%lld\n",ans);
	}
	if(m==3)
	{
		for(int i=1;i<=n;i++)
			for(int j=0;j<=n;j++)
				for(int k=0;k<=n;k++)
					for(int w=0;w<=n;w++)
					{
						f[i][j][k][w]=f[i-1][j][k][w];
						if(j>=1)
							f[i][j][k][w]=(f[i][j][k][w]+f[i-1][j-1][k][w]*a[i][1]%mod)%mod;
						if(k>=1)
							f[i][j][k][w]=(f[i][j][k][w]+f[i-1][j][k-1][w]*a[i][2]%mod)%mod;
						if(w>=1)
							f[i][j][k][w]=(f[i][j][k][w]+f[i-1][j][k][w-1]*a[i][3]%mod)%mod;
					}
		ll ans=0;
		for(int j=0;j<=n;j++)
			for(int k=0;k<=n;k++)
				for(int w=0;w<=n;w++)
					if(((j+k+w)>>1)>=j&&((j+k+w)>>1)>=k&&((j+k+w)>>1)>=w&&(j!=0||k!=0||w!=0))
						ans=(ans+f[n][j][k][w])%mod;
		printf("%lld\n",ans);
	}
	fclose(stdin),fclose(stdout);
	return 0;
}
