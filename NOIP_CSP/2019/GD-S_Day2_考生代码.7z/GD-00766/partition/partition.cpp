#include<cstdio>
#define N 3510
#define ll long long
using namespace std;
int readi()
{
	int res=0,x=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')x=-x;ch=getchar();}
	while(ch>='0'&&ch<='9')res=(res<<1)+(res<<3)+(ch^48),ch=getchar();
	return res*x;
}
ll readl()
{
	ll res=0,x=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')x=-x;ch=getchar();}
	while(ch>='0'&&ch<='9')res=res*10+(ch^48),ch=getchar();
	return res*x;
}
ll Min(ll a,ll b){return a<b?a:b;}
ll Max(ll a,ll b){return a<b?a:b;}
const ll inf=4611686018427387903;
int n,type;
ll a[N+1],sum[N+1],f[N+1][N+1];
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=readi(),type=readi();
	for(int i=1;i<=n;i++)
		a[i]=readl(),sum[i]=sum[i-1]+a[i]; 
	for(register int i=1;i<=n;i++)
		for(register int j=i;j>=1;j--)
		{
			if(j!=1)
				f[i][j]=inf;
			else
				f[i][j]=(sum[i]-sum[j-1])*(sum[i]-sum[j-1]);
			if(sum[i]-sum[j-1]<sum[j-1]-sum[j-2])
				continue;
			for(register int k=j-1;k>=1;k--)
			{
				if(sum[i]-sum[j-1]>=sum[j-1]-sum[k-1])
				{
					if(f[j-1][k]!=inf)
					{
						f[i][j]=Min(f[i][j],f[j-1][k]+(sum[i]-sum[j-1])*(sum[i]-sum[j-1]));
						break;
					}
				}
				else
					break;
			}
		}
	ll ans=inf;
	for(register int i=1;i<=n;i++) 
		ans=Min(ans,f[n][i]);
	printf("%lld",ans);
	fclose(stdin),fclose(stdout);
	return 0;
}
