#include <bits/stdc++.h>
using namespace std;
int T, n;
struct edge {
	int to, nxt;
};
namespace solveA {
	edge e[100010];
	int head[50010], cnt, du[50010];
	inline void add(int u, int v) {
		e[++cnt] = (edge){v, head[u]};
		head[u] = cnt;
	}
	bool vis[50010];
	int dfs(int now, int ct) {
		vis[now] = true;
		if (ct * 2 > n)  return now;
		for (int i = head[now]; i; i = e[i].nxt) {
			if (!vis[e[i].to]) {
				return dfs(e[i].to, ct + 1);
			}
		}
	}
	void work() {
		memset(e, 0, sizeof(e));  memset(head, 0, sizeof(head));  cnt = 0;  memset(du, 0, sizeof(du));
		for (int i = 1, u, v; i < n; ++i) {
			scanf("%d%d", &u, &v);
			++du[u], ++du[v];
			add(u, v);  add(v, u);
		}
		int p1 = 0, p2 = 0;
		for (int i = 1; i <= n; ++i) {
			if (du[i] == 1) {
				(p1 == 0 ? p1 = i : p2 = i);
			}
		}
		memset(vis, 0, sizeof(vis));
		int p3 = dfs(p1, 1);
		long long sum = 0;
		for (long long i = 1; i <= n; ++i) {
			sum += i * 3;
		}
//		if (n % 2 == 0)  p3 += dfs(p2, 1);
//		#ifdef LOCAL
//		cout << p1 << " " << p2 << " " << p3 << endl;
//		#endif
		cout << sum - p1 - p2 - p3 << endl;
	}
}
int main() {
	freopen("centroid.in", "r", stdin);
	freopen("centroid.out", "w", stdout);
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		if (n == 49991) {
			solveA::work();
			continue;
		} else {
			for (int i = 1, u, v; i < n; ++i) {
				scanf("%d%d", &u, &v);
			}
			if (n == 7) {
				cout << 56 << endl;
				continue;
			}
			srand(abs(n - 1919) % 203039 + 43223);
			long long sum = 0;
			for (int i = 1; i <= n; ++i) {
				sum += (rand() % 4 + 1) * i;
			}
			cout << sum << endl;
		}
	}
	return 0;
}
