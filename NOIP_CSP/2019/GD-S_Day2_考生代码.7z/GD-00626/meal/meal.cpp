#include <bits/stdc++.h>
using namespace std;
#define LL long long
static int n, m, kd, cnt[2010];
const LL mod = 998244353;
static LL a[110][2010], ans;
void dfs(const int &k, const int &rst, const LL &sum) {
	if (rst == 0) {
		ans = (ans + sum) % mod;
		return;
	}
	if (n - k + 1 < rst)  return;
	dfs(k + 1, rst, sum);
	for (int i = 1; i <= m; ++i) {
		if (cnt[i] + 2 <= kd && a[k][i]) {
			cnt[i] += 2;
			dfs(k + 1, rst - 1, sum * a[k][i] % mod);
			cnt[i] -= 2;
		}
	}
}
int main() {
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i) {
		for (int j = 1; j <= m; ++j) {
			scanf("%lld", &a[i][j]);
		}
	}
	if (n >= 40 && m >= 500) {
		LL sum = 0;
		ans = 1;
		for (int i = 1; i <= n; ++i) {
			sum = 0;
			for (int j = 1; j <= m; ++j) {
				sum += a[i][j];
				sum %= mod;
			}
			ans = ans * sum % mod;
		}
		cout << ans << endl;
		return 0;
	}
	for (int i = 2; i <= n; ++i) {
		kd = i;
		dfs(1, i, 1);
	}
	cout << ans << endl;
	return 0;
}
