#include <bits/stdc++.h>
using namespace std;
#define LL long long
int n, type;
LL a[40001000];
void input() {
	scanf("%d%d", &n, &type);
	if (type == 0) {
		for (register int i = 1; i <= n; ++i) {
			scanf("%lld", &a[i]);
		}
	} else {
		int x, y, z, m, mod = (1 << 30);
		scanf("%d%d%d%lld%lld%d", &x, &y, &z, &a[1], &a[2], &m);
		for (register int i = 3; i <= n; ++i) {
			a[i] = (x * a[i - 1] + y * a[i - 2] + z) % mod;
		}
		for (register int i = 1, p, l, r, j = 1; i <= m; ++i) {
			scanf("%d%d%d", &p, &l, &r);
			while (j <= p)  a[j] = a[j] % (r - l + 1) + l, ++j;
		}
	}
}
LL stk[40001000];
int top;
namespace solve1 {
	unsigned LL work() {
		top = 0;
		stk[++top] = a[n];
		for (register int i = n - 1; i >= 1; --i) {
			if (a[i] <= stk[top])  stk[++top] = a[i];
			else { 
				while (a[i] > stk[top] && top > 0) {
					a[i] += stk[top--];
				}
				stk[++top] = a[i];
			}
		}
		unsigned LL ans = 0;
		for (register int i = 1; i <= top; ++i) {
			ans += stk[i] * stk[i];
		}
		return ans;
	}
}
namespace solve2 {
	unsigned LL work() {
		top = 0;
		stk[++top] = a[1];
		for (register int i = 2; i <= n; ++i) {
			if (a[i] >= stk[top])  stk[++top] = a[i];
			else {
				while (a[i] < stk[top] && top > 0) {
					a[i] += stk[top--];
				}
				stk[++top] = a[i];
			}
		}
		unsigned LL ans = 0;
		for (register int i = 1; i <= top; ++i) {
			ans += stk[i] * stk[i];
		}
		return ans;
	}
}
namespace solve3 {
	unsigned LL work() {
		srand(n % 1919 + a[n / 7 + 1]);
		for (int i = 1; i <= rand() % 10000 + 191919; ++i) {
			int pp = 1LL * rand() * rand() % (n - 2) + 2;
			if (a[pp] == 0)  continue;
			if (a[pp - 1] == 0 && a[pp] > a[pp + 1])  a[pp] += a[pp + 1], a[pp + 1] = 0;
			else if (a[pp + 1] == 0 && a[pp - 1] > a[pp])  a[pp] += a[pp - 1], a[pp - 1] = 0;
			else if (a[pp + 1] && a[pp - 1] && !(a[pp - 1] < a[pp] && a[pp] < a[pp + 1])) {
				if (a[pp - 1] + a[pp] <= a[pp + 1]) {
					a[pp - 1] += a[pp];
				} else {
					a[pp + 1] += a[pp];
				}
			}
		}
		unsigned LL ans = 0, last = 0;
		for (int i = 1; i <= n; ++i) {
			if (a[i] < last && a[i])  return 0x7fffffffffffffff;
			ans += a[i] * a[i];
			if (a[i])  last = a[i];
		}
		return ans;
	}
}
int main() {
	freopen("partition.in", "r", stdin);
	freopen("partition.out", "w", stdout);
	input();
	unsigned LL ans = min(solve1::work(), solve2::work());
	cout << ans << endl;
	return 0;
}
