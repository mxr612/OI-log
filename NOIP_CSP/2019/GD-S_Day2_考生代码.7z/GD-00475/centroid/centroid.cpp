#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <map>
#include <cstdlib>
#define MAXN 300005
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while (ch<'0'||ch>'9'){
		if (ch=='-') f=-1;
		ch=getchar();
	}
	while (ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^'0');
		ch=getchar();
	}
	return x*f;
}
vector<int>G[MAXN];
int sz[MAXN];
long long ans;
int n;
void AddEdge(int u,int v){
	G[u].push_back(v);
}
void dfs(int u,int father,int tot){
	sz[u]=1;
	int maxn=0;
	for (int i=0;i<(int)G[u].size();++i){
		int v=G[u][i];
		if (v==father) continue;
		dfs(v,u,tot);
		sz[u]+=sz[v];
		maxn=max(maxn,sz[v]);
	}
	int up=tot-sz[u];
	maxn=max(maxn,up);
	if (maxn<=tot/2) ans+=u;
}
int pre_sz[MAXN],dep[MAXN];
void pre(int u,int father){
	pre_sz[u]=1;
	dep[u]=dep[father]+1;
	for (int i=0;i<(int)G[u].size();++i){
		int v=G[u][i];
		if (v==father) continue;
		pre(v,u);
		pre_sz[u]+=pre_sz[v];
	}
}
int deg[MAXN];
namespace Chain_Solve{
	int top,bot;
	bool Check(){
		int cnt=0;
		for (int i=1;i<=n;++i){
			if (deg[i]==1){
				if (!top) top=i;
				else if (!bot) bot=i;
				else return false;
			}
			else if (deg[i]==2){
				cnt++;
			}
		}
		if (cnt!=n-2) return false;
		else return true;
	}
	int seq[MAXN*2],cnt;
	void make_chain(int u,int father){
		seq[++cnt]=u;
		for (int i=0;i<(int)G[u].size();++i){
			int v=G[u][i];
			if (v==father) continue;
			make_chain(v,u);
		}
	}
	void Solve(){
		cnt=0;
		make_chain(top,0);
		for (int i=2;i<=n;++i){
			int left=i-1;
			if (left&1) ans+=seq[(left+1)/2];
			else ans+=seq[left/2],ans+=seq[left/2+1];
		}
		cnt=0;
		make_chain(bot,0);
		for (int i=2;i<=n;++i){
			int left=i-1;
			if (left&1) ans+=seq[(left+1)/2];
			else ans+=seq[left/2],ans+=seq[left/2+1];
		}
		printf("%lld\n",ans);
		return ;
	}
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T=read();
	while (T--){
		n=read();
		for (int i=1;i<=n;++i) G[i].clear();
		for (int i=1;i<n;++i){
			int u=read(),v=read();
			AddEdge(u,v);
			AddEdge(v,u);
			deg[u]++,deg[v]++;
		}
		if (Chain_Solve::Check()){Chain_Solve::Solve();continue;}
		dep[1]=0;
		pre(1,1);
		ans=0;
		for (int i=1;i<=n;++i){
			for (int j=0;j<(int)G[i].size();++j){
				int k=G[i][j];
				//printf("del Edge %d %d\n",i,k);
				if (dep[i]<dep[k]) dfs(i,k,n-pre_sz[k]),dfs(k,i,pre_sz[k]);
			}
		}
		printf("%lld\n",ans);
	}
}
