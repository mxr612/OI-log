//#include <iostream>
//#include <cstdio>
//#include <cstring>
//#include <vector>
//#include <map>
//#include <cstdlib>
//#define MAXN 105
//#define MAXM 25
//#define SIZE (1<<20)+5
//#define MOD 998244353
//using namespace std;
//inline int read(){
//	int x=0,f=1;
//	char ch=getchar();
//	while (ch<'0'||ch>'9'){
//		if (ch=='-') f=-1;
//		ch=getchar();
//	}
//	while (ch>='0'&&ch<='9'){
//		x=(x<<1)+(x<<3)+(ch^'0');
//		ch=getchar();
//	}
//	return x*f;
//}
//int dp[MAXM][SIZE],Sum[MAXM][SIZE],n,m;
//int cnt[MAXN];
//int a[MAXN][MAXM];
//inline int Calc(int p){
//	memset(dp,0,sizeof(dp));
////	for (int i=0;i<(1<<n);++i){
////		dp[0][i]=1;
////	}
//	dp[0][0]=1;
//	for (int i=1;i<=m;++i){
//		for (int j=0;j<(1<<n);++j){
//			for (int k=0;k<(1<<n);++k){
//				if (((j|k)==(j+k))&&cnt[k]<=(p/2)){
//					//if (Sum[i][k]==0) Sum[i][k]=1;
//					dp[i][j+k]=(dp[i][j+k]+1ll*dp[i-1][j]*Sum[i][k]%MOD)%MOD;
//				}
//			}
//		}
//	}
////	printf("now p=%d\n",p);
//	for (int j=1;j<=m;++j){
//		for (int i=0;i<(1<<n);++i){
//			printf("%d ",dp[j][i]);
//		}
//		puts("");
//	}
//	int ans=0;
//	for (int i=1;i<=m;++i){
//		for (int j=0;j<(1<<n);++j){
//			if (cnt[j]==p) ans=(ans+dp[i][j])%MOD;
//		}
//	}
//	return ans;//ȫ���ù�
//}
//inline void Pre(){
//	for (int i=1;i<=m;++i){
//		for (int j=0;j<(1<<n);++j){
//			for (int k=1;k<=n;++k){
//				if (j&(1<<(k-1))) Sum[i][j]+=a[i][k];
//			}
//		}
//	}
//}
//int main(){
//	n=read(),m=read();
//	for (int i=1;i<=n;++i){
//		for (int j=1;j<=m;++j){
//			a[i][j]=read();
//		}
//	}
//	cnt[0]=0;
//	for (int i=1;i<(1<<n);++i){
//		cnt[i]=cnt[i-(i&-i)]+1;
//	}
//	Pre();
//	int ans=0;
//	for (int i=1;i<=n;++i) ans=(ans+Calc(i))%MOD,printf("p=%d ans=%d\n",i,Calc(i));
//	printf("%d\n",ans);
//}
///*
//3 3
//1 2 3
//4 5 0
//6 0 0
//
//2 3
//1 0 1
//0 1 1
//*/
#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <map>
#include <cstdlib>
#define MAXN 105
#define MAXM 2005
#define MOD 998244353
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while (ch<'0'||ch>'9'){
		if (ch=='-') f=-1;
		ch=getchar();
	}
	while (ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^'0');
		ch=getchar();
	}
	return x*f;
}
int n,m;
int a[MAXN][MAXM];
long long ans;
int used[MAXN][MAXM];
inline int Calc(){
	int sum=0;
	for (int i=1;i<=n;++i){
		for (int j=1;j<=m;++j){
			sum+=used[i][j];
		}
	}
	if (sum==0) return 0;
	for (int i=1;i<=m;++i){
		int sum2=0;
		for (int j=1;j<=n;++j){
			sum2+=used[j][i];
		}
		if (sum2>sum/2) return 0;
	}
	int ret=1;
	for (int j=1;j<=m;++j){
		int sum2=0,cnt=0;
		for (int i=1;i<=n;++i){
			if (used[i][j]) sum2+=a[i][j],cnt++;
		}
		//printf("---%d\n",sum2);
		if (cnt) ret=1ll*ret*sum2%MOD;
	}
	//printf("ret=%d\n",ret);
	return ret;
}
void dfs(int pos){
	if (pos==n+1) {
		ans+=Calc();
		return ;
	}
	for (int i=1;i<=m;++i){
		used[pos][i]=true;
		dfs(pos+1);
		used[pos][i]=false;
	}
	dfs(pos+1);
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read(),m=read();
	for (int i=1;i<=n;++i){
		for (int j=1;j<=m;++j){
			a[i][j]=read();
		}
	}
	dfs(1);
	printf("%lld\n",ans);
}
/*
3 3
1 2 3
4 5 0
6 0 0

2 3
1 0 1
0 1 1
*/
