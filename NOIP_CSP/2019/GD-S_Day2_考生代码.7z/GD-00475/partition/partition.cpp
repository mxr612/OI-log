#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#include <map>
#include <cstdlib>
#define MAXN 5005
using namespace std;
inline int read(){
	int x=0,f=1;
	char ch=getchar();
	while (ch<'0'||ch>'9'){
		if (ch=='-') f=-1;
		ch=getchar();
	}
	while (ch>='0'&&ch<='9'){
		x=(x<<1)+(x<<3)+(ch^'0');
		ch=getchar();
	}
	return x*f;
}
int a[MAXN];
long long dp[MAXN][MAXN];
long long sum[MAXN];
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int n=read(),type=read();
	if (type==0){
		sum[0]=0;
		for (int i=1;i<=n;++i){
			a[i]=read();
			sum[i]=a[i]+sum[i-1];
		}
		memset(dp,0x3f,sizeof(dp));
		for (int i=1;i<=n;++i){
			for (int j=1;j<=n;++j){
				dp[i][j]=(long long)4*(long long)1e18;
			}
		}
		for (int i=1;i<=n;++i){
			dp[i][1]=min(dp[i][1],sum[i]*sum[i]);
		}
		for (int i=1;i<=n;++i){
			for (int j=i;j>=1;--j){
				for (int k=j;k>=1;--k){
					long long sum1=sum[j-1]-sum[k-1],sum2=sum[i]-sum[j-1];
					if (sum1<=sum2){
						dp[i][j]=min(dp[i][j],dp[j-1][k]+sum2*sum2);
					}
					else {
						break;
					}
				}
			}
		}
		long long ans=(long long)4*(long long)1e18;
		for (int i=1;i<=n;++i){
			ans=min(ans,dp[n][i]);
		}
		printf("%lld\n",ans);
	}
}
/*
10 0
5 6 7 7 4 6 2 13 19 9
5 0
5 1 7 9 9
*/
