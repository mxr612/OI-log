#include <set>
#include <map>
#include <ctime>
#include <cmath>
#include <queue>
#include <stack>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long LL;
using namespace std;

const int maxn = 262143;

map<int, bool> pic[maxn];

inline void solve(void) {
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i) pic[i].clear();
	for (int i = 0; i < n - 1; ++i) {
		int u, v;
		scanf("%d%d", &u, &v);
		pic[u][v] = pic[v][u] = true;
	}
	int i;
	for (i = 1; i < n; ++i)
		if (!pic[i][i + 1])
			break;
	if (i >= n) {
		LL ans = 1;
		for (int i = 1; i <= n; ++i) {
			ans += ((1 + i) >> 1) + ((i + 1 + n) >> 1);
			if ((1 + i) ^ 1) ans += ((1 + i) >> 1) + 1;
			if ((i + 1 + n) ^ 1) ans += ((i + 1 + n) >> 1) + 1;
		}
		printf("%lld\n", ans);
		return;
	}
}

int main() {
	freopen("centroid.in", "r", stdin);
	freopen("centroid.out", "w", stdout);
	int t;
	scanf("%d", &t);
	while (t--) solve();
	return 0;
}