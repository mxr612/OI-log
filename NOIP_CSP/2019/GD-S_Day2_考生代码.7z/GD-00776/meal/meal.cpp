#include <set>
#include <map>
#include <ctime>
#include <cmath>
#include <queue>
#include <stack>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long LL;
using namespace std;

const int maxn = 100 + 10, maxm = 2000 + 10, mod = 998244353;

int a[maxn][maxm];

int n, m, k;
int ans = 0;
int cnt[maxm];
bool mark[maxn];

inline void init() { memset(cnt, 0, sizeof (cnt)); memset(mark, false, sizeof (mark)); }

void dfs(int last, int step, int sum) {
	if (step == k) {  ans = (ans + sum) % mod; return; }
	for (int i = last; i < n; ++i)
		if (!mark[i])
			for (int j = 0; j < m; ++j)
				if (a[i][j] && cnt[j] < (k >> 1)) {
					mark[i] = true;
					++cnt[j];
					dfs(i + 1, step + 1, (LL)sum * a[i][j] % mod);
					--cnt[j];
					mark[i] = false;
				}
}

int main() {
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	scanf("%d%d", &n, &m);
	int sum = 0;
	for (int i = 0; i < n; ++i)
		for (int j = 0; j < m; ++j)
			scanf("%d", &a[i][j]);
	for (k = 2; k <= n; ++k)
		init(), dfs(0, 0, 1);
	printf("%lld\n", ans);
	return 0;
}/*
5 5
1 0 0 1 1
0 1 0 1 0
1 1 1 1 0
1 0 1 0 1
0 1 1 0 1
*/