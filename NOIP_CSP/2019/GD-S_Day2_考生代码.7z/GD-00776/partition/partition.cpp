#include <set>
#include <map>
#include <ctime>
#include <cmath>
#include <queue>
#include <stack>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long LL;
using namespace std;

const int maxn = 400 + 10;
const LL oo = 8e18 + 9;

LL a[maxn], dp[maxn][maxn][maxn];
LL M[maxn];

LL solve(int p, int l, int r) {
	if (dp[p][l][r]) return dp[p][l][r];
	if (l == r) {
		M[p] = a[l] - a[l - 1];
		if (M[p] >= M[p - 1]) return dp[p][l][r] = M[p] * M[p];
		return dp[p][l][r] = oo;
	}
	LL ans = oo;
	for (int i = l; i < r; ++i) {
		M[p] = a[i] - a[l - 1];
		if (M[p] >= M[p - 1])
			ans = min(ans, M[p] * M[p] + solve(p + 1, i + 1, r));
	}
	M[p] = a[r] - a[l - 1];
	if (M[p] > M[p - 1]) ans = min(ans, M[p] * M[p]);
	return dp[p][l][r] = ans;
}

int main() {
	freopen("partition.in", "r", stdin);
	freopen("partition.out", "w", stdout);
	int n, type;
	scanf("%d%d", &n, &type);
	if (!type && n <= 1e3) {
		for (int i = 1; i <= n; ++i)
			scanf("%lld", &a[i]);
	} else return 0;
	for (int i = 1; i <= n; ++i) a[i] += a[i - 1];
	M[0] = -1;
	printf("%lld\n", solve(1, 1, n));
	return 0;
}