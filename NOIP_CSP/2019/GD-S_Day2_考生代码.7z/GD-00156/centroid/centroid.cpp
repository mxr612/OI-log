#include <cstdio>
#include <cstring>
#include <algorithm>
#define LL long long 
const LL N=1e5+10;
LL last[N],size[N],n,deg[N],d[N],ans,S;
bool bz[N*2];
struct node {
	LL a,b;
}a[N*2];
void add(LL x,LL y) {
	a[++a[0].a]=(node){y,last[x]};last[x]=a[0].a;
}
bool pd() {
	for (LL i=1;i<=n;i++) {
		if (deg[i]!=1 && deg[i]!=2) return 0;
	}
	return 1;
}
LL get(LL x,LL y) {
	LL z=(x+y)/2;
	LL zl=d[z];
	if ((y-x+1)%2==0) zl+=d[z+1];
	return zl;
}
bool jud(LL x,LL y) {
	if (S-size[x]>S/2) return 0;
	for (LL i=last[x];i;i=a[i].b) {
		if (!bz[i] && a[i].a!=y) {
			if (size[a[i].a]>S/2) return 0;
		}
	}
	return 1;
}
void dfs(LL x,LL y) {
	size[x]=1;
	d[++d[0]]=x;
	for (LL i=last[x];i;i=a[i].b) {
		if (!bz[i] && a[i].a!=y) {
			dfs(a[i].a,x);
			size[x]+=size[a[i].a];
		}
	}
}
void dfs1(LL x,LL y) {
	if (jud(x,y)) ans+=x;
	for (LL i=last[x];i;i=a[i].b) {
		if (!bz[i] && a[i].a!=y) dfs1(a[i].a,x);
	}
}
void work() {
	memset(last,0,sizeof(last));
	memset(deg,0,sizeof(deg));
	a[0].a=0;
	LL i,j,k;
	scanf("%lld",&n);
	for (i=1;i<=n-1;i++) {
		LL x,y;scanf("%lld%lld",&x,&y);
		add(x,y);add(y,x);
		deg[x]++;deg[y]++;
	}
	d[0]=0;
	if (pd()) {
		LL z;
		for (i=1;i<=n;i++) 
			if (deg[i]==1) z=i;
		d[0]=0;
		dfs(z,0);
		LL ans=0;
		for (i=1;i<=d[0]-1;i++) {
			ans+=get(1,i)+get(i+1,d[0]);
		}
		printf("%lld\n",ans);
		return;
	}
	ans=0;
	for (i=1;i<=a[0].a;i+=2) {
		
		d[0]=0;
		bz[i]=bz[i+1]=1;
		dfs(a[i].a,0);S=size[a[i].a]; dfs1(a[i].a,0);
		dfs(a[i+1].a,0);
		S=size[a[i+1].a]; dfs1(a[i+1].a,0);
		bz[i]=bz[i+1]=0;
	}
	printf("%lld\n",ans);
}
int main() {
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	LL t;scanf("%lld",&t);
	while (t--) work();
	return 0;
}
