#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
#define LL long long 
#define pw(x) ((x)*(x))
const LL N=5010,inf=9223372036854775807;
LL n,a[N],b[N],f[N][N];
int main() {
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	LL i,j,k;
	scanf("%lld%lld",&n,&i);
	
	memset(f,0x7f,sizeof(f));
	for (i=1;i<=n;i++) {
		scanf("%lld",&a[i]);
		b[i]=b[i-1]+a[i];
		f[1][i]=pw(b[i]);
	}
	for (i=2;i<=n;i++) {
		for (j=i;j<=n;j++) {
			LL x=b[j]-b[i-1];
			LL l=1,r=i-1;
			k=n+1;
			while (l<=r) {
				LL mid=l+r>>1;
				if (b[i-1]-b[mid-1]>x) l=mid+1;
				else r=mid-1,k=mid; 
			}
			for (;k<=i-1;k++) f[i][j]=min(f[k][i-1],f[i][j]);
			if (k!=n+1) f[i][j]+=x*x;
		}
	}
	LL ans=inf;
	for (i=1;i<=n;i++) ans=min(f[i][n],ans);
	printf("%lld",ans);
}
