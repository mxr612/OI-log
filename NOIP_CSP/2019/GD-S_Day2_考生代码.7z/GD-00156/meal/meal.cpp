#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
#define LL long long 
const LL N=110,M=2010,mo=998244353;
LL n,m,a[N][M],ans;
LL bz[M];
bool pd() {
	LL i,s=0,z=0;
	for (i=1;i<=m;i++) s+=bz[i],z+=(bz[i]!=0);
	if (z<=1) return 0;
	for (i=1;i<=m;i++) 
		if (bz[i]>s/2) return 0;
	return 1;
}
void dfs(LL x,LL y) {
	if (x>n) {
		if (pd())
			ans=(ans+y)%mo;
	}
	else {
		dfs(x+1,y);
		for (LL j=1;j<=m;j++) {
			if (a[x][j]!=0) {
				bz[j]++;
				dfs(x+1,y*a[x][j]%mo);
				bz[j]--;
			}
		}
	}
}
int main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	LL i,j,k;
	scanf("%lld%lld",&n,&m);
	for (i=1;i<=n;i++) 
		for (j=1;j<=m;j++) scanf("%lld",&a[i][j]);
	dfs(1,1);
	printf("%lld",ans);
	return 0;
}
