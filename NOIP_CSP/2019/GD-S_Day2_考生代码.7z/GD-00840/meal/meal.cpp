#include<cstdio>
#include<iostream>
#define maxn 5555
using namespace std;
int i,j,k,l,n,m,type,min1,min2,a[maxn];
long long f[maxn],ma[maxn];
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	printf("0");
	return 0;
}
