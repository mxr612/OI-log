#include<cstdio>
#include<iostream>
#define maxn 5555
using namespace std;
int i,j,l,n,m,type,a[maxn];
long long f[maxn],ma[maxn],min1,min2,k;
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	for(i=1;i<=n;i++)	scanf("%d",&a[i]);
	f[1]=a[1]*a[1];
	ma[1]=a[1];
	for(i=2;i<=n;i++)
	{
		k=0;
		min1=9223372036857580;
		min2=ma[i-1];
		for(j=i;j>=0;j--)
		{
			k+=a[j];
			if(k>=ma[j-1] && min1>f[j-1]+k*k)	
			{
				min1=f[j-1]+k*k;
				min2=k;
			}
		}
		f[i]=min1;
		ma[i]=min2;
	}
	printf("%lld",f[n]);
	return 0;
}
