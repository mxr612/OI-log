#include<cstdio>
#include<cstring>
#include<string.h>
#include<iostream>
#define maxn 205
using namespace std;
int i,j,k,l,n,m,ttt,ans,x[maxn],y[maxn],a[maxn][maxn],son[maxn][maxn],b[maxn],siz,dep;
bool v[maxn];
void dfs(int i)
{
	int j;
	v[i]=true;
	siz++;
	for(j=1;j<=b[i];j++)
	if(!v[a[i][j]])
		dfs(a[i][j]);
}
int find(int i)
{
	int j;
	v[i]=false;
	for(j=1;j<=b[i];j++)
	if(v[a[i][j]])
	{
		dep++;
		if(dep>k)	k=dep;
		find(a[i][j]);
		dep--;
	}
	v[i]=true;
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&ttt);
	while(--ttt>=0)
	{
		scanf("%d",&n);
		memset(a,0,sizeof(a));
		memset(son,0,sizeof(son));
		memset(b,0,sizeof(b));
		ans=0;
		for(i=1;i<n;i++)
		{
			scanf("%d%d",&x[i],&y[i]);
			a[x[i]][++b[x[i]]]=y[i];
			a[y[i]][++b[y[i]]]=x[i];
		}
		for(i=1;i<n;i++)
		{
			siz=0;
			memset(v,false,sizeof(v));
			v[y[i]]=true;
			dfs(x[i]);
			l=siz;
			v[y[i]]=false;
			for(int i1=1;i1<=n;i1++)
			if(v[i1])
			{
				bool t=true;
				dep=0;
				k=0;
				find(i1);
				if(k<=l/2) ans+=i1;
			}
			l=n-siz;
			memset(v,false,sizeof(v));
			v[x[i]]=true;
			dfs(y[i]);
			v[x[i]]=false;
			for(int i1=1;i1<=n;i1++)
			if(v[i1] )
			{
				bool t=true;
				v[i1]=false;	
				k=0;
				dep=0;
				find(i1);
				if(k<=l/2)	ans+=i1;
			}
		}
		printf("%d\n",ans);	
	}
	return 0;
}
