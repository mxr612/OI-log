#include<iostream>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#define rint register int 
using namespace std;
const int MAX=1+5e5,inf=998244353;
int v[105][2005],a[105][2005],curr_operators,total_operators;
bool operators(int y,int x,int n,int m){
	if(a[y][x]==-1)
		return false;
	for(int i=1;i<=m;i++)
		if(a[y][i]==1)
			return false;
	rint cnt=0;
	for(int i=1;i<=n;i++)
		if(a[i][x]==1)
			cnt++;
	if(cnt>total_operators)
		return false;
	curr_operators++;		
	a[x][y]=1;
	return true;
}
int main(){
	memset(v,0,sizeof(v));
	memset(a,0,sizeof(a));
	rint n,m,ans=1;
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			cin>>v[i][j];
			if(!v[i][j])
				a[i][j]=-1;
		};		
	for(int i=2;i<=n;i++){
		total_operators=i;
		curr_operators=0;
		for(int y=1;y<=n;y++)
			for(int x=1;x<=m&&curr_operators<total_operators;x++){
				if(operators(y,x,n,m))
					ans++;	
			}				
	};
	cout<<ans<<endl;			
}
