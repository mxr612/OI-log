#include<iostream>
#include<cstring>
#include<cstdio>
#include<cstdlib>
#include<cmath>
using namespace std;
const int MAX=1+5e5;
int a[MAX],p[MAX],l[MAX],r[MAX],b[MAX];
int main(){
	int n,type;
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>type;
	if(!type)
		for(int i=1;i<=n;i++)
			cin>>a[i];
	else{
		int x,y,z,m;
		cin>>x>>y>>z>>b[1]>>b[2]>>m;
		long long inf=pow(2,30);
		for(int k=1;k<=m;k++)
			cin>>p[k]>>l[k]>>r[k];
		for(int k=3;k<=n;k++)
			b[k]=(x*b[k-1]+y*b[k-2]+z)%inf;
		for(int k=1;k<=m;k++)
			for(int q=1;q<=n;q++)
				if(p[k-1]<q<p[k])
					a[q]=b[q]%(r[k]-l[k]+1)+l[k];				
	}				
	int i=1,j=2,p=2;
	while(i<n){
		while(j<=n){
			if(a[i]<=a[j]){
				i++;
				j++;
				p++;
				break;
			}
			if(a[i]>a[j]){
				int x=0;
				while(p<=n&&x<a[i])
					x+=a[p++];	
				if(a[i]+a[j]<=x||!x){
					a[i]+=a[j];
					a[j]=0;
					i=j;
					j++;
					break;
				}
				else{
					a[j]=x;
					for(int q=p-1;q>=j+1;q--)
						a[q]=0;
					i=j;
					j=p;
					break;	
				}	
			}	
		}
	}
	long long ans=0;
	for(int i=1;i<=n;i++)
		ans+=a[i]*a[i];	
	cout<<ans;				
}
