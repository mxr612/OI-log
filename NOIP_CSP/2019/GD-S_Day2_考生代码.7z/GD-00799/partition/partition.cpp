#include<cstdio>
#include<cstdlib>
#include<cstring>
int n,type;
long long sum=0,max=0;
long long last[500010];
int r[500010];
long long ans=0;
long long a[500010];
int len=0;

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d %d",&n,&type);
	if (type==0)
	{
		for (int i=1;i<=n;i++)
			scanf("%lld",&a[i]);
		sum=a[1],max=a[1];
		for (int i=2;i<=n;i++)
		{
			if (a[i]<max)
			{
				if (i==n)
				{
					sum+=a[i];
					if (sum<max)
					{
						bool tf=false;
						int tt=len;
						last[len]+=sum;
						while (tf==false)
						{
							tf=true;
							for (int i=len;i>=tt;i--)
							{
								while (last[i]-a[r[i-1]+1]>=last[i-1]+a[r[i-1]+1])
								{
									r[i-1]++;	
									last[i]-=a[r[i-1]];
									last[i-1]+=a[r[i-1]];
									tf=false;
									if (i==tt) tt--;
								}
							}
						}
					}
					else
					{
						len++;
						last[len]=sum;
						bool tf=false;
						int tt=len;
						while (tf==false)
						{
							tf=true;
							for (int i=len;i>=tt;i--)
							{
								while (last[i]-a[r[i-1]+1]>=last[i-1]+a[r[i-1]+1])
								{
									r[i-1]++;	
									last[i]-=a[r[i-1]];
									last[i-1]+=a[r[i-1]];
									tf=false;
									if (i==tt) tt--;
								}
							}
						}
					}
				}
				else
				{
					if (a[i+1]<sum && sum>=max)
					{
						len++;
						last[len]=sum;
						r[len]=i-1;
						if (sum>max) max=sum;
						sum=a[i]+a[i+1];
						if (sum>max) max=sum;
						i++;
					}
					else
					{
						sum+=a[i];
						if (sum>max) max=sum;
					}
				}
			}
			else
			{
				len++;
				last[len]=sum;
				r[len]=i-1;
				sum=a[i];
				max=a[i];
				if (i==n)
				{
					len++;
					last[len]=sum;
					r[len]=n;
				}
			}
		}
		for (int i=1;i<=len;i++)
		{
			ans=ans+last[i]*last[i];
//			printf("%d %d\n",last[i],r[i]);
		}
//		system("pause");
		printf("%lld\n",ans);
	}
}
