#include<cstdio>
#include<cstdlib>
#include<cstring>
int t;
int n;
struct node{int x,y,next;};
node s[600010];
int len=0;
int p[300010];
int du[300010],to[300010];
int first[300010];

void ins(int x,int y)
{
	len++;
	s[len].x=x;s[len].y=y;
	s[len].next=first[x];first[x]=len;
}

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&t);
	while (t--)
	{
		long long ans=0;
		memset(first,0,sizeof(first));
		scanf("%d",&n);
		for (int i=1;i<n;i++)
		{
			int x,y;
			scanf("%d %d",&x,&y);
			p[i]=x;
			p[i+1]=y;
			du[x]++;du[y]++;
			ins(x,y);
			ins(y,x);
		}
		for (int i=1;i<=n;i++)
			to[du[i]]++;
		if (to[1]==2 && to[2]==n-2)
		{
			for (int i=1;i<n;i++)
			{
				if (i&1)
				{
					if ((n-i)&1) ans=ans+p[(i+1)/2]+p[(n-(n-i+1)/2)];
					else ans=ans+p[(i+1)/2]+p[(n-(n-i)/2)]+p[(n-(n-i)/2+1)];
				}
				else
				{
					if ((n-i)&1) ans=ans+p[i/2]+p[i/2+1]+p[(n-(n-i)/2)];
					else ans=ans+p[i/2]+p[i/2+1]+p[(n-(n-i)/2)]+p[(n-(n-i)/2+1)];
				}
//				printf("%lld\n",ans);
//				system("pause");
			}
		}
		if (n==1) ans=1;
		if (n==2) ans=3;
		if (n==3) ans=12;
		printf("%lld\n",ans);
	}
}
