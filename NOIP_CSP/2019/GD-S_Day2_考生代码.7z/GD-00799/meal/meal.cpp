#include<cstdio>
#include<cstdlib>
#include<cstring>
int n,m;
long long a[110][2010];
int mod=998244353;
long long ans=0;
long long tot[2010];
long long zh[2010];
long long jc[2010];
bool v[110];
bool tf=false;
long long sum=0;

long long ksm(long long x,long long y)
{
	long long c=1;
	while (y>=1)
	{
		if (y&1) c=c*x%mod;
		x=x*x%mod;
		y/=2;
	}
	return c;
}

void dfs(int x,int xz,int d,long long t)
{
	if (x==d+1)
	{
		sum+=t;
		sum%=mod;
		return;
	}
	for (int i=1;i<=n;i++)
	{
		if (!v[i])
		{
			for (int j=1;j<=m;j++)
			{
				if (a[i][j]>0 && tot[j]+1<=xz)
				{
					tot[j]++;
					v[i]=true;
					zh[x]=a[i][j];
					dfs(x+1,xz,d,t*a[i][j]);
					tot[j]--;
					v[i]=false;
				}
			}
		}
	}
	
}

int main()
{
	freopen("meal.in","r",stdin);
	freoepn("meal.out","w",stdout);
	scanf("%d %d",&n,&m);
	jc[0]=1;
	for (int i=1;i<=n;i++)
	{
		jc[i]=jc[i-1]*i;
		for (int j=1;j<=m;j++)
		{
			scanf("%lld",&a[i][j]);
		}
	}
	for (int i=2;i<=n;i++)
	{
		if (i&1 && m==2) continue;
		sum=0;
		dfs(1,i/2,i,1);
		ans=(ans+sum*ksm(jc[i],mod-2)%mod)%mod;
	}
	printf("%lld\n",ans%mod);
}
