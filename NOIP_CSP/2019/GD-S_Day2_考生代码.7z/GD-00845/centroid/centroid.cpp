#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
#include<queue>
using namespace std;
const int c=3e5+10;
struct node{ int x,y;} lu[c];
vector <int> h[c];
queue <int> q;
int Tsize[c],size[c],dep[c],son[c],n;
void dfs(int u,int fa,int cnt){
	size[u]=1;
	for(int i=h[u].size()-1;i>=0;i--) {
		int v=h[u][i];
		if(v==fa) continue;
		dfs(v,u,cnt);
		if(size[v]>size[son[u]]) son[u]=v;
		size[u]+=size[v];
	}
	if(size[son[u]]*2<=cnt&&(cnt-size[u])*2<=cnt) q.push(u);
}
void deal_first(int u,int fa) {
	Tsize[u]=1;
	dep[u]=dep[fa]+1;
	for(int i=h[u].size()-1;i>=0;i--) {
		int v=h[u][i];
		if(v==fa) continue;
		deal_first(v,u);
		Tsize[u]+=Tsize[v];
	}
}
void slove() {
	scanf("%d",&n);
	for(int i=1,x,y;i<=n-1;++i) {
		scanf("%d%d",&lu[i].x,&lu[i].y);
		x=lu[i].x;y=lu[i].y;
		h[x].push_back(y);
		h[y].push_back(x);
	}
	deal_first(1,0);
	long long ans=0;
	for(int i=1;i<=n-1;++i) {
		int u,v;
		if(dep[lu[i].x]<dep[lu[i].y]) u=lu[i].x,v=lu[i].y;
		else u=lu[i].y,v=lu[i].x;
		memset(size,0,sizeof(size));
		dfs(u,v,n-Tsize[v]);
		memset(size,0,sizeof(size));
		dfs(v,u,Tsize[v]);
	} 
	for(int i=1;i<=n;++i) h[i].clear();
	while(!q.empty()) {
		//printf("%d ",q.front());
		ans+=q.front();q.pop();
	}
	printf("%lld\n",ans);
}
int main() {
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--) slove();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
