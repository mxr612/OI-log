#include<iostream>
#include<cstdio>
using namespace std;
const int mod=998244353;
int a[110][2100],dp[110][2100];
int n,m;
int main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i) {
		for(int j=1;j<=m;++j) {
			scanf("%d",&a[i][j]);
			dp[i][j]=dp[i][j-1]+a[i][j];
		}
	}
	int qua=0;
	for(int i=1;i<n;++i) {
		for(int j=1;j<=m;++j) {
			int sum=0;
			for(int q=i+1;q<=n;++q) {
				sum+=dp[q][m]-a[q][j];
			}
			qua+=sum*a[i][j];
		}
	}
	printf("%d",qua);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
