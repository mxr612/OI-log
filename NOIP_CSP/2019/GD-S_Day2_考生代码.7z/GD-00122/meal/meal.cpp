#include <cstdio>
#include <algorithm>
#include <cstring>
#define ll long long

using namespace std;

const int N = 1e2 + 5,M = 2e3 + 5,mo = 998244353;

int n,m;
int a[N][M];
ll ans;
ll f[2][N][N],g[N][N],sum[N];

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i = 1 ; i <= n ; i++) for (int j = 1 ; j <= m ; j++) scanf("%d",&a[i][j]),sum[i] = (sum[i] + a[i][j]) % mo;
	g[0][0] = 1;
	for (int i = 0 ; i < n ; i++)
		for (int j = 0 ; j <= i ; j++)
		{
			for (int k = 1 ; k <= m ; k++) 
				if (a[i + 1][k]) g[i + 1][j + 1] = (g[i + 1][j + 1] + g[i][j] * a[i + 1][k] % mo) % mo;
			g[i + 1][j] = (g[i + 1][j] + g[i][j]) % mo;
		}
	for (int x = 1 ; x <= m ; x++)
	{
		memset(f,0,sizeof(f));
		int opt = 0;
		f[0][0][0] = 1;
		for (int i = 0 ; i < n ; i++)
		{
			memset(f[opt ^ 1],0,sizeof(f[opt ^ 1]));
			for(int j = 0 ; j <= i ; j++)
			{
				for (int k = 0 ; k <= j ; k++)
				{
					f[opt ^ 1][j + 1][k] = (f[opt ^ 1][j + 1][k] + f[opt][j][k] * (sum[i + 1] - a[i + 1][x] + mo) % mo) % mo;
					if (a[i + 1][x]) f[opt ^ 1][j + 1][k + 1] = (f[opt ^ 1][j + 1][k + 1] + f[opt][j][k] * a[i + 1][x] % mo) % mo;
					f[opt ^ 1][j][k] = (f[opt ^ 1][j][k] + f[opt][j][k]) % mo;
				}
			}
			opt ^= 1;
		}
		for (int i = 2 ; i <= n ; i++) 
		{
			ll res = 0;
			for (int k = i / 2 + 1 ; k <= i ; k++) res = (res + f[opt][i][k]) % mo;
			g[n][i] = (g[n][i] - res + mo) % mo;
		}
	}
	for (int i = 2 ; i <= n ; i++) ans = (ans + g[n][i]) % mo;
	ans = (ans + mo) % mo;
	printf("%lld\n",ans);
	return 0;
}


