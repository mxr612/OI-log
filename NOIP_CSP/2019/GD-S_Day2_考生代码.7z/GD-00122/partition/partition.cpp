#include <cstdio>
#include <algorithm>
#include <cstring>
#define ll long long

using namespace std;

const int N = 1e3 + 5;

int n,typ;
int a[N],vis[N];
ll ans = 1e18;

ll sqr(ll x)
{
	return x * x;
}

void calc()
{
	ll res = a[1],sum = 0,lst = 0;
	for (int i = 2 ; i <= n ; i++)
		if (!vis[i]) 
		{
			if (lst > res) return;
			sum += sqr(res);
			lst = res;
			res = a[i];
		}
		else res += a[i];
	if (lst > res) return;
	if (res) sum += sqr(res);
	ans = min(ans,sum);
}

void dfs(int x)
{
	if (x == n + 1) { calc(); return; }
	for (int i = 0 ; i <= 1 ; i++) vis[x] = i,dfs(x + 1);
}

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&typ);
	for (int i = 1 ; i <= n ; i++) scanf("%d",&a[i]);
	dfs(2);
	printf("%lld\n",ans);
	return 0;
}
