#include <cstdio>
#include <algorithm>
#include <cstring>
#define ll long long

using namespace std;

const int N = 3e5 + 5;

struct Edge
{
	int to,next;
}edge[N << 1];

struct Edge2
{
	int u,v;
}e[N];

int T,n,tot,sum,tail;
int st[N],size[N],mx[N],vis[N],d[N],fa[N],b[N],son[N][2],son_t[N];
ll ans;

void clr()
{
	ans = 0;
	tot = 0;
	memset(st,0,sizeof(st));
	memset(d,0,sizeof(d));
	memset(fa,0,sizeof(fa));
	memset(vis,0,sizeof(vis));
	memset(size,0,sizeof(size));
	memset(mx,0,sizeof(mx));
	memset(son,0,sizeof(son));
	memset(son_t,0,sizeof(son_t));
}

int read()
{
	int f = 0;
	char ch = getchar();
	while (ch < '0' || ch > '9') ch = getchar();
	while (ch >= '0' && ch <= '9') f = f * 10 + ch - '0',ch = getchar();
	return f;
}

void link(int u,int v)
{
	edge[++tot].to = v;
	edge[tot].next = st[u];
	st[u] = tot;
}

void dfs(int x)
{
	sum++,vis[x] = size[x] = 1;
	for (int l = st[x] ; l ; l = edge[l].next)
	{
		int v = edge[l].to;
		if (vis[v]) continue;
		dfs(v);
		size[x] += size[v];
		mx[x] = max(mx[x],size[v]);
	}
}

void solve(int x)
{
	sum = 0;
	dfs(x);
	for (int i = 1 ; i <= n ; i++) 
		if (vis[i]) 
		{
			if (max(mx[i],sum - size[i]) <= sum / 2) ans += i;
			size[i] = mx[i] = vis[i] = 0;
		}
}

void work(int x)
{
	b[++tail] = x;
	vis[x] = 1;
	for (int l = st[x] ; l ; l = edge[l].next)
	{
		int v = edge[l].to;
		if (vis[v]) continue;
		work(v);
	}
}

int query(int l,int r)
{
	int x = r - l + 1;
	return x & 1 ? b[(l + r) / 2] : b[(l + r) / 2] + b[(l + r + 1) / 2];
}

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	T = read();
	while (T--)
	{
		clr();
		n = read();
		for (int i = 1,u,v ; i < n ; i++) u = read(),v = read(),d[u]++,d[v]++,link(u,v),link(v,u),e[i] = ((Edge2){u,v});
		int flag = 1;
		for (int i = 1 ; i <= n ; i++) if (d[i] > 2) { flag = 0; break; }
		if (flag)
		{
			int pos = 0;
			for (int i = 1 ; i <= n ; i++) if (d[i] == 1) { pos = i; break; }
			tail = 0;
			work(pos);
			for (int i = 1 ; i < n ; i++) ans += query(1,i) + query(i + 1,n);
			printf("%lld\n",ans);
			continue;
		}
		for (int i = 1 ; i < n ; i++)
		{
			vis[e[i].u] = vis[e[i].v] = 1;
			solve(e[i].u);
			vis[e[i].u] = vis[e[i].v] = 1;
			solve(e[i].v);
		}
		printf("%lld\n",ans);
	}
	return 0;
}
