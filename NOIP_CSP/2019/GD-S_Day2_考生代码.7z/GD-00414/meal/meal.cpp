#include <iostream>
#include <memory.h>
using namespace std;

int n , m , deep ;
long long Ans = 0 ;
const long long mod = 998244353 ;
int C[2010] ;
int M[105][2005] ;


void DFS(long long sum , int ge , int b){
	if (!ge){
		Ans = (Ans+sum) % mod ;
		return ;
	}
	for (int i=b;i<=n;i++)
		for (int j=1;j<=m;j++)
			if (C[j]+1 <= deep/2){
				if (!M[i][j])		continue ;
				C[j]++;
				DFS ((sum*M[i][j])%mod , ge-1 , i+1) ;
				C[j]--;
			}
	return ;
}

int main (){
	freopen ("meal.in","r",stdin) ;
	freopen ("meal.out","w",stdout);
	memset(M,0,sizeof (M)) ;
	cin >> n >> m ;
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
			cin >> M[i][j] ;		
			
	for (deep=2;deep<=n;deep++){
		memset (C,0,sizeof (C)) ;
		DFS(1,deep,1) ;
	}
	cout << Ans % mod ;
	fclose(stdin) ;
	fclose(stdout);
	return 0;
}
