#include<cstring>
#include<cstdio>
#define N 300000
using namespace std;
void read(int &n){
	int c;for(n=0;(c=getchar())>57||c<48;);
	for(;c>47&&c<58;c=getchar())n=n*10+c-48;
}
int n,fir[N],nex[N+N],to[N+N],top,fa[N],nx[19][N],hvy[N],sz[N],tp[N],S,ms[N],W,st[N],bl[N],tot,l[N],r[N],d[N],R,smx[N];
long long ans;
#define link(x,y) to[++top]=y,nex[top]=fir[x],fir[x]=top
void dg(int x){
	++tot;l[x]=tot;smx[x]=0;
	hvy[x]=0;sz[x]=1;tp[x]=x;
	for(int i=fir[x];i;i=nex[i]){
		int y=to[i];if(y==fa[x])continue;
		fa[y]=x;dg(y);sz[x]+=sz[y];
		if(sz[y]>sz[hvy[x]])smx[x]=hvy[x],hvy[x]=y;
	}nx[0][x]=hvy[x];tp[hvy[x]]=x;
	r[x]=tot;
}
void dfs1(int x,int c){
	if(tp[x]==x){
		int P=0;
		for(int X=x;X;X=hvy[X]){
			int Q=sz[x]-sz[X]<=sz[x]/2;
			for(int i=fir[X];i;i=nex[i]){
				int y=to[i];if(y==fa[X])continue;
				if(sz[y]>sz[x]/2){Q=0;break;}
			}
			if(Q)P=X;
		}c=P;
	}
	if(x^R){
		ans+=c;
		if(c^x){
			if(sz[hvy[fa[c]]]<=sz[x]/2&&sz[x]-sz[fa[c]]<=sz[x]/2)ans+=fa[c];
		}
		if(hvy[c]){
			if(sz[hvy[hvy[c]]]<=sz[x]/2&&sz[x]-sz[hvy[c]]<=sz[x]/2)ans+=hvy[c];
		}
	}
	for(int i=fir[x];i;i=nex[i]){
		int y=to[i];if(y==fa[x]||y==hvy[x])continue;
		dfs1(y,0);
	}
	if(hvy[x]){
		if(x==c)c=hvy[x];x=hvy[x];
		while(sz[hvy[c]]>sz[x]/2||sz[x]-sz[c]>sz[x]/2)c=hvy[c];
		dfs1(x,c);
	}
}
void dfs3(int x,int c){
	if(tp[x]==x){
		int P=0;
		for(int X=x;X;X=hvy[X]){
			int Q=sz[x]-sz[X]<=sz[x]/2;
			for(int i=fir[X];i;i=nex[i]){
				int y=to[i];if(y==fa[X])continue;
				if(sz[y]>sz[x]/2){Q=0;break;}
			}
			if(Q)P=X;
		}c=P;
	}
	if(x^W){
		ans+=c;
		if(c^x){
			if(sz[hvy[fa[c]]]<=sz[x]/2&&sz[x]-sz[fa[c]]<=sz[x]/2)ans+=fa[c];
		}
		if(hvy[c]){
			if(sz[hvy[hvy[c]]]<=sz[x]/2&&sz[x]-sz[hvy[c]]<=sz[x]/2)ans+=hvy[c];
		}
	}
	for(int i=fir[x];i;i=nex[i]){
		int y=to[i];if(y==fa[x]||y==hvy[x])continue;
		if(ms[y])dfs3(y,0);
	}
	if(hvy[x]&&ms[hvy[x]]){
		if(x==c)c=hvy[x];x=hvy[x];
		while(sz[hvy[c]]>sz[x]/2||sz[x]-sz[c]>sz[x]/2)c=hvy[c];
		dfs3(x,c);
	}
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int _;scanf("%d",&_);
	while(_--){
		scanf("%d",&n);ans=0;tot=0;
		for(int i=1;i<=n;++i)fir[i]=0,ms[i]=0,d[i]=0;top=0;
		for(int i=1;i<n;++i){
			int x,y;read(x);read(y);
			link(x,y);link(y,x);++d[x];++d[y];
		}
		for(int i=1;i<=n;++i)if(d[i]==1)R=i;
		fa[R]=0;dg(R);
		for(int j=1;j<19;++j)for(int i=1;i<=n;++i)nx[j][i]=nx[j-1][nx[j-1][i]],tp[i]=tp[tp[i]];
		dfs1(R,0);
		for(int x=1;x<=n;++x)if(tp[x]^R){
			int c=R,S=n-sz[x];
			for(int j=18;j+1;--j)if(nx[j][c]){
				int X=nx[j][c];
				if(sz[hvy[X]]-(l[hvy[X]]<=l[x]&&r[hvy[X]]>=r[x]?sz[x]:0)>S/2)c=X;
				else if(smx[X])if(sz[smx[X]]-(l[smx[X]]<=l[x]&&r[smx[X]]>=r[x]?sz[x]:0)>S/2)c=X;
			}c=hvy[c];
			ans+=c;
			if(fa[c]){
				int tt=hvy[fa[c]],tl=smx[fa[c]];
				if(sz[tt]-(l[tt]<=l[x]&&r[tt]>=r[x]?sz[x]:0)<=S/2&&S-sz[fa[c]]+(l[fa[c]]<=l[x]&&r[fa[c]]>=r[x]?sz[x]:0)<=S/2)
				//if(!tl||sz[tl]-(l[tl]<=l[x]&&r[tl]>=r[x]?sz[x]:0)<=S/2)
				ans+=fa[c];
			}
			if(hvy[c]){
				int tt=hvy[hvy[c]],tl=smx[hvy[c]];
				if(sz[tt]-(l[tt]<=l[x]&&r[tt]>=r[x]?sz[x]:0)<=S/2&&S-sz[hvy[c]]+(l[hvy[c]]<=l[x]&&r[hvy[c]]>=r[x]?sz[x]:0)<=S/2)
				//if(!tl||sz[tl]-(l[tl]<=l[x]&&r[tl]>=r[x]?sz[x]:0)<=S/2)
				ans+=hvy[c];
			}
		}
		for(int i=1;i<=n;++i)if(tp[i]==R)ms[i]=1;
		for(int i=1;i<=n;++i)if(!hvy[i]&&tp[i]==R){
			tot=0;fa[i]=0;dg(i);W=i;
			for(int j=1;j<19;++j)for(int x=1;x<=n;++x)tp[x]=tp[tp[x]];
			dfs3(i,0);break;
		}printf("%lld\n",ans);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
