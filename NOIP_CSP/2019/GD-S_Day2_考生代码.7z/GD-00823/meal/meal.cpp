#include<cstring>
#include<cstdio>
#define mo 998244353
using namespace std;
int n,m,a[110][2100],f[45][45][45],g[45][45][45][45];
void add(int &x,long long v){x=(x+v)%mo;}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;++i)for(int j=1;j<=m;++j)scanf("%d",&a[i][j]);
	if(m==2){
		f[0][0][0]=1;
		for(int i=0;i<=n;++i)for(int j=0;j<=i;++j)for(int k=0;k<=i;++k)if(f[i][j][k])
			add(f[i+1][j][k],f[i][j][k]),add(f[i+1][j+1][k],1ll*a[i+1][1]*f[i][j][k]),add(f[i+1][j][k+1],1ll*a[i+1][2]*f[i][j][k]);
		int ans=0;
		for(int i=2;i<=n;++i)for(int j=0;j<=i/2;++j)for(int k=0;k<=i/2;++k)if(j+k==i)add(ans,f[n][j][k]);
		printf("%d",ans);
	}else
	if(m==3){
		g[0][0][0][0]=1;
		for(int i=0;i<=n;++i)for(int j=0;j<=i;++j)for(int k=0;k<=i;++k)for(int l=0;l<=i;++l)if(g[i][j][k][l])
			add(g[i+1][j][k][l],g[i][j][k][l]),
			add(g[i+1][j+1][k][l],1ll*a[i+1][1]*g[i][j][k][l]),
			add(g[i+1][j][k+1][l],1ll*a[i+1][2]*g[i][j][k][l]),
			add(g[i+1][j][k][l+1],1ll*a[i+1][3]*g[i][j][k][l]);
		int ans=0;
		for(int i=2;i<=n;++i)for(int j=0;j<=i/2;++j)for(int k=0;k<=i/2;++k)for(int l=0;l<=i/2;++l)if(j+k+l==i)add(ans,g[n][j][k][l]);
		printf("%d",ans);
		
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
