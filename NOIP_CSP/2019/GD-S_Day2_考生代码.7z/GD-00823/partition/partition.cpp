#include<cstring>
#include<cstdio>
#include<iostream>
using namespace std;
void read(int &n){
	int c;for(n=0;(c=getchar())>57||c<48;);
	for(;c>47&&c<58;c=getchar())n=n*10+c-48;
}
int n,a[500100],k[500100];
long long sm[500100],ans;
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int tp;scanf("%d %d",&n,&tp);
	for(int i=1;i<=n;++i)read(a[i]),sm[i]=sm[i-1]+a[i];
	long long ls=0,nw=0;
	int tt=0;
	for(int i=1;i<=n;++i){
		nw+=a[i];if(nw>=ls)k[++tt]=i,ls=nw,nw=0;
	}k[tt]=n;ans=5e18;long long res=0;
	for(int i=1;i<=tt;++i){
		int h=k[i],t=n,T=i,P=k[i],m;long long LS=0;
		if(i>1)for(int j=k[i-2]+1;j<=k[i-1];++j)LS+=a[i];
		while(h<=t){
			m=h+t>>1;
			long long lls=LS,nnw=0;
			for(int o=k[i-1]+1;o<=m;++o)nnw+=a[o];
			lls=nnw;nnw=0;T=i;
			for(int o=m+1;o<=n;++o){
				nnw+=a[o];
				if(nnw>=lls)lls=nnw,nnw=0,++T;
			}
			if(T<tt)t=m-1;else P=m,h=m+1;
		}k[i]=P;
			long long lls=LS,nnw=0;
			for(int o=k[i-1]+1;o<=P;++o)nnw+=a[o];
			lls=nnw;nnw=0;T=i;
			for(int o=P+1;o<=n;++o){
				nnw+=a[o];
				if(nnw>=lls)lls=nnw,nnw=0,k[++T]=o;
			}k[T]=n;
	}
	ans=0;
	for(int i=1;i<=tt;++i)ans+=(sm[k[i]]-sm[k[i-1]])*(sm[k[i]]-sm[k[i-1]]);
	cout<<ans;
	fclose(stdin);fclose(stdout);
	return 0;
} 
