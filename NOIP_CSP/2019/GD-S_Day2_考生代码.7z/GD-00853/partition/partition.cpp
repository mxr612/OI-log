#include<bits/stdc++.h>
#define R register
#define I inline
#define V void
#define ll long long
using namespace std;
I int read()
{
	R int num=0,f=1;
	R char ch=getchar();
	while(0==isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(0!=isdigit(ch))num=(num<<3)+(num<<1)+ch-'0',ch=getchar();
	return num*f;
}
const int N=40000000+7;
long long a[N];
ll l=0,r=0,ans=0;
I ll ping(R ll x)
{
	return x*x;
}
int n=0,type=0;
ll x,y,z,b1,b2,m;
ll q[N],hou[N],top=0;
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=read();type=read();
	l=0;r=0;
	ans=(9e18);
	for(R int i=1;i<=n;i++)
	{
		a[i]=read();
		r+=a[i];
	}
	for(R int i=n;i>=1;i--)
	{
		hou[i]=hou[i+1]+a[i];
	}
	q[++top]=a[1];
	a[++n]=(ll)5e18;
	for(R int i=2;i<=n;i++)
	{
		if(a[i]>=q[top])
		{
			q[++top]=a[i];
			continue;
		}
		else
		{
			R int j=i;
			R int sum=0;
			while(sum<q[top]&&j<=n)
			{
				sum+=a[j];
				j++;
			}
			j--;
			if(sum==q[top])q[++top]=sum,i=j;
			else
			{
				R int k=i;
				while(q[top]+a[k]<=sum-a[k]&&k<=j)
				{
					q[top]+=a[k];sum-=a[k];
					k++;
				}
				q[++top]=sum;i=j;
			}
		}
	}
	R ll sum=0;
	for(R int i=1;i<=top-1;i++)
	{
		sum+=ping(q[i]);
	}
	cout<<sum;
	return 0;
}
