#include<bits/stdc++.h>
#define R register
#define I inline
#define V void
#define ll long long
using namespace std;
I int read()
{
	R int num=0,f=1;
	R char ch=getchar();
	while(0==isdigit(ch)){if(ch=='-')f=-1;ch=getchar();}
	while(0!=isdigit(ch))num=(num<<3)+(num<<1)+ch-'0',ch=getchar();
	return num*f;
}
const int N=100+3;
const int M=2000+3;
const int mod=998244353;
int jc[N],inv[N],jc_inv[N];
int a[N][M];
int n=0,m=0;
I ll power(R ll a,R ll b)
{
	R ll res=1;
	for(;b;b>>=1)
	{
		if(b&1)res=res*a%mod;
		a=a*a%mod;
	}
	return res;
}
I ll C(R int n,R int m)
{
	if(n<m)return 0;
	if(m==0)return 1;
	return (jc[n]*jc_inv[m])%mod*jc_inv[n-m]%mod;
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read();m=read();
	R int numa=0,numb=0,numc=0;
	for(R int i=1;i<=n;i++)
	{
		for(R int j=1;j<=m;j++)
		{
			a[i][j]=read();
			if(j==2)
			{
				if(a[i][1]==1)numa++;
				if(a[i][2]==1)numb++;
				if(a[i][1]==1&&a[i][2]==1)numc++;
			}
		}
	}
	jc[0]=1;
	for(R int i=1;i<=n;i++)jc[i]=(jc[i-1]*i)%mod;
	inv[0]=1;inv[1]=1;jc_inv[0]=1;
	for(R int i=2;i<=n;i++)inv[i]=(mod-mod/i)*inv[mod%i];
	for(R int i=1;i<=n;i++)jc_inv[i]=jc_inv[i-1]*inv[i]%mod;
	R int need=1;
	if(numa<numb)swap(numa,numb);
	R int lesa=numa-numc,lesb=numb-numc;
	R ll ans=0;
	while(need*2<=n)
	{
		if((lesb+numc)<need||(lesa+numc)<need)break;
		for(R int i=0;i<=lesa;i++)
		{
			R int a_needc=need-i;
			R int lesc=numc-a_needc;
			if(a_needc<=numc&&lesc+lesb>=need)
			{
				for(R int j=0;j<=lesb;j++)
				{
					if(j+lesc>=need)
					{
						R int b_needc=need-j;
						ans+=(C(lesa,i)*C(numc,a_needc)*C(numc-a_needc,b_needc)*C(lesb,j));
					}
				}
			}
		}
		need++;
	}
	cout<<ans;
	return 0;
}
