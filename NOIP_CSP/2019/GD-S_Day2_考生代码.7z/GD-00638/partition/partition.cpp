#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#define max_n 200
using namespace std;

int n,typ;
long long a[max_n],ans=0,maxx=0;

int DFS(int lasts,int dept)
{
	if(dept>n) return 0;
	int sum=0;
	int an=214748364;
	bool p=false;
	for(int i=dept;i<=n;i++)
	{
		sum+=a[i];
		if(sum>=lasts)
		{
			an=min(an,sum*sum+DFS(sum,i+1));
			p=true;
		}
	}
	if(!p) return an;
	return an;
}

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	
	scanf("%d%d",&n,&typ);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		maxx=max(maxx,a[i]);
	}
	if(n<=10)
	{
		cout<<DFS(0,1);
		return 0;
	}
	
	for(int i=1;i<=n;i++)
	{
		if(a[i]<=a[i+1])
			ans+=a[i]*a[i];
		else 
		{
			long long sum=a[i+1]+a[i];
			int j=i+2;
			bool p=false;
			for(j=i+2;j<=n;j++)
			{
				if(sum>maxx) break;
				if(sum<=a[j])
				{
					p=true;
					break;
				}
				sum+=a[j];
			}
			if(p)
			{
				ans=ans+sum*sum;
				i=j-1;
			}
			else
			{
				long long s1=0;
				bool po=false;
				int j;
				for(j=i+1;j<=n;j++)
				{
					s1+=a[j];
					if(s1>=a[i]&&s1<=a[j+1])
					{
						po=true;
						break;
					}
					if(s1>maxx) break;
				}
				if(po) 
				{
					
					ans+=a[i]*a[i]+s1*s1;
					i=j;
				}
				else 
				{
					if(s1>=40000000000LL) 
					{
						ans+=(a[i]+a[i+1])*(a[i]+a[i+1]);
						i=i+1;
					}
					else 
					{
						ans+=(a[i]+s1)*(a[i]+s1);
						i=j;
					}
				}
			}
		}
	}
	cout<<ans<<"\n";
	return 0;
}
