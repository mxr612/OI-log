#include<iostream>
#include<cstdio>
#include<cstring>
#define max_n 15000
using namespace std;

int T,n,head[150000],cur=1,r[2000][2000];
int x[max_n],y[max_n],ans=0,degree[20000];
struct EDGE{
	int target,ys,next_;
}edge[1500000];

void add_(int x,int y)
{
	edge[cur].target=y;
	edge[cur].next_=head[x];
	edge[cur].ys=true;
	head[x]=cur++;
	degree[y]++;
	return;
}

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		ans=0;
		scanf("%d",&n);
		for(int i=1;i<n;i++)
		{
			int x,y;
			scanf("%d%d",&x,&y);
			add_(x,y);
			add_(y,x);
		}
		printf("%d\n",(n-1)*(n+1)*n/2);
	}
	return 0;
}
