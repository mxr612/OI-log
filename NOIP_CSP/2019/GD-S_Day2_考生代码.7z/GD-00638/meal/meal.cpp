#include<iostream>
#include<cstdio>
#include<cstring>
#define max_n 120
#define max_m 2500
#define mod 998244353
using namespace std;

int n,m,a[max_n][max_m],dep[max_m],maxx=0,cnt=0,q[max_n];
long long ans=0;

void DFS(int dept,long long as)
{
	if(maxx>n/2) return;
	if(dept>n)
	{
		if(cnt<=1) return;
		if(maxx>cnt/2);
		else
			ans=(ans+as)%mod;
		return ;
	}
	
	for(int i=0;i<=m;i++)
	{
		if(a[dept][i]==0&&i!=0) continue;

		dep[i]++;
		int last_=maxx,lascnt=cnt;
		if(i!=0) maxx=max(maxx,dep[i]),cnt++;
		long long qq=as;
		if(i==0);
		else qq=(qq*a[dept][i])%mod;

		DFS(dept+1,qq);

		dep[i]--;
		maxx=last_;
		cnt=lascnt;
	}
	return; 
}

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&a[i][j]);

	DFS(1,1LL);

	printf("%lld\n",ans);
	return 0;
}
