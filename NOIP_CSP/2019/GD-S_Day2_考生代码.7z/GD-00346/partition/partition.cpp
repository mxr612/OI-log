#include <cstdio>
#include <iostream>
#include <cstring>
using namespace std;
int n,type,a[40001000];
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	if (type==0)
	{
		long long ans=0;
		for (int i=1;i<=n;i++) 
			scanf("%d",&a[i]);
		a[n+1]=1000001000;
		long long last=a[1];
		for (int i=2;i<=n+1;i++)
			if (last>a[i]) 
			{
				if (last+a[i]<=a[i+1]) last+=a[i];
					else a[i+1]+=a[i];
			}
			else 
			{
				ans+=(long long)last*last;
				last=a[i];
			}
		cout<<ans<<endl;
	}
	return 0;
}
