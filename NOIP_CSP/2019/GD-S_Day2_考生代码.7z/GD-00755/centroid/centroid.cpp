#include<bits/stdc++.h>
using namespace std;
#define MAXN 300000
int head[MAXN],ver[MAXN],next[MAXN],tot=0,c[MAXN]={0},line[MAXN]={0},mark[MAXN];
//count - x as index 
//mark - tot as index

void addedge(int x, int y)
{
	ver[++tot] = y;
	next[tot] = head[x];
	head[x] = tot;
	c[x]++;
}

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T;
	long long total=0;
	cin >> T;
	while(T--)
	{
		int n,i,u,v;
		memset(line,0,sizeof(mark));
		memset(mark,0,sizeof(mark));
		cin >> n;
		for(i=1;i<n;i++)
		{
			scanf("%d%d",&u,&v);
			addedge(u,v);
			addedge(v,u);
		}
		int ind,cnt=1;
		for(i=1;i<=n;i++)
			if(c[i]==1)
			{
				ind = i;
				break;
			}
		total = 0;
		int t;
		while(cnt <= n)
		{
			line[cnt] = ind;
			t = head[ind];
			if(mark[t])
				t = next[t];
			mark[t] = 1;
			if(t%2)
				mark[t+1] = 1;
			else
				mark[t-1] = 1;
			ind = ver[t];
			cnt++;
		}
		for(i=1;i<n;i++)
		{
			int rl = n-i,mid;
			if(i%2)
				total += line[(i+1)/2];
			else
				total += line[(i+1)/2] + line[(i+1)/2+1];
			
			if(rl%2)
				total += line[i+(1+rl)/2];
			else
				total += line[i+rl/2] + line[1+i+rl/2];
		}
		cout << total << endl;
	}
	return 0;
}
