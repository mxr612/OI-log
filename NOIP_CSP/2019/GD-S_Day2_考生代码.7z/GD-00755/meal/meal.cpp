#include<bits/stdc++.h>
using namespace std;

int a[105][2010],markn[105]={0},markm[2010]={0},n,m;
long long total=0,k,cnt=0;

void dfs(long long i, int maxn, int left, long long kinds)
{
	if(i > k)
		return;
	if(i == k)
	{
		if(maxn > k/2)
			return;
		cnt+=kinds;
		cnt %= 998244353;
		//cout << cnt << endl;
		return;
	}
	int p,q,r;
	for(p=left;p<=n;p++)
		//if(!markn[p])
		{
			//markn[p]=1;
			for(q=1;q<=m;q++)
				if(a[p][q])
				{
					markm[q]++;
					dfs(i+1,max(maxn,markm[q]),p+1,kinds*a[p][q]%998244353);
					markm[q]--;
				}
			//markn[p]=0;
		}
}    
	 
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	int i,j;
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++)
		for(j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
			total += a[i][j];
		}
	//cout << 11 << endl;
	for(k=2;k<=n;k++)
	{
		memset(markm,0,sizeof(markm));
		dfs(0,0,1,1);
		//cout << 21 << endl;
		//cout << k << ' ' << cnt << endl;
	}
	cout << cnt%998244353 << endl;
	return 0;
}
