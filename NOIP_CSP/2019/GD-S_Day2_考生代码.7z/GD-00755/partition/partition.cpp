#include<bits/stdc++.h>
using namespace std;

int a[500050],n;
long long minv = 1e18;

void dfs(long long s,long long ls,int ind)
{
	if(s > minv)
		return;
	//cout << s << ' ' << ls << ' ' << ind << endl;
	if(ind > n)
	{
		//cout << s << endl;
		minv = min(minv,s);
		return;
	}
	int i;
	long long t=0;
	for(i=ind;i<=n;i++)
	{
		t+=a[i];
		//cout << t << endl;
		if(t >= ls)
			dfs(s+t*t,t,i+1);
	}
}

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int type,i;
	cin >> n >> type;
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	dfs(0,0,1);
	cout << minv << endl;
	return 0;
}
