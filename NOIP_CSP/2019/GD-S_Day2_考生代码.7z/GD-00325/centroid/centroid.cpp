#include<iostream>
#include<cstdio>
using namespace std;
int ti,n,ans=0,a,b;
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	cin>>ti;
	while(ti--){
			cin>>n;
			for(int i=1;i<=n-1;i++)cin>>a>>b;
			for(int i=1;i<=n-1;i++){
				if(i%2){
					ans+=(i+1)/2;
					ans+=(i+1+n);
				}else{
					ans+=(i+1);
					ans+=(i+1+n)/2;
				}
			}
		}
	cout<<ans;
	return 0;
}
