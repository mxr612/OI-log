#include<iostream>
#include<cstdio>
using namespace std;
long long n,dp[401][10001],type,ma=0,ans=0x3f3f3f3f3f3f3f3fll,ji[401][401],s[401],a[401];
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>type;
	if(type==0){
		for(int i=1;i<=n;i++)cin>>a[i],ma=max(ma,a[i]),s[i]=a[i]+s[i-1];
		for(int i=1;i<=n;i++)
			for(int j=i;j<=n;j++)ji[i][j]=(s[j]-s[i-1])*(s[j]-s[i-1]);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=ma;j++)dp[i][j]=0x3f3f3f3f3f3f3f3fll;
		for(int i=1;i<=n;i++)
			for(int j=0;j<=i;j++)
				for(long long k=1;k<=ma;k++)
					for(long long l=1;l<=k;l++)
						if(j!=0&&k==max(l,s[i]-s[j]))dp[i][k]=min(dp[i][k],dp[j][l]+ji[j+1][i]);
		for(int i=1;i<=ma;i++)
			for(long long k=1;k<=ma;k++)ans=min(ans,dp[n][k]);
	}
	cout<<ans<<endl;
	return 0;
}
