#include <cstdio>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <cstring>
using namespace std;
long long mod=998244353;
long long ans=0,sn=0;
int N,type;
struct lb
{
	long long v;
	int l,r;
}A[5005];
long long qzh[5005];
void dfs(int now,long long maxn,long long sumn,long long nowans)
{
	if (nowans>=ans) return;
	if (now==N)
	{
		if (sumn<maxn) return;
		nowans+=sumn*sumn;
//		printf("%d %lld %lld %lld\n",now,maxn,sumn,nowans);
		ans=min(ans,nowans); 
		return;
	}
	if (sumn<=A[now+1].v && sumn>=maxn)
	{
		dfs(now+1,sumn,A[now+1].v,nowans+sumn*sumn);
		return;
	}
	if (sumn>=maxn) dfs(now+1,sumn,A[now+1].v,nowans+sumn*sumn);
	dfs(now+1,maxn,sumn+A[now+1].v,nowans);
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d %d",&N,&type);
	if (type==0)
	{
		for (int i=1;i<=N;i++)
		{
			scanf("%lld",&A[i].v);
			qzh[i]=qzh[i-1]+A[i].v;
			A[i].l=i; A[i].r=i;
			sn+=A[i].v;
		}
	} 
	ans=sn*sn;
    if (N<=10) dfs(1,0,A[1].v,0);
    else
    {
    	A[N+1].v=1e18;
        for (int i=1;i<=N;i++)
        {
        	if (A[i].v<=A[i+1].v) continue;
        	else
        	{
        		long long c1ans,c2ans;
        		//case 1
        		int L=i+1,R=i+1;
        		while(qzh[R]-qzh[L-1]<A[i].v && R<=N) R++;
        		if (R<=N) c1ans=(qzh[R]-qzh[L-1])*(qzh[R]-qzh[L-1]);
        		else c1ans=1e18;
//        		printf("%d,%d  ",L,R);
        		//case 2
        		c2ans=(A[i].v+A[i+1].v)*(A[i].v+A[i+1].v);
//        		printf("%lld vs %lld\n",c1ans,c2ans);
        		if (c1ans>c2ans)
        		{
        			A[i+1].v+=A[i].v;
        			A[i].v=0;
        		}
        		else
        		{
        		    for (int j=L;j<R;j++)
        		    {
        		    	A[R].v+=A[j].v;
        		        A[j].v=0;
        		    }
        		}
        	}
        }
        ans=0;
        for (int i=1;i<=N;i++)
        {
//        	printf("%lld\n",A[i].v);
        	ans+=A[i].v*A[i].v;
        }
    }
    printf("%lld",ans);
	return 0;
}
