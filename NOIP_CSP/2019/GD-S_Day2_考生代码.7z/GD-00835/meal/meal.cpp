#include <cstdio>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <cstring>
using namespace std;
long long mod=998244353;
long long dp[45][45][45][45]={0};
int N,M;
long long A[105][2005];
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d %d",&N,&M);
	for (int i=1;i<=N;i++)
	{
		for (int j=1;j<=M;j++)
		{
			scanf("%lld",&A[i][j]);
			if (j==1) dp[i][1][1][0]=A[i][j];
			if (j==2) dp[i][1][0][1]=A[i][j];
			if (j==3) dp[i][1][0][0]=A[i][j];
			dp[i][0][0][0]=0;
		}
	}
	for (int i=1;i<=N;i++)
	{
			for (int k=1;k<=i;k++)
			{
				for (int l=0;l<=k;l++)
				{
					for (int m=0;m<=k;m++)
					{
						dp[i][k][l][m]=(dp[i-1][k][l][m]+dp[i][k][l][m])%mod;
						for (int j=1;j<=M;j++)
		                {
						if (l+m>k) continue;
						if (j==1 && l!=0) dp[i][k][l][m]=(dp[i][k][l][m]+(dp[i-1][k-1][l-1][m]*A[i][j])%mod)%mod;
						if (j==2 && m!=0) dp[i][k][l][m]=(dp[i][k][l][m]+(dp[i-1][k-1][l][m-1]*A[i][j])%mod)%mod;
						if (j==3 && k-l-m!=0) dp[i][k][l][m]=(dp[i][k][l][m]+(dp[i-1][k-1][l][m]*A[i][j])%mod)%mod;
					    }
					}
				}
			}
	}
	long long ans=0;
	for (int k=2;k<=N;k++)
	{
		for (int l=0;l<=k/2;l++)
		{
			for (int m=0;m<=k/2;m++)
			{
				if (l+m>k) continue;
				if (k-l-m>k/2) continue;
				ans=(ans+dp[N][k][l][m])%mod;
			}
		}
	}
//	for (int i=1;i<=N;i++)
//	{
//		printf("%d:\n",i);
//		for (int j=1;j<=i;j++)
//		{
//			printf("%d---",j);
//			for (int l=0;l<=j;l++)
//			{
//				for (int k=0;k<=j;k++)
//				{
//					if (l+k>j) continue;
//					printf("A:%d B:%d C:%d to %lld\n",l,k,j-l-k,dp[i][j][l][k]);
//				}
//			}
//		}
//	}
	printf("%lld",ans);
	return 0;
}
