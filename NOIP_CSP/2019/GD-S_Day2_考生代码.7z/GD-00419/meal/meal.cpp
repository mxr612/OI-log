#include<bits/stdc++.h>
using namespace std;
const int mod=998244353;
int n,m;
int ans;
int sum[107];
int a[107][1007];
int dp[107][527];
void upd(int &x,int y){
	x=x+y>=mod?x+y-mod:x+y;
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	ans=1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%d",&a[i][j]);
			upd(sum[i],a[i][j]);
		}
		ans=1ll*ans*(sum[i]+1)%mod;
	}
	ans--;
	if(ans<0) ans+=mod;
	for(int k=1;k<=m;k++){
		dp[0][n]=1;
		for(int i=1;i<=n;i++){
			for(int j=1;j<2*n;j++){
				if(!dp[i-1][j]) continue;
				upd(dp[i][j],dp[i-1][j]);//������⿷�������
				upd(dp[i][j-1],1ll*dp[i-1][j]*a[i][k]%mod);//ʹ���ض�ʳ��
				upd(dp[i][j+1],1ll*dp[i-1][j]*((sum[i]-a[i][k]+mod)%mod)%mod);//��ʹ���ض�ʳ�� 
				dp[i-1][j]=0;
			}
		}
		for(int i=0;i<n;i++) upd(ans,mod-dp[n][i]);
		for(int i=0;i<=2*n;i++) dp[n][i]=0;
	}
	printf("%d\n",ans);
}
