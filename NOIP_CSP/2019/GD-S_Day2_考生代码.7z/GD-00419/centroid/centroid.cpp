#include<bits/stdc++.h>
#define now e[i].v
#define go(x) for(int i=head[x];i;i=e[i].nxt)
using namespace std;
const int sz=2e5+527;
typedef long long ll;
int n,T;
ll ans;
int u,v,cnt;
int siz[sz],mx[sz];
int head[sz];
struct Edge{
	int v,w,nxt;
}e[sz<<1]; 
struct bl{
	int u,v;
}ed[sz<<1];
void make_edge(int u,int v,int w){
	e[++cnt]=(Edge){v,w,head[u]};head[u]=cnt;
	e[++cnt]=(Edge){u,w,head[v]};head[v]=cnt;
}
void dfs(int x,int fa){
	siz[x]=1;
	go(x) if(now!=fa){
		dfs(now,x);
		siz[x]+=siz[now];
	}
}
void getans(int x,int fa,int sum){
	mx[x]=0;
	go(x) if(now!=fa){
		mx[x]=max(mx[x],siz[now]);
		getans(now,x,sum);
	}
	mx[x]=max(mx[x],sum-siz[x]);
	if(mx[x]<=sum/2) ans+=x;
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		cnt=ans=0;
		memset(head,0,sizeof(head));
		for(int i=1;i<n;i++){
			scanf("%d%d",&u,&v);
			make_edge(u,v,i);
			ed[i]=(bl){u,v};
		}
		for(int i=1;i<n;i++){
			u=ed[i].u,v=ed[i].v;
			dfs(u,v),dfs(v,u);
			getans(u,v,siz[u]),getans(v,u,siz[v]);
		}
		printf("%lld\n",ans);
	}
}
