#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int sz=5664;
const ll inf=2e9;
int n;
int type;
int pos[sz];
int a[sz];
ll sum[sz];
ll dp[sz][sz];
ll sq(ll x){
	return x*x;
}
ll Sum(int R,int L){
	if(L==0) return sum[R];
	else return sum[R]-sum[L-1];
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		sum[i]=sum[i-1]+a[i];
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=i;j++){
			if(sum[i]-sum[i-j]>inf){ pos[i]=j; break; }
			dp[i][j]=1ll*inf*inf;
			int l=1,r=i-j;
			while(l<r){
				int mid=(l+r+1)>>1;
				if(sum[i-j]-sum[i-j-mid]<=sum[i]-sum[i-j]) l=mid;
				else r=mid-1;
			}
			if(Sum(i,i-j+1)>=Sum(i-j,i-j-l+1)) dp[i][j]=dp[i-j][min(l,pos[i-j]-1)]+sq(Sum(i,i-j+1));
		}
		if(!pos[i]) pos[i]=i+1;
		for(int j=2;j<pos[i];j++) dp[i][j]=min(dp[i][j],dp[i][j-1]);
	}
	ll ans=inf*inf;
	for(int i=1;i<pos[n];i++) ans=min(ans,dp[n][i]);
	printf("%lld\n",ans);
}
