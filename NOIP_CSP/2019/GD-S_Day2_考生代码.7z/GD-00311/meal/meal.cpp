#include<cstdio>
#define ll long long
#define N 110
#define M 2010
#define inf 998244353
ll s;
int n,m,t[M],a[N][M];
void Meal(int x,int y,int z,ll v)
{
	if (x==n+1)
	{
		if (y==z) s+=v,s%=inf;
		return;
	}
	for (int i=1;i<=m;++i)
	if (t[i]<z>>1)
	{
		++t[i];
		Meal(x+1,y+1,z,v*a[x][i]%inf);
		--t[i];
	}
	Meal(x+1,y,z,v);
}
int main()
{
	freopen("meal.in","r",stdin);freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;++i) for (int j=1;j<=m;++j) scanf("%d",&a[i][j]);
	for (int i=2;i<=n;++i) Meal(1,0,i,1);
	printf("%lld",s);
	fclose(stdin);fclose(stdout);
	return 0;
}
