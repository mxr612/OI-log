#include<cstdio>
#define ll unsigned long long
#define sqr(T) ((T)*(T))
#define N 500010
int n,m;
ll a[N],s;
void Partition(int l,int k,ll v)
{
	if (s&&v>s) return;
	if (k==n+1)
	{
		s=v;
		return;
	}
	for (int i=0;i<=n-k;++i) if (!l||a[k-1]-a[l-1]<=a[k+i]-a[k-1]) 
	Partition(k,k+i+1,v+sqr(a[k+i]-a[k-1]));
}
int main()
{
	freopen("partition.in","r",stdin);freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;++i) scanf("%llu",&a[i]),a[i]+=a[i-1];
	Partition(0,1,0);
	printf("%llu",s);
	fclose(stdin);fclose(stdout);
	return 0;
}
