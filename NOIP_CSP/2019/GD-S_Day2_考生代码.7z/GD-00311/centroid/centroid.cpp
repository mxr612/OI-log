#include<cstdio>
#include<cstring>
#define N 50010
struct edge
{
	int to,nxt,bz;
}t[N<<1];
int head[N],m,n,s,f[N],F[N],cnt,From[N];
bool vis[N];
void add(int x,int y)
{
	t[++cnt]=(edge){y,head[x],0};
	head[x]=cnt;
}
void Tree(int k,int from)
{
	f[k]=1;
	From[k]=from;
	for (int i=head[k];i;i=t[i].nxt)
	if (!vis[t[i].to])
	{
		vis[t[i].to]=1;
		F[t[i].to]=k;
		Tree(t[i].to,from);
		f[k]+=f[t[i].to];
	}
}
int main()
{
	freopen("centroid.in","r",stdin);freopen("centroid.out","w",stdout);
	scanf("%d",&m);
	for (;m--;)
	{
		cnt=1;
		s=0;
		scanf("%d",&n);
		for (int i=1;i<=n;++i) head[i]=0;
		for (int i=1,x,y;i<n;++i) scanf("%d%d",&x,&y),add(x,y),add(y,x);
		for (int i=2;i<=cnt;i+=2)
		{
			for (int j=1;j<=n;++j) F[j]=f[j]=vis[j]=0;
			vis[t[i].to]=vis[t[i^1].to]=1;
			Tree(t[i].to,t[i].to);
			Tree(t[i^1].to,t[i^1].to);
			for (int j=1;j<=n;++j)
			if (f[From[j]]-f[j]<=f[From[j]]>>1)
			{
				bool bz=1;
				for (int k=head[j];k;k=t[k].nxt)
				if (From[j]==From[t[k].to]&&f[t[k].to]>f[From[j]]>>1&&t[k].to!=F[j])
				{
					bz=0;
					break;
				}
				if (bz) s+=j;
			}
		}
		printf("%d\n",s);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
