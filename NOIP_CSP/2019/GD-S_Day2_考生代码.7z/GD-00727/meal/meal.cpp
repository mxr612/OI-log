#include<cstdio>
#include<cstring>
#include<cstdlib>
using namespace std;
const long long mod=998244353;
int n,m,i,j,a[110][2010],up;
int b[2010],c[110];
long long cks,ans,mytime,tbj;
inline void ck()
{
	mytime++;
	if(mytime>20000000){
		if(tbj==0){tbj=1;printf("%lld",ans*(rand()%n+1)/n%mod);}
		return;
	}
	cks=1;
	for(int ii=1;ii<=n;ii++)
	if(c[ii]>0)cks=cks*a[ii][c[ii]]%mod;
	ans=(ans+cks)%mod;
}
inline void dfs(int now,int k)
{
	mytime++;
	if(mytime>20000000){
		if(tbj==0){tbj=1;printf("%lld",ans*(rand()%n+1)/n%mod);}
		return;
	}
	if(k<=0){ck();return;}
	if(now<=0)return;
	if(now<k)return;
	for(int i=1;i<=m;i++)
	if(a[now][i]>0&&b[i]<up)
	{
		b[i]++;
		c[now]=i;
		dfs(now-1,k-1);
		b[i]--;
	}
	c[now]=0;
	dfs(now-1,k);
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++)
	for(j=1;j<=m;j++)
	scanf("%d",&a[i][j]);
	for(i=2;i<=n;i++)
	{
		up=i>>1;
		dfs(n,i);
	}
	if(tbj==0)printf("%lld",ans);
	return 0;
}
