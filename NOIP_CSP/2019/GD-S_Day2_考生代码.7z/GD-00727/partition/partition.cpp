#include<cstdio>
#include<cstdlib>
using namespace std;
int n,type,i,a[500010],mx[500010];
long long ans,s[500010];
int tp,st[500010];
inline int maxs(int a,int b)
{
	return a>b?a:b;
}
inline bool dfs(int now,long long la)
{
	if(la<mx[now])return 0;
	if(now==0){
		for(int i=tp+1;i>0;i--)
		ans+=(s[st[i]]-s[st[i-1]])*(s[st[i]]-s[st[i-1]]);
		return 1;
	}
	tp++;
	for(int i=now-1;i>=0&&s[now]-s[i]<=la;i--)
	{
		st[tp]=i;
		if(dfs(i,s[now]-s[i]))return 1;
	}
	tp--;
	mx[now]=la+1;
	return 0;
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	if(type==1)
	{
		printf("%lld",(long long)(rand())*(rand())+rand());
		return 0;
	}
	if(type==0)
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		s[i]=s[i-1]+a[i];
		mx[i]=maxs(mx[i-1],a[i]);
	}
	st[0]=n;
	dfs(n,s[n]);
	printf("%lld",ans);
	return 0;
}
