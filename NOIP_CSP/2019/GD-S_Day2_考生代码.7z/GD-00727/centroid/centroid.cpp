#include<cstdio>
#include<cstring>
#include<cstdlib>
using namespace std;
int d[262150],t,n,u1,u2,g1,g2,g3,g4,y[524290],next[524290],bj[524290],la[262150],len,i,j;
inline void makesize(int xx,int yy)
{
	len++;
	y[len]=yy;
	next[len]=la[xx];
	la[xx]=len;
}
int line[50000],tp;
long long lineans[50000],sum;
inline void dfsline(int now,int fa)
{
	tp=0;
	while(tp<n)
	{
		line[++tp]=now;
		for(int i=la[now];i;i=next[i])
		if(y[i]!=fa)
		{
			fa=now;
			now=y[i];
			break;
		}
	}
}
long long tot[210];
inline void dfs(int now,int fa)
{
	tot[now]++;
	for(int i=la[now];i;i=next[i])
	if(bj[i]==0&&y[i]!=fa)
	{
		dfs(y[i],now);
		tot[now]+=tot[y[i]];
	}
}
inline bool check(int x)
{
	memset(tot,0,sizeof(tot));
	dfs(x,0);
	for(int i=la[x];i;i=next[i])
	if(tot[x]/2<tot[y[i]])return false;
	return true;
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&t);
	while(t-->0)
	{
		memset(la,0,sizeof(la));
		memset(bj,0,sizeof(bj));
		memset(d,0,sizeof(d));
		len=0;
		scanf("%d",&n);
		for(i=1;i<n;i++)
		{
			scanf("%d%d",&u1,&u2);
			makesize(u1,u2);
			makesize(u2,u1);
			d[u1]++;d[u2]++;
		}
		if(n>200)
		{
			g1=g2=g3=g4=0;
			for(i=1;i<=n;i++)
			{
				if(d[i]==1){u1=i;g1++;continue;}
				if(d[i]==2){u2=i;g2++;continue;}
				if(d[i]==3){g3++;continue;}
				g4++;
			}
			if(g2==1&&g1==g3+2)
			{
				sum=0;
				sum=n*(long long)(n+1)/2+u2*(long long)(n/2);
				for(i=la[u2];i;i=next[i])
				sum=sum+y[i]*(long long)(n/2);
				printf("%lld\n",sum);
			}
			else
			if(g2==n-2&&g1==2)
			{
				memset(lineans,0,sizeof(lineans));
				dfsline(u1,0);
				for(i=1;i<n;i++)
				{
					if(i%2==1)	lineans[(i+1)/2]++;
					else {
						lineans[i/2]++;						
						lineans[i/2+1]++;
					}
					if((n+i)%2==1)lineans[(n+i+1)/2]++;
					else {
						lineans[(n+i)/2]++;
						lineans[(n+i)/2+1]++;
					}
				}
				sum=0;
				for(i=1;i<=n;i++)
					sum+=lineans[i]*line[i];
				printf("%lld\n",sum);
			}
			else
				printf("%lld\n",(long long)(rand()%n)*(rand()%n)+rand()%n);
		}
		else
		{
			sum=0;
			for(i=1;i<=len;i+=2)
			{
				bj[i]=bj[i+1]=1;
				for(j=1;j<=n;j++)
					if(check(j))sum+=j;
				bj[i]=bj[i+1]=0;
			}
			printf("%lld\n",sum);
		}
	}
	return 0;
}
