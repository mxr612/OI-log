#include<cstdio>
#include<cctype>
#include<cstring>
#include<algorithm>
using namespace std;

const int maxn = 3e5 + 7;
const int maxm = 6e5 + 7;
int head[maxn], to[maxm], nxt[maxm], ecnt, n;
int deg[maxn];
int sze[maxn], SZE[maxn], TREEN, HFN, FA[maxn];
int id[maxn], dep[maxn];
int cen;

void adde (int, int);
int qr ();
inline int init ()
{
	memset(head, 0, sizeof(head));
	memset(deg, 0, sizeof(deg));
	ecnt = 1;
}

void DFS (int u, int f)
{
	FA[u] = f;
	SZE[u] = 1;
	for(int i = head[u]; i; i = nxt[i])
	{
		int v = to[i];
		if(v == f) continue;
		DFS(v, u);
		SZE[u] += SZE[v];
	}
}

void dfs (int u, int f)
{
	sze[u] = 1;
	char flag = 1;
	for(int i = head[u]; i; i = nxt[i])
	{
		int v = to[i];
		if(v == f) continue;
		dfs(v, u);
		sze[u] += sze[v];
		flag &= (sze[v] <= HFN);
	}
	if(flag && TREEN - sze[u] <= HFN) cen += u;
}

long long ans2 = 0;

void dfs2 (int u, int f)
{
	dep[u] = dep[f] + 1;
	ans2 += u * (1<<dep[u]);
	for(int i = head[u]; i; i = nxt[i])
	{
		int v = to[i];
		if(v == f) continue;
		dfs2(v, u);
	}
}

int main ()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int kase;
	scanf("%d", &kase);
	while(kase--)
	{
		init();
		scanf("%d",&n);
		int lian = 1, S = 0, T;
		int ecs = 1;
		for(int i = 1; i < n; i++)
		{
			int u = qr();
			int v = qr();
			deg[u]++;
			deg[v]++;
			adde(u, v);
			adde(v, u);
		}
		for(int i = 1; i <= n; i++)
		{
			lian &= deg[i] <= 2;
			if(deg[i] == 1) S ? T = i : S = i;
		}
		if(lian)
		{
			long long ans = 0;
			int u = S, f = 0, cnt = 0;
			id[++cnt] = S;
			while(u != T)
			{
				for(int i = head[u]; i; i = nxt[i])
				{
					int v = to[i];
					if(v == f) continue;
					f = u;
					u = v;
					break;
				}
				id[++cnt] = u;
			}
			//if(kase == 4)
			for(int i = 1; i <= n; i++) printf("%d ",id[i]);
			//printf("<%d %d>",cnt,n);
			for(int i = 1; i < n; i++)
			{
				int l = i, r = n - i;
				ans += (l & 1) ? id[(l+1)>>1] : id[l>>1] + id[(l>>1)+1];
				//if(kase == 4)printf("<%lld>",ans);
				ans += (r & 1) ? id[i+(r>>1)+1] : id[i+(r>>1)] + id[i+(r>>1)+1];
				//if(kase == 4)printf("<%lld>",ans);
			}
			printf("%lld\n",ans);
			continue;
		}
		if(n == 262143)
		{
			long long ans = 0;
			int RT;
			for(int i = 1; i <= n; i++)
			{
				if(deg[i] == 2)
				{
					RT = i;
				}
				else
				{
					ans += i;
				}
			}
			dfs2(RT, 0);
			ans += ans2 - RT - RT;
			printf("%lld\n",ans);
			continue;
		}
		DFS(1, 0);
		long long ans = 0;
		for(int i = 2; i <= ecnt; i += 2)
		{
			int u = to[i], v = to[i^1];
			
			TREEN = FA[u] == v ? SZE[u] : n - SZE[u];
			HFN = TREEN >> 1;
			cen = 0;
			dfs(u, v);
			ans += cen;
			
			TREEN = n - TREEN;
			HFN = TREEN >> 1;
			cen = 0;
			dfs(v, u);
			ans += cen;
		}
		printf("%lld\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

inline void adde (int u, int v)
{
	to[++ecnt] = v;
	nxt[ecnt] = head[u];
	head[u] = ecnt;
}

inline int qr ()
{
	int num = 0;
	char ch = getchar();
	while(!isdigit(ch)) ch = getchar();
	while(isdigit(ch)) num = (num<<1) + (num<<3) + ch - 48, ch = getchar();
	return num;
}
