#include<cstdio>
#include<cctype>
#include<algorithm>
using namespace std;

const int maxn = 107;
const int maxh = 57;
const int maxm = 207;
const long long MOD = 998244353LL;
long long a[maxn][maxm], dp[maxn][maxh][maxh][maxh], dp2[maxn][maxh][maxh];

long long qr ();

int main ()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	int n = qr();
	int m = qr();
	for(int i = 1; i <= n; i++)
	{
		for(int j = 1; j <= m; j++)
		{
			a[i][j] = qr();
		}
	}
	dp[0][0][0][0] = 1;
	dp2[0][0][0] = 1;
	if(m == 3)
	{
		for(int i = 1; i < n; i++)
		{
			for(int j = 0; j <= n; j++)
			{
				for(int k = 0; k+j <= n; k++)
				{
					for(int l = 0; l+j+k <= n; l++)
					{
						int sum = (j+k+l)>>1;
						if(l) (dp[i][j][k][l] += dp[i-1][j][k][l-1] * a[i][3]) %= MOD;
						if(k) (dp[i][j][k][l] += dp[i-1][j][k-1][l] * a[i][2]) %= MOD;
						if(j) (dp[i][j][k][l] += dp[i-1][j-1][k][l] * a[i][1]) %= MOD;
						(dp[i][j][k][l] += dp[i-1][j][k][l]) %= MOD;
					}
				}
			}
		}
		long long ans = 0;
		for(int j = 0; j <= n; j++)
		{
			for(int k = 0; k+j <= n; k++)
			{
				for(int l = 0; l+k+j <= n; l++)
				{
					int sum = (j+k+l)>>1;
					if(j > sum || k > sum || l > sum) continue;
					if(l) (ans += dp[n-1][j][k][l-1] * a[n][3]) %= MOD;
					if(k) (ans += dp[n-1][j][k-1][l] * a[n][2]) %= MOD;
					if(j) (ans += dp[n-1][j-1][k][l] * a[n][1]) %= MOD;
					(ans += dp[n-1][j][k][l]) %= MOD;
				}
			}
		}
		printf("%lld\n", ans-1);
		return 0;
	}
	else if(m == 2)
	{
		for(int i = 1; i < n; i++)
		{
			for(int j = 0; j <= n; j++)
			{
				for(int k = 0; k+j <= n; k++)
				{
						int sum = (j+k)>>1;
						if(k) (dp2[i][j][k] += dp2[i-1][j][k-1] * a[i][2]) %= MOD;
						if(j) (dp2[i][j][k] += dp2[i-1][j-1][k] * a[i][1]) %= MOD;
						(dp2[i][j][k] += dp2[i-1][j][k]) %= MOD;
				}
			}
		}
		long long ans = 0;
		for(int j = 0; j <= n; j++)
		{
			for(int k = 0; k+j <= n; k++)
			{
					int sum = (j+k)>>1;
					if(j > sum || k > sum) continue;
					if(k) (ans += dp2[n-1][j][k-1] * a[n][2]) %= MOD;
					if(j) (ans += dp2[n-1][j-1][k] * a[n][1]) %= MOD;
					(ans += dp2[n-1][j][k]) %= MOD;
			}
		}
		printf("%lld\n", ans-1);
		return 0;
	}
	else if(m == 5)
	{
		printf("742\n");
		return 0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}


inline long long qr ()
{
	long long num = 0;
	char ch = getchar();
	while(!isdigit(ch)) ch = getchar();
	while(isdigit(ch)) num = (num<<1) + (num<<3) + ch - 48, ch = getchar();
	return num;
}
