#include<bits/stdc++.h>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
#define ll long long
#define M (1ll<<30)
using namespace std;
ll ans,n,type,a[40000010],f[40000010],r,x,y,z;
ll b[40000010],l[100010],R[100010],p[100010],m;
ll sqr(ll x){return x*x;}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%lld%lld",&n,&type);
	if(!type){
		fo(i,1,n){
			scanf("%lld",&a[i]);
		}
	}else{
		scanf("%lld%lld%lld%lld%lld%lld",&x,&y,&z,&b[1],&b[2],&m);
		fo(i,3,n)b[i]=(((x*b[i-1])%M)+((y*b[i-2])%M)+z)%M;
		fo(j,1,m){
			scanf("%lld%lld%lld",&p[j],&l[j],&R[j]);
			fo(i,1,n){
				if(p[j-1]<i && i<=p[j])a[i]=(b[i]%(R[j]-l[j]+1))+l[j];
			}
		}
	}
	r=1;f[1]=1;
	fo(i,2,n){
		if(a[f[r]]<=a[i]){
			ans+=sqr(a[f[r]]);
			f[++r]=i;
			continue;
		}                                              
		if(a[f[r]]+a[i]<=a[i+1]){
			a[f[r]]+=a[i];
		}else{
//				ans+=sqr(a[f[r]]);
			x=a[i];
			while(x<a[f[r]] && i<n){
				x+=a[++i];
			}
			if(x>=a[f[r]])ans+=sqr(a[f[r]]),f[++r]=i,a[i]=x;
			else a[f[r]]+=x;
		}
	}
	ans+=sqr(a[f[r]]);
        
	printf("%lld\n",ans);
	
	return 0;
}                                                  			
