#include<bits/stdc++.h>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
#define mod 998244353
#define ll long long
using namespace std;
ll n,m,a[110][2010],s[110][2010],f[110][2010],x;
int ans;
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	srand(time(NULL));
	scanf("%lld%lld",&n,&m);
	x=1;
	fo(i,1,n){
		fo(j,1,m){
			scanf("%lld",&a[i][j]);
			s[i][j]=s[i-1][j]+s[i][j-1]-s[i-1][j-1]+a[i][j];
			if(a[i][j])x*=a[i][j];
		}
	}
	ans=rand()%x+1;
	printf("%lld\n",ans);
	
	return 0;
}
