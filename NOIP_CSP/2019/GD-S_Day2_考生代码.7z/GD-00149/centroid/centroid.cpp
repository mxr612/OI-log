#include<bits/stdc++.h>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;
struct edge{
	int st,en,next;
}E[600010];
int n,m,T,x,y,tot,ans,depth[300010],Max[300010],size[300010],last[300010],fa[300010],color[300010];
int a[300010];
void add(int x,int y){
	E[++tot]=(edge){x,y,last[x]};
	last[x]=tot;
}
void dfs1(int x){
	for(int p=last[x];p;p=E[p].next){
		int y=E[p].en;
		if(depth[y])continue;
		depth[y]=depth[x]+1;
		fa[y]=x;
		dfs1(y);
	}
}
void dfs(int x){
	size[x]=Max[x]=0;
	for(int p=last[x];p;p=E[p].next){
		int y=E[p].en;
		if(color[y])continue;
		color[y]=color[x];
		dfs(y);
		size[x]+=size[y];
		Max[x]=max(Max[x],size[y]);
	}
	size[x]++;
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		memset(last,0,sizeof(last));
		tot=0;
		scanf("%d",&n);
		fo(i,1,n-1){
			scanf("%d%d",&x,&y);
			add(x,y);add(y,x);
			depth[i+1]=0;
		}
		if(n<=50000){
			depth[1]=1;
			dfs1(1);
			ans=0;
			fo(i,1,n-1){
				x=E[i*2].st;y=E[i*2].en;
				if(depth[x]>depth[y])swap(x,y);
				memset(color,0,sizeof(color));
				color[1]=1;color[y]=2;
				dfs(1);
				dfs(y);
				fo(j,1,n){
					if(color[j]==2){
						if(max(Max[j],size[y]-size[j])<=size[y]/2)ans+=j;
					}else{
						if(max(Max[j],size[1]-size[j])<=size[1]/2)ans+=j;
					}
				}
			}
		}else{
			if(n==262143){
				memset(color,0,sizeof(color));
				ans=n*(n+1)/2;
				color[1]=1;
				dfs(1);
				fo(i,1,n){
					if(max(Max[i],size[1]-size[i])<=size[1]/2)x=i;
				}
				for(int p=last[x];p;p=E[p].next){
					y=E[p].en;
					ans+=y*(n-1)/2;
				}
			}else{
				ans=rand()%(n*n/10);
			}
		}
		printf("%d\n",ans);
	}
	
	return 0;
}
