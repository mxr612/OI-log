#include<cstdio>
#include<cstdlib>
#include<iostream>
#include<iomanip>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
const long long mod=998244353;
int n,m;
int bj[5];
int a[45][5];
int cnt;
long long ans;
long long sum[5];
inline void dfs(int x,int tim,int lim,int y,long long val)
{
	if(y==tim)
	{
	//	cout<<val<<"  "<<x<<endl;
		ans+=val;
		ans%=mod;
		return;
	}
	if(tim-y>n-x+1) return;
	for(int i=1;i<=m;i++)
	{
		if(bj[i]!=lim&&a[x][i])
		{
			bj[i]++;
			dfs(x+1,tim,lim,y+1,(val*a[x][i])%mod);
			bj[i]--;
		}
	}
	dfs(x+1,tim,lim,y,val);
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(int i=2;i<=n;i++)
	{
		dfs(1,i,i/2,0,1);
//		cout<<"asdnudh"<<endl;
	}
	cout<<ans<<endl;
	return 0;
}
