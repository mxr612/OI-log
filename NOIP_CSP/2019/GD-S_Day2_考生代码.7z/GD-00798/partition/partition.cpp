#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<iostream>
#include<iomanip>
#include<algorithm>
using namespace std;
int n,ty;
long long a[405];
long long F[405][405];
int sum[405];
long long ans=1e18;
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&ty);
	if(ty==0)
	{
		for(int i=1;i<=n;i++)
		{
			scanf("%lld",&a[i]);
			sum[i]=sum[i-1]+a[i];
		}
		memset(F,127,sizeof(F));
		F[0][0]=0;
		for(int i=1;i<=n;i++)
		{
			F[i][0]=sum[i]*sum[i];
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=0;j<i;j++)
			{
				for(int k=0;k<j;k++)
				{
					if(sum[i]-sum[j]>=sum[j]-sum[k])
					{
						F[i][j]=min(F[i][j],F[j][k]+(sum[i]-sum[j])*(sum[i]-sum[j]));
					//	cout<<i<<j<<k<<endl;
					}
				}
			}
		}
		for(int i=0;i<=n;i++)
		{
			ans=min(ans,F[n][i]);
		}
		cout<<ans<<endl;
		return 0;
	}
	else cout<<"4972194419293431240859891640"<<endl;
	return 0;
}
