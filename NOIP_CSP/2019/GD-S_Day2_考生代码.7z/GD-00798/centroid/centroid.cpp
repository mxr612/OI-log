#include<cstdio>
#include<cstdlib>
#include<iostream>
#include<iomanip>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int T;
int n;
bool ban[100050];
int cnt=1;
int ver[100050];
int nxt[100050];
int head[100050];
int from[100050];
int F[50050];
int siz[50050];
int tmp;
int ans=99999999;
int rua;
int sum;
int in[50050];
int sum1[50050];
int sum2[50050];
int sx[50050];
int tot;
inline void init()
{
	memset(ver,0,sizeof(ver));
	memset(nxt,0,sizeof(nxt));
	memset(head,0,sizeof(head));
	memset(from,0,sizeof(from));
	sum=0;
	tmp=0;
	cnt=1;
}
inline void add(int x,int y)
{
	cnt++;
	from[cnt]=x;
	ver[cnt]=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
inline void dfs(int x,int fa)
{
	siz[x]=1;
	for(int i=head[x];i;i=nxt[i])
	{
		if(ver[i]==fa||ban[i]) continue;
		dfs(ver[i],x);
		siz[x]+=siz[ver[i]];
	}
}
inline void dfs2(int x,int fa)
{
	for(int i=head[x];i;i=nxt[i])
	{
		if(ver[i]==fa||ban[i]) continue;
		dfs2(ver[i],x);
		F[x]=max(siz[ver[i]],F[x]);
	}
	F[x]=max(F[x],siz[tmp]-siz[x]);
	if(F[x]<=ans)
	{
		if(F[x]==ans) rua+=x;
		else
		{
			//if(ban[4]==1&&tmp==2) cout<<x<<endl;
			rua=x;
			ans=F[x];
		}
	}
}
inline void dfs3(int x,int fa)
{
	sx[++tot]=x;
	for(int i=head[x];i;i=nxt[i])
	{
		if(ver[i]==fa) continue;
		dfs3(ver[i],x);
	}
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		init();
		scanf("%d",&n);
		for(int i=1;i<n;i++)
		{
			int x,y;
			scanf("%d%d",&x,&y);
			add(x,y);
			add(y,x);
			in[x]++;
			in[y]++;
		}
	//	cout<<from[4]<<ver[4]<<endl;
		if(n<=2000)
		{
			for(int i=2;i<=cnt;i+=2)
			{
				memset(F,0,sizeof(F));
				ans=99999999;
				rua=0;
				ban[i]=ban[i^1]=1;
				dfs(from[i],0);
				tmp=from[i];
				dfs2(from[i],0);
			//	if(tmp==2) cout<<"HUA  "<<rua<<endl;
				sum+=rua;rua=0;ans=99999999;
				dfs(ver[i],0);
				tmp=ver[i];
				dfs2(ver[i],0);
				sum+=rua;
				//if(tmp==2) cout<<rua<<endl;
				ban[i]=ban[i^1]=0;
			}
			cout<<sum<<endl;
		}
		else
		{
			int tmp1=0;
			int tmp2=0;
			for(int i=1;i<=n;i++)
			{
				if(in[i]==1&&!tmp1) tmp1=i;
				if(in[i]==1&&tmp1) tmp2=i;
			}
			dfs3(tmp1,0);
			for(int i=1;i<=tot;i++)
			{
				if((i-1)%2==0)
				{
					sum+=sx[(i-1)/2]+sx[(i-1)/2+1];
				}
				else
				{
					sum+=sx[(i-1)/2+1];
				}
				if((n-1)%2==0)
				{
					sum+=sx[(i+1+n)/2]+sx[(i+1+n)/2+1];
				}
				else
				{
					sum+=sx[(i+1+n)/2];
				}
			}
			cout<<sum<<endl;
		}
	}
	return 0;
}
