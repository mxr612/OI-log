#include<bits/stdc++.h>
using namespace std;
long long n,a[500001],type,ans=LONG_LONG_MAX,minnn[500001],minans[500001],remainmin[500002];
void dfs(int x,long long sum,long long tot,long long minn){
	if(x>n){
		if(tot>=minn)sum+=tot*tot,ans=min(ans,sum);
	}
	else{
		if(sum>4*(1e18)||sum<0||sum+remainmin[x]>=ans)return;
		dfs(x+1,sum,tot+a[x],minn);
		if(tot+a[x]>=minn){
			bool flag=false;
			if(tot+a[x]<minnn[x])minnn[x]=tot+a[x],flag=true;
			if(sum+(tot+a[x])*(tot+a[x])<minans[x])minans[x]=sum+(tot+a[x])*(tot+a[x]),flag=true;
			if(flag)dfs(x+1,sum+(tot+a[x])*(tot+a[x]),0,tot+a[x]);
		}
	}
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%lld%lld",&n,&type);
	for(int i=1;i<=n;i++)minnn[i]=LONG_LONG_MAX;
	for(int i=1;i<=n;i++)minans[i]=LONG_LONG_MAX; 
	for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
	for(int i=n;i>=1;i--)remainmin[i]=remainmin[i+1]+a[i]*a[i];
	dfs(1,0,0,0);
	printf("%lld",ans);
	return 0;
}
