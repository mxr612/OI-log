#include<bits/stdc++.h>
using namespace std;
int read(){
	int x=0;
	char c=getchar();
	while(c>'9'||c<'0')c=getchar();
	while('0'<=c&&c<='9')x=x*10+c-'0',c=getchar();
	return x;
}
int n,head[300001],to[600001],link[600001],e[300001][2],siz[300001],maxp[300001],tot,deg[300001],qwq;
long long ans;
bool vis[300001];
void add(int u,int v){
	to[++tot]=v,link[tot]=head[u],head[u]=tot;
}
void dfs(int x,int f){
	siz[x]=1;
	maxp[x]=0;
	for(int i=head[x];i;i=link[i]){
		if(f==to[i]||vis[to[i]])continue;
		dfs(to[i],x);
		maxp[x]=max(maxp[x],siz[to[i]]);
		siz[x]+=siz[to[i]];
	}
}
void find_cen(int x,int f,int treesize){
	if(qwq==2)return;
	if(max(maxp[x],treesize-siz[x])<=treesize/2)ans+=x,qwq++;
	for(int i=head[x];i;i=link[i]){
		if(to[i]==f||vis[to[i]])continue;
		find_cen(to[i],x,treesize);
	}
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int t;
	cin>>t;
	while(t--){
		ans=0;
		tot=0;
		n=read();
			for(register int i=1;i<=n;i++)head[i]=0;
			for(int i=1;i<n;i++)e[i][0]=read(),e[i][1]=read(),add(e[i][0],e[i][1]),add(e[i][1],e[i][0]);
			for(int i=1;i<n;i++){
				vis[e[i][0]]=true,vis[e[i][1]]=true;
				dfs(e[i][0],e[i][0]),dfs(e[i][1],e[i][1]);
				qwq=0;
				find_cen(e[i][0],e[i][0],siz[e[i][0]]);
				qwq=0;
				find_cen(e[i][1],e[i][1],siz[e[i][1]]);
				vis[e[i][0]]=false,vis[e[i][1]]=false;
			}
			printf("%lld\n",ans);
		}
	return 0;
}
