#include<bits/stdc++.h>
using namespace std;
#define wxp 998244353
long long n,m,a[101][2001],used_cai[2001],tot,remain[102][2002],link[101][2001][2];
bool used_way[101];
long long ans;
void dfs(long long curway,long long curcai,long long sum,long long ans1,long long lim){
	if(sum==lim){
		ans=(ans+ans1)%wxp;
	}
	else{
		if(sum+remain[curway][curcai]<lim)return;
		dfs(link[curway][curcai][0],link[curway][curcai][1],sum,ans1,lim);
		if(!used_way[curway]&&a[curway][curcai]){
			used_way[curway]=true;
			used_cai[curcai]++;
			if(used_cai[curcai]<=lim/2)dfs(link[curway][curcai][0],link[curway][curcai][1],sum+1,ans1*a[curway][curcai]%wxp,lim);
			used_cai[curcai]--;
			used_way[curway]=false;
		}
	}
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)scanf("%lld",&a[i][j]);
	remain[n+1][1]=0,link[n+1][1][0]=n+1,link[n+1][1][1]=1;
	for(int	i=n;i>=1;i--)for(int j=m;j>=1;j--){
		int nexti=(j==m?i+1:i),nextj=(j==m?1:j+1);
		remain[i][j]=remain[nexti][nextj]+(a[i][j]!=0);
		if(a[nexti][nextj])link[i][j][0]=nexti,link[i][j][1]=nextj;
		else link[i][j][0]=link[nexti][nextj][0],link[i][j][1]=link[nexti][nextj][1];
	}
	for(int i=2;i<=remain[1][1];i++)dfs(1,1,0,1,i);
	printf("%lld",ans);
	return 0;
}
