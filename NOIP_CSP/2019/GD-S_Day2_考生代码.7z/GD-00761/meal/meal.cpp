#include<algorithm>
#include<iostream>
#include<cstring>
#include<fstream>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
#include<deque>
#include<stack>
#include<list>
#include<map>
using namespace std;
const int mode=998244353;
int n,m,a[101][2001],lj;
int bj[2001];
bool pd(int x)
{
	for(int i=1;i<=m;i++)
		if(bj[i]>x/2) return false;
	return true; 
}
void DFS(int k,int x,long long js)
{
	if(k>n) {if(x&&pd(x)) lj=(lj+js)%mode;return;}
	for(int i=1;i<=m;i++)
		if(a[k][i]&&((x+1+n-k)/2>=bj[i]+1)) ++bj[i],DFS(k+1,x+1,js*a[k][i]),--bj[i];
	DFS(k+1,x,js);
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&a[i][j]);
	if(n==2)
	{
		for(int i=1;i<=m;i++)
			for(int j=1;j<=m;j++)
				if(i!=j) lj+=(a[1][i]*a[2][j])%mode;
	} else
	{
		DFS(1,0,1);
	}
	cout<<lj;
	return 0;
}
