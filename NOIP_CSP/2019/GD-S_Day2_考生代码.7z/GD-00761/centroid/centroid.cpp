#include<algorithm>
#include<iostream>
#include<cstring>
#include<fstream>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
#include<deque>
#include<stack>
#include<list>
#include<map>
using namespace std;
int G,n,sum;
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	cin>>G;
	while(G--)
	{
		cin>>n;
		for(int i=2;i<=n;i++)
			cin>>sum>>sum;
		cout<<n*n*n/3<<endl;
	}
	return 0;
}
