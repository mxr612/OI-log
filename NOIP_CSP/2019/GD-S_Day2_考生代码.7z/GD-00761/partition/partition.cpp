#include<algorithm>
#include<iostream>
#include<cstring>
#include<fstream>
#include<cstdio>
#include<vector>
#include<cmath>
#include<queue>
#include<deque>
#include<stack>
#include<list>
#include<map>
using namespace std;
int n,type,m,j;
long long x,y,z,b1,b2,b3,now,a1,a2,r[100001],l[100001],p[100001],lj;
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	if(type)
	{
		scanf("%lld%lld%lld%lld%lld%d",&x,&y,&z,&b1,&b2,&m);
		for(int i=1;i<=m;i++) scanf("%lld%lld%lld",&p[i],&l[i],&r[i]);
		while(!(p[j-1]<1&&1<=p[j])) ++j;
		now=(b1%(r[j]-l[j]+1))+l[j];
		while(!(p[j-1]<2&&2<=p[j])) ++j;
		a1=(b2%(r[j]-l[j]+1))+l[j];
		for(int i=3;i<=n;i++)
		{
			b3=((x%1073741824)*(b2%1073741824)%1073741824+(y%1073741824)*(b1%1073741824)%1073741824+(z%1073741824))%1073741824;
			while(!(p[j-1]<i&&i<=p[j])) ++j;
			a2=(b3%(r[j]-l[j]+1))+l[j];
			if(now>a1)
			{
				if(now+a1<=a2) now+=a1; else a2+=a1; 
			} else lj+=now*now,now=a1;
			a1=a2;
			b1=b2;
			b2=b3;
		}
		if(a1<now) now+=a1,a1=0;
		lj+=now*now+a1*a1;
		lj+=now*now;
	} else
	{
		scanf("%d%d",&now,&a1);
		for(int i=3;i<=n;i++)
		{
			scanf("%d",&a2);
			if(now>a1)
			{
				if(now+a1<=a2) now+=a1; else a2+=a1; 
			} else lj+=now*now,now=a1;
			a1=a2;
		}
		if(a1<now) now+=a1,a1=0;
		lj+=now*now+a1*a1;
	}
	printf("%lld",lj);
	return 0;
}
