#include <cstdio>
#include <cstring>

int n, op;
long long a[500001], s[500001], f[500011], ma[500001];
long long ans;

void dfs(int dep, long long ns, long long ls, long long ss) {
	if (ss + ma[n] - ma[dep - 1] >= ans) return;
	if (ss >= ans || ss >= f[dep]) return;
	if (dep > n) {
		ans = ss;
		f[dep] = ans;
		return;
	}
	f[dep] = ss;
	for (int i = dep; i <= n; i++) {
		if (s[i] - s[dep - 1] < ls) continue;
		if (ss + (s[i] - s[dep - 1]) * (s[i] - s[dep - 1]) >= ans) return;
		dfs(i + 1, 0, s[i] - s[dep - 1], ss + (s[i] - s[dep - 1]) * (s[i] - s[dep - 1]));
	}
}

int main() {
	freopen("partition.in", "r", stdin);
	freopen("partition.out", "w", stdout);
	scanf("%d %d", &n, &op);
	for (int i = 1; i <= n; i++)
		scanf("%lld", &a[i]), s[i] = s[i - 1] + a[i], ma[i] = ma[i - 1] + a[i] * a[i];
	ans = 4e18 + 1;
	for (int i = 1; i <= n + 1; i++)
		f[i] = s[n] * s[n];
	dfs(1, 0, 0, 0);
	printf("%lld", ans);
	fclose(stdin);
	fclose(stdout);
}
