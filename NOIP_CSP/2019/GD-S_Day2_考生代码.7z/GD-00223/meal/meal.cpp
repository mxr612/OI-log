#include <cstdio>

int n, m;
int a[101][2001], used[2001];
long long ans;

void dfs(int dep, int kk, int mxx, long long ss) {
	if (dep > n) {
		if (kk / 2 < mxx) return;
		if (kk) (ans += ss) %= 998244353;
		return;
	}
	for (int i = dep + 1; i <= n + 1; i++)
		dfs(i, kk, mxx, ss);
	for (int i = 1; i <= m; i++) {
		if (!a[dep][i]) continue;
		used[i]++;
		dfs(dep + 1, kk + 1, mxx > used[i] ? mxx : used[i], ss * a[dep][i] % 998244353);
		used[i]--;
	}
}

int main() {
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	scanf("%d %d", &n, &m);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			scanf("%d", &a[i][j]);
	dfs(1, 0, 0, 1);
	printf("%d", ans);
	fclose(stdin);
	fclose(stdout);
}
