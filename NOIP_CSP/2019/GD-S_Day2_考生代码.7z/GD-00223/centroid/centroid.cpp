#include <cstdio>
#include <cstring>

int t, n, cnt, tot, ans;
int a[50001];
int head[50001], ver[100001], next[100001], d[50001], sb[50001];

void add(int u, int v) {
	ver[++tot] = v;
	next[tot] = head[u];
	head[u] = tot;
	d[u]++;
}

void dfs(int p, int fa) {
	a[++cnt] = p;
	for (int i = head[p]; i; i = next[i]) {
		if (ver[i] == fa) continue;
		dfs(ver[i], p);
	}
}

int main() {
	freopen("centroid.in", "r", stdin);
	freopen("centroid.out", "w", stdout);
	scanf("%d", &t);
	for (; t; t--) {
		memset(head, 0, sizeof(head));
		memset(d, 0, sizeof(d));
		int root = 0;
		scanf("%d", &n);
		tot = cnt = ans = 0;
		for (int i = 1, x, y; i < n; i++)
			scanf("%d %d", &x, &y), add(x, y), add(y, x);
		for (int i = 1; i <= 50000; i++)
			if (d[i] == 1) {
				root = i;
				break;
			}
		dfs(root, 0);
		for (int i = 1; i < n; i++) {
			if (i & 1) ans += a[(1 + i) / 2];
			else ans += a[(1 + i) / 2] + a[(2 + i) / 2];
			if ((i + n + 1) & 1) ans += a[(i + n + 1) / 2] + a[(i + n + 2) / 2];
			else ans += a[(i + n + 1) / 2]; 
		}
		printf("%d\n", ans);
	}
	fclose(stdin);
	fclose(stdout);
}
