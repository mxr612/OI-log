#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
#define int long long
inline int read(){
	int a=0,b=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')b=-1;c=getchar();}
	while(isdigit(c)){a=a*10+c-'0';c=getchar();}
	return a*b;
}
const int N=150,M=2050,mod=998244353;
int n,m,a[N][M],sum[N],ans;
signed main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++){
		a[i][j]=read();
		sum[i]+=a[i][j];
	}
	if(n==2){
		for(int i=1;i<=m;i++){
			ans=(ans+(sum[2]-a[2][i])*a[1][i])%mod;
		}
		printf("%lld\n",ans);
		return 0;
	}
	printf("0\n");
	return 0;
}
