#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
#define int long long
inline int read(){
	int a=0,b=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')b=-1;c=getchar();}
	while(isdigit(c)){a=a*10+c-'0';c=getchar();}
	return a*b;
}
const int N=3e5+50;
int T,n,tot,h[N],nx[N*2],ver[N*2],size[N],rem,ans;
void add(int u,int v){
	ver[++tot]=v;
	nx[tot]=h[u];h[u]=tot;
}
void find_(int x,int f){
	size[x]=1;
	for(int i=h[x];i;i=nx[i]){
		int v=ver[i];
		if(v==f)continue;
		find_(v,x);
		size[x]+=size[v];
	}
	if(size[x]==1)ans-=x,rem=x;
}
void dfs2(int x,int f,int dep){
	if(n%2==1){
		if(dep==(n+1)/2){
		ans+=x;
		}
	}
	else{
		if(dep==n/2||dep==n/2+1){
			ans-=x;
		}
	}
	for(int i=h[x];i;i=nx[i]){
		int v=ver[i];
		if(v==f)continue;
		dfs2(v,x,dep+1);
	}
	if(dep==n)ans-=x;
}
signed main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int u,v;
	T=read();
	while(T--){
		tot=0;
		ans=0;
		memset(h,0,sizeof(h));
		n=read();
		for(int i=1;i<n;i++){
			u=read();v=read();
			ans+=i;
			add(u,v);add(v,u);
		}
		ans+=n;
		ans*=3;
		find_(1,0);
		dfs2(rem,0,1);
		printf("%lld\n",ans);
	}
	return 0;
}
