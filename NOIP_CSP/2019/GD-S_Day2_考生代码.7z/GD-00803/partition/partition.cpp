#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
#define int long long
inline int read(){
	int a=0,b=1;char c=getchar();
	while(!isdigit(c)){if(c=='-')b=-1;c=getchar();}
	while(isdigit(c)){a=a*10+c-'0';c=getchar();}
	return a*b;
}
const int N=5e5+50;
int n,type,a[N],ans=0;
signed main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=read();type=read();
	if(type==0){
		for(int i=1;i<=n;i++){
			a[i]=read();
			ans+=a[i]*a[i];
		}
		int now=2;
		while(1){
			while(a[now-1]<=a[now]&&now<=n)now++;
			if(now==n+1){
			printf("%lld\n",ans);
			return 0;
			}
			int sum=0,rem=now;
			while(sum+a[now]<a[now-1]&&rem<n)sum+=a[++rem];
			if(rem==n||sum>a[now-1])ans+=2*a[now-1]*a[now],a[now]+=a[now-1];
			else{
				ans+=2*a[now]*sum;
				now=rem;
				a[rem]=a[now]+sum;
			}
			now++;
		}
	}
	else printf("4972194419293431240859891640\n");
	return 0;
}
