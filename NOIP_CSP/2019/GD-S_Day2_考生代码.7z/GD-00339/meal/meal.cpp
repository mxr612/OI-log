#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
using namespace std;

const int N=105,M=2005;
const int P=998244353;

int n,m,ans=0;
int a[N][M],use[M];

int qread(){
	char c=getchar();
	int x=0;
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	return x;
}

void dfs(int i,int num,bool choose,int maxm,int k){
	if (choose&&maxm<=k/2&&i>1) ans=(ans+num%P)%P;
	if (i==n+1) return;
	dfs(i+1,num,0,maxm,k);
	for (int j=1;j<=m;j++) if (a[i][j]){
		use[j]++;
		if (use[j]>maxm) dfs(i+1,(long long)(((num%P)*a[i][j]))%P,1,use[j],k+1);
		else dfs(i+1,(long long)(((num%P)*a[i][j]))%P,1,maxm,k+1);
		use[j]--;
	}
}

int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=qread(),m=qread();
	for (int i=1;i<=n;i++) for (int j=1;j<=m;j++) a[i][j]=qread();
	dfs(1,1,0,0,0);
	printf("%d",ans%P);
	return 0;
}
