#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#define ll long long
using namespace std;

const int N=5e5+5;

ll ans=4e18,sum;
int type,n;
int a[N];

int qread(){
	char c=getchar();
	int x=0;
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	return x;
}

void dfs(int t,ll num){
	if (t==n+1){
		bool ok=1;
		for (int i=2;i<=n;i++) if (a[i]<a[i-1]){
			ok=0;
			break;
		}
		if (ok) ans=min(ans,num);
		return;
	}
	dfs(t+1,num);
	int x=a[t],y=a[t+1];
	a[t]=a[t+1]=x+y;
	dfs(t+1,(ll)(num+2*x*y));
	a[t]=x,a[t+1]=y;
}

int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=qread(),type=qread();
	for (int i=1;i<=n;i++) a[i]=qread();
	for (int i=1;i<=n;i++) sum+=(ll)a[i]*a[i];
	dfs(1,sum);
	printf("%lld",ans);
	return 0;
}
