#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <vector>
#define ll long long
using namespace std;

const int N=3e5;
int t,n;
ll ans;
int in[N];
bool vis[N];
int g[N][2];

int qread(){
	char c=getchar();
	int x=0;
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9'){
		x=x*10+c-'0';
		c=getchar();
	}
	return x;
}

void dfs(int k,int u){
	vis[u]=1;
	if (k==1||k==n||( (n%2==0)&&( (k==n/2)||(k==n/2+1) ) )||( (n%2==1)&&(k==n/2+1) )) ans-=(ll)u;
	if (k==n) return;
	for (int i=0;i<=1;i++){
		int v=g[u][i];
		if (!v) continue;
		if (vis[v]) continue;
		dfs(k+1,v);
	}
}

int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	t=qread();
	while (t--){
		n=qread();
		memset(in,0,sizeof(in));
		memset(vis,0,sizeof(vis));
		memset(g,0,sizeof(g));
		for (int i=1;i<n;i++){
			int x,y;
			x=qread(),y=qread();
			in[x]++;in[y]++;
			if (g[x][1]) g[x][0]=y;
			else g[x][1]=y;
			if (g[y][1]) g[y][0]=x;
			else g[y][1]=x;
		}
//		if (t) continue;
		if (n==2){
			printf("%d\n",3);
			continue;
		}
		ans=(ll)(n*(n+1)/2*3);
		for (int i=1;i<=n;i++){
			if (in[i]==1){
				dfs(1,i);
				break;
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
