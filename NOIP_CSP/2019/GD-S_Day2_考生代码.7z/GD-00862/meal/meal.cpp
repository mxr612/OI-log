#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
typedef long long ll;

const int N=110,M=1010,MOD=998244353;
int n,m,cnt[M],a[N][M],f[30][30][30];
ll ans;

bool check(int p,int id,ll s)
{
	for (int i=1;i<=m;i++)
		if (cnt[i]*2>p) return 0;
	if (id) f[cnt[1]][cnt[2]][cnt[3]]=(f[cnt[1]][cnt[2]][cnt[3]]+s)%MOD;
	return 1;
}

void dfs(int x,ll s,int p,int id)
{
	if (!s) return;
	if (x>n)
	{
		if (check(p,id,s)) ans=(ans+s)%MOD;
		return;
	}
	dfs(x+1,s,p,id);
	for (int i=1;i<=m;i++)
	{
		cnt[i]++;
		dfs(x+1,s*a[x][i],p+1,id);
		cnt[i]--;
	}
}

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
			scanf("%d",&a[i][j]);
	if (n<=10) dfs(1,1,0,0);
	else
	{
		int qqq=n; n/=2;
		dfs(1,1,0,1); 
		n=qqq; 
		dfs(n/2+1,1,0,1);
		ans=0;
		for (int _1=0;_1<=20;_1++)
			for (int _2=0;_2<=20;_2++)
				for (int _3=0;_3<=20;_3++)
					for (int _4=0;_4<=20;_4++)
						for (int _5=0;_5<=20;_5++)
							for (int _6=0;_6<=20;_6++)
							{
								int sss=_1+_2+_3+_4+_5+_6;
								if ((_1+_4)*2>sss || (_2+_5)*2>sss || (_3+_6)*2>sss) continue;
								ans=(ans+1LL*f[_1][_2][_3]*f[_4][_5][_6])%MOD;
							}
	}
	printf("%lld",(ans-1+MOD)%MOD);
	return 0;
}
