#include <queue>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
typedef long long ll;

const int N=40000010,MOD=(1<<30),M=100010;
int n,x,type,pos,tot,cnt;
ll xx,yy,zz,m,f[N],sum[N],ans[N],b[3],p[M],l[M],r[M];
deque<int> q;

ll Get(int i)
{
	tot++;
	if (tot==4) tot=1;
	if (i>2 && tot==1) b[1]=(xx*b[3]+yy*b[2]+zz)%MOD;
	if (i>2 && tot==2) b[2]=(xx*b[1]+yy*b[3]+zz)%MOD;
	if (i>2 && tot==3) b[3]=(xx*b[2]+yy*b[1]+zz)%MOD;
	if (i>p[cnt]) cnt++;
	return (b[tot]%(r[cnt]-l[cnt]+1))+l[cnt];
}

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	if (type)
	{
		scanf("%lld%lld%lld%lld%lld%lld",&xx,&yy,&zz,&b[1],&b[2],&m);
		for (int i=1;i<=m;i++)
			scanf("%lld%lld%lld",&p[i],&l[i],&r[i]);
	}
	q.push_back(0);
	for (int i=1;i<=n;i++)
	{
		if (!type) scanf("%d",&x);
			else x=Get(i);
		sum[i]=sum[i-1]+(ll)x;
		while (q.size() && sum[i]>=sum[q.front()]+f[q.front()])
		{
			pos=q.front();
			q.pop_front();
		}
		q.push_front(pos);
		f[i]=sum[i]-sum[pos];
		ans[i]=ans[pos]+(sum[i]-sum[pos])*(sum[i]-sum[pos]);
		while (q.size() && f[q.back()]+sum[q.back()]>=f[i]+sum[i]) q.pop_back();
		q.push_back(i);
	}
	printf("%lld",ans[n]);
	return 0;
}

/*
int main()
{
	scanf("%d%d",&n,&type);
	for (int i=1;i<=n;i++)
	{
		if (!type) scanf("%d",&x);
		sum[i]=sum[i-1]+(ll)x;
		for (int j=i-1;j>=0;j--)
		{
			if (sum[i]-sum[j]>=f[j])
			{
				f[i]=sum[i]-sum[j];
				ans[i]=ans[j]+(sum[i]-sum[j])*(sum[i]-sum[j]);
				break;
			}
		}
	}
	printf("%lld",ans[n]);
	return 0;
}*/
//// WYC AK CSP-S %%%
