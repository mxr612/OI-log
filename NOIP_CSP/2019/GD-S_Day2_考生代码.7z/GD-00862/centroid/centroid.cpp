#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int N=300010;
int T,n,ans,tot,head[N],in[N],a[N];

struct edge
{
	int next,to;
	bool flag;
}e[N*2];

void add(int from,int to)
{
	e[++tot].to=to;
	e[tot].next=head[from];
	head[from]=tot;
}

int dfs(int x,int fa)
{
	int s=1;
	for (int i=head[x];~i;i=e[i].next)
		if (!e[i].flag && e[i].to!=fa) s+=dfs(e[i].to,x);
	return s;
}

bool check1()
{
	int cnt=0,pos;
	for (int i=1;i<=n;i++)
	{
		if (in[i]>2) return 0;
		if (in[i]==1) cnt++,pos=i;
		if (cnt>2) return 0;
	}
	cnt=0;
	for (int i=pos,fa=0;;)
	{
		a[++cnt]=i;
		if (in[i]==1 && i!=pos) break;
		for (int j=head[i];~j;j=e[j].next)
			if (e[j].to!=fa)
			{
				fa=i;
				i=e[j].to;
			}
	}
	return 1;
}

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while (T--)
	{
		scanf("%d",&n);
		memset(head,-1,sizeof(head));
		tot=ans=0;
		for (int i=1,x,y;i<n;i++)
		{
			scanf("%d%d",&x,&y);
			add(x,y); add(y,x);
			in[x]++; in[y]++;
		}
		if (n<200)
		{
			for (int k=1;k<n;k++)
			{
				e[k*2-1].flag=e[k*2].flag=1;
				for (int i=1;i<=n;i++)
				{
					bool flag=1;
					int cnt=dfs(i,0);
					for (int j=head[i];~j;j=e[j].next)
						if (!e[j].flag && dfs(e[j].to,i)>cnt/2)
						{
							flag=0;
							break;
						}
					if (flag) ans+=i;
				}
				e[k*2-1].flag=e[k*2].flag=0;
			}
			printf("%d\n",ans);
			continue;
		}
		if (check1())
		{
			for (int i=1;i<n;i++)
			{
				int p=i,q=i+1;
				if (p&1) ans+=a[p/2+1];
					else ans+=a[p/2]+a[p/2+1];
				if ((n-q+1)&1) ans+=a[(n+q)/2];
					else ans+=a[(n+q)/2]+a[(n+q)/2+1];
			}
			printf("%d",ans);
			continue;
		}
	}
}
/*
2
5
1 2
2 3
2 4
3 5
7
1 2
1 3
1 4
3 5
3 6
6 7
*/
