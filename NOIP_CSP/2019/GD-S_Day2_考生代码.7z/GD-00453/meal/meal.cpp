#include <cstdio>
using namespace std;

typedef unsigned long long UINT64;

int N,M;
int A[101][2001];

UINT64 MARK[2001];
UINT64 RES=0;

void dfs(int n,int mg,UINT64 mc,int mt)
{
	if (mg==mt)
	{
		RES+=mc%998244353;
		return;
	}
	if (N-n<mt-mg) return;
	
	dfs(n+1,mg,mc,mt);
	for (int i=1;i<=M;i++)
	{
		if (A[n+1][i]&&(MARK[i]+1)<=mt/2)
		{
			MARK[i]++;
			dfs(n+1,mg+1,(mc*A[n+1][i])%998244353,mt);
			MARK[i]--;
		}
	}
	
}

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	
	scanf("%d %d",&N,&M);
	for (int i=1;i<=N;i++)
		for (int j=1;j<=M;j++)
			scanf("%d",&A[i][j]);

	for (int i=2;i<=N;i++)
		dfs(0,0,1,i);
	
	printf("%d",RES%998244353);
	
	return 0;
}
