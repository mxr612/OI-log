#include <cstdio>
#include <algorithm>
using namespace std;

typedef unsigned long long UINT64;

int N,TYPE;
int A[500010];

UINT64 SQR[5000010];
UINT64 sqr(UINT64 n)
{
	if (SQR[n]) return SQR[n];
	return SQR[n] = n*n;
}

UINT64 RES=0;

void dfs(UINT64 last,int idx,UINT64 res)
{
	//printf("%lld %d %lld\n",last,idx,res);
	if (idx==N)
	{
		RES = min(RES,res+sqr(last));
		return;
	}
	if (res>=RES) return;
	
	//not conbine better
	if (last <= A[idx+1])
	{
		dfs(A[idx+1],idx+1,res+sqr(last));
	}
	else//combine
	{
		dfs(last+A[idx+1],idx+1,res);
		
		UINT64 sum=0,i=1;
		while ((idx+i<=N)&&(sum+=A[idx+i])<last) i++;
		if (sum >= last) dfs(sum,idx+i,res+sqr(last));
	}
}

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	
	scanf("%d %d",&N,&TYPE);
	for (int i=1;i<=N;i++)
	{
		scanf("%d",A+i);
		RES+=A[i];
	}
	RES = RES*RES;
	
	dfs(0,0,0);
	
	printf("%lld",RES);
	
	return 0;
}
