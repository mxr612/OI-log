#include<iostream>
#include<stdio.h>
using namespace std;
const long long int INF=998244353;
long long int n,m;
long long int a[105][1005];
long long int vis[1005];
long long int ans=0;
int level=2,fl=1;
int t;
bool flag=true;

void dp(int x,int y)
{
	for(int i=x+1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			if((j!=y)&&(a[i][j]!=0))
			{
				t=t*a[i][j];
				ans=ans+t;
				fl++;
				if(fl==level)
				{
					t=a[x][y];
					fl--;
				}
			}
		}
	}
	if(level<n)
	{
		level++;
	}
	else flag=false;
	return ;
}

int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
		}
	}
	while(flag)
	{
		for(int i=1;i<=n-1;i++)
		{
			for(int j=1;j<=m;j++)
			{
				vis[j]=1;
				t=a[i][j];
				dp(i,j);
				for(int k=1;k<=m;k++)
				{
					vis[k]=0;
				}
			}
		}
	}
	/*for(int i=1;i<=n;i++)
	{
		int floor=0;
		for(int j=1;j<=m;j++)
		{
			dp(floor+1,i,j,a[i][j]);
		}
	}*/
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
