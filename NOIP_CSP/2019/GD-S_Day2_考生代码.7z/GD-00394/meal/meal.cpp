#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <queue>
#include <vector>
#include <set>
#include <map>
#include <bitset>
using namespace std;
int n, m;
long long cnt;
int veg[105][2005], used[2005];
bool check(int k){
	if(k < 1)    return false;
	for(int i = 1; i <= m; i++)
		if(used[i] > k/2)    return false;
	return true;
}
void dfs(int x, int k){
	//printf("x:%d k:%d\n", x, k);
	//for(int i = 1; i <= m; i++)    printf("%d ", used[i]);
	//putchar('\n');
	//cout << bitset<5>(sta) << endl;
	if(check(k))    cnt++;
	if(x == n+1)    return;
	for(int i = 1; i <= m; i++)
	{
		if(!veg[x][i])    continue;
		used[i] += veg[x][i];
		dfs(x+1, k+veg[x][i]);
		used[i] -= veg[x][i];
	}
	dfs(x+1, k);
}
int main(void)
{
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	scanf("%d %d", &n, &m);
	for(int i = 1; i <= n; i++)
	    for(int j = 1; j <= m; j++)
	    	scanf("%d", &veg[i][j]);
	dfs(1, 0);
	printf("%lld\n", cnt%998244353);
}
