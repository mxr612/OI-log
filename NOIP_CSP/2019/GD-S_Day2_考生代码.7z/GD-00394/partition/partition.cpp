#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <queue>
#include <vector>
#include <set>
#include <map>
#define maxn 500005
using namespace std;
int n, t, a[maxn], ans = (1<<30);
void dfs(int x, int cost, int last){
	if(cost > ans)    return;
	if(x == n+1)
	{
		ans = cost;
		return;
	}
	int sum = 0;
	for(int i = x; i <= n; i++)
	{
		sum += a[i];
		if(sum < last)    continue;
		dfs(i+1, cost+sum*sum, sum);
	}
}
int main(void)
{
	freopen("partition.in", "r", stdin);
	freopen("partition.out", "w", stdout);
	scanf("%d %d", &n, &t);
	if(t == 0)
	{
		for(int i = 1; i <= n; i++)    scanf("%d", &a[i]);
		dfs(1, 0, 0);
		printf("%d\n", ans);
	}
	return 0;
}
