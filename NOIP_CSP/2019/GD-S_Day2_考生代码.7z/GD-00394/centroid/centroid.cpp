#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <queue>
#include <vector>
#include <set>
#include <map>
#include <stack>
#define maxn 2005
using namespace std;
int n, u[maxn*2], v[maxn*2], in[maxn];
int k, head[maxn*2];
long long ans;
bool fib[maxn][maxn];
int siz[maxn], sizz[maxn];
struct Edge{
	int to;
	int nxt;
}Edge[maxn];
void Build(int u, int v){
	Edge[k].to = v;
	Edge[k].nxt = head[u];
	head[u] = k++;
}
bool sub1 = true;
namespace subtask1{
	void solve(){
		int ans = 0;
		for(int i = 1; i <= n-1; i++)
		{
			int lef = i, rig = n-i;
			lef & 1 ? ans += (lef+1)/2 : ans += lef+1;
			rig & 1 ? ans += (lef+1+n)/2 : ans += lef+1+n;
		}
		printf("%d\n", ans);
	}
}
void dfs1(int x, int fa){
	siz[x] = 1;
	for(int i = head[x]; ~i; i = Edge[i].nxt)
	{
		if(fib[Edge[i].to][x])    continue;
		if(Edge[i].to == fa)    continue;
		dfs1(Edge[i].to, x);
		siz[x] += siz[Edge[i].to];
	}
}
void dfs2(int x, int fa){
	sizz[x] = 1;
	for(int i = head[x]; ~i; i = Edge[i].nxt)
	{
		if(fib[Edge[i].to][x])    continue;
		if(Edge[i].to == fa)    continue;
		dfs2(Edge[i].to, x);
		sizz[x] += sizz[Edge[i].to];
	}
}
bool check(int x, int s){
	dfs2(x, 0);
	bool flag = true;
	for(int i = head[x]; ~i; i = Edge[i].nxt)
	{
		if(fib[Edge[i].to][x])    continue;
		if(sizz[Edge[i].to] > s/2)
		{
			flag = false;
			return flag;
		}
	}
	return flag;
}
void calc(int x, int fa, int s){
	if(check(x, s))    
	{
		ans += 1LL*x;
		//printf("h: %d\n", x);
	}
	for(int i = head[x]; ~i; i = Edge[i].nxt)
	{
		if(fib[Edge[i].to][x])    continue;
		if(Edge[i].to == fa)    continue;
		calc(Edge[i].to, x, s);
	}
}
int main(void)
{
	freopen("centroid.in", "r", stdin);
	freopen("centroid.out", "w", stdout);
	int T; scanf("%d", &T);
	while(T--)
	{
		memset(head, -1, sizeof(head));
		scanf("%d", &n);
		for(int i = 1; i <= n-1; i++)    
		{
			scanf("%d %d", &u[i], &v[i]);
			in[u[i]]++; in[v[i]]++;
			if(u[i]+1 != v[i])    sub1 = false;
			Build(u[i], v[i]); Build(v[i], u[i]);
		}
		if(sub1)    {subtask1::solve(); continue;}
		for(int i = 1; i <= n-1; i++)
		{
			fib[u[i]][v[i]] = fib[v[i]][u[i]] = true;
			dfs1(u[i], 0); 
			calc(u[i], 0, siz[u[i]]);
			
			dfs1(v[i], 0); 
			calc(v[i], 0, siz[v[i]]);
			fib[u[i]][v[i]] = fib[v[i]][u[i]] = false;
			
			//printf("%d %d %d %d\n", u[i], v[i], siz[u[i]], siz[v[i]]);
		}
		printf("%lld\n", ans);
		ans = 0;
	}
	return 0;
}
