#include<cstdio>
#include<cstring>

const int P = 998244353;

inline void mo(int &x,int y){x = (x + y) % P;}
int x[50][510] , n , m , f[2][41][41][41];
int ans;

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	
	scanf("%d %d",&n,&m);
	for(int i = 1;i <= n;i ++)
		for(int j = 1;j <= m;j ++) scanf("%d",&x[i][j]);
	
	f[0][0][0][0] = 1;
	
	for(int i = 1;i <= n;i ++)
	{
		memset(f[i & 1] , 0 , sizeof f[i & 1]);
		
		for(int j = 0;j < i;j ++)
			for(int k = 0;k <= j;k ++)
				for(int l = 0;l + k <= j;l ++)
					if(f[i & 1 ^ 1][j][k][l])
					{
						int t = f[i & 1 ^ 1][j][k][l];
						mo(f[i & 1][j][k][l] , t);
						if(x[i][3]) mo(f[i & 1][j + 1][k][l] , 1ll * t * x[i][3] % P);
						if(x[i][1]) mo(f[i & 1][j + 1][k + 1][l] , 1ll * t * x[i][1] % P);
						if(x[i][2]) mo(f[i & 1][j + 1][k][l + 1] , 1ll * t * x[i][2] % P); 
					} 
	}
	
	for(int j = 2;j <= n;j ++)
		for(int k = 0;k <= j / 2;k ++)
			for(int l = 0;l + k <= j && l <= j / 2;l ++)
				if((j - k - l) <= j / 2) 
					if(f[n & 1][j][k][l]) mo(ans , f[n & 1][j][k][l]);
						
	printf("%d\n",ans);
	
	fclose(stdin) , fclose(stdout);
	return 0;
}
