#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

inline void read(int &x)
{
	x = 0;char c = getchar();
	while(c > '9' || c < '0') c = getchar();
	while(c >= '0' && c <= '9') x = x * 10 + c - '0' , c = getchar();
}

const int N = 5e5 + 100;

struct note
{
	int to , nex;
}g[N << 1];
int n , st[N] , fa[N] , size[N] , dfn[N] , tim , tot , T , rec[N];
long long ans;

inline void add(int u , int v)
{
	g[++ tot] = (note){v , st[u]} , st[u] = tot;
}

int solve(int tar)
{
	int ret = 0;
	for(int i = 1;i <= n;i ++)
		if(dfn[i] >= dfn[tar] && dfn[i] <= dfn[tar] + size[tar] - 1) 
		{
			int mx = 0;
			for(int j = st[i] ; j ; j = g[j].nex)
			{
				int v = g[j].to;
				if(i == tar && v == fa[i]) continue;
				mx = v == fa[i] ? max(mx , size[tar] - size[i]) : max(mx , size[v]); 
			}
			if(mx <= size[tar] / 2) ret += i;
		} 
		else
		{
			int mx = 0;
 			for(int j = st[i] ; j ; j = g[j].nex)
			{
				int v = g[j].to;
				if(v == tar) continue;
				if(v == fa[i])
				{
					if(dfn[i] + size[i] - 1 >= dfn[tar] && dfn[tar] >= dfn[i]) 
						mx = max(mx , n - size[i]);
					else
						mx = max(mx , n - size[tar] - size[i]);
				}
				else
					mx = max(mx , size[v] - (dfn[tar] >= dfn[v] && dfn[tar] <= dfn[v] + size[v] - 1 ? size[tar] : 0));
			}
			if(mx <= (n - size[tar]) / 2) ret += i;
		}
	return ret;
}

void dfs1(int now)
{
	dfn[now] = ++ tim , size[now] = 1;
	for(int i = st[now] ; i ; i = g[i].nex)
	{
		int v = g[i].to;
		if(v == fa[now]) continue;
		fa[v] = now , dfs1(v) , size[now] += size[v];
	}
}

void dfs2(int now)
{
	for(int i = st[now] ; i ; i = g[i].nex)
	{
		int v = g[i].to;
		if(v == fa[now]) continue;
		int t = solve(v);
		ans += t;dfs2(v);
	}
}

void dfs3(int now , int fa)
{
	rec[++ tot] = now;
	for(int i = st[now] ; i ; i = g[i].nex)
	{
		int v = g[i].to;
		if(v == fa) continue;
		dfs3(v , now);
	}
}
void clear(){ans = tim = 0;memset(st , 0 , sizeof st) , memset(fa , 0 , sizeof fa) , tot = 1;}

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	
	for(read(T) ; T -- ; )
	{
		clear() , read(n);
		for(int i = 1 , u , v ; i < n;i ++) read(u) , read(v) , add(u , v) , add(v , u);
		if(n <= 1999)
		{
			dfs1(1) , 
			dfs2(1) ;printf("%lld\n",ans);
		}
		
		if(n == 49991)
		{
			tot = 0 , dfs1(1);
			int id;
			for(int i = 1;i <= n;i ++) if(size[i] == 1) {id = i;break;}
			dfs3(id , 0);
			for(int i = 1;i < n;i ++)
			{
				ans += (i & 1) ? rec[i + 1 >> 1] : rec[i >> 1] + rec[(i >> 1) + 1];
				int len = n - i;
				ans += (len & 1) ? rec[i + (1 + len >> 1)] : rec[i + (len >> 1)] + rec[i + (len >> 1) + 1]; 		
			}
			printf("%lld\n",ans);
		}
		if(n > 49991) printf("F**K\n");
	}
	
	fclose(stdin) , fclose(stdout);
	return 0;
}
