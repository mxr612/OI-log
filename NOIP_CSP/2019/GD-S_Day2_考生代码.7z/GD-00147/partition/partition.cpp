#include<cstdio>
#include<algorithm>
#define LL long long
#include<cstring>

using namespace std;

inline void read(int &x)
{
	x = 0;char c = getchar();
	while(c > '9' || c < '0') c = getchar();
	while(c >= '0' && c <= '9') x = x * 10 + c - '0' , c = getchar();
}

const int N = 5e3 + 100;

int x[N] , n , opt;

LL ans, f[N][N] , sum[N];
LL sqr(LL x){return x * x;}

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	
	read(n) , read(opt);
	for(int i = 1;i <= n;i ++) read(x[i]) , sum[i] = sum[i - 1] + x[i];
	ans = sqr(sum[n]) , memset(f , 0x3f , sizeof f);
	
	for(int i = 1;i <= n;i ++) f[1][i] = sqr(sum[i]);
	
	for(int i = 1;i < n;i ++)
	{
		int j = i + 1;LL mi = f[0][0];
		for(int k = i + 1;k <= n;k ++)
		{
			while(j && sum[i] - sum[j - 2] <= sum[k] - sum[i]) -- j , mi = min(mi , f[j][i]);
			if(j <= i) f[i + 1][k] = min(f[i + 1][k] , mi + sqr(sum[k] - sum[i])); 
		}
	}

	for(int i = 1;i <= n;i ++) ans = min(ans , f[i][n]);
	printf("%lld\n",ans); 
	
	fclose(stdin) , fclose(stdout);
	return 0;
}
