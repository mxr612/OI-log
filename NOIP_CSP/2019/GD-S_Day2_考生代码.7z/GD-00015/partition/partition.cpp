#include<bits/stdc++.h>
using namespace std;
int a[500005],p[100005],l[100005],r[100005],b[500005];
vector <int> q[500005];
struct BigInt {
	int num[105],len;
	BigInt() {
		clear();
	}
	void clear() {
		memset(num,0,sizeof(num));
		len=0;
	}
	void itb(int n) {
		int cnt=0;
		len=0;
		while(n>0) {
			num[++cnt]=n%10;
			n/=10;
			len++;
		}
	}
	void write() {
		for(int i=len; i>0; i--) {
			cout<<num[i];
		}
	}
	bool empty() {
		return len==0;
	}
	friend BigInt operator + (const BigInt a,const BigInt b) {
		BigInt c;
		for(int i=1; i<=max(a.len,b.len); i++) {
			int k=a.num[i]+b.num[i];
			c.num[i]+=k;
			c.num[i+1]+=c.num[i]/10;
			c.num[i]%=10;
			if(c.num[i]) c.len=i;
			if(c.num[i+1]) c.len=i+1;
		}
		return c;
	}
	friend BigInt operator * (const BigInt a,const BigInt b) {
		BigInt c;
		for(int i=1; i<=a.len; i++) {
			for(int j=1; j<=b.len; j++) {
				int k=a.num[i]*b.num[j];
				c.num[i+j-1]+=k%10;
				c.num[i+j]+=k/10;
				if(c.num[i+j-1]) c.len=max(c.len,i+j-1);
				if(c.num[i+j]) c.len=max(c.len,i+j);
			}
		}
		for(int i=1; i<=c.len; i++) {
			if(c.num[i]>9) {
				c.num[i+1]+=c.num[i]/10;
				c.num[i]%=10;
			}
		}
		return c;
	}
	friend bool operator < (const BigInt a,const BigInt b) {
		if(a.len!=b.len) return a.len<b.len;
		else for(int i=a.len; i>0; i--) {
				if(a.num[i]!=b.num[i]) return a.num[i]<b.num[i];
			}
	}
} f[500005];
int main() {
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int n;
	bool ty;
	cin>>n>>ty;
	if(!ty) {
		for(int i=1; i<=n; i++) cin>>a[i];
	}
	BigInt sum,num;
	for(int i=1; i<=n; i++) {
		sum.clear();
		for(int j=i-1; j>0; j--) {
			num.itb(a[j+1]);
			sum=sum+num;
			if(f[j]<sum) {
				if(f[i].empty()) {
					f[i]=sum;
					q[i]=q[j];
					q[i].push_back(j);
					break;
				}
			}
		}
		if(f[i].empty()) {
			BigInt l;
			l.itb(a[i]);
			f[i]=f[i-1]+l;
		}
	}
	q[n].push_back(n);
	BigInt ans;
	for(int i=0; i<q[n].size(); i++) {
		ans=ans+f[q[n][i]]*f[q[n][i]];
	}
	ans.write();
}
