#include<bits/stdc++.h>
using namespace std;
int a[105][2005],cnt[2005],ans,n,m;
const int mod=998244353;
void dfs(int g,int step,int sum,int maxx) {
	if(maxx>n/2) return;
	if(maxx<=step/2&&g==n) ans+=sum;
	if(g>=n) return;
	for(int i=1; i<=m+1; i++) {
		if(i==m+1) {
			dfs(g+1,step,sum%mod,maxx);
		} else {
			cnt[i]++;
			if(a[g+1][i]) dfs(g+1,step+1,((sum%mod)*a[g+1][i])%mod,max(maxx,cnt[i]));
			cnt[i]--;
		}
	}
}
int main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1; i<=n; i++) {
		for(int j=1; j<=m; j++) {
			cin>>a[i][j];
			a[i][j]%=mod;
		}
		a[i][m+1]=1;
	}
	dfs(0,0,1,0);
	cout<<ans-1;
}
