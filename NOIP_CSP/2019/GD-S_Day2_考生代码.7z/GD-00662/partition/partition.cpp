#include<iostream>
#include<stdio.h>
using namespace std;
int n;
int temp=0;
int type;
int a[1001]={0};

int s=0;
int main()

{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>type;
	for(int i=0;i<n;i++) 
	{
		cin>>a[i];
		
	}
	for(int i=1;i<n;i++)
	{
		if(a[i]<a[i-1])
		{
			if(a[i-1]-a[i]<a[i+1]-a[i])
			{
				a[i-1]=a[i-1]+a[i];
			    a[i]=0;
			}
			else 
			{
				a[i+1]=a[i+1]+a[i];
			    a[i]=0;
			}
		}
	}
	for(int i=0;i<=n;i++)
	s=s+a[i]*a[i];
	cout<<s;
	
	
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
