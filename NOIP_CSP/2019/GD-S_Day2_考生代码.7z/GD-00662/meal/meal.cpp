#include<iostream>
#include<stdio.h>
using namespace std;
int n,m;//n:���� m��ʳ�� 
long long a[1001][1001]={0};
int tot=0;
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	cin>>a[i][j];
	if(n==2)
	{
		if(m==2) tot=a[1][1]*a[2][2]+a[1][2]*a[2][1];
		else if(m==3) tot=a[1][1]*(a[2][2]+a[2][3])+a[1][2]*(a[2][1]*a[2][3])+a[1][3]*(a[2][1]+a[2][2]);
	}
	cout<<tot;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
