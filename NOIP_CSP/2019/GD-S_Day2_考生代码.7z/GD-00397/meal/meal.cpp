#include <iostream>
#include <cstdio>
using namespace std;
const long long mod = 998244353;
int n,m;
long long S = 1,a[105][2005],s[105],f[105][105][105];
int read(){
	int x = 0;
	char c = getchar();
	while(c < '0' || c > '9') c = getchar();
	while(c >= '0' && c <= '9') x = x * 10 + (c ^ 48),c = getchar();
	return x;
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n = read(),m = read();
	for(int i = 1; i <= n; i ++){
		for(int j = 1; j <= m; j ++) a[i][j] = read(),s[i] = (s[i] + a[i][j]) % mod;
		S = S * (s[i] + 1) % mod;
	}
	S --;
	//cout << S << endl;
	for(int i = 1; i <= m; i ++){
		for(int j = 1; j <= n; j ++)
			for(int k = 1; k <= n; k ++)
				for(int l = 1; l <= n; l ++)
					f[j][k][l] = 0;
		f[0][0][0] = 1;
		for(int j = 1; j <= n; j ++){
			for(int k = 0; k <= j; k ++){
				for(int l = 0; l + k <= j; l ++){
					f[j][k][l] = (f[j - 1][k][l] + (k == 0 ? 0 : f[j - 1][k - 1][l] * a[j][i] % mod) + (l == 0 ? 0 : f[j - 1][k][l - 1] * (((s[j] - a[j][i]) % mod + mod) % mod) % mod)) % mod;
				}
			}
		}
//		cout << i << endl;
//		for(int j = 1; j <= n; j ++){
//			for(int k = 0; k <= j; k ++){
//				for(int l = 0; l + k <= j; l ++){
//					cout << j << ' ' << k << ' ' << l << ' ' << f[j][k][l] << endl;
//				}
//			}
//		}
		for(int j = 1; j <= n; j ++){
			for(int k = j / 2 + 1; k <= j; k ++){
				S = ((S - f[n][k][j - k]) % mod + mod) % mod;
			}
		}
	}
	cout << S << endl;
	return 0;
}
