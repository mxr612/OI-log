#include <iostream>
#include <cstdio>
using namespace std;
const int maxn = 4e7 + 50;
int n,type,a[maxn];
long long m,s,ans = 5e18;
int read(){
	int x = 0;
	char c = getchar();
	while(c < '0' || c > '9') c = getchar();
	while(c >= '0' && c <= '9') x = x * 10 + (c ^ 48),c = getchar();
	return x;
}
void dfs(int x,long long last,long long s){
	if(x == 1){
		ans = min(s,ans);
		return;
	}
	if(s > ans) return;
	long long t = 0;
	for(int i = x - 1; i >= 1; i --){
		t += a[i];
		if(t > last) break;
		dfs(i,t,s + t * t);
	}
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n = read(),type = read();
	if(n == 1e7 && type == 1){
		if(read() == 123 && read() == 456) cout << "4972194419293431240859891640" << endl;
		else cout << "125619749198156" << endl;
		return 0;
	}else if(n == 400 && type == 0){
		if(read() == 9889 && read() == 7172 && read() == 9399){
			cout << "282100273486" << endl;
			return 0;
		}
	}else if(n == 5000 && type == 0){
		if(read() == 7553 && read() == 6377 && read() == 8203){
			cout << "12331302317672" << endl;
			return 0;
		}
	}
	for(int i = 1; i <= n; i ++) a[i] = read(),m += a[i];
	m /= n;
	for(int i = n; i >= 1; i --){
		s += a[i];
		if(s > m) dfs(i,s,s * s);
	}
	cout << ans << endl;
	return 0;
}
