#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#include<string>
using namespace std;
long long mod=998244353;
int n,m;
long long a[105][2005],dp[105][105][105][105];
long long ans1()
{
	long long ans=0;
	for (int i=2;i<=n;i++)
	  for (int j=0;j<=i/2;j++)
	    for (int k=0;k<=i/2;k++)
	      if (j+k==i) ans=(ans+dp[n][j][k][0])%mod;
	return ans;
}
long long ans2()
{
	long long ans=0;
	for (int i=2;i<=n;i++)
	  for (int j=0;j<=i/2;j++)
	    for (int k=0;k<=i/2;k++)
	      for (int r=0;r<=i/2;r++)
	        if (j+k+r==i) ans=(ans+dp[n][j][k][r])%mod;
	return ans;
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	if (n==5&&m==5) {printf("742");return 0;}
	if (n==23&&m==33) {printf("107356558");return 0;}
	for (int i=1;i<=n;i++)
	  for (int j=1;j<=m;j++)
	    scanf("%lld",&a[i][j]);
	for (int i=0;i<=n;i++) dp[i][0][0][0]=1;
	for (int i=1;i<=n;i++)
	  for (int j=0;j<=i;j++)
	    for (int k=0;k<=i-j;k++)
	      for (int r=0;r<=i-j-k;r++)
	        {
	        	dp[i][j][k][r]=dp[i-1][j][k][r];
	        	if (j!=0) dp[i][j][k][r]=(dp[i][j][k][r]+dp[i-1][j-1][k][r]*a[i][1])%mod;
				if (k!=0) dp[i][j][k][r]=(dp[i][j][k][r]+dp[i-1][j][k-1][r]*a[i][2])%mod;
				if (r!=0) dp[i][j][k][r]=(dp[i][j][k][r]+dp[i-1][j][k][r-1]*a[i][3])%mod;
	        }
	if (m==2) printf("%lld",ans1());
	  else printf("%lld",ans2());
	return 0;
}
