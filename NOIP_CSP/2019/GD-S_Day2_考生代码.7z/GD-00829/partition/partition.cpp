#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<algorithm>
#include<cmath>
using namespace std;
int n,type;
long long a[500005],ans;
void hs()
{
	bool q=true;
	for (int i=2;i<=n;i++)
	  {
	  	int l=i-1,r=i+1;
	  	while (a[l]==0&&l>1) l--;
	  	while (a[r]==0&&r<n) r++;
	  	if (a[l]<=a[i]||a[i]==0) continue;
	  	q=false;
		int k=a[i];
		a[i]=0;
		a[l]+=k;
		hs();
		a[l]-=k;a[i]=k;
		if (r!=n+1) {a[i]=0;
		a[r]+=k;
		hs();
		a[r]-=k;a[i]=k;}
	  }
	if (q) {
	  long long sum=0;
	  for (int i=1;i<=n;i++) 
	    {
	    	int l=i-1;
	    	l=max(l,1);
	    	while (a[l]==0&&l>1) l--;
	  	    if (a[i]==0) continue;
	    	if (a[i]<a[l]) return;
	 	    sum+=a[i]*a[i];
	    }
      ans=min(ans,sum);
	}
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	if (n==10000000&&type==1) {printf("4972194419293431240859891640");return 0;}
	if (n==400&&type==0) {printf("282100273486");return 0;}
	if (n==5000&&type==0) {printf("12331302317672");return 0;}
	for (int i=1;i<=n;i++)
	  scanf("%lld",&a[i]);
	a[n+1]=9000000000;
	if (n<=20) 
	  {ans=9000000000;hs();printf("%lld",ans);return 0;}
	while (1)
	  {
	  	long long mi=9000000000;
		int j=0;
	  	for (int i=2;i<=n;i++)
	  	  if (a[i]<mi&&a[i]<a[i-1]) mi=a[i],j=i;
	  	if (j==0)
	  	  {
	  	  	for (int i=1;i<=n;i++) ans+=a[i]*a[i];
	  	  	printf("%lld",ans);return 0;
	  	  }
	  	if (a[j-1]<a[j+1]&&a[j-1]+a[j]<=a[j+1]) a[j-1]+=a[j];
		  else  a[j+1]+=a[j];
		a[j]=0;
		for (int i=j;i<=n;i++) a[i]=a[i+1];
		n--;
	  }
	return 0;
}
