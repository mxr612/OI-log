#include<bits/stdc++.h>
using namespace std;
#define F(j,a,b) for(register int j=a;j<=b;++j)
#define Fu(j,a,b) for(register int j=a;j<b;++j)
#define Fd(j,a,b) for(register int j=a;j>=b;--j)

const int N=1000860;
#define LL long long
int n;
int a[N];
void solve()
{
	LL ans =0;
	LL a;
	LL pre;
	cin>>pre;
	F(i,2,n)
	{
		
		cin>>a;
		//cout<<"pre="<<pre<<" a="<<a<<" "; 
		
		if(a<pre)pre+=a;
		else 
		{
		
			ans+=pre*pre,pre=a;
		}
	}
	ans+=pre*pre;
	cout<<ans;
	

}

const LL INF=(1ull<<62)-1;
map<int,LL> mat[N];

LL dfs(int cur,int val)
{
	
	if(cur==n)
	{
		return 0;
	}
	if(mat[cur][val])return mat[cur][val];
	LL mm=0;
	LL anss=INF; 

	F(i,cur+1,n)
	{
		mm+=a[i];
		if(mm>=val)anss=min(dfs(i,mm)+mm*mm,anss);
	}
	
	//printf("\ncur=%d,val=%d\n",cur,val);
	mat[cur][val]=anss;
	//cout<<"ans="<<anss<<" ";	
	return anss;
	
}


void solve2()
{
	F(i,1,n)cin>>a[i];
	cout<<dfs(0,0);
}


int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	
	int type;
	cin>>n>>type;
	if(!type)solve2();
	//cout<<"INF="<<INF;
	return 0;
}
