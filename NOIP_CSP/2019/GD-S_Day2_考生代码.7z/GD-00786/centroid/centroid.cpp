#include<bits/stdc++.h>
using namespace std;
#define F(j,a,b) for(register int j=a;j<=b;++j)
#define Fu(j,a,b) for(register int j=a;j<b;++j)
#define Fd(j,a,b) for(register int j=a;j>=b;--j)
#define LL long long
const int N=1008880;
int T;
int n;
int a[N],b[N];

vector<int>son[N];
int sz[N];


int ans=0;




void dfs(int u,int fa)
{
	sz[u]=1;
	int si=son[u].size();
	Fu(i,0,si)
	{
		int v=son[u][i];
		if(v==fa)continue;
		dfs(v,u);
		sz[u]+=sz[v];
	}
	
}


int dfs2(int u,int fa,int allsz)
{
	
	int mid=-1,maxx=0;
	int si=son[u].size();
	Fu(i,0,si)
	{
		int v=son[u][i];
		if(v==fa)continue;
		if(dfs2(v,u,allsz))return 1;
		
		if(sz[v]>maxx)maxx=sz[v],mid=v;
	}
	if(allsz-sz[u]>maxx)maxx=allsz-sz[u],mid=fa;
	if(maxx<=allsz/2)
	{
		if(maxx*2==allsz)ans+=mid+u;
		else ans+=u;
		return 1;
	}
	return 0;
}

int solve(int t)
{
	F(i,1,n)son[i].clear();
	memset(sz,0,sizeof(sz));
	
	Fu(i,1,n)
	{
		if(i==t)continue;
		son[a[i]].push_back(b[i]);
		son[b[i]].push_back(a[i]);  
	}
	
	ans=0;
	dfs(a[t],0);
	dfs2(a[t],0,sz[a[t]]);
	
	dfs(b[t],0);
	dfs2(b[t],0,sz[b[t]]);
	
	return ans;
}



int ser[N];





int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	cin>>T;
	while(T--)
	{
		LL aa=0;
		cin>>n;
		
		Fu(i,1,n)
		cin>>a[i]>>b[i];
		Fu(i,1,n)
		aa+=solve(i);
		cout<<aa<<endl;
	}
	
	
	
	return 0;
}
