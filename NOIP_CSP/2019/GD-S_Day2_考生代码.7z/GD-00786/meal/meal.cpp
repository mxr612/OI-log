#include<bits/stdc++.h>
using namespace std;
#define F(j,a,b) for(register int j=a;j<=b;++j)
#define Fu(j,a,b) for(register int j=a;j<b;++j)
#define Fd(j,a,b) for(register int j=a;j>=b;--j)

const int N=0;
#define LL long long
int a[110][2100];
int num[2100];
const int p=998244353;
LL ans;
int n,m;
void dfs(int cur,LL sm,int k)
{
	if(cur==n+1)return;
	F(j,1,m)
	{	
		if(a[cur][j])
		{
			
	
			if(num[j]+1<=k/2)
			{
				int fff=1;
				F(l,1,m)if(num[l]>k/2)fff=0;
				if(fff)ans+=(sm*a[cur][j])%p;
				ans%=p;
			}		
			num[j]++;
			dfs(cur+1,(sm*a[cur][j])%p,k+1);
			num[j]--;
		}
	}
	
	dfs(cur+1,sm,k);
}


int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);

	cin>>n>>m;
	
	
	F(i,1,n)
	F(j,1,m)
	{
		cin>>a[i][j];	
	}
	
	ans=0;
	dfs(1,1,1);
	
	cout<<ans;
	return 0;
}
