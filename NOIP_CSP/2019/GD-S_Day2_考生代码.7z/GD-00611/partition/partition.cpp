#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;
typedef long long ll;
ll n,typ,a[500005],ans=0,lst,tmp;
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
//�ɱ��� 
	scanf("%lld%lld",&n,&typ);
	if	(typ==0){
		lst=0, tmp=0;
		for	(ll i=1;i<=n;i++){
			scanf("%lld",&a[i]);
			tmp+=a[i];
			if	(tmp>=lst){
				lst=tmp;
				ans+=tmp*tmp;
				tmp=0;
			}
		}
		printf("%lld\n",ans);
	}








	fclose(stdin);
	fclose(stdout);
	return 0;
}
