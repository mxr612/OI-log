#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;
typedef long long ll;
ll n,m,a[105][2005],f[105],ans=0,jc[105];
inline void qjc(){
	jc[0]=1;
	for	(ll i=1;i<105;i++){
		jc[i]=(jc[i-1]*i)%998244353;
	}
	return ;
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for	(ll i=1;i<=n;i++){
		for	(ll j=1;j<=m;j++){
			scanf("%lld",&a[i][j]);
		}
	}
	qjc();
//	if	(m==2){
		for	(ll i=1;i<=n;i++){
			if	(i%2==1)	f[i]=0;
			else{
				f[i]=jc[i]/(jc[i/2]*jc[i/2]%998244353)%998244353;
			}
			ans+=f[i];
		}
//	}
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
