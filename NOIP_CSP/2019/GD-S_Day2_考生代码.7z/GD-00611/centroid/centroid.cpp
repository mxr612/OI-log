#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
using namespace std;
typedef long long ll;
struct edge{
	int to,bot;
}e[600000];
int head[300000],ds[300000],ecnt=0;
inline void add_edge(int u, int v){
	e[++ecnt].to=v;
	e[ecnt].bot=head[u];
	head[u]=ecnt;
	return ;
}
int T,n,typ,lie[300000];
ll ans;
bool ed[300000];
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	for	(int I=1;I<=T;I++){
		ans=0;
		typ=1;
		scanf("%d",&n);
		memset(head,0,sizeof(head));
		memset(ds,0,sizeof(ds));
		for	(int i=1;i<=n;i++)	ed[i]=true;
		int u,v;
		for	(int i=1;i<n;i++){
			scanf("%d%d",&u,&v);
			add_edge(u,v);
			add_edge(v,u);
			++ds[u], ++ds[v];
			if	(ds[u]>2||ds[v]>2)	typ=0;
			if	(ds[u]==2)	ed[u]=false;
			if	(ds[v]==2)	ed[v]=false;
		}
		int ted;
		for	(int i=1;i<=n;i++){
			if	(ed[i]){
				ted=i;
				break;
			}
		}
		if	(typ==1){
			int now=ted,lst=0;
			for	(int i=1;i<=n;i++){
				lie[i]=now;
				for	(int j=head[now];j;j=e[j].bot){
					if	(e[j].to!=lst){
						lst=now;
						now=e[j].to;
						break;
					}
				}
			}
			for	(int i=1;i<n;i++){
				if	(i&1){
					ans+=lie[(1+i)/2];
				}else{
					ans+=lie[i/2]+lie[(i/2)+1];
				}
				if	((n-i)&1){
					ans+=lie[(i+1+n)/2];
				}else{
					ans+=lie[(i+1+n)/2]+lie[(i+1+n)/2+1];
				}
			}
			printf("%lld\n",ans);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
