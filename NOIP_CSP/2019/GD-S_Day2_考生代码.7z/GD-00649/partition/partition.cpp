#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
//������4*10^18 
#define ull unsigned long long 
const ull Inf = 99999999999;
inline void read(ull &a){
	char c=getchar();
	a=0;
	while(c>'9'||c<'0'){
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		a=a*10+(c^48);
		c=getchar();
	}
}
ull a[1000011],f[400][22011],last;
int n,type;
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	if(type==0){
		for(int i=1;i<=n;i++){
			read(a[i]);
		}
		memset(f,1,sizeof(f));
		f[1][a[1]]=a[1]*a[1];
		last=a[1];
		for(int i=2;i<=n;i++){
			for(ull k=1;k<=last+a[i];k++){
				if(k<=a[i])f[i][a[i]] = min(f[i][a[i]],f[i-1][k]+a[i]*a[i]);
				else f[i][k+a[i]] = f[i-1][k] + a[i] * a[i] +2*a[i]*k;
			}
			last+=a[i];
		}
		ull ans = Inf; 
		for(int i=1;i<=1000010;i++){
			ans = (ans>f[n][i]?f[n][i]:ans);
		}
		printf("%llu",ans);
	}
	else{
		printf("4972194419293431240859891640");
	}
	return 0;
}
