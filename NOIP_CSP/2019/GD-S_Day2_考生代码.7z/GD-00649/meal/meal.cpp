#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
inline void read(int &a){
	char c=getchar();
	a=0;
	while(c>'9'||c<'0'){
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		a=a*10+(c^48);
		c=getchar();
	}
}
const long long p=998244353;
int n,m;
int a[1000][105];
struct zt{
	int num;
	long long q;
}sum[(1<<15)];
int tot=0;
long long ans=0;
inline void dfs(int wei,int nums,long long now){
	if(wei==n){
		sum[++tot].num=nums;
		sum[tot].q=now;
		return;
	}
	dfs(wei+1,nums,now<<1);
	dfs(wei+1,nums+1,(now<<1)|1);
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	read(n);read(m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			read(a[i][j]);
		}
	}
	dfs(0,0,0);
	if(m==2){
		for(int i=1;i<=tot;i++){
			if(sum[i].num==0)continue;
			for(int j=1;j<=tot;j++){
				if(((sum[i].q)&(sum[j].q))>0)continue;
				if(sum[i].num!=sum[j].num)continue;
				if(sum[i].num==0)continue;
				if(sum[j].num==0)continue;
				long long tmp=1;
				long long q1=sum[i].q,q2=sum[j].q;
				int num1=1,num2=1;
				while(q1){
					if(q1&1){
						//printf("1(choose %d)  ",num1);
						tmp = (tmp *(long long)a[num1][1])%p;
					}
					num1++;
					q1>>=1;
				}
				while(q2){
					if(q2&1){
						//printf("2(choose %d) ",num2);
						tmp = (tmp *(long long)a[num2][2])%p;
					}
					num2++;
					q2>>=1;
				}
				ans = (ans + tmp)%p;
				//printf("ans += %lld\n",tmp);
			}
		}
		printf("%lld",ans);
	}
	if(m==3){
		for(int i=1;i<=tot;i++){
			for(int j=1;j<=tot;j++){ 
				if((sum[j].q&sum[i].q)>0)continue;
				for(int k=1;k<=tot;k++){ 
					if((sum[j].q&sum[k].q)>0)continue;
					if((sum[i].q&sum[k].q)>0)continue;
					if(sum[i].num+sum[j].num+sum[k].num==0)continue;
					if(max(sum[i].num,max(sum[j].num,sum[k].num)) > (sum[i].num+sum[j].num+sum[k].num)/2) continue;
					long long tmp=1;
					long long q1=sum[i].q,q2=sum[j].q,q3=sum[k].q;
					int num1=1,num2=1,num3=1;
					while(q1){
						if(q1&1){
							//printf("1(choose %d)  ",num1);
							tmp = (tmp *(long long)a[num1][1])%p;
						}
						num1++;
						q1>>=1;
					}
					while(q2){
						if(q2&1){
							//printf("2(choose %d)  ",num2);
							tmp = (tmp *(long long)a[num2][2])%p;
						}
						num2++;
						q2>>=1;
					}
					while(q3){
						if(q3&1){
							//printf("3(choose %d)  ",num3);
							tmp = (tmp *(long long)a[num3][3])%p;
						}
						num3++;
						q3>>=1;
					}
					ans = (ans+tmp)%p;
					//printf("ans += %lld\n",tmp);
				}
			}
		}
		printf("%lld",ans);
		
	}
	return 0;
}
