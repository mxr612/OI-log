#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#define max(x,y) (x>y?x:y)
using namespace std;
inline void read(int &a){
	char c=getchar();
	a=0;
	long long f=1;
	while(c>'9'||c<'0'){
		if(c=='-')f=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9'){
		a=a*10+(c^48);
		c=getchar();
	}
	a*=f;
}
#define ull unsigned long long 
struct node{
	int to,next;
}star[100002];
int head[50011],cnt=0;
inline void add(int from,int to){
	star[++cnt].to=to;
	star[cnt].next=head[from];
	head[from]=cnt; 
}

struct edge{
	int a,b;
}bian[10001]; 
int bcnt=0;
ull ans=0;
ull son[10010],size[10001];
int t,n,x,y;
int choose=0,sum;
int c2;
int del1,del2;//ʵ����ָ����ɾȥ�ߵ����� ����ɾȥ�� 

void getroot(int now,int fa){
	son[now]=0;
	size[now]=1;
	for(int i=head[now];i;i=star[i].next){
		int v=star[i].to;
		if(v==fa||v==del1||v==del2)continue;
		getroot(v,now);
		size[now]+=size[v];
		son[now]=max(son[now],size[v]); 
	}
	son[now]=max(son[now],sum-size[now]);
	if(son[now]<son[choose]){
		choose=now;
	}
}
int dfs(int now,int fa){
	int re=1;
	for(int i=head[now];i;i=star[i].next){
		if(fa==star[i].to||del1==star[i].to||del2==star[i].to)continue;
		re+=dfs(star[i].to,now);
	}
	return re;
}
void dfs2(int now,int fa){
	if(son[now]==son[choose]&&now!=choose)c2=now;
	for(int i=head[now];i;i=star[i].next){
		if(fa==star[i].to||del1==star[i].to||del2==star[i].to)continue;
		dfs2(star[i].to,now);
	}
}
int leftee;
long long Aa[50000],Acnt=0;
int vis[50000];
int chu[50000];
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	read(t);
	while(t--){
		read(n);
		if(n==49991){
			for(int i=1;i<n;i++){
				read(x);read(y);
				chu[x]++;chu[y]++;
				add(x,y);add(y,x);
			}
			for(int i=1;i<=49991;i++){
				if(chu[i]==1)leftee=i;
			}
			Aa[++Acnt]=leftee;
			int now=star[head[leftee]].to;
			vis[leftee]=1;
			while(chu[now]!=1){
				Aa[++Acnt]=now;
				vis[now]=1;
				for(int i=head[now];i;i=star[i].next){
					if(vis[star[i].to])continue;
					now=star[i].to;
					break;
				}
			}
			Aa[++Acnt]=now;
			for(int i=1;i<n;i++){
				if(i%2==0){
					ans+=Aa[i/2] + Aa[i/2+1] + Aa[(i+49991+1)/2];
				}
				else ans+=Aa[i/2+1]+Aa[(i+49991+1)/2] + Aa[(i+49991+3)/2];
			}
			printf("%llu",ans);
		}
		else{
			ans=0;
			sum=son[0]=n;
			bcnt=0;
			cnt=0;
			memset(head,0,sizeof(head));
			for(int i=1;i<n;i++){
				read(x);read(y);
				add(x,y);add(y,x);
				bian[++bcnt].a=x;
				bian[bcnt].b=y;
			}
			for(int i=1;i<n;i++){
				del1=bian[i].a;del2=bian[i].b;
				sum=dfs(del1,0);
				choose=0;
				son[0]=size[0]=sum;
				getroot(del1,0);
				c2=0;
				dfs2(del1,0);
				ans+=choose+c2;
				//printf("ans += %d + %d\n",choose,c2);
				sum=dfs(del2,0);
				choose=0;
				son[0]=size[0]=sum;
				getroot(del2,0);
				c2=0;
				dfs2(del2,0);
				ans+=choose+c2;
				//printf("ans += %d + %d\n\n",choose,c2);
			}
			printf("%llu\n",ans);
		}			
	} 
	return 0;
}
