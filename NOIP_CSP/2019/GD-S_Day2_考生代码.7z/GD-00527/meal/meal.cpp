#include<bits/stdc++.h>
using namespace std;
long long n,m,a[101][2001],pp[2001];
long long ans,an=1,k=0;
void check(void)
{
	long long ant=0,maxx=0,ll=1;
	for(int i=1;i<=m;++i)
	{
		maxx=max(maxx,pp[i]);
		ant+=pp[i];
	}
	if(maxx<=ant/2&&k>1)
	{
		ans+=an;
		ans%=998224353;
	}
}
void asdf(int x)
{
	while(1)
	{
		if(an%x==0)
		{
			an/=x;
			break;
		}
		else
		{
			an+=998224353;
		}
	}
}
void find(int x)
{
	if(x==n+1)
	{
		check();
		return;
	}
	k++;
	for(int i=1;i<=m;++i)
	{
		if(a[x][i]==0)
		{
			continue;
		}
		an*=a[x][i];
		an%=998244353;
		pp[i]++;
		find(x+1);
		pp[i]--;
		asdf(a[x][i]);
	}
	k--;
	find(x+1);
	return;
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	memset(pp,0,sizeof(pp));
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			cin>>a[i][j];
		}
	}
	ans=0;
	find(1);
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
