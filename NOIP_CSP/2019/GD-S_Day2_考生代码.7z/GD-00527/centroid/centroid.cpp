#include<bits/stdc++.h>
using namespace std;
struct node
{
	int fo,to,nex;
}tt[600001];
int t,a[600001],head[600001],cnt=0,du[600001];
unsigned long long n;
int add(int x,int y)
{
	cnt++;
	tt[cnt].fo=x;
	tt[cnt].to=y;
	tt[cnt].nex=head[x];
	head[x]=cnt;
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	unsigned long long ans=0;
	cin>>t;
	while(t--)
	{
		ans=0;
		memset(du,0,sizeof(du));
		cin>>n;
		int x,y,k=0,pq=0,kk,emmm=0;
		for(int i=1;i<n;++i)
		{
			cin>>x>>y;
			add(x,y);
			add(y,x);
			du[x]++;
			du[y]++;
		}
		for(int i=1;i<=n;++i)
		{
			if(du[i]==2)
			{
				k++;
				kk=i;
			}
			if(du[i]==1)
			{
				pq++;
				emmm+=i;
			}
		}
		if(k==1&&pq==n/2+1)
		{
			if(n==3)
			{
				cout<<"12"<<endl;
				continue;
			}
			ans=(unsigned long long)n*(n+1)/2;
			ans+=kk*(n/2);
			ans+=(n/2)*(tt[head[kk]].to+tt[tt[head[kk]].nex].to);
		}
		if(k==n-2&&pq==2)
		{
			ans+=n*(n-1)/2;
			ans+=n*(n-1)/2;
			ans+=n*(n-1)/2;
			ans-=emmm;
			if(n%2==0)
			{
				ans-=tt[cnt/2].fo;
				ans-=tt[cnt/2].to;
			}
			else
			{
				ans-=tt[cnt/2].fo;
			}
		}
		cout<<ans<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
