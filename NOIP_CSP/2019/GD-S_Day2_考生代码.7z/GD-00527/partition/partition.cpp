#include<bits/stdc++.h>
using namespace std;
struct node
{
	long long num,fo,to;
}a[500001];
long long n,t,endd,inff,maxx[500001];
bool check()
{
	for(int i=inff;i!=n+1;i=a[i].to)
	{
		maxx[i]=max(maxx[a[i].fo],a[i].num);
	}
	for(int i=endd;i!=0;i=a[i].fo)
	{
		if(a[i].num<a[a[i].fo].num)
		{
			return 0;
		}
	}
	return 1;
}
int change()
{
	for(int i=endd;a[i].fo!=0;i=a[i].fo)
	{
		if(a[i].num<maxx[i])
		{
			if(i==endd)
			{
				a[a[i].fo].to=n+1;
				a[a[i].fo].num+=a[i].num;
				endd=a[i].fo;
			}
			else
			{
				if(a[a[i].fo].num+a[i].num>a[a[i].to].num)
				{
					if(a[i].fo==0)
					{
						inff=a[i].to;
					}
					a[a[i].to].fo=a[i].fo;
					a[a[i].fo].to=a[i].to;
					a[a[i].to].num+=a[i].num;
				}
				else
				{
					a[a[i].fo].to=a[i].to;
					a[a[i].to].fo=a[i].fo;
					a[a[i].fo].num+=a[i].num;
				}
			}
		}
	}
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>t;
	maxx[0]=0;
	if(t==1)
	{
		cout<<"emmm"<<endl;
		fclose(stdin);
		fclose(stdout);
		return 0;
	}
	else for(int i=1;i<=n;++i)
	{
		cin>>a[i].num;
		a[i].fo=i-1;
		a[i].to=i+1;
	}
	endd=n;
	inff=1;
	a[1].fo=0;
	a[n].to=n+1;
	while(!check())
	{
		change();
	}
	unsigned long long ans=0;
	for(int i=inff;i!=a[i].to;i=a[i].to)
	{
		ans+=a[i].num*a[i].num;
	}
	cout<<ans<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
