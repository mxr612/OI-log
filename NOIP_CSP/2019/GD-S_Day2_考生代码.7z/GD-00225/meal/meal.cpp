#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
int shiyong[2005];
int cai[105][2005];
int n,m;
bool ling[105];
long long int ans;
const long long int zhishu=998244353;
void dfs(int di,long long int fangfa,int zhong)
{
	if (di==n+1){
		bool f=1;
		for (int i=1;i<=m;i++) if (shiyong[i]>zhong/2){
			f=0;
			break;
		}
		if (f && fangfa>0){
			ans=(ans+fangfa)%zhishu;
			printf("%d\n",fangfa);
		}
		return ;
	}
	for (int i=1;i<=m;i++)
	{
		if (cai[di][i]>0){
			shiyong[i]++;
			if (fangfa>0){
				long long int q=fangfa;
				fangfa=fangfa*cai[di][i]%zhishu;
				di++;
				zhong++;
				dfs(di,fangfa,zhong);
				di--;
				zhong--;
				fangfa=q;
			}
			else if (fangfa==0){
				zhong++;
				fangfa=cai[di][i]%zhishu;
				di++;
				dfs(di,fangfa,zhong);
				zhong--;
				fangfa=0;
				di--;
			}
			shiyong[i]--;
		}
	}
	dfs(di+1,fangfa,zhong);
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
	{
		bool f=0;
		for (int j=1;j<=m;j++)
		{
			scanf("%d",&cai[i][j]);
			if (f && cai[i][j]==0) cai[i][j]=-1;
			if (cai[i][j]==0) f=1;
		}
	}
	dfs(1,0,0);
	ans=ans%zhishu;
	printf("%d",ans);
	return 0;
}
