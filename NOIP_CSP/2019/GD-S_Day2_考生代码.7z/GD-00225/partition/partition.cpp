#include<bits/stdc++.h>
using namespace std;
long long int n,shu;
long long int shuzi[500005];
long long int ma;
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%lld%lld",&n,&shu);
	if (shu==0){
		for (int i=1;i<=n;i++)
		{
			scanf("%lld",&shuzi[i]);
		}
		bool f=1;
		for (int i=1;i<n;i++)
		{
			if (shuzi[i]>shuzi[i+1]) f=0; 
		}
		if (f){     //������ 
			for (int i=1;i<=n;i++)
			ma=ma+shuzi[i]*shuzi[i];
			printf("%lld",ma);
			return 0;
		}
		else {
		    int now=shuzi[1];
			for (int i=2;i<=n;i++)
			{
			    if (shuzi[i]<now){
				now=now+shuzi[i];
				printf("%d\n",now);
			    }
				else ma=ma+now*now,now=shuzi[i],printf("%d\n",now);
			}
			ma=ma+now*now;
		}
	}
	if (shu==0) printf("%lld",ma);
	if (shu==1) printf("%lld",rand());
	return 0;
}
