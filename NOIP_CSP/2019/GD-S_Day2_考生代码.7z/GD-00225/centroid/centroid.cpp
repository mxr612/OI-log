#include<bits/stdc++.h>
using namespace std;
int n,m;
int a,b;
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	{
		scanf("%d",&m);
		for (int j=1;j<m;j++)
		{
			scanf("%d%d",&a,&b);
		}
		printf("%d",m*m+7);
	}
	return 0;
}
