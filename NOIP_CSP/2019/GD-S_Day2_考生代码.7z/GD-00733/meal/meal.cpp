#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;

const int maxn=2005;
const int mod=998244353;

int n,m;
int map[maxn][maxn];
bool vis[maxn][maxn];
int same[maxn];			//��ͬ�Ĳ��ж��ٵ��� 
long long ans;

void dfs(int x,int y,long long num,int dep){
	if(x and y){
		num=(num*map[x][y])%mod;
		if(!num)	return;
		same[y]++;
		bool f=true;
		for(int i=1;i<=m;i++)
			if(same[i]>dep/2){
				f=false;
				break;
			}
		if(f)
			ans=(ans+num)%mod;
	}
	for(int i=x+1;i<=n;i++)
		for(int j=1;j<=m;j++)
			dfs(i,j,num,dep+1);
	if(x and y)	same[y]--;
}

int main(){						//dfs����������dp?�� 
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&map[i][j]);
	dfs(0,0,1,0);
	printf("%lld\n",ans%mod);
	return 0;
}
