#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;

const int maxn=50005;	

int t,n;
int lian[maxn];

int main(){			//9~11���ַ� 
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1;i<n;i++){
			int u,v;
			scanf("%d %d",&u,&v);
			lian[i]=u;
			if(i==n-1)
				lian[i+1]=v;
		}
		long long ans=0;
		for(int k=1;k<n;k++){		//ö�ٶϱ�(k,k+1) 
			int rt1=(k+1)/2,rt2=(k+1+n)/2,rt3;
			if(k%2)
				rt3=rt2+1;
			else
				rt3=rt1+1;
			ans+=lian[rt1]+lian[rt2]+lian[rt3];
		}
		printf("%lld\n",ans);
	}
	return 0;
}
