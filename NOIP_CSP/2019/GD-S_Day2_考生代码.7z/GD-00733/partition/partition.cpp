#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;

const int maxn=500005;

int n,type;
long long arr[maxn];
bool cut[maxn];		//��i�ĺ����� 
long long ans=1<<30;

void dfs(int x,int k){
	if(!k){
		long long tmp=0,check=0;
		for(int i=1;i<=n;i++){
			tmp+=arr[i];
			if(cut[i]){
				if(check>tmp)		//���Ϸ� 
					return;
				check=tmp;
				tmp=0;
			}
		}
		long long res=0;
		tmp=0;
		for(int i=1;i<=n;i++){
			tmp+=arr[i];
			if(cut[i]){
				res+=tmp*tmp;
				tmp=0;
			}
		}
		ans=min(ans,res);
		return;
	}
	for(int i=x+1;i<n;i++){
		cut[i]=true;
		dfs(i,k-1);
		cut[i]=false;
	}
}

int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d %d",&n,&type);
	if(type==1)	return 0;
	for(int i=1;i<=n;i++)
		scanf("%d",&arr[i]);
	cut[n]=true;				//��βҪ��һ�� 
	for(int k=0;k<n;k++)		//����ö���ж��ٵ� 
		dfs(0,k);
	printf("%lld\n",ans);
	return 0;
}
