#include <iostream>
#include <stdio.h>
#include <vector>
using namespace std;
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int n,type;
	cin>>n>>type;
	int a[n];
	int x,y,z,b1,b2,m;
	vector<int> b;
	vector<int> pa;
	if(type==0)
	{
		for(int i=0;i<n;i++)
		{
			cin>>a[i];
		}
	}
	else
	{
		cin>>x>>y>>z>>b1>>b2>>m;
		b.push_back(b1);
		b.push_back(b2);
		int plr[3][m];
		for(int i=0;i<m;i++)
		{
			cin>>plr[0][i]>>plr[1][i]>>plr[2][i];
		}
	}
	int i=0,j=1,k=1,sum=0;
	while(i<n&&j<n&&k<n)
	{
		while(i<n&&j<n&&k<n)
		{
			if(a[i]>a[j])
			{
				j++;
			}
			else
			{
				k=i+1;
				break;
			}
		}
		sum=0;
		while(k<j)
		{
			sum+=a[k];
			if(sum>a[i])
			{
				break;
			}
			else
			{
				k++;
			}
		}
		if(sum>a[i])
		{
			pa.push_back(a[i]);
			a[k]=sum;
			i=k;
			j=k+1;
		}
		else
		{
			if(sum+a[i]<a[j]||sum+a[i]<sum+a[j])
			{
				pa.push_back(sum+a[i]);
				i=j;
				j=i+1;
			}
			else if(sum+a[i]>sum+a[j])
			{
				pa.push_back(a[i]);
				a[j]=sum+a[j];
				i=j;
				j=i+1;
			}
		}
	}
	sum=0;
	for(int i=0;i<pa.size();i++)
	{
		sum+=pa[i]*pa[i];
	}
	cout<<sum;
	return 0;
}
