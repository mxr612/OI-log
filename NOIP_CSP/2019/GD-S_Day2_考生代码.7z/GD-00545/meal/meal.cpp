#include <iostream>
#include <stdio.h>
using namespace std;
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int a[n][m];
	int mor[m];
	bool hor[n];
	for(int i=0;i<n;i++)
	{
		hor[i]=false;
		for(int j=0;j<m;j++)
		{
			cin>>a[i][j];
			mor[j]=0;
		}
	}
	int sum=0;
	int I=2,J=I;
	while(I<=n)
	{
		int i,j;
		while(J>0)
		{
			i=0;j=0;
			while(i<n)
			{
				if(hor[i]==false)
				{
					if(mor[j]+1<I/2&&a[i][j]!=0)
					{
						hor[i]=true;
						mor[j]++;
						i++;
						j=0;
						J--;
						if(J==0)
						{
							hor[i]=false;
							mor[j]--;
							J++;
							j++;
							sum++;
						}
					}
					else
					{
						if(j==m)
						{
							i++;
							j=0;
						}
						else
						{
							j++;
						}
					}
				}
				else
				{
					i++;
				}
			}
			J--;
		}
		I++;
	}
	cout<<sum;
	return 0;
}
