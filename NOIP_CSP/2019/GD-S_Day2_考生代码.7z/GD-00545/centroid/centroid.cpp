#include <iostream>
#include <stdio.h>
using namespace std;
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T;
	cin>>T;
	while(T)
	{
		int n;
		cin>>n;
		int uv[2][n-1];
		for(int i=0;i<n-1;i++)
		{
			cin>>uv[0][i]>>uv[1][i];
		}
		for(int i=0;i<n-1;i++)
		{
			for(int j=i;j<n-1;j++)
			{
				if(uv[0][i]==uv[0][j])
				{
					if(uv[1][i]>uv[1][j])
					{
						swap(uv[1][i],uv[1][j]);
					}
				}
				else if(uv[0][i]>uv[0][j])
				{
					swap(uv[0][i],uv[0][j]);
					swap(uv[1][i],uv[1][j]);
				}
			}
		}
		int i=0,j=1;
		int tuv[n];
		for(int i=0;i<n;i++)
		{
			tuv[i]=0;
		}
		while(i<n-1&&j<n)
		{
			if(uv[0][i]==j)
			{
				tuv[j]++;
			}
			else if(uv[0][i]<j)
			{
				i++;
			}
			else
			{
				j=uv[0][i];
			}
		}
		int sum=0;
		for(i=0;i<n-1;i++)
		{
			tuv[uv[0][i]]-=1;
			if(tuv[uv[0][i]]<=0)
			{
				sum+=uv[0][i];
			}
			else
			{
				int max=0;
				for(j=i+1;j<n-1;j++)
				{
					if(uv[0][j]==uv[0][i])
					{
						if(max<tuv[uv[0][j]])
						{
							max=tuv[uv[0][j]];
						}
					}
				}
				sum=sum+uv[0][j]+uv[1][j];
			}
			if(tuv[uv[1][i]]<=0)
			{
				sum+=uv[0][i];
			}
			else
			{
				int max=0;
				for(j=i+1;j<n-1;j++)
				{
					if(uv[0][j]==uv[0][i])
					{
						if(max<tuv[uv[0][j]])
						{
							max=tuv[uv[0][j]];
						}
					}
				}
				sum=sum+uv[0][j]+uv[1][j];
			}
		}
		cout<<sum<<endl;
		T--;
	}
	return 0;
}
