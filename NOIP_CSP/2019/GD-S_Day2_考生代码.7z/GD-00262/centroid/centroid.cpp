#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#define MAXN 300010
#define LL long long
using namespace std;
struct node
{
	int x,y,next;
}a[MAXN*2];int len,last[MAXN];
void ins(int x,int y)
{
	
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T;scanf("%d",&T);
	while(T--)
	{
		int n;scanf("%d",&n);
		len=-1;memset(last,0,sizeof(last));
		for(int i=1;i<=n;i++)
		{
			int x,y;//scanf("%d%d",&x,&y);
			ins(x,y);ins(y,x);
		}
		LL ans=0;
		for(int i=1;i<n;i++)
		{
			int x=1,y=i;
			if(y%2==1)ans+=y/2+1;
			else ans+=y+1;
			x=i+1;y=n;
			x-=i;y-=i;
			if(y%2==1)ans+=y/2+1+i;
			else ans+=y+1+i*2;
		}
		printf("%llu\n",ans);
	}
	return 0;
}
