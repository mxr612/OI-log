#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#define MAXN 40000010
#define uLL unsigned long long
using namespace std;
int n,tp;
struct node
{
	uLL val;
	int l,r;
	node()
	{
		val=0;l=0;r=0;
	}
}a[MAXN];
bool isset(int x)
{
	return x>=1&&x<=n;
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&tp);
	a[0].r=1;a[n+1].l=n;
	for(int i=1;i<=n;i++)
	{
		scanf("%llu",&a[i].val);
		a[i].l=i-1;a[i].r=i+1;
	}
	for(int i=1;i<=n;i=a[i].r)
	{
		while( isset(a[i].r) && ! (a[i].val<=a[a[i].r].val) )
		{
			int r=a[i].r;
			//���ұ�����ϲ� 
			if( !isset(a[r].r) || a[i].val+a[r].val<=a[a[r].r].val)
			{
				a[i].val+=a[r].val;
				a[i].r=a[r].r;
				a[a[r].r].l=i;
			}
			else
			{
				int rr=a[r].r;
				a[rr].val+=a[r].val;
				a[i].r=rr;a[rr].l=i;
			}
		}
	}
	uLL ans=0;
	for(int i=a[0].r;i<=n;i=a[i].r)
		ans+=a[i].val*a[i].val;
	printf("%llu\n",ans);
	return 0;
}
