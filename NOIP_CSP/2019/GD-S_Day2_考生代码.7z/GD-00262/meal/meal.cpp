#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<cmath>
#include<algorithm>
#define LL long long
#define MAXN 110
#define MAXM 2010
#define MOD 998244353
using namespace std;
bool v[MAXN][MAXM];
int n,m,a[MAXN][MAXM];
int ned=0;
LL mul,ans;
bool way[MAXN];
int food[MAXM];

bool check(int x)
{
	for(int i=1;i<=m;i++)
		if(food[i]>x/2)return false;
	return true;
}

void dg(int now,int bi,int bj)
{
	
	if(now>=3&&check(now-1))ans=(ans+mul)%MOD;
	if(now==n+1)return ;
	
	for(int i=bi;i<=n;i++)
		for(int j=(i==bi?bj:1);j<=m;j++)
			if(v[i][j]&&way[i])
			{
				
				v[i][j]=false;
				way[i]=false;
				food[j]++;
				int origin=mul;
				mul=mul*a[i][j]%MOD;
				
				dg(now+1,i,j+1);
				
				v[i][j]=true;
				way[i]=true;
				food[j]--;
				mul=origin;
				
			}
			
	return ;
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	
	memset(v,false,sizeof(v));
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
			if(a[i][j])v[i][j]=true;
		}
		
	mul=1;ans=0;	
	memset(way,true,sizeof(way));
	memset(food,0,sizeof(food));
	dg(1,1,1);
	
	printf("%lld\n",ans);
	
	return 0;
}
