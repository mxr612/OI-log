#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#include<ctime>
#include<iostream>
using namespace std;
const long N=300000;
struct edge
{
	long x,y;
};
long t,n,tot,ans; bool flag[N]; edge e[N],first[N],next[N];
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%ld",&t);
	srand(time(NULL));
	for (long i=0;i<t;i++)
	{
		cout<<rand()<<endl;
	}
	return 0;
}
