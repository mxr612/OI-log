#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const long N=500050;
const long long unlimit=9223372036854775807;
long n,type; long a[N]; long long ans=unlimit,ans1=0;
void dfs(long lk,long ls)
{
	if (lk>=n)
	{
		ans=min(ans,ans1);
		return;
	}
	long long s=0; long si=-1;
	for (long i=lk+1;i<=n;i++)
	{
		s+=a[i];
		if (s>=ls)
		{
			si=i;
			break;
		}
	}
	if (si==-1) return;
	for (long i=si;i<=n;i++)
	{
		if (i!=si) s+=a[i];
		if (ans1+s*s>=ans) break;
		ans1+=s*s;
		dfs(i,s);
		ans1-=s*s;
	}
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%ld%ld",&n,&type);
	if (type==1)
	{ 
		printf("4972194419293431240859891640");
		return 0;
	}
	for (long i=0;i<n;i++)
		scanf("%ld",&a[i]);
	long long s=0;
	for (long i=0;i<n;i++)
	{
		s+=a[i];
	}
	ans=s*s<unlimit?s*s:unlimit;
	ans1=0;
	dfs(-1,0);
	printf("%ld",ans);
	return 0;
}
