#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const long N=150,M=2050;
long n,m,a[N][M],use[M]; long long ans=0,ans1=1;
void dfs(long h,long k)
{
	if (h>n)
	{
		if (k==0) return;
		bool flag=true;
		for (long i=1;i<=m;i++)
		{
			if (use[i]>k/2)
			{
				flag=false;
				break;
			}
		}
		if (!flag) return;
		ans+=ans1;
		return;
	}
	dfs(h+1,k);
	for (long i=1;i<=m;i++)
	{
		if (a[h][i]==0) continue;
		ans1*=a[h][i];
		use[i]++;
		dfs(h+1,k+1);
		use[i]--;
		ans1/=a[h][i];
	}
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%ld%ld",&n,&m);
	for (long i=1;i<=n;i++)
		for (long j=1;j<=m;j++)
		{
			scanf("%ld",&a[i][j]);
			a[i][j]%=998244353;
		}
	memset(use,0,sizeof(use));
	dfs(1,0);
	printf("%ld",ans);
	return 0;
}
