
#include <iostream>
#include <cstdio>

using namespace std;

typedef int ULL;

const int max_n = 100 + 10,max_m = 2000 + 10,mod = 998244353;
ULL G[max_n][max_m],used[max_m],ans = 0,n,m;

int dfs(ULL cur,ULL c,const ULL k) {
	//cout << "run for " << " cur " << cur << " c " << c << " k " << k << endl;
	int res = 0;
	if (cur > n || c >= k)
		return 1;
	for (int i = 1;i <= m;i++)
		if (G[cur][i] && used[i] + 1 <= k / 2) {
			used[i]++;
			res = (res + (G[cur][i] * dfs(cur + 1,c + 1,k)) % mod) % mod;
			used[i]--;
		}
	if (n - cur >= k - c)
		res = (res + dfs(cur + 1,c,k)) % mod;
	return res % mod;
}

int main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	
	cin >> n >> m;
	for (int i = 1;i <= n;i++)
		for (int j = 1;j <= m;j++)
			cin >> G[i][j];
	for (int k = 2;k <= n;k++)
		ans = (ans + dfs(1,0,k)) % mod;
	cout << ans % mod;
	return 0;
}
