
#include <iostream>
#include <cstdio>

using namespace std;

const int maxn = 4e7 + 10;
int d[maxn],s[maxn],n,type;
unsigned long long ans = 0;

int find(int c) {
	if (s[c] == c)
		return c;
	return s[c] = find(s[c]);
}

void add_to_set(int src,int val,int obj) {
	int src_root = find(src);
	int obj_root = find(obj);
	d[obj_root] += val;
	s[src_root] = obj_root;
}

int main() {
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	
	cin >> n >> type;
	for (int i = 1; i <= n; i++) {
		cin >> d[i];
		s[i] = i;
	}
	for (int i = 2; i <= n - 1; i++) {
		if (s[i] != i)
			continue;
		int pre_root = find(i - 1);
		int next_root = find(i + 1);
		if (d[pre_root] <= d[i])
			continue ;
		if (d[pre_root] + d[i] <= d[i] + d[next_root])
			add_to_set(i,d[i],pre_root);
		else
			add_to_set(i,d[i],next_root);
	}
	if (d[n] < d[n - 1])
		add_to_set(n,d[n],n - 1);
	//cout << "###" << endl;
	for (int i = 1; i <= n; i++) {
		if (s[i] != i)
			continue ;
		ans += d[i] * d[i];
		//cout << d[i] << " ";
	}
	cout << ans;
	return 0;
}
