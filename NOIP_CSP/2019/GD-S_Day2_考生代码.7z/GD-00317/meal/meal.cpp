#include <bits/stdc++.h>
#define fo(i,a,b) for(int i=a;i<=b;++i)
#define fod(i,a,b) for(int i=a;i>=b;--i)
#define efo(i,q) for(int i=A[q];i;i=B[i][0])

using namespace std;
typedef long long LL;
const int N=2050,mo=998244353;
int read(int &n)
{
	int q=1;n=0;
	char ch=' ';
	for(;ch!='-'&&(ch<'0'||ch>'9');ch=getchar());
	if(ch=='-')ch=getchar(),q=-1;
	for(;ch<='9'&&ch>='0';ch=getchar())n=(n<<3)+(n<<1)+ch-48;
	return n=n*q;
}
int n,m;
int a[N][N];
LL f[N][N*2];
LL ans;
LL MO(LL &q,int w){return (q+=w)>=mo?q-=mo:0;}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	int q,w;
	read(n),read(m);
	fo(i,1,n)fo(j,1,m)a[i][0]+=read(a[i][j]);
	ans=1;
	fo(i,1,n)ans=ans*(a[i][0]+1LL)%mo;
	ans-=1;
	fo(I,1,m)
	{
		f[0][n]=1;
		fo(i,1,n)
		{
			fo(j,n-i,n+i)
			{
				f[i][j]=(f[i-1][j-1]*a[i][I]+f[i-1][j+1]*(a[i][0]-a[i][I])+f[i-1][j])%mo;
			}
			fo(j,n-i,n+i)f[i-1][j]=0;
		}
		fo(i,1,n)ans=(ans-f[n][n+i])%mo;
		// printf("%d %lld\n",I,ans);
	}
	printf("%lld\n",(ans+mo)%mo);
	return 0;
}