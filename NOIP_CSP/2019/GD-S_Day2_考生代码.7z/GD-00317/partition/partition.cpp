#include <bits/stdc++.h>
#define fo(i,a,b) for(int i=a;i<=b;++i)
#define fod(i,a,b) for(int i=a;i>=b;--i)
#define efo(i,q) for(int i=A[q];i;i=B[i][0])
#define sqr(q) ((LL)(q)*(q))
#define min(q,w) ((q)>(w)?(w):(q))
using namespace std;
typedef long long LL;
const int N=51,M=50001,INF=1e9;
int read(int &n)
{
	int q=1;n=0;
	char ch=' ';
	for(;ch!='-'&&(ch<'0'||ch>'9');ch=getchar());
	if(ch=='-')ch=getchar(),q=-1;
	for(;ch<='9'&&ch>='0';ch=getchar())n=(n<<3)+(n<<1)+ch-48;
	return n=n*q;
}
int n,m;
int a[N];
LL ans;
int f[N][M],g[N][M];
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int q,w,_;
	read(n),read(_);
	if(!_)
	{
		fo(i,1,n)a[i]=read(q)+a[i-1];
	}else
	{

	}
	
	fo(i,0,n)fo(j,0,a[n])f[i][j]=g[i][j]=INF;
	f[0][0]=0;
	fo(i,0,a[n])g[0][i]=0;
	fo(i,1,n)
	{
		f[i][a[i]]=min(f[i][a[i]],g[i-1][a[i]]+sqr(a[i]));
		fod(j,i-1,0)
		{
			q=a[i]-a[j];
			f[i][q]=min(f[i][q],g[j][q]+sqr(q));
		}
		fo(j,1,a[n])g[i][j]=min(g[i][j-1],f[i][j]);
	}
	ans=INF;
	fo(i,1,a[n])ans=min(ans,f[n][i]);
	printf("%lld\n",ans);
	return 0;
}