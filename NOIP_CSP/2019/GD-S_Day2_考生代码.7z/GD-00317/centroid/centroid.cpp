#include <bits/stdc++.h>
#define fo(i,a,b) for(int i=a;i<=b;++i)
#define fod(i,a,b) for(int i=a;i>=b;--i)
#define efo(i,q) for(int i=A[q];i;i=B[i][0])
#define NX(q) ((q)&(-(q)))
using namespace std;
typedef long long LL;
const int N=300500;
int read(int &n)
{
	int q=1;n=0;
	char ch=' ';
	for(;ch!='-'&&(ch<'0'||ch>'9');ch=getchar());
	if(ch=='-')ch=getchar(),q=-1;
	for(;ch<='9'&&ch>='0';ch=getchar())n=(n<<3)+(n<<1)+ch-48;
	return n=n*q;
}
int n,m;
LL ans;
int Si[N],dfn0,dfn[N];
struct TR
{
	int root,dfn,si;
}a[N];
struct SGT
{
	int l,r,v;
}tr[N*20];
int tr0;

int b[N*4],b1[N*4];

int B[N*2][2],A[N],B0;
void link(int q,int w)
{
	B[++B0][0]=A[q],A[q]=B0,B[B0][1]=w;
	B[++B0][0]=A[w],A[w]=B0,B[B0][1]=q;
}
int dfsf(int q,int fa)
{
	Si[q]=1;
	a[q].dfn=++dfn0;
	dfn[dfn0]=q;
	efo(i,q)if(B[i][1]!=fa)Si[q]+=dfsf(B[i][1],q);
	a[q].si=Si[q];
	return Si[q];
}
void ADD(int l1,int l2,int l=1,int r=n,int e=1)
{
	if(l==r)
	{
		b[e]+=l2;
		return;
	}
	int mid=(l+r)>>1;
	if(l1<=mid)ADD(l1,l2,l,mid,e<<1);
	else ADD(l1,l2,mid+1,r,(e<<1)+1);
	b[e]+=l2;
}
int Gsum(int l1,int r1,int l=1,int r=n,int e=1)
{
	if(l1<=l&&r<=r1)return b[e];
	int mid=(l+r)>>1,ans=0;
	if(l1<=mid)ans+=Gsum(l1,r1,l,mid,e<<1);
	if(mid<r1)ans+=Gsum(l1,r1,mid+1,r,(e<<1)+1);
	return ans;
}
void ADD1(int l1,int l2,int l=1,int r=n,int e=1)
{
	if(l==r)
	{
		b1[e]+=l2;
		return;
	}
	int mid=(l+r)>>1;
	if(l1<=mid)ADD1(l1,l2,l,mid,e<<1);
	else ADD1(l1,l2,mid+1,r,(e<<1)+1);
	b1[e]+=l2;
}
int Gsum1(int l1,int r1,int l=1,int r=n,int e=1)
{
	if(l1<=l&&r<=r1)return b1[e];
	int mid=(l+r)>>1,ans=0;
	if(l1<=mid)ans+=Gsum1(l1,r1,l,mid,e<<1);
	if(mid<r1)ans+=Gsum1(l1,r1,mid+1,r,(e<<1)+1);
	return ans;
}
void build(int l,int r,int &e,int l1)
{
	tr[++tr0]=tr[e];
	++tr[e=tr0].v;
	if(l==r)return;
	int mid=(l+r)>>1;
	if(l1<=mid)build(l,mid,tr[e].l,l1);
	else build(mid+1,r,tr[e].r,l1);
}
int find(int l,int r,int &e,int l1,int r1)
{
	if(!e)return 0;
	if(l1<=l&&r<=r1)return tr[e].v;
	int mid=(l+r)>>1,ans=0;
	if(l1<=mid)ans+=find(l,mid,tr[e].l,l1,r1);
	if(mid<r1)ans+=find(mid+1,r,tr[e].r,l1,r1);
	return ans;
}
int Gfd(int q,int l1,int r1)
{
	return find(1,n,a[dfn[a[q].dfn+a[q].si-1]].root,l1,r1)-find(1,n,a[dfn[a[q].dfn-1]].root,l1,r1);
}
void dfs(int q,int fa)
{

	LL cnt=0;
	int mx=0,mx1=0,mxx;
	efo(i,q)
	{
		int t=Si[B[i][1]];
		if(t>=mx)mx1=mx,mx=t,mxx=B[i][1];
		else if(t>mx1)mx1=t;
	}
	if(mx==mx1)
	{
		cnt+=find(1,n,a[dfn[n]].root,1,n-2*mx)-Gsum1(1,n-2*mx)+Gsum(1,n-2*mx);
	}else
	{
		if(n-2*mx>=0)
		{
			if(mxx==fa)
			{
				cnt+=Gfd(q,1,n-2*mx);
			}else
			{
				cnt+=find(1,n,a[dfn[n]].root,1,n-2*mx)-Gsum1(1,n-2*mx)+Gsum(1,n-2*mx);
				// if(q==2)printf("         %d\n",Gsum1(1,n-2*mx));
				cnt-=Gfd(mxx,1,n-2*mx);
			}
		}
		int t=max(1,2*mx-n),t1=min(n-2*mx1,n-1);
		if(t<=t1)
		{
			if(mxx==fa)
			{
				cnt+=find(1,n,a[dfn[n]].root,t,t1)-Gfd(q,t,t1)-Gsum1(t,t1)+Gsum(t,t1);
				// if(q==3)printf("   %d\n",Gsum1(t,t1));
			}else
			{
				cnt+=Gfd(mxx,t,t1);
			}
		}
	}

	// printf("%d %lld\n",q,cnt);
	ans+=cnt*q;

	ADD1(a[q].si,1);
	efo(i,q)if(B[i][1]!=fa)
	{
		int t=Si[B[i][1]];
		ADD(Si[q]=n-t,1);
		Si[B[i][1]]=n;
		dfs(B[i][1],q);
		Si[B[i][1]]=t;
		ADD(Si[q],-1);
	}
	Si[q]=n;
	ADD1(a[q].si,-1);
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int q,w,_;
	read(_);
	while(_--)
	{
		read(n);
		fo(i,1,n-1)read(q),read(w),link(q,w);
		dfsf(1,0);
		fo(i,1,n)
		{
			a[dfn[i]].root=a[dfn[i-1]].root;
			build(1,n,a[dfn[i]].root,a[dfn[i]].si);
		}
		dfs(1,0);

		printf("%lld\n",ans);

		fo(i,0,n)Si[i]=A[i]=dfn[i]=0;
		fo(i,1,n)a[i].root=a[i].dfn=a[i].si=0;
		fo(i,1,3*n)b[i]=b1[i]=0;
		B0=0;ans=0;dfn0=0;
		tr0=0;
	}
	
	// printf("dede\n");
	return 0;
}