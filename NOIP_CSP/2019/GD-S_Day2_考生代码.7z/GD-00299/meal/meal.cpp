#include<iostream>
#include<fstream>
using namespace std;

#define N 100
#define M 2000
#define NUMBER 998244353

void findRubs(long numbers[N][M], int * columns, 
	const int maxTimes, const int times, long total, 
	long & getNum, const int same, int * rubs, 
	const int m)
{
	if (times > maxTimes)
	{
		getNum += total;
		getNum %= NUMBER;
	//	cout << "  find one, getNumber: " << total 
			//<< endl;
		return;
	}
	
	for (int i = 0; i < m; ++i)
	{
		if (rubs[i] >= same)
			continue;
		
	//	cout << "    get cl: " << columns[times - 1] 
		//	<< " rb: " << i 
		//	<< " number: " << numbers[columns[times - 1]][i] 
		//	<< endl;
		long nextTotal = total * 
			numbers[columns[times - 1]][i];
		nextTotal %= NUMBER;
	//	cout << "    total: " << total << endl;
		++rubs[i];
		findRubs(numbers, columns, maxTimes, 
			times + 1, nextTotal, getNum, same, rubs, m);
		--rubs[i];
	}
}

long caculate(long numbers[N][M], 
	int * columns, int * rubs,
	int maxTimes, const int m)
{
	int same = maxTimes / 2;
	for (int i = 0; i < M; ++i)
		rubs[i] = 0;
	
	long getNum = 0;
	findRubs(numbers, columns, maxTimes, 1, 
		1, getNum, same, rubs, m);
	return getNum;
}

void findColumns(long numbers[N][M], 
	int * columns, int * rubs,
	int maxTimes, int times, long & getNum, 
	const int n, const int m)
{
	if (times > maxTimes)
		return;
		
	int max = n - times + 1;
	for (int i = columns[times - 2] + 1; i <= max; ++i)
	{
		//cout << "  find cl: " << i << endl;
		columns[times - 1] = i;
		findColumns(numbers, columns, rubs, 
			maxTimes, times + 1, getNum, n, m);
	}
	
	if (times == maxTimes)
	{
		getNum += caculate(numbers, columns, rubs, 
			maxTimes, m);
		//cout << "find columns in " << maxTimes << 
			//" now number: " << getNum << endl;
		getNum %= NUMBER;
	}
}


int main()
{
	ifstream fin;
	ofstream fout;
	
	fin.open("meal.in");
	fout.open("meal.out");
	
	int m, n;
	fin >> n >> m;
	long numbers[N][M];
	
	for (int i = 0; i < n; ++i)
	{
		for (int j = 0; j < m; ++j)
		{
			long input;
			fin >> input;
			numbers[i][j] = input;
		}
	}
	
	long answer = 0;
	int columns[N];
	int rubs[M];
	//p is how many meals
	for (int p = 2; p <= n; ++p)
	{
		int max = n - p + 1;
		for (int i = 0; i < max; ++i)
		{
			columns[0] = i;
			findColumns(numbers, columns, rubs, 
				p, 2, answer, n, m);
			answer %= NUMBER;
		}
	}
	
	fout << answer;
	fin.close();
	fout.close();
	return 0;
}

