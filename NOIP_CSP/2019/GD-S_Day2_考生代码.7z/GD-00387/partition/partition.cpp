#include<bits/stdc++.h>
#define res register int
using namespace std;
typedef long long ll;
inline int rd(){
	char ch;int f=0,w=1;
	ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){f=f*10+ch-'0';ch=getchar();}
	return f*w;
}
const int N=5e5+7;
int n,ty,a[N],minn=1e9+7;
ll tot=0,ans,pre[N];
ll dp[N],big[N];
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=rd();ty=rd();
	memset(pre,0,sizeof(pre));
	if(ty==0){
		for(res i=1;i<=n;i++){
			a[i]=rd();pre[i]=pre[i-1]+a[i];
			if(minn>a[i])minn=a[i];
		}
		for(res i=1;i<=n;i++)dp[i]=pre[i]*pre[i],big[i]=pre[i];
		for(res i=2;i<=n;i++){
			for(res j=i-1;j>=1;j--){
				if(pre[i]-pre[j]>=big[j]&&dp[i]>dp[j]+(pre[i]-pre[j])*(pre[i]-pre[j]))dp[i]=dp[j]+(pre[i]-pre[j])*(pre[i]-pre[j]),big[i]=pre[i]-pre[j];
		    }
		}
		printf("%lld",dp[n]);
    }
    
}
