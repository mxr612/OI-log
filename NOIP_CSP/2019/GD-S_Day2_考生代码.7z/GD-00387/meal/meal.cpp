#include<bits/stdc++.h>
#define res register int
using namespace std;
typedef long long ll;
inline int rd(){
	char ch;int f=0,w=1;
	ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){f=f*10+ch-'0';ch=getchar();}
	return f*w;
}
int n,m,a[102][2002],preh[102],prez[2002],lim,limm;
int ons[102],st=0;
const int mo=998244353;
ll ans=0,tot;
int z[2002];
inline void dfs(int x,int lim1,int lim2){
	if(lim2==limm){
		tot=ons[lim2];
		for(res i=1;i<lim2;i++)tot=tot*ons[i]%mo;
		ans=ans+tot;if(ans>mo)ans-=mo;
		return;
	}
	if(x==n&&lim2+1!=limm){
		st=0;return;
	}
	for(res j=1;j<=m;j++){
		if(z[j]<lim1&&a[x][j]){
			z[j]++;ons[lim2+1]=a[x][j];
			if(lim2+1!=limm)for(res i=x+1;i<=x+n-(limm-lim2-1);i++){
				dfs(i,lim1,lim2+1);
			}
			else dfs(x+1,lim1,lim2+1);
			z[j]--;
		}
	}
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=rd();m=rd();
	memset(preh,0,sizeof(preh));
	memset(prez,0,sizeof(prez));
	for(res i=1;i<=n;i++)
	for(res j=1;j<=m;j++){
		a[i][j]=rd();preh[i]+=a[i][j];
		if(preh[i]>mo)preh[i]-=mo;
		prez[j]+=a[i][j];if(prez[j]>mo)prez[j]-=mo;
	}
	for(res i=2;i<=n;i++){
		lim=i/2;limm=i;
		for(res k=1;k<=n-i+1;k++){
			memset(z,0,sizeof(z));
			dfs(k,lim,0);
		}
	}
	printf("%lld",ans);
}
