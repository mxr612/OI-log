#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
#define LL long long
const LL mod = 998244353;
LL len, n, m, a[110][2010], ans, b[2010], s[110], c;
void dfs(LL x, LL k){
	if(n - x + 1 < k) return;
	if(k == 0 && x <= n + 1){
		LL cnt = 1;
		for(LL i = 1; i <= len; ++i){
			cnt *= s[i];
			cnt %= mod;
		}
		ans += cnt;
		ans %= mod;
		return;
	}
	if(x == n + 1) return;
	for(LL i = 1; i <= m; ++i){
		if(b[i] + 1 > c) continue;
		b[i]++;
		s[++len] = a[x][i];
		dfs(x + 1, k - 1);
		s[len] = 0;
		len--;
		b[i]--;
	}
	dfs(x + 1, k);
	return;
}
int main(){
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	scanf("%lld%lld", &n, &m);
	for(LL i = 1; i <= n; ++i){
		for(LL j = 1; j <= m; ++j){
			scanf("%lld", &a[i][j]);
		}
	}
	for(LL k = 2; k <= n; ++k){
		c = (k >> 1);
		dfs(1, k);
	}
	printf("%lld", ans);
	return 0;
}
