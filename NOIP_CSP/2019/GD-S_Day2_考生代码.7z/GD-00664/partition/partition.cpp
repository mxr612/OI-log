#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
#define LL long long
LL n, typ, a[500010], s[500010], f[500010];
void dfs(LL k, LL l, LL cnt){
	if(cnt > f[k]) return;
	f[k] = cnt;
	if(k == n) return;
	for(LL i = k + 1; i <= n; ++i){
		if(s[i] - s[k] >= l){
			dfs(i, s[i] - s[k], cnt + (s[i] - s[k]) * (s[i] - s[k]));
		}
	}
	return;
}
int main(){
	freopen("partition.in", "r", stdin);
	freopen("partition.out", "w", stdout);
	scanf("%lld%lld", &n, &typ);
	for(LL i = 1; i <= n; ++i){
		scanf("%lld", &a[i]);
		s[i] = s[i - 1] + a[i];
	}
	memset(f, 126, sizeof(f));
	dfs(0, 0, 0);
	printf("%lld", f[n]);
	return 0;
}
