#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
struct edg{
	int v, nxt;
}e[600010];
int hed[600010], cnt, T, n, x[300010], y[300010], vis[300010], ez[300010], du[300010];
int a, b, c, d, ans, ez2[300010], vis2[300010], zx, zy, gx, gy;
bool f[300010];
void addadd(int u, int v){
	e[++cnt].v = v;
	e[cnt].nxt = hed[u];
	hed[u] = cnt;
}
void dfs(int u){
	for(int i = hed[u]; i; i = e[i].nxt){
		int v = e[i].v;
		if(vis[v]) continue;
		vis[v] = vis[u] + 1;
		dfs(v);
		ez[u] += ez[v];
	}
	return;
}
void dfs2(int u){
	for(int i = hed[u]; i; i = e[i].nxt){
		int v = e[i].v;
		if(vis2[v]) continue;
		vis2[v] = vis2[u] + 1;
		dfs2(v);
		ez2[u] += ez2[v];
	}
	return;
}
bool is_G(int u, int g){
	int h;
	if(g == gx) h = zx;
	else h = zy;
	for(int i = hed[u]; i; i = e[i].nxt){
		int v = e[i].v;
		if(u == gx && v == gy) continue;
		if(u == gy && v == gx) continue;
		if(vis2[v] < vis2[u]){
			if(ez2[g] - ez2[u] > h / 2) return 0;
		}
		else if(ez2[v] > h / 2) return 0;
	}
	return 1;
}
void find_G(int u, int g){
	f[u] = 1;
	bool flag = is_G(u, g);
	if(flag){
		if(!a) a = u;
		else if(!b) b = u;
		else if(!c) c = u;
		else if(!d) d = u;
	}
	for(int i = hed[u]; i; i = e[i].nxt){
		int v = e[i].v;
		if(v == gx || v == gy) continue;
		if(f[v]) continue;
		find_G(v, g);
	}
	return;
}
void wok(){
	memset(hed, 0, sizeof(hed));
	memset(vis, 0, sizeof(vis));
	cnt = 0;
	ans = 0;
	scanf("%d", &n);
	for(int i = 1; i < n; ++i){
		scanf("%d%d", &x[i], &y[i]);
		addadd(x[i], y[i]);
		addadd(y[i], x[i]);
		ez[i] = 1;
	}
	ez[n] = 1;
	dfs(vis[1] = 1);
	for(int i = 1; i < n; ++i){
		a = b = c = d = 0;
		memset(f, 0, sizeof(f));
		memset(vis2, 0, sizeof(vis2));
		for(int j = 1; j <= n; ++j) ez2[j] = 1;
		if(vis[x[i]] < vis[y[i]]){
			zx = ez[1] - ez[y[i]];
			zy = ez[y[i]];
			gx = x[i];
			gy = y[i];
			vis2[gx] = vis2[gy] = 1;
			dfs2(gx);
			dfs2(gy);
			find_G(gx, gx);
			find_G(gy, gy);
			ans += a + b + c + d;
		}
		else{
			zx = ez[x[i]];
			zy = ez[1] - ez[x[i]];
			gx = x[i];
			gy = y[i];
			vis2[gx] = vis2[gy] = 1;
			dfs2(gx);
			dfs2(gy);
			find_G(gx, gx);
			find_G(gy, gy);
			ans += a + b + c + d;
		}
	}
	printf("%d\n", ans);
	return;
}
int main(){
	freopen("centroid.in", "r", stdin);
	freopen("centroid.out", "w", stdout);
	scanf("%d", &T);
	while(T--) wok();
	return 0;
}
