#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>

using namespace std;

const int N = 1e6;
const long long oo = 4e18;

struct P { int p, l, r; } tmp[N];
pair <long long, long long> f[N];
long long a[N], b[N], sum[N];

int q[N];

int main() {
	
	freopen("partition.in", "r", stdin);
	freopen("partition.out", "w", stdout);
	
	int n, opt;
	
	scanf("%d%d", &n, &opt);
	
	if(opt) {
		
		int x, y, z, m;
		int o = 1 << 30;
		
		scanf("%d%d%d%d%d%d", &x, &y, &z, &b[1], &b[2], &m);
		for (int i = 3; i <= n; i ++) {
			b[i] = (1LL * b[i - 1] * x % o + 1LL * b[i - 2] * y % o + z) % o;
		}
		tmp[0].p = 0;
		for (int i = 1; i <= m; i ++) {
			scanf("%d%d%d", &tmp[i].p, &tmp[i].l, &tmp[i].r);
		}
		for (int i = 1, j = 1; i <= m; i ++) {
			while(tmp[i - 1].p < b[j] && b[j] <= tmp[i].p) a[j] = (b[j] % (tmp[i].r - tmp[i].l + 1)) + tmp[i].l, j ++;
		}
	}
	else {
		
		for (int i = 1; i <= n; i ++)
			scanf("%lld", &a[i]);
	}
	
	for (int i = 1; i <= n; i ++) {
		sum[i] = sum[i - 1] + a[i];
	}
	
//	int he, ta;
//	q[he = ta = 1] = 0;
	
	for (int i = 1, j = 0; i <= n; i ++) {
		
		int tmp = j;
		for (j = i - 1; j >= tmp; j --) {
			if(sum[i] - sum[j] >= f[j].first) break;
		}
		f[i].first = sum[i] - sum[j];
		f[i].second = f[j].second + (sum[i] - sum[j]) * (sum[i] - sum[j]);

//		while(he + 1 <= ta && sum[i] - sum[q[he + 1]] >= f[q[he + 1]].first) he ++;
//		j = q[he];
//		
//		f[i].first = sum[i] - sum[j];
//		f[i].second = f[j].second + (sum[i] - sum[j]) * (sum[i] - sum[j]);
//		
//		while(he + 1 <= ta && f[q[ta]].first >= f[i].first) ta --;
//		q[++ ta] = i;
	}
	
	printf("%lld", f[n].second);
	
	return 0;
}
