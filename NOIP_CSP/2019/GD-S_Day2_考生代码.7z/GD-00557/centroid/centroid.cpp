#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>
#include <vector>

using namespace std;

const int N = 3e5 + 100;

vector <int> a[N];

int sumx, sumy;
int siz[N], masiz[N];

void calc(int u, int p) {
	
	sumx ++;
	sumy --;
	
	for (int i = 0; i < a[u].size(); i ++)
		if(a[u][i] != p) calc(a[u][i], u);
}

long long ans;

void dfs(int u, int p, int s) {
	
	siz[u] = 1;
	masiz[u] = 0;
	
	for (int i = 0; i < a[u].size(); i ++) {
		int v = a[u][i];
		if(v != p) {
			dfs(v, u, s);
			siz[u] += siz[v];
			masiz[u] = max(masiz[u], siz[v]);
		}	
	}
	masiz[u] = max(masiz[u], s - siz[u]);
	if(masiz[u] <= s / 2) ans += u;
}

int x[N], y[N];

int main() {

	freopen("centroid.in", "r", stdin);
	freopen("centroid.out", "w", stdout);

	int T;
	int n;
	
	scanf("%d", &T);
	
	while(T --) {
		
		scanf("%d", &n);
		for (int i = 1; i < n; i ++) {
			scanf("%d%d", &x[i], &y[i]);
			a[x[i]].push_back(y[i]);
			a[y[i]].push_back(x[i]);
		}
		
		ans = 0;
		
		for (int i = 1; i < n; i ++) {
			sumx = 0;
			sumy = n;
			calc(x[i], y[i]);
			dfs(x[i], y[i], sumx);
			dfs(y[i], x[i], sumy);
		}
	
		printf("%lld\n", ans);	
		
		for (int i = 1; i <= n; i ++)
			a[i].clear();
	}

	return 0;
}
