#include <algorithm>
#include <iostream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <cstdio>

using namespace std;

const int N = 110;
const int M = 2010;
const int mod = 998244353;

long long t[N][N];
long long f[N][N][N];
long long sum[N][M];
long long p[N][M];
long long tot, o;

int main() {
	
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	
	int n, m;
	
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i ++) {
		for (int j = 1; j <= m; j ++) {
			scanf("%lld", &p[i][j]);
			sum[i][j] = (sum[i][j - 1] + p[i][j]) % mod;	
		}
	}
	
	t[0][0] = 1;
	for (int i = 1; i <= n; i ++) {
		for (int j = 0; j <= i; j ++) {
			if(sum[i][m] != 0 && j) t[i][j] = t[i - 1][j - 1] * sum[i][m] % mod;
			(t[i][j] += t[i - 1][j]) %= mod;
		}
	}
	for (int j = 1; j <= n; j ++)
		(tot += t[n][j]) %= mod;
	
	memset(f, 0, sizeof(f));
	
	for (int cnt = 1; cnt <= m; cnt ++) {
		for (int i = 1; i <= n; i ++) 
		for (int j = 0; j <= i; j ++)
		for (int k = 0; k <= j; k ++)
			f[i][j][k] = 0;
		f[0][0][0] = 1;
		for (int i = 1; i <= n; i ++) 
		for (int j = 0; j <= i; j ++)
		for (int k = 0; k <= j; k ++) {
			(f[i][j][k] += f[i - 1][j][k]) %= mod;
			if(sum[i][m] - p[i][cnt] && j)
				(f[i][j][k] += f[i - 1][j - 1][k] * (sum[i][m] - p[i][cnt] + mod) % mod) %= mod;
			if(p[i][cnt] && j && k)
				(f[i][j][k] += f[i - 1][j - 1][k - 1] * p[i][cnt] % mod) %= mod;
		}
		for (int j = 1; j <= n; j ++) 
		for (int k = (j / 2) + 1; k <= j; k ++) {
			(o += f[n][j][k]) %= mod;
		}
	}
	printf("%lld\n", (tot - o + mod) % mod);
	
	return 0;
}
