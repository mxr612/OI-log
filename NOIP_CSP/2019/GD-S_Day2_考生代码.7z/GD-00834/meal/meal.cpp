#include<cstdio>
#include<cstring>
using namespace std;
long long f[2][41][41][41],a[2100];
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	int n,m;scanf("%d%d",&n,&m);
	memset(f,0,sizeof(f));f[0][0][0][0]=1;
	for(int i=m+1;i<=3;i++)a[i]=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)scanf("%lld",&a[j]);
		const int nowlb=i&1,lstlb=(i&1)^1;
		for(int j=0;j<=i;j++)
		{
			for(int k=0;k<=i-j;k++)
			{
				for(int l=0;l<=i-j-k;l++)
				{
					f[nowlb][j][k][l]=f[lstlb][j][k][l];
					if(j>=1)f[nowlb][j][k][l]=(f[nowlb][j][k][l]+f[lstlb][j-1][k][l]*a[1])%998244353;
					if(k>=1)f[nowlb][j][k][l]=(f[nowlb][j][k][l]+f[lstlb][j][k-1][l]*a[2])%998244353;
					if(l>=1)f[nowlb][j][k][l]=(f[nowlb][j][k][l]+f[lstlb][j][k][l-1]*a[3])%998244353;
				}
			}
		}
	}
	const int nlb=n&1;
	long long ss=0;
	for(int i=0;i<=n;i++)
	{
		for(int j=0;j<=n-i;j++)
		{
			for(int k=0;k<=n-i-j;k++)
			{
				if(i+j+k==0)continue;
				if(i>(i+j+k)/2)continue;
				if(j>(i+j+k)/2)continue;
				if(k>(i+j+k)/2)continue;
				ss=(ss+f[nlb][i][j][k])%998244353;
			}
		}
	}
	printf("%lld\n",ss);
	return 0;
}
