#include<cstdio>
#include<cstring>
using namespace std;
struct node
{
	int x,y,next;
}a[610000];int len,last[310000];
inline void ins(int x,int y)
{
	len++;a[len].x=x;a[len].y=y;
	a[len].next=last[x];last[x]=len;
}
int xx,yy;
int lbcnt[310000],cnt[310000],lb[310000];
void dfs(int x,int fa,int tk)
{
	cnt[x]=1;lbcnt[x]=0;lb[x]=tk;
	for(int k=last[x];k>0;k=a[k].next)
	{
		int y=a[k].y;
		if(y!=fa&&(x!=xx||y!=yy)&&(x!=yy||y!=xx))
		{
			dfs(y,x,tk);
			cnt[x]+=cnt[y];
			if(cnt[y]>lbcnt[x])lbcnt[x]=cnt[y];
		}
	}
}
int lian[310000],lia;
void dfsli(int x,int fa)
{
	lia++;lian[lia]=x;
	for(int k=last[x];k>0;k=a[k].next)
	{
		int y=a[k].y;
		if(y!=fa)dfsli(y,x);
	}
}
int pp[310000];
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int t;scanf("%d",&t);
	while(t--)
	{
		int n;scanf("%d",&n);
		len=0;memset(last,0,sizeof(last));
		memset(pp,0,sizeof(pp));
		for(int i=1;i<n;i++)
		{
			int x,y;scanf("%d%d",&x,&y);
			ins(x,y);ins(y,x);
			pp[x]++;pp[y]++;
		}
		bool bk=true;int pr=0;
		for(int i=1;i<=n;i++)
		{
			if(pp[i]>2){bk=false;break;}
			if(pp[i]==1)pr=i;
		}
		if(bk==true)
		{
			long long ss=0;
			lia=0;
			dfsli(pr,0);
			for(int i=1;i<=n;i++)
			{
				int j=n-i+1;
				if(2*i<n)ss=ss+lian[i];
				if(i<=2*i-1&&2*i-1<n)ss=ss+lian[i];
				if(i<=2*i-2&&2*i-2<n)ss=ss+lian[i];
				if(2*j<n)ss=ss+lian[i];
				if(j<=2*j-1&&2*j-1<n)ss=ss+lian[i];
				if(j<=2*j-2&&2*j-2<n)ss=ss+lian[i];
			}
			printf("%lld\n",ss);
			continue;
		}
		long long ss=0;
		for(int i=1;i<n;i++)
		{
			xx=a[i*2-1].x;yy=a[i*2-1].y;
			dfs(xx,0,xx);dfs(yy,0,yy);
			for(int j=1;j<=n;j++)
			{
				int tk=lb[j];
				if(cnt[tk]-cnt[j]<=cnt[tk]/2&&lbcnt[j]<=cnt[tk]/2)ss=ss+j;
			}
		}
		printf("%lld\n",ss);
	}
	return 0;
}
