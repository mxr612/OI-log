#include<cstdio>
#include<cstring>
using namespace std;
long long f[5100][5100],a[5100],sj[5100];
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int n,opt;scanf("%d%d",&n,&opt);
	if(opt==0)
	{
		sj[0]=0;
		for(int i=1;i<=n;i++)
		{
			scanf("%lld",&a[i]);
			sj[i]=sj[i-1]+a[i];
		}
	}
	for(int i=1;i<=n;i++)f[i][1]=sj[i]*sj[i];
	for(int j=2;j<=n;j++)
	{
		int k=j;
		long long ss=0x3f3f3f3f3f3f3f3fll;
		for(int i=j;i<=n;i++)
		{
			while(k>1&&sj[j-1]-sj[k-2]<=sj[i]-sj[j-1])
			{
				k--;
				if(f[j-1][k]<ss)ss=f[j-1][k];
			}
			f[i][j]=ss+(sj[i]-sj[j-1])*(sj[i]-sj[j-1]);
		}
	}
	long long ss=0x3f3f3f3f3f3f3f3fll;
	for(int i=1;i<=n;i++)
	{
		if(f[n][i]<ss)ss=f[n][i];
	}
	printf("%lld\n",ss);
	return 0;
}
