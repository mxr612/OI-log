#include<iostream>
#include<cstring>
#include<cstdio>
#include<vector>
using namespace std;
#define il inline
#define re register int
#define maxn 300005
vector <int> vec[maxn];

int t,n,cnt,head1,head2,nk;
unsigned long long ans;
int f[maxn],sum[maxn],ff[maxn],summ[maxn];

il void dfs(int p,int fa)
{
	f[p]=fa;
	for(re i=0;i<vec[p].size();++i)
		if(vec[p][i]!=fa)
		{
			if(vec[p][i]==head2||vec[p][i]==head1) continue;
			dfs(vec[p][i],p),sum[p]+=sum[vec[p][i]];
		}
	++sum[p];
}

il void pre(int p,int fa)
{
	ff[p]=fa;
	for(re i=0;i<vec[p].size();++i)
		if(vec[p][i]!=fa)
			pre(vec[p][i],p),summ[p]+=summ[vec[p][i]];
	++summ[p];
}

il void cntre(int p)
{
	bool judge=true;
	if(nk-sum[p]>nk/2) judge=false;
	else
		for(re i=0;i<vec[p].size();++i)
			if(vec[p][i]!=f[p])
			{
				if(vec[p][i]==head2||vec[p][i]==head1) continue;
				cntre(vec[p][i]);
				if(sum[vec[p][i]]>nk/2)	judge=false;
			}
	unsigned long long temp=p;
	if(judge) ans+=temp;
}

il void doo(int p)
{
	for(re i=0;i<vec[p].size();++i)
		if(vec[p][i]!=ff[p])
		{
			head1=p;head2=vec[p][i];
			dfs(head1,head1);dfs(head2,head2);
			nk=summ[vec[p][i]];cntre(head2);
			nk=n-nk;cntre(head1);
			memset(sum,0,sizeof sum);
			doo(vec[p][i]);
		}
} 

int main ( )
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&t);
	while(--t>=0)
	{
		int l,r;cnt=0;ans=0;
		scanf("%d",&n);
		for(re i=1;i<n;++i)
		{
			scanf("%d%d",&l,&r);
			vec[l].push_back(r);
			vec[r].push_back(l);
		}
		pre(1,1);
		doo(1);
		for(re i=1;i<=n;++i)
			while(vec[i].size())
				vec[i].pop_back();
		memset(summ,0,sizeof summ);
		printf("%lld\n",ans);
	}
	return 0;
}
