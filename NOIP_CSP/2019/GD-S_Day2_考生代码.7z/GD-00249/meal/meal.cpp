#include<iostream>
#include<cstdio>
using namespace std;
#define re register int
int a[105][2005];
int val[5],ans=0;
int n,m;

inline void dfs(int p)
{
	if(p==n)
	{
		int sum=0;
		bool judge1=false,judge2=true;
		for(re j=1;j<=m;++j)
		{
			if(val[j]!=0) judge1=true;
			sum+=val[j];
		}
		if(judge1==false) return;
		for(re j=1;j<=m;++j)
			if(val[j]>sum/2) judge2=false;
		if(judge2) ++ans;
		return;
	}
	for(re j=1;j<=m;++j)
		val[j]+=a[p][j],dfs(p+1),val[j]-=a[p][j];
}

int main ( )
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(re i=1;i<=n;++i)
		for(re j=1;j<=m;++j)
			scanf("%d",&a[i][j]);
	for(re i=1;i<=n;++i)
	{
		for(re j=1;j<=m;++j)
			val[j]+=a[i][j],dfs(i),val[j]-=a[i][j];
	}
	printf("%d",ans);
	return 0;
}
