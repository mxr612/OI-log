#include<cstdio>
#include<cstring>
#include<algorithm>
#define N 300010
using namespace std;
int T,n,u,v,tot,la[N],si[N],dep[N],fa[N],bz[N];
long long ans;
struct ed
{
	int u,v,ne;
}w[2*N];
void add(int u,int v)
{
	w[++tot].u=u;
	w[tot].v=v;
	w[tot].ne=la[u];
	la[u]=tot;
	w[++tot].u=v;
	w[tot].v=u;
	w[tot].ne=la[v];
	la[v]=tot;
}
void dfs(int u,int ss,int nn)
{
	int ma=0,s=0;
	for(int i=la[u];i;i=w[i].ne)
		if(w[i].v!=fa[u]&&w[i].v!=nn)
		{
			dfs(w[i].v,ss,nn);
			if(bz[w[i].v])
			{
				ma=max(ma,si[w[i].v]-si[nn]);
				s+=si[w[i].v]-si[nn];
			}
			else
			{
				ma=max(ma,si[w[i].v]);
				s+=si[w[i].v];
			}
		}
	ma=max(ma,ss-1-s);
	if(ma<=ss/2)ans+=(long long)u;
}
void build(int u)
{
	dep[u]=dep[fa[u]]+1;
	for(int i=la[u];i;i=w[i].ne)
		if(w[i].v!=fa[u])
		{
			fa[w[i].v]=u;
			build(w[i].v);
			si[u]+=si[w[i].v];
		}
	si[u]++;
}
void tag(int u,int bb)
{
	while(u)
	{
		bz[u]=bb;
		u=fa[u];
	}
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		tot=0;
		for(int i=1;i<=n;i++)la[i]=si[i]=dep[i]=fa[i]=0;
		for(int i=1;i<n;i++)
		{
			scanf("%d%d",&u,&v);
			add(u,v);
		}
		build(1);
		ans=0;
		for(int i=1;i<tot;i+=2)
		{
			u=w[i].u;
			v=w[i].v;
			if(dep[u]>dep[v])swap(u,v);
			tag(u,1);
			dfs(1,n-si[v],v);
			dfs(v,si[v],v);
			tag(u,0);
		}
		printf("%lld\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
