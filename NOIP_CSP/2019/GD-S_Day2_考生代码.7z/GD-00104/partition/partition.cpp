#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,opt;
unsigned long long a[5010],sum[5010],g[5010],f[5010];
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&opt);
	for(int i=1;i<=n;i++)
	{
		scanf("%llu",&a[i]);
		sum[i]=sum[i-1]+a[i];
	}
	for(int i=1;i<=n;i++)
	{
		int s=0;
		for(int j=1;j<i;j++)
			if(sum[i]-sum[j]>=g[j]&&f[j]+(sum[i]-sum[j])*(sum[i]-sum[j])<=f[s]+(sum[i]-sum[s])*(sum[i]-sum[s]))s=j;
		f[i]=f[s]+(sum[i]-sum[s])*(sum[i]-sum[s]);
		g[i]=sum[i]-sum[s];
	}
	printf("%llu",f[n]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
