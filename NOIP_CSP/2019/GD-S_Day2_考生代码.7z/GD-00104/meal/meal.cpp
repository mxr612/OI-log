#include<cstdio>
#include<cstring>
#include<algorithm>
#define mo 998244353
#define N 110
#define M 2010
using namespace std;
int n,m,b[M];
long long a[N][M],ans;
void dfs(int x,int s,long long sum,int lm)
{
	if(s==lm)
	{
		ans=(ans+sum)%mo;
		return;
	}
	if(x>n)return;
	dfs(x+1,s,sum,lm);
	for(int i=1;i<=m;i++)
		if(a[x][i])
		{
			if(b[i]+1<=lm/2)
			{
				b[i]++;
				dfs(x+1,s+1,sum*a[x][i]%mo,lm);
				b[i]--;
			}
		}
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%lld",&a[i][j]);
	for(int i=2;i<=n;i++)dfs(1,0,1,i);
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

//#include<cstdio>
//#include<cstring>
//#include<algorithm>
//#define mo 998244353
//#define N 50
//using namespace std;
//int n,m,a[N][N],f[N][N][N],g[N][N][N],ans;
//void work(int x,int l,int r)
//{
//	f[l][r][0]=1;
//	for(int i=l;i<=r;i++)
//		if(a[i][x])
//			for(int j=1;j<=i-l+1;j++)
//			{
//				f[l][r][j]=(f[l][r][j]+f[l][r][j-1]*a[i][x]%mo)%mo;
//				f[l][r][j-1]=(f[l][r][j-1]+a[i][x])%mo;
//			}
//}
//int main()
//{
//	freopen("meal.in","r",stdin);
//	freopen("meal.out","w",stdout);
//	scanf("%d%d",&n,&m);
//	for(int i=1;i<=n;i++)
//		for(int j=1;j<=m;j++)
//			scanf("%d",&a[i][j]);
//	for(int i=1;i<=n;i++)
//		for(int j=i;j<=n;j++)
//			g[i][j][0]=1;
//	for(int i=1;i<=m;i++)
//	{
//		for(int j=1;j<=n;j++)
//			for(int k=j;k<=n;k++)
//				work(i,j,k);
//		for(int j=1;j<=n;j++)
//			for(int k=j;k<=n;k++)
//				for(int l=j;l<=k;l++)
//					for(int u=1;u<=n;u++)
//						for(int v=1;v<=u/2;v++)
//							g[j][k][u]=(g[j][k][u]+g[j][l][u-v]*f[l+1][k][v]%mo+f[j][l][v]*g[l+1][k][u-v]%mo)%mo;
////		for(int j=1;j<=n;j++)
////			for(int k=j;k<=n;k++)
////				for(int l=1;l<=n;l++)
////					g[j][k][l]=(g[j][k][l]+f[j][k][l])%mo;
//	}
//	for(int i=1;i<=n;i++)ans=(ans+g[1][n][i])%mo;
//	printf("%d",ans);
//	fclose(stdin);
//	fclose(stdout);
//	return 0;
//}
