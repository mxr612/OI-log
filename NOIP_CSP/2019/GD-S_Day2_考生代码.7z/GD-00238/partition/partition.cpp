#include<cstdio>
const int N=55;
typedef long long LL;
const LL Inf=4e18;
int Num[N],n;
LL Answer;
inline int Read(){
	char ch;
	while((ch=getchar())<'0'||ch>'9');
	int x=ch^48;
	while((ch=getchar())>='0'&&ch<='9')
		x=(x<<3)+(x<<1)+(ch^48);
	return x;
}
inline LL Min(const LL x,const LL y){
	return x<y?x:y;
}
inline void Dfs(const int x,const int Las,const LL ss){
	if(x==n) return Answer=Min(Answer,ss),void();
	int s1=0;
	for(register int i=x+1;i<=n;i++){
		s1+=Num[i];
		if(s1<Las) continue ;
		LL s2=ss+1ll*s1*s1;
		if(s2>Answer) return ;
		Dfs(i,s1,s2);
	}
}
inline void Init(){
	n=Read();
	Answer=Read();
	Answer=Inf;
	for(register int i=1;i<=n;i++)
		Num[i]=Read();
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	Init();
	Dfs(0,0,0);
	printf("%lld\n",Answer);
	return 0;
}
