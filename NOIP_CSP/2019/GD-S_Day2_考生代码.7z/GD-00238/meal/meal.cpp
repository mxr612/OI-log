#include<cstdio>
#include<cstring>
const int N=45;
const int M=505;
const int Z=2;
const int Mod=998244353;
int Num[N][M],n,m,f[Z][M][N][N],p,q,Sum[N],Answer,ss;
inline int Read(){
	char ch;
	while((ch=getchar())<'0'||ch>'9');
	int x=ch^48;
	while((ch=getchar())>='0'&&ch<='9')
		x=(x<<3)+(x<<1)+(ch^48);
	return x;
}
inline void Query(){
	p=0;q=1;
	Answer=1;
	ss=0;
	for(register int j=1;j<=m;j++)
		f[0][j][0][0]=1;
	for(register int i=1;i<=n;i++){
		p^=1;q^=1;
		for(register int j=1;j<=m;j++){
			int ll=(Sum[i]-Num[i][j]+Mod)%Mod;
			for(register int l=1;l<=i;l++){
				for(register int k=1;k<=l;k++){
					f[p][j][k][l]=(1ll*f[q][j][k-1][l-1]*Num[i][j]%Mod+f[q][j][k][l])%Mod;
					f[p][j][k][l]=(1ll*f[q][j][k][l-1]*ll%Mod+f[p][j][k][l])%Mod;
				}
				f[p][j][0][l]=(1ll*f[q][j][0][l-1]*ll%Mod+f[q][j][0][l])%Mod;
			}
			f[p][j][0][0]=1;
		}
		Answer=1ll*Answer*(Sum[i]+1)%Mod;
	}
	for(register int j=1;j<=m;j++){
		for(register int l=1;l<=n;l++){
			for(register int k=(l>>1)+1;k<=l;k++)
				ss=(ss+f[p][j][k][l])%Mod;
		}
	}
	Answer=(Answer-ss-1+Mod)%Mod;
}
inline void Init(){
	n=Read();m=Read();
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=m;j++){
			Num[i][j]=Read();
			Sum[i]=(Sum[i]+Num[i][j])%Mod;
		}
	}
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	Init();
	Query();
	printf("%d\n",Answer);
	return 0;
}
