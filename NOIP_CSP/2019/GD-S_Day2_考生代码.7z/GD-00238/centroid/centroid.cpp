#include<cstdio>
#include<cstring>
const int N=5e4+5;
typedef long long LL;
int n,Pos[N],Dfn[N],clk,cnt,q[N][2],T;
int Head[N],Ver[N<<1],Nxt[N<<1],cnt_edge,Root,Cnt_[N],Father[N];
LL Answer;
bool flag,Vis[N];
inline int Read(){
	char ch;
	while((ch=getchar())<'0'||ch>'9');
	int x=ch^48;
	while((ch=getchar())>='0'&&ch<='9')
		x=(x<<3)+(x<<1)+(ch^48);
	return x;
}
inline void Add_Edge(const int u,const int v){
	Ver[++cnt_edge]=v;
	Nxt[cnt_edge]=Head[u];
	Head[u]=cnt_edge;
}
inline void Dfs(const int u,const int fa){
	Dfn[u]=++clk;
	Pos[clk]=u;
	Father[u]=fa;
	for(register int i=Head[u];i!=-1;i=Nxt[i]){
		int v=Ver[i];
		if(v==fa) continue ;
		Dfs(v,u);
	}
}
inline void Dfs2(const int u,const int k){
	q[++q[0][k]][k]=u;
	Vis[u]=1;
	for(register int i=Head[u];i!=-1;i=Nxt[i]){
		int v=Ver[i];
		if(Vis[v]) continue ;
		if(v==-1) continue ;
		Dfs2(v,k);
	}
}
inline void Init(){
	memset(Head,-1,sizeof(Head));
	n=Read();
	Answer=0;
	clk=0;
	cnt_edge=-1;
	for(register int i=1;i<n;i++){
		int u=Read(),v=Read();
		Cnt_[u]++;
		Cnt_[v]++;
		Add_Edge(u,v);
		Add_Edge(v,u);
	}
}
inline int Size(const int u){
	int ss=1;
	for(register int i=Head[u];i!=-1;i=Nxt[i]){
		int v=Ver[i];
		if(v==Father[u]) continue ;
		if(v==-1) continue ;
		ss+=Size(v);
	}
	return ss;
}
inline void Swap(int&x,int&y){
	int tmp=x;
	x=y;y=tmp;
}
inline void Query_15(){
	for(register int i=1;i<n;i++){
		int p=i-1<<1;
		int u=Ver[p],v=Ver[p^1];
		if(Dfn[u]<Dfn[v]) Swap(u,v);
		int s1=Dfn[v],s2=n-Dfn[v];
		int k;
		k=s1>>1;
		Answer+=Pos[Dfn[v]-k];
		if(k%2==0) Answer+=Pos[Dfn[v]-k+1];
		k=s2>>1;
		Answer+=Pos[Dfn[u]+k];
		if(k%2==0) Answer+=Pos[Dfn[u]+k-1];
	}
}
inline void Query_25(){
	for(register int i=1;i<n;i++){
		memset(Vis,0,sizeof(Vis));
		int p=i-1<<1;
		int u=Ver[p],v=Ver[p^1];
		Ver[p]=Ver[p^1]=-1;
		q[0][0]=q[0][1]=0;
		Dfs2(u,0);
		Dfs2(v,1);
		for(register int i=1;i<=q[0][0];i++){
			int uu=q[i][0];
			int ss=q[0][0];
			flag=1;
			for(register int j=Head[uu];j!=-1;j=Nxt[j]){
				int vv=Ver[j];
				if(vv==Father[uu]) continue ;
				if(vv==-1) continue ;
				if(Size(vv)>(q[0][0]>>1)){
					flag=0;
					break ;
				}
				ss-=Size(vv);
			}
			if(ss-1>(q[0][0]>>1)&&q[0][0]>2) flag=0;
			if(flag) Answer+=uu;
		}
		for(register int i=1;i<=q[0][1];i++){
			int uu=q[i][1];
			int ss=q[0][1];
			flag=1;
			for(register int j=Head[uu];j!=-1;j=Nxt[j]){
				int vv=Ver[j];
				if(vv==Father[uu]) continue ;
				if(vv==-1) continue ;
				if(Size(vv)>(q[0][1]>>1)){
					flag=0;
					break ;
				}
				ss-=Size(vv);
			}
			if(ss-1>(q[0][1]>>1)&&q[0][1]>2) flag=0;
			if(flag) Answer+=uu;
		}
		Ver[p]=u;Ver[p^1]=v;
	}
}
inline void Query(){
	flag=1;
	for(register int i=1;i<=n;i++){
		if(Cnt_[i]>2){
			flag=0;
			break ;
		}
		if(Cnt_[i]==1){
			++cnt;
			if(cnt>2){
				flag=0;
				break ;
			}
			Root=i;
		}
	}
	if(flag) Dfs(Root,0);
	else Dfs(1,0);
	if(flag) Query_15();
	else Query_25();
	printf("%d\n",Answer);
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	for(T=Read();T;T--){
		Init();
		Query();
	}
	return 0;
}
