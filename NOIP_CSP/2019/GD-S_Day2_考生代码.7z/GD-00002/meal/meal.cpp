#include<bits/stdc++.h>
using namespace std;
int sum[1005],n,m,mapp[1005][2005],num;
void dfs(int t,int cs,int x,int q){ //��t��,������cs��,��ǰ�˻�Ϊx,ѡ��q���� 
	if(t>n)return;
	if(cs>n/2)return;
//	if(q==1)printf("564564 ");
	for(int i=1;i<=m;i++){
		if(mapp[t][i]){
			int cha=0,qwq=0;
			qwq=x*mapp[t][i]%998244353;
			if(sum[i]+1>cs)cs=++sum[i],cha=1;
			else sum[i]++;
			if(cs<=(q+1)/2)
			{
			//	printf("%d %d %d %d\n",t,x,q,num);
				num=(num+qwq)%998244353;//printf("%d\n",qwq);
			//	printf("146466");
			}
			dfs(t+1,cs,qwq,q+1);
			sum[i]--;
			if(cha)cs--;
		}
	}
	dfs(t+1,cs,x,q);
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++){
			scanf("%d",&mapp[i][j]);
		}
	dfs(1,0,1,0);
	printf("%d",num);
	return 0;
}
