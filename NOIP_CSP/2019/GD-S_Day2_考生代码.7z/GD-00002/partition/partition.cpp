#include<bits/stdc++.h>
using namespace std;
long long n,num[50005]={-1},nen[50005],cnt,m,n1[50005],n2[50005];
long long find1(long long w){
	long long maxx=0;
	long long q=w;
	long long e=num[w],ee=num[q-1];
	while(ee>num[w]&&w<=n)ee+=num[w++],maxx=max(ee,maxx);//�������������������ִ������������� 
	return maxx;
}
long long find2(long long w){
	long long maxx=0;
	long long q=w;
	long long ee=num[w];
	while(ee<num[q-1]&&w<=n)ee+=num[w++],maxx=max(ee,maxx);// ������������������� 
	if(w==n+1)return 223372036854775808-1000;
	return maxx;
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(long long i=1;i<=n;i++){
		scanf("%d",&num[i]);
		n1[i]=n2[i]=num[i];
	}
	for(long long i=1;i<=n;i++){
		if(num[i-1]<=num[i])nen[++cnt]=num[i];
		else {     //num[i-1]>num[i]
			if(i==n){
				while(nen[cnt]>num[i])nen[cnt]+=num[i++];
				nen[++cnt]=num[i];
			}
			else{
			long long l=find1(i),r=find2(i);
			if(l>r){
				long long ee=num[i],eee=num[i-1];
				while(ee<eee)ee+=num[++i];
				nen[++cnt]=ee;
				num[i]=ee;
			}
			else {
				while(nen[cnt]>num[i])nen[cnt]+=num[i++];
				nen[++cnt]=num[i];
			}
		}
		}
	}
	long long ans=0;
	for(long long i=1;i<=cnt;i++){
		if(nen[i]<=100000)
		ans+=nen[i]*nen[i];
	}
	cout<<ans<<endl;
	return 0;
}
