#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>
#define ll long long
using namespace std;
int n,m;
ll ans=0;
int cnt[2010];
ll v[110][2010];
const ll mod=998244353;
void dfs(int p,ll sum)
{
	if(p==n+1)
	{
		int maxn=0;
		bool flag=true;
		for(int i=1;i<=m;i++)
			maxn+=cnt[i];
		for(int i=1;i<=m;i++)
		{
			if(cnt[i]>maxn/2)
			{
				flag=false;
				break;
			}
		}
		if(flag&&maxn!=0) ans=(ans+sum)%mod;
		return;
	}
	dfs(p+1,sum);
	for(int i=1;i<=m;i++)
	{
		cnt[i]++;
		dfs(p+1,sum*v[p][i]);
		cnt[i]--;
	}
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%lld",&v[i][j]);
	dfs(1,1);
	printf("%lld\n",ans%mod);
	return 0;
}
