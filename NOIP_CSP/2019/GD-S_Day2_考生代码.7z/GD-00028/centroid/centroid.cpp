#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>
#define ll long long
using namespace std;
int n,minn,tot,tail;
int fir[300000],fa[300000],maxn[300000],size[300000],val[300000],que[300000];
struct edge
{
	int to;
	int nxt;
}e[600000];
void add(int x,int y)
{
	e[++tot].to=y;
	e[tot].nxt=fir[x];
	fir[x]=tot;
}
void dfs1(int p)
{
	val[p]=1;
	for(int i=fir[p];i;i=e[i].nxt)
	{
		int q=e[i].to;
		if(q==fa[p]) continue;
		fa[q]=p;
		dfs1(q);
		val[p]+=val[q];
	}
}
void dfs2(int p,int f,int all)
{
	size[p]=1;
	que[++tail]=p;
	for(int i=fir[p];i;i=e[i].nxt)
	{
		int q=e[i].to;
		if(q==f) continue;
		dfs2(q,p,all);
		size[p]+=size[q];
		maxn[p]=max(maxn[p],size[q]);
	}	
	maxn[p]=max(maxn[p],all-size[p]);
	minn=min(minn,maxn[p]);
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--)
	{
		ll ans=0;
		tot=0;
		memset(fir,0,sizeof(fir));
		scanf("%d",&n);
		for(int i=1;i<n;i++)
		{
			int a,b;
			scanf("%d%d",&a,&b);
			add(a,b);
			add(b,a);
		}
		dfs1(1);
		for(int i=2;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
				maxn[j]=size[j]=0;
			minn=n+1,tail=0;
			dfs2(i,fa[i],val[i]);
			for(int j=1;j<=tail;j++)
				if(maxn[que[j]]==minn) ans+=(ll)que[j];
			minn=n+1,tail=0;
			dfs2(fa[i],i,val[1]-val[i]);
			for(int j=1;j<=tail;j++)
				if(maxn[que[j]]==minn) ans+=(ll)que[j];
		}
		printf("%lld\n",ans);
	}
	return 0;
}
