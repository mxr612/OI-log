#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>
#define ll long long
using namespace std;
ll v[40000010],sum[40000010],f[5010][5010];//f[i][j]��i�ǵ�ǰ�εĽ�β��j����һ�εĽ�β 
const ll INF=4000000000000000010;
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int n,type;
	ll ans=INF;
	scanf("%d%d",&n,&type);
	for(register int i=1;i<=n;i++)
	{
		scanf("%lld",&v[i]);
		sum[i]=sum[i-1]+v[i];
	}
	memset(f,0x3f,sizeof(f));
	for(register int i=1;i<=n;i++)
	{
		for(register int j=1;j<i;j++)
			for(register int k=0;k<j;k++)
				if(sum[i]-sum[j]>=sum[j]-sum[k]) f[i][j]=min(f[i][j],f[j][k]+(sum[i]-sum[j])*(sum[i]-sum[j]));
		f[i][0]=sum[i]*sum[i];
	}
	for(register int i=0;i<n;i++)
		ans=min(ans,f[n][i]);
	printf("%lld\n",ans);
	return 0;
}
