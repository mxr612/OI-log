#include <stdio.h>
#include <string.h>
#include <algorithm>

#define rep(i,st,ed) for (register int i=st;i<=ed;++i)

typedef long long LL;
const int MOD=998244353;
const int N=2005;

int f[N][N],u[N];
int n,m; LL a[N][N],ans;

bool check() {
}

void fd2(int dep,int c1,int c2,LL tot) {
	if (dep==n+1) {
		if (c1==c2&&(c1+c2)) ans=(ans+tot)%MOD;
		return ;
	}
	u[dep]=1; fd2(dep+1,c1+1,c2,tot*a[dep][1]%MOD);
	u[dep]=2; fd2(dep+1,c1,c2+1,tot*a[dep][2]%MOD);
	u[dep]=0; fd2(dep+1,c1,c2,tot);
}

void fd3(int dep,int c1,int c2,int c3,LL tot) {
	if (dep==n+1) {
		int up=(c1+c2+c3)/2;
		if (c1<=up&&c2<=up&&c3<=up&&(c1+c2+c3)) ans=(ans+tot)%MOD;
		return ;
	}
	u[dep]=1; fd3(dep+1,c1+1,c2,c3,tot*a[dep][1]%MOD);
	u[dep]=2; fd3(dep+1,c1,c2+1,c3,tot*a[dep][2]%MOD);
	u[dep]=3; fd3(dep+1,c1,c2,c3+1,tot*a[dep][3]%MOD);
	u[dep]=0; fd3(dep+1,c1,c2,c3,tot);
}

int main(void) {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	rep(i,1,n) rep(j,1,m) scanf("%lld",&a[i][j]);
	if (m==2) {
		fd2(1,0,0,1);
	} else if (m==3) fd3(1,0,0,0,1);
	printf("%lld\n", ans);
	return 0;
	return 0;
}