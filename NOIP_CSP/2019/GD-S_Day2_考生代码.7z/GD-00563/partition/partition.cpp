#include <stdio.h>
#include <string.h>
#include <algorithm>

#define rep(i,st,ed) for (register int i=st;i<=ed;++i)

typedef long long LL;
const int N=6005;

LL f[N][N],mn[N][N],a[N],s[N];

LL min(LL x,LL y) {
	return x<y?x:y;
}

int main(void) {
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int n,typ; scanf("%d%d",&n,&typ);
	rep(i,1,n) {
		scanf("%lld",&a[i]);
		s[i]=s[i-1]+a[i];
	}
	LL INF=s[n]*s[n]+1;
	rep(i,1,n) {
		rep(j,1,i-1) f[i][j]=INF;
		f[i][i]=s[i]*s[i];
	}
	rep(i,1,n) {
		mn[i][0]=INF;
		rep(j,1,i) {
			int k=i-j; LL v=s[i]-s[i-j]; v=v*v;
			int l=1,r=k,pos=-1,mid;
			while (l<=r) {
				mid=(l+r)>>1;
				if (s[k]*2-s[i]>s[k-mid]) r=mid-1;
				else pos=mid,l=mid+1;
			}
			if (pos>0) f[i][j]=min(f[i][j],mn[k][pos]+v);
			mn[i][j]=(f[i][j]<mn[i][j-1])?f[i][j]:mn[i][j-1];
		}
	}
	LL ans=INF;
	rep(i,1,n) (ans>f[n][i])?(ans=f[n][i]):0;
	printf("%lld\n", ans);
	return 0;
}
