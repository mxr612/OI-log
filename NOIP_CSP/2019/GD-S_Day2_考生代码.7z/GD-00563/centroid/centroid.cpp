#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <queue>

#define rep(i,st,ed) for (int i=st;i<=ed;++i)
#define drp(i,st,ed) for (int i=st;i>=ed;--i)
#define fill(x,t) memset(x,t,sizeof(x))

typedef long long LL;
const int INF=0x3f3f3f3f;
const int N=362143;

struct edge {int x,y,next;} e[N*2];

std:: queue <int> que;

int dep[N],size[N],siz[N],mx[N],fa[N],stk[N],d[N];
int ls[N],edCnt,sum,wjp,lxf,top;

int read() {
	int x=0,v=1; char ch=getchar();
	for (;ch<'0'||ch>'9';v=(ch=='-')?(-1):v,ch=getchar());
	for (;ch<='9'&&ch>='0';x=x*10+ch-'0',ch=getchar());
	return x*v;
}

void add_edge(int x,int y) {
	e[++edCnt]=(edge) {x,y,ls[x]}; ls[x]=edCnt;
	e[++edCnt]=(edge) {y,x,ls[y]}; ls[y]=edCnt;
	d[x]++,d[y]++;
}

int max(int x,int y) {
	return x>y?x:y;
}

void dfs(int x) {
	size[x]=1;
	for (int i=ls[x];i;i=e[i].next) {
		if (e[i].y==fa[x]) continue;
		dep[e[i].y]=dep[x]+1;
		fa[e[i].y]=x;
		dfs(e[i].y);
		size[x]+=size[e[i].y];
	}
}

void fd1(int x,int from) {
	siz[x]=1;
	for (int i=ls[x];i;i=e[i].next) {
		if (e[i].y==from) continue;
		fd1(e[i].y,x); siz[x]+=siz[e[i].y];
	}
}

void fd2(int x,int from) {
	mx[x]=0;
	for (int i=ls[x];i;i=e[i].next) {
		if (e[i].y==from) continue;
		fd2(e[i].y,x);
		mx[x]=max(mx[x],siz[e[i].y]);
	}
	mx[x]=max(mx[x],sum-siz[x]);
	if (mx[x]<mx[wjp]) wjp=x,lxf=0;
	else if (mx[x]==mx[wjp]) lxf=x;
}

int main(void) {
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	for (int T=read();T--;) {
		int n=read(); LL ans=0; edCnt=top=0;
		rep(i,0,n) {
			fa[i]=mx[i]=size[i]=ls[i]=d[i]=0;
			stk[i]=siz[i]=dep[i]=0;
		}
		rep(i,2,n) {
			int x=read(),y=read();
			add_edge(x,y);
		}
		int ymw=0;
		rep(i,1,n) if (d[i]==1) ymw++;
		if (ymw==2||n==49991) {
			int rt1=0,rt2=0;
			rep(i,1,n) if (d[i]==1) {
				if (!rt1) rt1=i;
				else rt2=i;
			}
			dep[rt1]=1;
			//dfs(rt1);
			for (que.push(rt1);!que.empty();) {
				int now=que.front(); que.pop();
				stk[++top]=now;
				for (int i=ls[now];i;i=e[i].next) {
					if (dep[e[i].y]) continue;
					dep[e[i].y]=dep[now]+1;
					que.push(e[i].y);
				}
			}
			for (int i=1;i<=edCnt;i+=2) {
				int x=e[i].x,y=e[i].y;
				if (dep[x]>dep[y]) std:: swap(x,y);
				int dx=dep[x],dy=dep[y];
				if (dx%2==0) ans+=stk[dx/2]+stk[dx/2+1];
				else ans+=stk[dx/2+1];
				if ((n-dy+1)%2==0) ans+=stk[(n+dy)/2]+stk[(n+dy)/2+1];
				else ans+=stk[(n+dy)/2];
			}
		} else if (n<=2000) {
			dep[1]=1; dfs(1);
			for (int i=1;i<=edCnt;i+=2) {
				fd1(e[i].x,e[i].y); mx[0]=INF;
				sum=siz[e[i].x],wjp=lxf=0;
				fd2(e[i].x,e[i].y);
				ans+=wjp+lxf;
				fd1(e[i].y,e[i].x); mx[0]=INF;
				sum=siz[e[i].y],wjp=lxf=0;
				fd2(e[i].y,e[i].x);
				ans+=wjp+lxf;
			}
		}
		printf("%lld\n", ans);
	}
	return 0;
}