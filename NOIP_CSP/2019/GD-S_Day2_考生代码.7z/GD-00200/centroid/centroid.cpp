#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 299995 + 5;
template<typename T> void read(T &x) {
	x = 0; int f = 1; char c;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -f;
	for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
	x *= f;
}
template<typename T> void write(T x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}
template<typename T> void writeln(T x) { write(x); putchar('\n'); }
int head[MAXN], ver[MAXN << 1], nxt[MAXN << 1], tot = 1;
int n, a[MAXN], b[MAXN], flag;
ll ans, sum_a, sum_b, siz[MAXN];
void prework(int x, int fa) {
	++sum_a;
	for (int i = head[x]; i; i = nxt[i]) {
		if (ver[i] == fa) continue;
		prework(ver[i], x);
	}
}
void dfs(int x, int fa) {
	ll maxp = 0;
	siz[x] = 1;
	for (int i = head[x]; i; i = nxt[i]) {
		if (ver[i] == fa) continue;
		dfs(ver[i], x);
		siz[x] += siz[ver[i]];
		maxp = max(maxp, siz[ver[i]]);
	}
	if (!flag) {
		maxp = max(maxp, sum_a - siz[x]);
		if (maxp <= sum_a / 2) ans += x;
	}
	else {
		maxp = max(maxp, sum_b - siz[x]);
		if (maxp <= sum_b / 2) ans += x;
	}
}
int cnt[MAXN], pid[MAXN], tmp;
void solve1_dfs(int x, int fa) {
	pid[++tmp] = x;
	for (int i = head[x]; i; i = nxt[i]) {
		if (ver[i] == fa) continue;
		solve1_dfs(ver[i], x);
	}
}
void solve1() {
	memset(cnt, 0, sizeof(cnt));
	ans = 0; tmp = 0;
	for (int i = 1; i < n; ++i) {
		read(a[i]); read(b[i]);
		++cnt[a[i]]; ++cnt[b[i]];
		ver[++tot] = b[i]; nxt[tot] = head[a[i]]; head[a[i]] = tot;
		ver[++tot] = a[i]; nxt[tot] = head[b[i]]; head[b[i]] = tot;
	}
	for (int x = 1; x <= n; ++x)
		if (cnt[x] == 1) {
			solve1_dfs(x, 0);
			break;
		}
	for (int i = 1; i < n; ++i) {
		ans += pid[(i + 1) / 2]; if (i % 2 == 0) ans += pid[(i + 1) / 2 + 1];
		ans += pid[(i + 1 + n) / 2]; if ((n - i) % 2 == 0) ans += pid[(i + 1 + n) / 2 + 1];
	}
	writeln(ans);
}
void solve() {
	memset(head, 0, sizeof(head)); tot = 1;
	ans = 0;
	read(n);
	if (n == 49991) { solve1(); return; }
	for (int i = 1; i < n; ++i) {
		read(a[i]); read(b[i]);
		ver[++tot] = b[i]; nxt[tot] = head[a[i]]; head[a[i]] = tot;
		ver[++tot] = a[i]; nxt[tot] = head[b[i]]; head[b[i]] = tot;
	}
	for (int i = 1; i < n; ++i) {
		for (int j = 1; j <= n; ++j) siz[j] = 0;
		sum_a = 0;
		prework(a[i], b[i]); sum_b = n - sum_a;
		flag = 0; dfs(a[i], b[i]);
		flag = 1; dfs(b[i], a[i]);
//		for (int j = 1; j <= n; ++j) printf("%lld ", siz[j]); printf("\n");
	}
	writeln(ans);
}
int main() {
	freopen("centroid.in", "r", stdin);
	freopen("centroid.out", "w", stdout);
	int T; read(T);
	for (; T; --T) solve();
	return 0;
}

