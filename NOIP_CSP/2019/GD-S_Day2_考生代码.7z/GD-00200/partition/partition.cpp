#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 5000 + 5;
template<typename T> void read(T &x) {
	x = 0; int f = 1; char c;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -f;
	for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
	x *= f;
}
template<typename T> void write(T x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}
template<typename T> void writeln(T x) { write(x); putchar('\n'); }
int n, T;
ll a[MAXN], f[MAXN][MAXN], sum[MAXN], ans = LONG_LONG_MAX;
ll tr[MAXN][MAXN];
void update(int rt, int x, ll d) {
	//tr[rt][x] = d;
	for (; x; x -= x & -x) tr[rt][x] = min(tr[rt][x], d);
}
ll query(int rt, int x) {
	ll res = 4e18;
	for (; x <= n; x += x & -x) res = min(tr[rt][x], res);
	return res;
}
int main() {
	freopen("partition.in", "r", stdin);
	freopen("partition.out", "w", stdout);
	read(n); read(T);
	for (int i = 1; i <= n; ++i) read(a[i]), sum[i] = sum[i - 1] + a[i];
	for (int i = 0; i <= n; ++i)
		for (int j = 0; j <= n; ++j) tr[i][j] = f[i][j] = 4e18;
	f[1][1] = a[1] * a[1];
	update(1, 1, f[1][1]);
	for (int i = 2; i <= n; ++i) {
		f[i][1] = sum[i] * sum[i];
		update(i, 1, f[i][1]);
		for (int j = 2; j <= i; ++j) {
			int k = lower_bound(sum + 0, sum + (j - 2) + 1, 2ll * sum[j - 1] - sum[i]) - sum + 1;
			if (k > j - 1) continue;
			f[i][j] = query(j - 1, k) + (sum[i] - sum[j - 1]) * (sum[i] - sum[j - 1]);
			update(i, j, f[i][j]);
		}
	}
	ans = query(n, 1);
	writeln(ans);
	return 0;
}

