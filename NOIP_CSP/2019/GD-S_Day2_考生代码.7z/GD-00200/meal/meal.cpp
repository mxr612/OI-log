#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAXN = 100 + 5;
const int MAXM = 2000 + 5;
const ll MOD = 998244353;
template<typename T> void read(T &x) {
	x = 0; int f = 1; char c;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -f;
	for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
	x *= f;
}
template<typename T> void write(T x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}
template<typename T> void writeln(T x) { write(x); putchar('\n'); }
int n, m;
ll ans, a[MAXN][MAXM], sum[MAXN], f[MAXN][MAXN];
int main() {
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	read(n); read(m);
	for (int i = 1; i <= n; ++i)
		for (int j = 1; j <= m; ++j) read(a[i][j]), sum[i] = (sum[i] + a[i][j]) % MOD;
	ans = 1;
	for (int i = 1; i <= n; ++i) ans = ans * ((sum[i] + 1) % MOD) % MOD;
	ans = (ans - 1 + MOD) % MOD;
//	writeln(ans);
	for (int x = 1; x <= m; ++x) {
		// f[j][k] = pick j, x pick k
		memset(f, 0, sizeof(f));
		f[0][0] = 1;
		for (int i = 1; i <= n; ++i)
			for (int j = i; j; --j)
				for (int k = j; ~k; --k) {
					f[j][k] = (f[j][k] + f[j - 1][k] * ((sum[i] - a[i][x] + MOD) % MOD) % MOD) % MOD;
					if (k) f[j][k] = (f[j][k] + f[j - 1][k - 1] * a[i][x] % MOD) % MOD;
				}
//		printf(" f for %d\n", x);
//		for (int k = 1; k <= n; ++k) {
//			for (int i = 0; i <= k; ++i) printf("%lld ", f[k][i]);
//			putchar('\n');
//		}
		for (int k = 1; k <= n; ++k)
			for (int i = k / 2 + 1; i <= k; ++i)
				ans = (ans - f[k][i] + MOD) % MOD;
	}
	writeln(ans);
	return 0;
}

