#include<iostream>
#include<cstdio>
using namespace std;
long long n,m,a[101][2001],sum[101],sumk=0,sumt=0;
long long kt[101][2001];
const int mod=998244353;
inline int read(){
	int t=1,x=0;char c=getchar();
	while('0'>c||'9'<c){if(c=='-')t=-1;c=getchar();}
	while('0'<=c&&'9'>=c){x=(x<<3)+(x<<1)+(c^48);c=getchar();}
	return t*x;
}
long long find(int x){
	if(x==n+1){
		if(sumt<2)return 0;
		bool b=0;
		for(int i=1;i<=m&&!b;i++)if((sum[i]*2)>sumk)b=1;
		if(b==0)return 1;
		return 0;
	}
	long long ansn=0,ansm=0;
	ansm=(ansm+find(x+1))%mod;
	for(int i=1;i<=m;i++)if(a[x][i]>0){
		ansn=0;
		sum[i]+=1;sumk+=1;sumt++;
		if((sum[i]*2)<=n){
			ansn=(find(x+1))%mod;ansm=(ansm+a[x][i]*ansn)%mod;
		}
		sum[i]-=1;sumk-=1;sumt--;
	}
	return ansm%mod;
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)a[i][j]=read();
	cout<<find(1)<<endl;
	return 0;
}
