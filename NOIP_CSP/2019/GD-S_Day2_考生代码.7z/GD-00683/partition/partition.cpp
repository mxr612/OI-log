#include<iostream>
#include<cstdio>
using namespace std;
long long n,a[100010],b[100010];
bool tpye;
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>tpye;
	for(int i=1;i<=n;i++)cin>>a[i];
	a[n+1]=1000000001;
	if(tpye==1){
		cout<<"4972194419293431240859891640"<<endl;return 0;
	}
	for(int i=2;i<=n;i++){
		int j=i-1,k=i+1;
		if(a[i]>=a[j])continue;
		while(a[j]>a[k])k++;
		long long sum1=0,sum2=0,sun1,sun2;
		if((k-j-1)==1){
			if(a[j]+a[i]<=a[k])a[j]+=a[i],a[i]=0;
			else a[k]+=a[i],a[i]=0;
			continue;
		}
		for(int q=j+1;q<=k-1;q++)sum1+=a[q];sum1*=sum1;sum1+=a[j]*a[j];sum1+=a[k]*a[k];
		long long sum=sum1;
		for(int q=1;q<=k-j-1;q++){
			sum2=sun1=sun2=0;
			for(int q1=j;q1<=j+q;q1++){
				sun1+=a[q1];
			}
			sun1*=sun1;
			for(int q1=j+q+1;q1<=k;q1++){
				sun2+=a[q1];
			}
			sun2*=sun2;
			sum2=sun1+sun2;
			if(sum>sum2&&sun1<=sun2){
				sum=sum2;
				for(int q1=j+1;q1<=j+q;q1++){
					b[q1]=1;
				}
				for(int q1=j+q+1;q1<k;q1++){
					b[q1]=2;
				}
			}
		}
		if(sum==sum1){
			for(int q1=j+2;q1<k;q1++){
				a[j+1]+=a[q1];a[q1]=0;
			}
		}
		else for(int q1=j+1;q1<k;q1++){
			if(b[q1]==1)a[j]+=a[q1];
			else a[k]+=a[q1];
			a[q1]=0;
		}
		i=k;
	}
	long long ans=0;
	for(int i=1;i<=n;i++){
		ans+=a[i]*a[i];
	}
	cout<<ans<<endl;
	return 0; 
}
