#include<iostream>
#include<cstdio>
using namespace std;
long long t,n;
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	cin>>t;
	for(int i=1;i<=t;i++){
		cin>>n;
		int a,b;
		for(int i=1;i<n;i++){
			cin>>a>>b;
		}
		cout<<t*n<<endl;
	}
	return 0;
}
