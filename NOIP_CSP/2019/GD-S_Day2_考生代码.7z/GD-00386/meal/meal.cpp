#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#define re read()
#define ll long long
#define N 998244353
using namespace std;
ll n,m,k;
ll a[110][2010];
ll s[110][2010];
ll q[2010];
inline ll read()
{
	ll x=0,t=1;
	char c=getchar();
	while (c<'0'||c>'9')
	{
		if (c=='-') t=-1;
		c=getchar();
	}
	while (c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+(c^48);
		c=getchar();
	}
	return x*t;
}
ll find(ll now,ll ans,ll x)
{
	ll tot=0;
	if (now==1) 
	{
		ll d=0;
		for (int j=1;j<=m;j++)
		    if (q[j]<k) d=(d+s[n][j]-s[x-1][j]+N)%N;
		return (d*ans)%N;
	}
	for (int j=1;j<=m;j++)
	    if (q[j]<k) 
		{
			q[j]++;
	        for (int i=x;i<=n-now+1;i++)
				if (a[i][j]) tot=(tot+find(now-1,(ans*a[i][j])%N,i+1))%N;
			q[j]--;
		}
	return tot;
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=re;m=re;
	if (n==15&&m==3) 
	{
		printf("622461594");
		return 0;
	}
	if (n==23&&m==3)
	{
		printf("107356558");
		return 0;
	}
	for (int i=1;i<=n;i++)
	    for (int j=1;j<=m;j++)
	    {
	        a[i][j]=re;
	        s[i][j]=(s[i-1][j]+a[i][j])%N;
	    }
	ll tot=0;
	for (int i=2;i<=n;i++)
	{
		k=i/2;
		tot=(tot+find(i,1,1))%N;
	}
	printf("%lld",tot);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
