#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
const long long mod=998244353;
long long n,m,a[105][2005],record[2005],visit[2005],ans=0,f[45][45][45],g[45][45][45][45];
void DFS(long long k,long long x)
{
	if (k>n)
	  {
	  	if (x==0) return;
	  	bool tf=true;
	  	for (long long i=1;i<=m;i++)
	  	  if (record[i]>x/2) {tf=false;break;}
	  	if (tf) 
	  	  {
	  	  	long long sum=1;
	  	  	for (long long i=1;i<=n;i++)
	  	  	  sum=(sum*a[i][visit[i]])%mod;
	  	  	ans=(ans+sum)%mod;
	  	  }
	  	return;
	  }
	DFS(k+1,x);
	for (long long i=1;i<=m;i++)
	  {
	  	if (a[k][i])
	  	  {
	  	  	visit[k]=i;
	  	  	record[i]++;
	  	  	DFS(k+1,x+1);
	  	  	visit[k]=0;
	  	  	record[i]--;
	  	  }
	  }
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for (long long i=1;i<=n;i++)
	  for (long long j=1;j<=m;j++)
		scanf("%lld",&a[i][j]);
	if (n<=10)
	  {
	
		for (long long i=1;i<=n;i++) a[i][0]=1;
		DFS(1,0);
		printf("%lld",ans);
	  }
	else if (m==2)
	  {
	  	f[0][0][0]=1;
	  	for (long long i=1;i<=n;i++)
	  	  {
	  	  	f[i][0][0]=1;
	  	  	for (long long a1=0;a1<=n;a1++)
	  	  	  for (long long a2=0;a2<=n;a2++)
	  	  	    {
	  	  	    	if (a1==0&&a2==0) continue;
	  	  	    	if (a1+a2>i) break;
	  	  	    	f[i][a1][a2]=f[i-1][a1][a2];
	  	  	    	if (a1>0) f[i][a1][a2]+=f[i-1][a1-1][a2]*a[i][1]%mod;
	  	  	    	if (a2>0) f[i][a1][a2]+=f[i-1][a1][a2-1]*a[i][2]%mod;
	  	  	    }
	  	  }
	  	long long ans1=0;
	  	for (long long i=0;i<=n;i++)
	  	  for (long long j=0;j<=n;j++)
	  	    {
	  	    	if (i==0&&j==0) continue;
	  	    	if (i+j>n) break;
	  	    	if (i!=j) continue;
	  	    	ans1+=f[n][i][j];
	  	    }
	  	cout<<ans1;
	  }
	else if (m==3)
	  {
	  	g[0][0][0][0]=1;
	  	for (long long i=1;i<=n;i++)
	  	  {
	  	  	g[i][0][0][0]=1;
	  	  	for (long long a1=0;a1<=n;a1++)
	  	  	  for (long long a2=0;a2<=n;a2++)
	  	  	    for (long long a3=0;a3<=n;a3++)
	  	  	      {
	  	  	      	if (a1+a2+a3>i) break;
	  	  	      	if (a1==0&&a2==0&&a3==0) continue;
	  	  	      	g[i][a1][a2][a3]=g[i-1][a1][a2][a3];
	  	  	      	if (a1>0) g[i][a1][a2][a3]+=g[i-1][a1-1][a2][a3]*a[i][1]%mod;
	  	  	      	if (a2>0) g[i][a1][a2][a3]+=g[i-1][a1][a2-1][a3]*a[i][2]%mod;
					if (a3>0) g[i][a1][a2][a3]+=g[i-1][a1][a2][a3-1]*a[i][3]%mod;
	  	  	      }
	  	  }
	  	long long ans1=0;
	  	for (long long i=1;i<=n;i++)
	  	  for (long long j=1;j<=n;j++)
	  	    for (long long k=1;k<=n;k++)
	  	      {
	  	      	if (i+j+k>n) break;
	  	      	long long x=i+j+k;
	  	      	if (i>x/2||j>x/2||k>x/2) continue;
	  	      	ans1=(ans1+g[n][i][j][k])%mod;
	  	      }
	  	cout<<ans1;
	  }
	return 0;
}
