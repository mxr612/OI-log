#include<cstdio>
#include<algorithm>
#include<iostream>
#include<cstring>
using namespace std;
const long long inf=4000000000000000000LL;
long long n,type,num[5005],ans[5005][5005];
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	if (type==1) {cout<<n;return 0;}
	for (long long i=1;i<=n;i++) scanf("%d",&num[i]);
	for (long long i=1;i<=n;i++)
	  for (long long j=1;j<=n;j++)
	    ans[i][j]=inf;
	for (long long i=1;i<=n;i++)
	  {
	  	long long sum=0;
	  	for (long long j=i;j>=1;j--)
	  	  {
	  	  	sum+=num[j];
	  	  	long long sum1=0;
	  	  	for (long long k=j-1;k>=0;k--)
	  	  	  {
	  	  	  	sum1+=num[k];
	  	  	  	if (sum1>sum) break;
	  	  	  	if (ans[j-1][k]!=inf) {ans[i][j]=min(ans[i][j],ans[j-1][k]+sum*sum);break;}
	  	  	  }
	  	  	if (ans[i][j]!=inf) break;
	  	  }
	  }
	long long ans1=inf;
	for (long long i=1;i<=n;i++)
	  ans1=min(ans1,ans[n][i]);
	cout<<ans1;
	return 0;
}
