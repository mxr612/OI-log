#include<iostream>
#include<stdio.h>
using namespace std;

int n,m;
int num[500000];

int Read()
{
	char ch='?';
	int ans=0;
	while (ch<'0'||ch>'9')
		ch=getchar();
	while (ch>='0'&&ch<='9')
	{
		ans=ans*10+ch-'0';
		ch=getchar();
	}
	return ans;
}

long long min(long long a,long long b)
{
	return a<b?a:b;
}

long long solve(int step,int last,long long sum)
{
	int i;
	if (step==n)
	{
		return sum;
	}
	if (num[step]<last)
	{
		long long a,b;
		long long tmpsum=0;
		a=solve(step+1,last+num[step],sum-(last*last)+(last+num[step])*(last+num[step]));
		bool flag=false;
		for (i=step;i<n;i++)
		{
			tmpsum+=num[i];
			if (tmpsum>last)
			{
				flag=true;
				break;
			}
		}
		if (flag)
		{
			b=solve(i+1,tmpsum,sum+tmpsum*tmpsum);
			return min(a,b);
		}
		return a;
	}
	else
	{
		return solve(step+1,num[step],sum+num[step]*num[step]);
	}
}

int main()
{
	int i;
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	
	n=Read(),m=Read();
	for (i=0;i<n;i++)
		num[i]=Read();
		
	cout<<solve(1,num[0],num[0]*num[0])<<endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
