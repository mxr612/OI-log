#include<iostream>
#include<stdio.h>
#include<algorithm>
using namespace std;

int map[110][2100];
bool xselected[110]= {0};
int xrecord[100];//��¼��ֱ������ѡ�����ļ��У�id�� 
int yrecord[100];//��¼��ÿѡ��ĺ���ѡ���˵ڼ��� 
int ycount[100];//��¼ÿ��ʳ�ĵ�ʹ�ô��� 
int n,m;
long long ans;

int Read()
{
	char ch='?';
	int ans=0;
	while (ch<'0'||ch>'9')
		ch=getchar();
	while (ch>='0'&&ch<='9')
	{
		ans=ans*10+ch-'0';
		ch=getchar();
	}
	return ans;
}

void solve2(int xid,int mc)//xid=ѡ��ĵڼ��У�mc=�Ѿ�ѡ����� 
{
	int i,j;
	if (xid==mc)
	{
		long long sum=1;
		for (i=0;i<mc;i++)
			sum=(sum*map[xrecord[i]][yrecord[i]])%998244353;
		//for (i=0;i<mc;i++)
		//	cout<<yrecord[i]<<" ";
		//cout<<":"<<sum<<endl;
		ans=(ans+sum)%998244353;
		return;
	}
	for (i=0;i<m;i++)
	{
		int x=xrecord[xid];
		if (map[x][i]==0)
			continue;
		if (ycount[i]+1<=mc/2)
		{
			ycount[i]++;
			yrecord[xid]=i;
			solve2(xid+1,mc);
			ycount[i]--;
		}
	}
}

void solve1(int pos,int count,int mc)//�ڼ���λ�ã��Ѿ�ѡ���������Ҫѡ������ 
{
	int i;
	if (count==mc)
	{
		//cout<<mc<<"xrecord:";
		//for (i=0;i<mc;i++)
		//	cout<<xrecord[i]<<" ";
		//cout<<endl;
		solve2(0,mc);
		return;
	}
	if (pos==n)
	{
		return;
	}
	xselected[pos]=1;
	xrecord[count]=pos;
	solve1(pos+1,count+1,mc);
	xselected[pos]=0;
	solve1(pos+1,count,mc);
}

bool cmp(pair <int,int> a,pair <int,int> b)
{
	return a.first>b.first;
}

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);

	int i,j,k;

	n=Read(),m=Read();
	
	for (i=0; i<n; i++)
	{
		for (j=0; j<m; j++)
			map[i][j]=Read();
		//sort(map[i],map[i]+m,cmp);
	}
	int mid=n/2;
	for (i=1; i<=n; i++)
	{
		solve1(0,0,i);
	}
	cout<<ans%998244353<<endl;

	fclose(stdin);
	fclose(stdout);
	return 0;
}
