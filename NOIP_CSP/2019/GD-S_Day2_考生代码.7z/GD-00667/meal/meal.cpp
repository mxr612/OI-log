#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int N=110;
const int M=2010;
const int mod=998244353;

inline void read(int &x) {
	x=0;
	int f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if (ch=='-') {
			f=-1;
		}
		ch=getchar();
	}
	while(ch<='9'&&ch>='0') {
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=f;
}

int a[N][M];
int s[N];//第i中烹饪方法的菜数为s[i]
int n,m;
int ans;

//返回做x道菜的方案数 要求O(nm)
inline int solve(int x) {
	int res=0;
	for(int i=1;i<n;i++) {
		for(int j=i+1;j<=n;j++) {
			for(int k=1;k<=m;k++) {
				res+=a[i][k]*(s[j]-a[j][k]);
				res%=mod;
			}
		}
	}
	return res;
}

inline int solve2(int x) {
	int res=0;
	for(int i=1;i<n-1;i++) {
		for(int j=i+1;j<n;j++) {
			for(int k=j+1;k<=n;k++) {
				for(int u=1;u<=m;u++) {
					for(int p=1;p<=m;p++) {
						if (u!=p) {
							res=(1ll*a[i][u]*a[j][p]*(0ll+s[k]-a[k][u]-a[k][p]))%mod;
						}
					}
				}
			}
		}
	}
	return res;
}

int main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	read(n),read(m);
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=m;j++) {
			read(a[i][j]);
			s[i]+=a[i][j];
		}
		// printf("%d\n",s[i]);
	}
	if (n==2) {
		for(int i=2;i<=n;i++) {
			ans+=solve(i);
			ans%=mod;
		}
		printf("%d\n",ans);
	}
	return 0;
}
