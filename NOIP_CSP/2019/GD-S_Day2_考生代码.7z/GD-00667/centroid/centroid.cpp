#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int N=300000;

inline void read(int &x) {
	x=0;
	int f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if (ch=='-') {
			f=-1;
		}
		ch=getchar();
	}
	while(ch<='9'&&ch>='0') {
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=f;
}

struct note {
	int t;
	int next;
	int val;
};

int head[N];
int cnt;
note e[N<<1];
int n;

inline void add(int x,int y,int val) {
	e[++cnt].t=y;
	e[cnt].next=head[x];
	e[cnt].val=val;
	head[x]=cnt;
}


struct data {
	int x,y;
};

data a[N];
int siz[N];
int is[N];
int del;

inline void init() {
	memset(head,-1,sizeof(head));
	cnt=0;
	memset(e,0,sizeof(e));
}

void dfs(int p,int fa) {
	siz[p]=1;
	for(int i=head[p];i+1;i=e[i].next) {
		int t=e[i].t;
		if (t==fa) {
			continue;
		}
		if (e[i].val==del) {
			continue;
		}
		dfs(t,p);
		siz[p]+=siz[t];
	}
	return;
}

void dfs1(int p,int fa,int on) {
	is[p]=1;
	if (on-siz[p]>(on>>1)) {
		is[p]=0;
	}
	for(int i=head[p];i+1;i=e[i].next) {
		int t=e[i].t;
		if (t==fa) {
			continue;
		}
		if (e[i].val==del) {
			continue;
		}
		dfs1(t,p,on);
		if (siz[t]>(on>>1)) {
			is[p]=0;
		}
	}
}

inline void solve1() {
	int ans=0;
	for(int i=1;i<n;i++) {
		memset(is,0,sizeof(is));
		del=i;
		dfs(a[i].x,-1);
		dfs(a[i].y,-1);
		int siz1=siz[a[i].x],siz2=siz[a[i].y];
		dfs1(a[i].x,-1,siz1);
		dfs1(a[i].y,-1,siz2);
		for(int j=1;j<=n;j++) {
			if (is[j]) {
				ans+=j;
				// printf("del:%d %d ans:%d\n",a[i].x,a[i].y,j);
			}
			// printf("siz[%d]:%d\n",j,siz[j]);
		}
	}
	printf("%d\n",ans);
}

inline void solve2() {
	int ans=0;
}

int main() {
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int t;
	read(t);
	while(t--) {
		init();
		read(n);
		for(int i=1;i<n;i++) {
			int x,y;
			read(x),read(y);
			add(x,y,i);
			add(y,x,i);
			a[i].x=x;
			a[i].y=y;
		}
		solve1();
	}
	return 0;
}