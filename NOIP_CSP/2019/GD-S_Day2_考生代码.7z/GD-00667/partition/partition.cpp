#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define int long long
using namespace std;

const int N=4e7+10;

inline void read(int &x) {
	x=0;
	int f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		if (ch=='-') {
			f=-1;
		}
		ch=getchar();
	}
	while(ch<='9'&&ch>='0') {
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=f;
}

int n;
int a[N];
int ans=9223372036854775807LL;

void dfs(int p,int sum,int last) {
	if (p>n) {
		ans=min(ans,sum);
		return;
	}
	int res=0;
	for(int i=p;i<=n;i++) {
		res+=a[i];
		if (res<last) {
			continue;
		}
		dfs(i+1,sum+res*res,res);
	}
}

signed main() {
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int type;
	read(n),read(type);
	for(int i=1;i<=n;i++) {
		read(a[i]);
	}
	dfs(1,0,-1);
	printf("%lld\n",ans);
	return 0;
}