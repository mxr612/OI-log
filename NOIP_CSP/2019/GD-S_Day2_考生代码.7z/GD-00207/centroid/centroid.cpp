#include<cstdio>
using namespace std;
struct node{
	int fa,son;
}nd[100000];
int ka[100000],kb[100000];
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T,n;
	scanf("%d",&T);
	while(T){
		scanf("%d",&n);
		for(int i=1;i<n;i++){
			scanf("%d%d",&a,&b);
			ka[i]=a;kb[i]=b;
			nd[a].son=b;
			nd[b].fa=a;
		}
		for(int i=1;i<n;i++){
			//buhuile !!
			//��û��
			//�������� 
			//����
			
		}
	printf("%d",nd[8].fa); 
	}
	return 0;
}
