#include<cstdio>
#include<iostream>
using namespace std;
#define ull unsigned long long
ull n,t=0,ans=0,a[1000000],d[1000000];
int main(){
	int type;
	freopen("partition.in","r",stdin);
	freopen("partition,out","w",stdout);
	scanf("%llu%d",&n,&type);
	if(type==0){
		for(int i=1;i<=n;i++)
			scanf("%llu",&a[i]);
		for(int i=1;i<=n;i++){
//			printf("%llu\n",t);
			if(a[i]>=t){
				ans+=t*t;
				t=a[i];
			}
			else{
				if(a[i]+t>a[i+1]&&a[i+1]){
					ans+=t*t;
					t=a[i]+a[i+1];i++;
				}
				else t+=a[i];
			}
		}
	}
	ans+=t*t;
	printf("%llu",ans);
	return 0;
}
