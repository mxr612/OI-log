#include<bits/stdc++.h>
using namespace std;
int n,m,i,j,k,T,ans;
struct AB
{
	int a,b,c,n;
}d[50005*2];
int h[50005],du[50005],l[50005],p[50005];

void dfs(int x,int fa,int num)
{
	p[num]=x;
	int b,i;
	for(i=h[x];i;i=d[i].n)
	{
		b=d[i].b;
		if(b==fa)continue;
		l[x]=b;
		dfs(b,x,num+1);
	}
}

int main()
{
	freopen("centroid.in","r",sdtin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		ans=0;
		memset(d,0,sizeof(d));
		memset(p,0,sizeof(p));
		memset(h,0,sizeof(h));
		memset(du,0,sizeof(du));
		memset(l,0,sizeof(l));
		scanf("%d",&n);
		for(i=1;i<n;i++)
		{
			int a,b;
			scanf("%d%d",&a,&b);
			du[a]++,du[b]++;
			d[i].a=a,d[i].b=b,d[i].n=h[a],h[a]=i;
			d[i+n-1].a=b,d[i+n-1].b=a,d[i+n-1].n=h[b],h[b]=i+n-1;
		}
		for(i=1;i<=n;i++)
		{
			if(du[i]==1)
			{
				k=i;
				break;
			}
		}
		dfs(k,0,1);
		for(i=1;i<n;i++)
		{
			if((i)%2==1)
			{
				ans+=p[(i/2+1)];
			}
			else
			ans+=p[i/2]+p[i/2+1];
			if((n-i)%2==1)
			ans+=p[i+(n-i)/2+1];
			else ans+=p[i+(n-i)/2]+p[i+(n-i)/2+1];
		}
		printf("%d",ans);
	}
	return 0;
}
