#include<bits/stdc++.h>
using namespace std;

int n,m,i,j,k,x,y,z,b1,b2;
const int MAXN=5005;
long long a[MAXN],b[MAXN];
long long ans=4*1e18+4;

void dfs(int i,int j,long long sum)
{
//	printf("(%d,%d)\n",i,j);
	if(b[j]<b[j-1])return;
	long long now=sum;
	if(sum>ans)return;
	if(i==n+1)
	{
//		printf("=%lld\n",sum);
		ans=min(ans,sum);
	}
	if(i>n)return;
	if(b[j]>a[i])
	{
		now=sum-b[j]*b[j];
		b[j]+=a[i];
		dfs(i+1,j,now+b[j]*b[j]);
		b[j]-=a[i];
		int jj=i,tmp=0;
		while(tmp<b[j]&&jj<=n)tmp+=a[jj++];
		b[j+1]=tmp;
		dfs(jj,j+1,sum+b[j+1]*b[j+1]);
	}
	else
	{
		b[j+1]=a[i];
		dfs(i+1,j+1,sum+b[j+1]*b[j+1]);
	}
}

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&k);
	if(k==0)
	{
		for(i=1;i<=n;i++)
		{
			scanf("%lld",a+i);
		}
		b[0]=a[1];
		dfs(1,0,0);
		printf("%lld",ans);
	}
	return 0;
}
