#include<bits/stdc++.h>
using namespace std;

int n,m,i,j,k,ans=0;
const int mo= 998244353,MAXN=105,MAXM=1005;
int a[MAXN][MAXM],f[MAXM],u[MAXN];

void solve1()
{
//	for(i=1;i<=n;i++)ans+=a[i][1]+a[i][2],ans%=mo;
	for(i=1;i<=n;i++)
	for(j=1;j<=n;j++)
	if(i!=j)
	ans=(a[i][1]*a[j][2]%mo)+ans,ans%=mo;
}

void solve2()
{
//	for(i=1;i<=n;i++)ans+=a[i][1]+a[i][2]+a[i][3],ans%=mo;
	for(i=1;i<=n;i++)
	for(j=1;j<=n;j++)
	if(i!=j)
	ans+=(a[i][1]*a[j][2]%mo)+(a[i][2]*a[j][3]%mo)+(a[i][1]*a[j][3]%mo),ans%=mo;
	for(i=1;i<=n;i++)
	for(j=1;j<=n;j++)
	for(k=1;k<=n;k++)
	if(i!=j&&j!=k&&k!=i)
	ans+=a[i][1]*a[j][2]*a[k][3]%mo,ans%=mo;
}

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=m;j++)
		scanf("%d",a[i]+j);
		a[i][0]=1;
	}
	if(m==2)solve1();
	else if(m==3)solve2();
	printf("%d",ans);
	return 0;
}
