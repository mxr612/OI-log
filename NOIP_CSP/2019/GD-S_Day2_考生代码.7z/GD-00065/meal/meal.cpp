#include<iostream>
#include<cstdio>
using namespace std;
const int mod=998244353;
int n,m,a[101][2001],ans,vis[5];
void dfs(int x,int lans)
{
	if(x>n) return;
	int llans=lans*a[x][1]%mod,sum=(vis[1]+vis[2]+vis[3]+1)/2;
	vis[1]++;
	if(max(vis[1],max(vis[2],vis[3]))<=sum) ans=(ans+llans)%mod;
	dfs(x+1,llans);
	vis[1]--;
	llans=lans*a[x][2]%mod;
	vis[2]++;
	if(max(vis[1],max(vis[2],vis[3]))<=sum) ans=(ans+llans)%mod;
	dfs(x+1,llans);
	vis[2]--;
	llans=lans*a[x][3]%mod;
	vis[3]++;
	if(max(vis[1],max(vis[2],vis[3]))<=sum) ans=(ans+llans)%mod;
	dfs(x+1,llans);
	vis[3]--;
	dfs(x+1,lans);
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&a[i][j]);
	dfs(1,1);
	cout<<ans<<endl;
	return 0;
}
