#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
long long n,a[500100],type,ans=9000000000000000000;
void dfs(int x,long long lans,long long t,long long c)
{
	if(lans>ans) return;
	if(x>n)
	{
		if(!c||c>t) ans=min(lans+c*c,ans);
		return;
	}
	c+=a[x];
	if(c>=t) dfs(x+1,lans+c*c,c,0);
	dfs(x+1,lans,t,c);
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>type;
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	dfs(1,0,0,0);
	cout<<ans<<endl;
	return 0;
}
