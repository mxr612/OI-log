#include<bits/stdc++.h>
#define il inline
#define ri register int
#define go(i,a,b) for(ri i(a);i<=(b);++i)
using namespace std;
typedef long long ll;
const int N=5e5+7;
template<class T>il T& read(T& a) {
	char c;while(!isdigit(c=getchar()));
	for(a=c^48;isdigit(c=getchar());a=a*10+(c^48));
	return a;
}
int n,type,a[N],k[N];ll s[N],ans;
il ll check(ll st) {
	ll pre=0,sum=0,psum=0,res=0;
	for(ri i=1;i<=n;++i) {
		if((st&(1<<(i-1))) || i==n) {
			sum=s[i]-s[pre];
			if(sum<psum) return ans;
			res+=sum*sum;pre=i;psum=sum;
		}
	}
	return res;
}
int main() {
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	read(n),read(type);
	go(i,1,n) s[i]=s[i-1]+read(a[i]);
	ans=s[n]*s[n];
	if(n<=10) for(ll st=1;st<(1ll<<n);++st) ans=min(ans,check(st));
	
	cout<<ans;
	return 0;
}

