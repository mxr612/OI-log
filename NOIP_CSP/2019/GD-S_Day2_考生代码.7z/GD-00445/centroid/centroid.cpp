#include<bits/stdc++.h>
#define il inline
#define ri register int
#define go(i,a,b) for(ri i(a);i<=(b);++i)
using namespace std;
typedef long long ll;
const int N=2007;
template<class T>il T& read(T& a) {
	char c;while(!isdigit(c=getchar()));
	for(a=c^48;isdigit(c=getchar());a=a*10+(c^48));
	return a;
}
int n,sz[N],dep[N],u,v;ll ans,c1,c2;
struct edge{int st,ed,nxt;}e[N<<1];int tot,head[N];
il void add(ri u,ri v) {e[++tot]=(edge){u,v,head[u]},head[u]=tot;}
il void dfs(ri x,ri fa) {
	sz[x]=1;dep[x]=dep[fa]+1;
	for(ri i=head[x],y;y=e[i].ed,i;i=e[i].nxt) if(y^fa) dfs(y,x),sz[x]+=sz[y];
}
//il void dfs0(ri x,ri fa) {
//	for(ri i=head[x],y;y=e[i].ed,i;i=e[i].nxt) if(y^fa) dfs0(y,x);
//}
//il int getsz(ri x,ri side,ri dir) {
//	if(side==u) {
//		if(!dir) return sz[x];
//		else return sz[u]-sz[x]+1;
//	}else {
//		if(!dir) return sz[x];
//		else if(dep[x]<dep[v]) return n-sz[fa[x] 
//	}
//}
//il void dfs2(ri x,ri fa) {
//	if(c1 || c2) return;
//	ri flag=1;
//	for(ri i=head[x],y;y=e[i].ed,i && flag;i=e[i].nxt) if(y^fa) {
//		ri tmp=getsz(y,u,0);
//		if(tmp*2>sz[u])
//			flag=0,dfs2(y,x);
//		else if(tmp*2==sz[u]) {c1=x,c2=y;return;}
//		if(c1 || c2) return;
//	}
//	if(flag) c1=x;
//}
//il void dfs3(ri x,ri fa) {
//	if(c1 || c2) return;
//	ri flag=1;
//	for(ri i=head[x],y;y=e[i].ed,i && flag;i=e[i].nxt) if(y^fa) {
//		if(dep[y]>dep[x]) {
//			ri tmp=getsz(y,v,0);
//			if(tmp*2>n-sz[u])
//				flag=0,dfs3(y,x);
//			else if(tmp*2==n-sz[u]) {c1=x,c2=y;return;}
//		}else {
//			ri tmp=getsz(y,v,1);
//			if(tmp*2>n-sz[u])
//				flag=0,dfs3(y,x);
//			else if(tmp*2==n-sz[u]) {c1=x,c2=y;return;}
//		}
//		if(c1 || c2) return;
//	}
//	if(flag) c1=x;
//}
int main() {
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	for(ri T=read(T);T--;) {
		read(n);ri x,y;ans=0;ri fl=1;
		go(i,2,n) read(x),read(y),add(x,y),add(y,x),fl&=(abs(x-y)==1);
//		dfs(1,1);
//		go(i,1,n-1) {
//			u=e[i*2-1].ed,v=e[i*2].ed;
//			if(dep[u]<dep[v]) swap(u,v);
//			c1=c2=0;dfs2(u,v);
//			ans+=c1+c2;
//			c1=c2=0;dfs3(v,u);
//			ans+=c1+c2;
//		}
		if(fl) {
			go(i,1,n-1) {
				if(i&1) ans+=((i+1)>>1);
				else ans+=i+1;
				if((n-i)&1) ans+=(n-i+1)>>1;
				else ans+=n+i-1;
			}
		}
		cout<<ans<<'\n';
		memset(head+1,0,n*4);
		memset(e+1,0,sizeof(*e)*tot);tot=0;
	}
	return 0;
}
