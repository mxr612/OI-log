#include<bits/stdc++.h>
#define il inline
#define ri register int
#define go(i,a,b) for(ri i(a);i<=(b);++i)
using namespace std;
typedef long long ll;
const int N=107,M=2007,p=998244353;
template<class T>il T& read(T& a) {
	char c;while(!isdigit(c=getchar()));
	for(a=c^48;isdigit(c=getchar());a=a*10+(c^48));
	return a;
}
int n,m,k,a[N][M],st;int vis[N][N],used[N],cnt;
ll ans;
il int count(ri x) {ri r=0;for(;x;x-=x&-x,++r);return r;}
il void dfs(ri x) {
	if(x>n || cnt>=k) {
		if(++ans>=p) ans-=p;
		return;
	}
	if(!(st&(1<<(x-1)))) {dfs(x+1);return;}
	go(i,1,m) if(a[x][i] && !vis[x][i] && (used[i]*2+2)<=k) {
		vis[x][i]=1;++used[i];++cnt;
		dfs(x+1);
		vis[x][i]=0;--used[i];--cnt;
	}
}
int main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	read(n),read(m);bool fl1=1;
	go(i,1,n) go(j,1,m) fl1&=(1>=read(a[i][j]));
	if(fl1) {
		for(st=3;st<(1<<n);++st)
			if((k=count(st))>=2) {
				dfs(1);cnt=0;
				memset(used+1,0,m*4);
				memset(vis,0,sizeof(vis));
			} 
		cout<<(ans%p+p)%p;
	}
	return 0;
}
