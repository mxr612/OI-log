//@HelloElwin-20191117
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
typedef unsigned long long ull;
ull n, ans, a[40000005], S[40000005];
int spt, type;

void Dfs(int dep) {
//	cerr<<dep<<": ";
//	for (int i = 0; i < spt; i++) printf("%lld ", S[i]);
//	cerr<<endl;
	if (dep == n + 1) {
		ull sum = 0;
		for (int i = 0; i < spt; i++) sum += S[i] * S[i];
		ans = min(ans, sum); 
//		cerr<<"["<<sum<<"]"<<endl;
		return;
	}
	ull la = S[spt - 1];
	if (a[dep] >= la) {
		S[spt++] = a[dep];
		Dfs(dep + 1);
		spt--;
	} else {
		ull t = S[spt - 1];
		S[spt - 1] += a[dep];
		Dfs(dep + 1);
		S[spt - 1] = t;
		if (dep == n) return;
		t = a[dep + 1];
		a[dep + 1] += a[dep];
		Dfs(dep + 1);
		a[dep + 1] = t;	
	}
}

int main () {
	freopen("partition.in", "r", stdin);
	freopen("partition.out", "w", stdout);
	
	ans = 5000000000000000000;
	
	scanf("%lld %d", &n, &type);
	for (int i = 1; i <= n; i++) scanf("%lld", a + i);
	
	a[n + 1] = 2e11;
	S[spt++] = a[1];
	
	if (n <= 10) {
		Dfs(2);
		printf("%lld", ans);
		return 0;
	}
	
	for (int i = 2; i <= n; i++) {
		ull la = S[spt - 1];
		if (a[i] >= la) {
			S[spt++] = a[i];
		} else {
			if (la <= a[i + 1]) {
				S[spt - 1] += a[i];
			} else {
				a[i + 1] += a[i];
			}
		}
	}
	
	ans = 0; 
	
	for (int i = 0; i < spt; i++) ans += S[i] * S[i];
	
	printf("%lld", ans);
	
	return 0;
}
