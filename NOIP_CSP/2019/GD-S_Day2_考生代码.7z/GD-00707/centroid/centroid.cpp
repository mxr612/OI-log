//@HelloElwin-20191117
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
int T, n, ghd, hd[300005];
int ans1, ans2, ans;
bool used[600005], vis[300005];
int sz[300005];

struct Edge {
	int u, v, nxt;
}g[600005];

void AddEdge (int u, int v) {
	g[ghd] = (Edge){u, v, hd[u]};
	hd[u] = ghd++;
}

void Pre (int u) {
	sz[u] = 1;
	vis[u] = true;
	for (int i = hd[u]; ~i; i = g[i].nxt) {
		int v = g[i].v;
		if (vis[v] || used[i]) continue;
		else Pre(v);
		sz[u] += sz[v];
	}
}

void Dfs (int u, int nn) {
	vis[u] = true;
	bool flg = true;
	for (int i = hd[u]; ~i; i = g[i].nxt) {
		int v = g[i].v;
		if (used[i]) continue;
		if (sz[v] > nn / 2) { flg = false; break; }
	}
	if (flg) {
//		printf("[%d %d]", ans1, u);
		if (ans1 == 0) ans1 = u;
		else ans2 = u;	
	}
	for (int i = hd[u]; ~i; i = g[i].nxt) {
		int v = g[i].v;
		if (vis[v] || used[i]) continue;
		int su = sz[u], sv = sz[v];
		sz[v] = su; sz[u] = su - sv;
		Dfs(v, nn);
		sz[u] = su, sz[v] = sv;	
	}
}

int main() {
	freopen("centroid.in", "r", stdin);
	freopen("centroid.out","w",stdout);
	
	scanf("%d", &T);
	
	while (T--) {

		memset(sz, 0, sizeof(sz)); ans = 0;
		memset(used,0,sizeof(used));
		memset(hd, -1, sizeof(hd)); ghd = 0;
		
		scanf("%d", &n);
		for (int i = 1; i < n; i++) {
			int x, y;
			scanf("%d %d", &x, &y);
			AddEdge(x, y);
			AddEdge(y, x);
		}
		
		for (int i = 0; i < n - 1; i++) {
			memset(vis, 0, sizeof(vis));
			ans1 = ans2 = 0;
			used[i * 2] = used[(i * 2) ^ 1] = true;
			int u = g[i * 2].u, v = g[i * 2].v;
			Pre(u); memset(vis, 0, sizeof(vis)); Dfs(u, sz[u]); ans += ans1 + ans2;
//			printf("%d %d %d %d %d - ", u, v, u, ans1, ans2);
			ans1 = ans2 = 0; memset(vis, 0, sizeof(vis));
			Pre(v); memset(vis, 0, sizeof(vis)); Dfs(v, sz[v]); ans += ans1 + ans2;
//			printf("%d %d %d %d %d\n", u, v, v, ans1, ans2);
			used[i * 2] = used[(i * 2) ^ 1] = false;
		}
		
		printf("%d\n", ans);
		
	}
	
	return 0;
}
