//@HelloElwin-20191117
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
int n, m, a[105][2005];
long long ans = 0;
int cnt[2005];

void Dfs (int dep, long long sum, long long dish) {
//	cerr<<dep<<" "<<sum<<" "<<dish<<endl;
	if (dep == n) {
		if (dish <= 1) return;
		for (int i = 0; i < m; i++) if (cnt[i] > dish / 2) return;
		ans += sum;
		return;
	}
	Dfs(dep + 1, sum, dish);
	for (int i = 0; i < m; i++) {
		if (a[dep][i] == 0) continue;
		cnt[i]++;
		Dfs(dep + 1, sum * a[dep][i], dish + 1);
		cnt[i]--;
	}
}

int main() {
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	
	scanf("%d %d", &n, &m);
	
	for (int i = 0; i < n; i++)
		for (int j = 0; j < m; j++)
			scanf("%d", &a[i][j]);
	
	Dfs(0, 1, 0);
	
	cout<<ans;
	
	return 0;
}
