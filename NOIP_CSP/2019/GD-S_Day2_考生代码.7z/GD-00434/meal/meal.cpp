#include <cstdio>
#include <cstring>

const int N = 100, M = 2000;
const int mod = 998244353;

int n, m, k;
int a[N + 5][M + 5];
int num[M + 5];
int each = 0, ans = 0;

void dfs (int x, int lim, int t, int choose) {
	if (x == n + 1) {
		if (choose == k) {
			each += t;
			if (each >= mod) {
				each -= mod;
			}
		}
		return;
	}
	dfs (x + 1, lim, t, choose);
	if (choose < k) {
		for (int i = 1;i <= m;i++) {
			if (num[i] == lim || !a[x][i]) {
				continue;
			}
			num[i]++;
			dfs (x + 1, lim, t * a[x][i] % mod, choose + 1);
			num[i]--;
		}
	}
	return;
}

int main () {
	freopen ("meal.in", "r", stdin);
	freopen ("meal.out", "w", stdout);
	scanf ("%d %d", &n, &m);
	for (int i = 1;i <= n;i++) {
		for (int j = 1;j <= m;j++) {
			scanf ("%d", &a[i][j]);
		}
	}
	memset (num, 0, sizeof (num));
	for (k = 2;k <= n;k++) {
		dfs (1, k / 2, 1, 0);
		ans += each, each = 0;
		if (ans >= mod) {
			ans -= mod;
		}
	}
	printf ("%d", ans);
	fclose (stdin);
	fclose (stdout);
	return 0;
}
