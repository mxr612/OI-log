#include <cstdio>
#include <cstring>
#define max(a, b) (a>b?a:b)

const int N = 3e5;

int T;
int n, st;
int el = 0;
struct nod {
	int x, y, nxt;
}edge[2 * N + 5];
int Edgehead[N + 5];
int fa[N + 5];
int tot[N + 5];
struct node {
	int x, y;
}dfn[N + 5];
int len = 0;
int From[N + 5];

void add (int x, int y) {
	el++;
	edge[el].x = x, edge[el].y = y, edge[el].nxt = Edgehead[x], Edgehead[x] = el;
	return;
}

void dfs (int k, int from) {
	if (k == st) {
		From[k] = k;
	}
	else {
		From[k] = From[from];
	}
	fa[k] = from;
	tot[k] = 1;
	dfn[k].x = dfn[k].y = ++len;
	for (int i = Edgehead[k];i;i = edge[i].nxt) {
		int y = edge[i].y;
		if (y == from) {
			continue;
		}
		dfs (y, k);
		tot[k] += tot[y];
		dfn[k].y = max (dfn[k].y, dfn[y].y);
	}
	return;
}

void work () {
	scanf ("%d", &n);
	memset (Edgehead, 0, sizeof (Edgehead));
	el = 0;
	for (int i = 1;i < n;i++) {
		int u, v;
		scanf ("%d %d", &u, &v);
		add (u, v), add (v, u);
	}
	int ans = 0;
	for (int x = 1;x <= n;x++) {
		len = 0;
		st = x;
		dfs (x, 0);
		int end = 0, b1 = 0, b3 = 0, b2 = 0;
		for (int i = Edgehead[x];i;i = edge[i].nxt) {
			int y = edge[i].y;
			if (tot[y] > b1) {
				b2 = b1, b1 = tot[y], b3 = y;
			}
			else if (tot[y] > b2) {
				b2 = tot[y];
			}
		}
		for (int i = 1;i <= n;i++) {
			if (i == x) {
				continue;
			}
			int cut = i, b = 0, item = dfn[i].x;
			for (int j = Edgehead[x];j;j = edge[j].nxt) {
				int y = edge[j].y;
				if (dfn[y].x <= item && dfn[y].y >= item) {
					b = max (b, tot[y] - tot[cut]);
				}
				else {
					b = max (b, tot[y]);
				}
			}
			if (b <= (n - tot[cut]) / 2) {
				end++;
			}
		}
		ans += end * x;
	}
	printf ("%d", ans);
	puts ("");
	return;
}

int main () {
	freopen ("centroid.in", "r", stdin);
	freopen ("centroid.out", "w", stdout);
	scanf ("%d", &T);
	while (T--) {
		work ();
	}
	fclose (stdin);
	fclose (stdout);
	return 0;
}
