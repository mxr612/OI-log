#include <cstdio>
#include <cstring>
#define min(a, b) (a<b?a:b)
#define ull unsigned long long

const int N = 5e3;
const ull inf = 4e18;

int n, TYPE;
ull a[N + 5];
ull s[N + 5];
ull f[N + 5][N + 5];
ull ans = inf;

ull sqr (ull x) {
	return x * x;
}

int main () {
	freopen ("partition.in", "r", stdin);
//	freopen ("partition.out", "w", stdout);
	scanf ("%d %d", &n, &TYPE);
	if (TYPE == 0) {
		s[0] = 0;
		for (int i = 1;i <= n;i++) {
			scanf ("%llu", &a[i]);
			s[i] = s[i - 1] + a[i];
			for (int j = 1;j <= n;j++) {
				f[i][j] = inf;
			}
		}
		if (n <= 400) {
			f[0][0] = 0;
			for (int i = 1;i <= n;i++) {
				f[i][1] = sqr (s[i]);
				for (int j = 2;j <= i;j++) {
					for (int k = 1;k <= j - 1;k++) {
						if (s[i] - s[j - 1] < s[j - 1] - s[k - 1]) {
							continue;
						}
						f[i][j] = min (f[i][j], f[j - 1][k] + sqr (s[i] - s[j - 1]));
					}
				}
			}
			for (int i = 1;i <= n;i++) {
				ans = min (ans, f[n][i]);
			}
			printf ("%llu", ans);
			return 0;
		}
		f[0][0] = 0;
		for (int i = 1;i <= n;i++) {
			f[i][1] = sqr (s[i]);
			for (int j = 2;j <= i;j++) {
				for (int k = 1;k <= j - 1;k++) {
					if (s[i] - s[j - 1] < s[j - 1] - s[k - 1]) {
						continue;
					}
					f[i][j] = min (f[i][j], f[j - 1][k] + sqr (s[i] - s[j - 1]));
				}
			}
		}
		for (int i = 1;i <= n;i++) {
			ans = min (ans, f[n][i]);
		}
		printf ("%llu", ans);
	}
	fclose (stdin);
	fclose (stdout);
	return 0;
}
