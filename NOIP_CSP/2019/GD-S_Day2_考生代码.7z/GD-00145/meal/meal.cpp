#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define maxn 110
#define maxm 2010
#define int ll
const int p = 998244353;
inline int read()
{
	int x = 0,f = 1;
	char ch = getchar();
	while(ch < '0' || ch > '9'){if(ch == '-')f = -1;ch = getchar();}
	while(ch >= '0' && ch <= '9'){x = x * 10 + ch - '0';ch = getchar();}
	return x * f;
}
int arr[maxn][maxm],sum[maxn],bef[maxn][maxn];
int f[maxn][maxm][maxn],g[maxn][maxm][maxn],dp[maxn][maxm][maxn];
signed main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	int n = read(),m = read();
	for(int i = 1;i <= n;++i)
	{
		for(int j = 1;j <= m;++j)
		{
			arr[i][j] = read();
			sum[i] += arr[i][j];
			sum[i] %= p;
		}
	}
	bef[1][1] = sum[1];
	bef[1][0] = 1;
	for(int i = 2;i <= n;++i)
	{
		bef[i][0] = 1;
		for(int j = 1;j <= i;++j)
		{
			bef[i][j] = (bef[i - 1][j] + bef[i - 1][j - 1] * sum[i] % p) % p;
		}
	}
	
	for(int j = 1;j <= m;++j)
	{
		f[1][j][1] = sum[1] - arr[1][j];
		g[1][j][1] = arr[1][j];
		f[1][j][0] = 1;
		g[1][j][0] = 1;
	}
	
	for(int i = 2;i <= n;++i)
	{
		for(int j = 1;j <= m;++j)
		{
			g[i][j][0] = f[i][j][0] = 1;
			for(int k = 1;k <= i;++k)
			{
				g[i][j][k] = (g[i - 1][j][k] + g[i - 1][j][k - 1] * arr[i][j] % p) % p;
				f[i][j][k] = (f[i - 1][j][k] + f[i - 1][j][k - 1] * (sum[i] - arr[i][j]) % p) % p;
			}
			for(int k = i + 1;k <= n;++k)
			{
				g[i][j][k] = f[i][j][k] = 1;
			}
		}
	}
	
//	for(int i = 1;i <= n;++i)
//	{
//		for(int j = 1;j <= m;++j)
//		{
//			for(int k = 1;k <= i;++k)
//			{
//				g[i][j][k] = (g[i - 1][j][k] + g[i - 1][j][k - 1] * arr[i][j] % p) % p;
//			}
//		}
//	}
//	for(int i = 1;i <= n;++i)
//	{
//		for(int j = 1;j <= m;++j)
//		{
//			
//		}
//	}
	for(int j = 1;j <= m;++j)
	{
		dp[1][j][1] = arr[1][j];
//		dp[1][j][0] = 1;
	}
	for(int i = 2;i <= n;++i)
	{
		for(int j = 1;j <= m;++j)
		{
//			dp[i][j][0] = 1;
			for(int k = 1;k <= i;++k)
			{
				if((k - 1) / 2 < k / 2)
				dp[i][j][k] = (dp[i - 1][j][k] + (dp[i - 1][j][k - 1] - g[i - 1][j][(k - 1) / 2 + 1] * f[i - 1][j][k - 2 - ((k - 1) / 2)]) % p * sum[i] % p + g[i - 1][j][(k - 1) / 2 + 1] * f[i - 1][j][k - 2 - ((k - 1) / 2)] % p * arr[i][j]) % p;
				else
				{
					dp[i][j][k] = (dp[i - 1][j][k - 1] * sum[i] % p + dp[i - 1][j][k]) % p;
				}
//				if(k == 1)
//				dp[i][j][k] = (dp[i][j][k] + arr[i][j]) % p;
			}
		}
	}
	int ans = 0;
	for(int i = 1;i <= n;++i)
	{
		ans += bef[n][i];
		for(int j = 1;j <= m;++j)
		{
			ans = (ans + p - dp[n][j][i]) % p;
		}
	}
	cout << ans;
	return 0;
}
//3 3
//1 2 3
//4 5 0
//6 0 0

