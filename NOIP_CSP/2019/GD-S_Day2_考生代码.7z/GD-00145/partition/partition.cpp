#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define maxn 500010
#define int ll
inline int read()
{
	int x = 0,f = 1;
	char ch = getchar();
	while(ch < '0' || ch > '9'){if(ch == '-')f = -1;ch = getchar();}
	while(ch >= '0' && ch <= '9'){x = x * 10 + ch - '0';ch = getchar();}
	return x * f;
}
inline ll maxx(int a,int b){return a > b ? a : b;}
inline ll minn(int a,int b){return a < b ? a : b;}
ll dp[maxn],ans[maxn],size,arr[maxn],sum[maxn],l[maxn];
signed main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int n = read(),tp = read();
	for(int i = 1;i <= n;++i)
	{
		arr[i] = read();
		sum[i] = sum[i - 1] + arr[i];
	}
	for(int i = 1;i <= n;++i)
	{
		ans[i] = INT_MAX;
		dp[i] = INT_MAX;
	}
	size = 1;
	dp[1] = arr[1];
	for(int i = 1;i <= n;++i)
	{
		dp[i] = arr[i] + dp[i - 1];
		ans[i] = dp[i] * dp[i] + ans[l[i - 1]];
		l[i] = l[i - 1];
		for(int j = i - 1;j;--j)
		{
			if(sum[i] - sum[j] >= dp[j])
			{
				l[i] = j;
				dp[i] = sum[i] - sum[j];
				ans[i] = ans[j] + dp[i] * dp[i];break;
			}
		}
	}
	cout << ans[n];
	return 0;
}

