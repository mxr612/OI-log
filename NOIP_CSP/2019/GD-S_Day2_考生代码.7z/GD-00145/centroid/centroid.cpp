#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define maxn 2010

inline int read()
{
	int x = 0,f = 1;
	char ch = getchar();
	while(ch < '0' || ch > '9'){if(ch == '-')f = -1;ch = getchar();}
	while(ch >= '0' && ch <= '9'){x = x * 10 + ch - '0';ch = getchar();}
	return x * f;
}
int head[maxn],sz,n,size[maxn],root;
struct type{
	int u,v,nxt;
	void in(int a,int b)
	{
		u = a;
		v = b;
		nxt = head[a];
		head[a] = sz++;
	}
	#define v(x) line[x].v
	#define u(x) line[x].u
}line[maxn * 2];
void dfs1(int x,int fa)
{
	size[x] = 1;
	for(int i = head[x];i;i = line[i].nxt)
	{
		if(v(i) == fa)continue;
		dfs1(v(i),x);
		size[x] += size[v(i)];
	}
}
int dfs2(int x,int fa,int tempp)
{
	if(x == 0)return tempp;
	if(size[root] - size[x] > size[root] / 2)return tempp;
	int tem = 0,temi = 0;
	bool jo = 1;
	for(int i = head[x];i;i = line[i].nxt)
	{
		if(v(i) == fa)continue;
		if(size[v(i)] > size[root] / 2)jo = 0;
		if(size[v(i)] > tem)
		{
			tem = size[v(i)];
			temi = v(i);
		}
	}
	if(jo && tempp)return tempp + x;
	if(tempp)return tempp;
	if(jo)return dfs2(temi,x,x);
	return dfs2(temi,x,0);
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T = read();
	while(T--)
	{
		memset(head,0,sizeof(head));
		memset(size,0,sizeof(size));
		sz = 2;
		n = read();
		for(int i = 1;i < n;++i)
		{
			int a = read(),b = read();
			line[sz].in(a,b);
			line[sz].in(b,a);
		}
		ll ans = 0;
		for(int i = 2;i <= sz - 1;i += 2)
		{
			
			dfs1(line[i].u,line[i].v);
			dfs1(line[i].v,line[i].u);
			root = line[i].u;
			ans += dfs2(line[i].u,line[i].v,0);
			root = line[i].v;
			ans += dfs2(line[i].v,line[i].u,0);
		}
		cout << ans << endl;
	}
	return 0;
}

//2
//5
//1 2
//2 3
//2 4
//3 5
//7
//1 2
//1 3
//1 4
//3 5
//3 6
//6 7
