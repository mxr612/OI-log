#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
int n,type;
int chart[1000001];

int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d %d",&n,&type);
	for(register int i=1;i<=n;++i){
		scanf("%d",&chart[i]);
	}
	int duan[100001];
	int num=1;
	duan[1]=chart[1];
	for(register int i=1;i<n;++i){
		if(chart[i]>chart[i+1]||duan[num]>chart[i+1]){
			duan[num]+=chart[i+1];
		}else if(chart[i]<=chart[i+1]){
			num++;
			duan[num]=chart[i+1];
			
		}	
	}
	int end=0;
	for(register int i=1;i<=num;++i){
		end+=pow(duan[i],2);
//		cout<<duan[i]<<' ';
	}
	printf("%d",end);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
