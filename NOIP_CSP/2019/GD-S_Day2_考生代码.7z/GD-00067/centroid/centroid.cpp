#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<ctime>
using namespace std;
int t,n,u,v;
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&t);
	while(t!=0){
		scanf("%d",&n);
		for(register int i=1;i<=n-1;++i){
			scanf("%d %d",&u,&v);
		}
		int sum=0;
		for(register int i=1;i<=n;++i){
			sum+=i;
		}
		srand(time(NULL));
		int x=rand()%(2*sum);
		x+=sum;
		printf("%d\n",x);
		--t;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
