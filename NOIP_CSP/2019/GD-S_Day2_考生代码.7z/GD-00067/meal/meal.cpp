#include<cstdio>
#include<iostream>
#define maxn 101
#define maxm 2001
using namespace std;
const int mod=998244353;
int n,m;
int w[maxn][maxm];
int sum1[maxn];


int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(register int i=1;i<=n;++i){
		for(register int j=1;j<=m;++j){
			scanf("%d",&w[i][j]);
			if(w[i][j]==1){
				sum1[i]++;
			}
		}
	}
	int end=0;
	for(register int i=1;i<=m;++i){
		if(w[1][i]==1){
			if(w[2][i]==1){
				end+=sum1[2]-1;
			}else if(w[2][i]==0){
				end+=sum1[2];
			}
		}
	}
	cout<<end;
	fclose(stdin);fclose(stdout);
	return 0;
}
