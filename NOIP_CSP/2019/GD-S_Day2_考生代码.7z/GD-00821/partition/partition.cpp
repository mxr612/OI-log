#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

typedef long long ll;
const int N=57,M=50007;

int n,typ,a[N];
ll sum[N],f[N][M];

ll sqr(ll a){return a*a;}

int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&typ);
	for(int i=1;i<=n;++i)scanf("%d",&a[i]),sum[i]=sum[i-1]+a[i];
	memset(f,0x3f,sizeof(f));
	for(int j=0;j<=50000;++j)f[0][j]=0;
	for(int i=1;i<=n;++i){
		for(int j=0;j<i;++j)f[i][sum[i]-sum[j]]=min(f[i][sum[i]-sum[j]],f[j][sum[i]-sum[j]]+sqr(sum[i]-sum[j]));
		for(int j=1;j<=50000;++j)f[i][j]=min(f[i][j],f[i][j-1]);
	}
	printf("%lld\n",f[n][50000]);
	return 0;
}
