#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

typedef long long ll;
const int N=107,M=2007;
const ll P=998244353;

int n,m;
ll ans,a[N][M],sum[N],f[N][N][N];

void doit(int po){
	memset(f,0,sizeof(f));
	f[0][0][0]=1;
	for(int i=1;i<=n;++i)
		for(int j=0;j<=i;++j)
			for(int k=0;k<=j;++k){
				f[i][j][k]=f[i-1][j][k];
				if(j>0)f[i][j][k]=(f[i][j][k]+f[i-1][j-1][k]*(sum[i]-a[i][po]+P)%P)%P;
				if(j>0&&k>0)f[i][j][k]=(f[i][j][k]+f[i-1][j-1][k-1]*a[i][po]%P)%P;
			}
}

int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	ans=1;
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j)scanf("%d",&a[i][j]),sum[i]=(sum[i]+a[i][j])%P;
		ans=ans*(sum[i]+1)%P;
	}
	ans=(ans-1+P)%P;
	for(int i=1;i<=m;++i){
		doit(i);
		for(int j=0;j<=n;++j)for(int k=0;k<=j;++k)if(k*2>j)ans=(ans-f[n][j][k]+P)%P;
	}
	printf("%lld\n",ans);
	return 0;
}
