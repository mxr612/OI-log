#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

typedef long long ll;
const int N=300007;

int T,n,siz[N],mxsiz[N],u[N],v[N],vis[N],d[N];
int len,ischain,arr[N];
ll ans;

int tot,st[N],to[N<<1],nx[N<<1];
void add(int u,int v){to[++tot]=v,nx[tot]=st[u],st[u]=tot;}

void dfs(int u,int from){
	vis[u]=1;
	siz[u]=1,mxsiz[u]=0;
	for(int i=st[u];i;i=nx[i])if(to[i]!=from)dfs(to[i],u),siz[u]+=siz[to[i]],mxsiz[u]=max(mxsiz[u],siz[to[i]]);
}

void go(int u){
	int lst=0,flag;
	while(1){
		flag=1;
		arr[++len]=u;
		for(int i=st[u];i;i=nx[i])if(to[i]!=lst){flag=0,lst=u,u=to[i];break;}
		if(flag)break;
	}
}

int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		ischain=0;
		tot=0;
		memset(st,0,sizeof(st));
		memset(d,0,sizeof(d));
		scanf("%d",&n);
		for(int i=1;i<n;++i)scanf("%d%d",&u[i],&v[i]),add(u[i],v[i]),add(v[i],u[i]),++d[u[i]],++d[v[i]];
		ischain=1;
		for(int i=1;i<=n;++i)if(d[i]>2){ischain=0;break;}
		ans=0;
		if(ischain){
			len=0;
			for(int i=1;i<=n;++i)if(d[i]==1){go(i);break;}
			for(int i=1;i<n;++i){
				if(i&1)ans+=arr[(i+1)/2];
				else ans+=arr[i/2]+arr[i/2+1];
				if((n-i)&1)ans+=arr[(i+1+n)/2];
				else ans+=arr[(i+1+n)/2]+arr[(i+1+n)/2+1];
			}
			printf("%lld\n",ans);
			continue;
		}
		for(int i=1;i<n;++i){
			memset(vis,0,sizeof(vis));
			dfs(u[i],v[i]);
			for(int j=1;j<=n;++j)if(vis[j]){
				mxsiz[j]=max(mxsiz[j],siz[u[i]]-siz[j]);
				if(mxsiz[j]<=siz[u[i]]/2)ans+=j;
			}
			memset(vis,0,sizeof(vis));
			dfs(v[i],u[i]);
			for(int j=1;j<=n;++j)if(vis[j]){
				mxsiz[j]=max(mxsiz[j],siz[v[i]]-siz[j]);
				if(mxsiz[j]<=siz[v[i]]/2)ans+=j;
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
