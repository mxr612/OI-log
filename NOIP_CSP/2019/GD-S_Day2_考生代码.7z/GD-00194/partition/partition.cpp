#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int a[500005],ans[500005];int div[500001];
bool finish;int p=1;
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	int type,n;
	unsigned long long ans;
	ans=0;
	scanf("%d%d",&n,&type);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		cout<<ans<<" ";
		ans+=a[i]*a[i];
	}
	cout<<ans;
	return 0;
}
