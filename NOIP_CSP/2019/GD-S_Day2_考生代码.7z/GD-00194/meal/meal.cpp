#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const long long p=998244353;
long long ans;
int meal[101][2001];
int fish[2001],cook[2001];
bool take[101];
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++)
	    scanf("%d",&meal[i][j]);
	for(int i=1;i<=m;i++)
	  for(int j=1;j<=n;j++)
	    {
	    	fish[i]=fish[i]+meal[j][i];
	    	cook[j]=cook[j]+meal[j][i];
	    }
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++)
	    for(int aim=1;aim<=m;aim++)
	      if(j!=aim)
	      	ans=ans+meal[i][j]*(fish[aim]-meal[i][aim]);
	ans=ans/2;
	int ans1=0;      	
	if(n==3)
	for(int i=1;i<=n;i++)
	  for(int j=1;j<=m;j++)
	    for(int x=1;x<=n;x++)
	      for(int y=1;y<=m;y++)
	        {
	        	if(i==x||j==y)continue;
	        	for(int u=1;u<=n;u++)
	              for(int v=1;v<=m;v++)
	                if(u==i||u==x||v==j||v==y)continue;
	                else 
					{
						ans1=ans1+meal[i][j]*meal[x][y]*meal[u][v];
					} 
	        }
	ans1=ans1/6;ans=ans+ans1;
	cout<<ans;
}
