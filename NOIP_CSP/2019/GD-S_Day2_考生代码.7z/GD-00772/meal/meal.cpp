#include <bits/stdc++.h>
const int mod=998244353;
using namespace std;
int ans=0,n,m,a[110][2010],cnt[2010];
bool vis[110];
void dfs(int dep,int las,int now,int lim){
	if(now==0) return;
	if(dep>lim){
		ans=(ans+now)%mod;
		return;
	}
	for(int i=las+1;i<=n;i++){
		if(!vis[i]){
			for(int j=1;j<=m;j++){
				if(cnt[j]<lim/2){
					cnt[j]++;
					vis[i]=true;
					dfs(dep+1,i,1ll*now*a[i][j]%mod,lim);
					vis[i]=false;
					cnt[j]--;
				}
			}
		}
	}
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) scanf("%d",&a[i][j]);
	for(int k=1;k<=n;k++){
		dfs(1,0,1,k);
	}
	printf("%d\n",ans);
	return 0;
}
