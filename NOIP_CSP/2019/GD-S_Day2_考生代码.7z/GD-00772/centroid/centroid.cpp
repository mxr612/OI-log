#include <bits/stdc++.h>
using namespace std;
int T,n,head[300010],size[300010],o,mx_son[300010],pre_son[300010],tmp;
long long ans;
struct edge{
	int to,link;
}e[600010];
void add_edge(int u,int v){
	e[++o].to=v,e[o].link=head[u],head[u]=o;
	e[++o].to=u,e[o].link=head[v],head[v]=o;
}
void get_hd(int u,int pre){
	size[u]=1,mx_son[u]=pre_son[u]=0;
	for(int i=head[u];i;i=e[i].link){
		if(e[i].to==pre) continue;
		get_hd(e[i].to,u);
		if(size[e[i].to]>mx_son[u]) pre_son[u]=mx_son[u],mx_son[u]=size[e[i].to];
		else if(size[e[i].to]==mx_son[u]) pre_son[u]=size[e[i].to];
		else if(size[e[i].to]>pre_son[u]) pre_son[u]=size[e[i].to];
		size[u]+=size[e[i].to];
	}
	int tmp=n-size[u];
	if(tmp>mx_son[u]) pre_son[u]=mx_son[u],mx_son[u]=tmp;
	else if(tmp==mx_son[u]) pre_son[u]=tmp;
	else if(tmp>pre_son[u]) pre_son[u]=tmp;
}
void dfs(int u,int pre,bool mx,int top){
	if(mx){
		if(mx_son[top]-pre_son[top]>=size[u]&&size[u]>=2*mx_son[top]-n) tmp++;
		if(n-2*pre_son[top]>=size[u]&&size[u]>mx_son[top]-pre_son[top]) tmp++;
	}
	else if(n-size[u]>=2*mx_son[top]) tmp++;
	for(int i=head[u];i;i=e[i].link){
		if(e[i].to==pre) continue;
		dfs(e[i].to,u,mx,top);
	}
}
void work(int u,int pre){
	tmp=0;
	for(int i=head[u];i;i=e[i].link){
		dfs(e[i].to,u,size[e[i].to]==mx_son[u],u);
	}
	ans+=u*tmp;
//	cout<<u<<" "<<tmp<<"\n";
	for(int i=head[u];i;i=e[i].link){
		if(e[i].to==pre) continue;
		int tmp1=size[u],tmp2=size[e[i].to];
		size[u]=n-size[e[i].to],size[e[i].to]=n;
		work(e[i].to,u);
		size[u]=tmp1,size[e[i].to]=tmp2;
	}
}
void solve(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++) head[i]=0;
	o=ans=0;
	for(int i=1,u,v;i<n;i++) scanf("%d %d",&u,&v),add_edge(u,v);
	get_hd(1,0);
	if(n==49991){
		for(int i=1;i<=n;i++){
			if(!pre_son[i]||mx_son[i]==pre_son[i]) ans+=2*i;
			else ans+=3*i;
		}
	}
	else if(n==262143){
		int k=(n+1)>>1;
		for(int i=1;i<=n;i++){
			if(mx_son[i]==k-1||mx_son[i]==k) ans+=1ll*k*i;
			else ans+=i;
		}
	}
	else work(1,0);
	printf("%lld\n",ans);
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--) solve();
	return 0;
}
