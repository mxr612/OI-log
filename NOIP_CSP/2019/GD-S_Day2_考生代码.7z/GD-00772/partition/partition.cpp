#include <bits/stdc++.h>
const int mod=1<<30;
using namespace std;
int n,op,a[40000010],x,y,z,b[40000010],m,p[100010],l[100010],r[100010];
long long sum[40000010],ans=0;
void init(){
	scanf("%d %d",&n,&op);
	if(op==0) for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	else{
		scanf("%d %d %d %d %d %d",&x,&y,&z,&b[1],&b[2],&m);
		for(int i=1;i<=m;i++) scanf("%d %d %d",&p[i],&l[i],&r[i]);
		for(int i=3;i<=n;i++) b[i]=(1ll*x*b[i-1]+1ll*y*b[i-2]+z)%mod;
		int j=1;
		for(int i=1;i<=n;i++){
			while(i>p[j]&&j<m) j++;
			a[i]=(b[i]%(r[j]-l[j]+1)+l[j]);
		}
	}
	return;
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	init();
	for(int i=n;i>=1;i--) sum[i]=sum[i+1]+a[i];
	long long las=0,now=0;
	for(int i=1;i<=n;i++){
		if(now<las){
			now+=a[i];
			continue;
		}
		if(now&&now<=a[i]&&(sum[i+1]>=a[i]||i+1>n)&&now>=las){
			ans+=now*now;
			las=now,now=a[i];
			continue;
		}
		if(now+a[i]<=a[i+1]){
			now+=a[i];
			continue;
		}
		if(i+1<=n&&now+a[i]>sum[i+1]&&(sum[i]>=now)&&now>=las){
			ans+=now*now;
			las=now,now=a[i];
			continue;
		}
		if(a[i]+a[i+1]<=sum[i+2]&&(sum[i]>=now)&&now>=las){
			ans+=now*now;
			las=now,now=a[i];
			continue;
		}
		now+=a[i];
	}
	ans+=now*now;
	printf("%lld\n",ans);
	return 0;
}
