#include<iostream>
#include<fstream>
#include<cstdio>
using namespace std;
ifstream fin("partition.in");
ofstream fout("partition.out");
namespace fio{
	streambuf*in=fin.rdbuf();
	char bb[1000000],*s=bb,*t=bb;
#define gc() (s==t&&(t=(s=bb)+in->sgetn(bb,1000000),s==t)?EOF:*s++)
	inline int read(){
		int x=0;
		char ch=gc();
		while(ch<48)ch=gc();
		while(ch>=48)x=x*10+ch-48,ch=gc();
		return x;
	}
}using fio::read;
int n,typ;
int l[40000005],r[40000005],lb[40000005],rb[40000005];
unsigned long long arr[40000005],sum[40000005],ans;
void add(int x,unsigned long long v){
	sum[x]+=v;
	if(~l[x])while(sum[l[x]]+arr[lb[x]]<=sum[x]-arr[lb[x]])add(l[x],arr[lb[x]]),sum[x]-=arr[lb[x]],lb[x]--,rb[l[x]]++;
}
void merge(int x,int y){
	// merge x into y
	lb[y]=min(lb[y],lb[x]),rb[y]=max(rb[y],rb[x]),r[l[x]]=r[x],l[r[x]]=l[x];
	add(y,sum[x]);
}
int main(){
	n=read(),typ=read();
	if(typ){while(1);}
	for(int i=1;i<=n;i++)arr[i]=sum[i]=read(),lb[i]=rb[i]=i;
	for(int i=2;i<=n;i++)l[i]=i-1;l[1]=-1;
	for(int i=1;i<n;i++)r[i]=i+1;r[n]=-1;
	int ptr=1;
	while(r[ptr]!=-1){
		if(sum[r[ptr]]<sum[ptr]){
			if((!(~r[r[ptr]]))||sum[ptr]<sum[r[r[ptr]]])merge(r[ptr],ptr);
			else merge(r[ptr],r[r[ptr]]);
		}
		else ptr=r[ptr];
	}
	ptr=1;
	while(~ptr)ans+=sum[ptr]*sum[ptr],ptr=r[ptr];
	fout<<ans;
}
