#include<iostream>
#include<vector>
#include<fstream>
#include<cstring>
#include<cstdio>
using namespace std;
ifstream fin("centroid.in");
ofstream fout("centroid.out");
namespace fio{
	streambuf*in=fin.rdbuf();
	char bb[1000000],*s=bb,*t=bb;
#define gc() (s==t&&(t=(s=bb)+in->sgetn(bb,1000000),s==t)?EOF:*s++)
	inline int read(){
		int x=0;
		char ch=gc();
		while(ch<48)ch=gc();
		while(ch>=48)x=x*10+ch-48,ch=gc();
		return x;
	}
}using fio::read;
typedef pair<int,int>mp;
int n;
int siz[300005],mxsz[300005],mmxsz;
vector<int>road[300005],mmxszc;
mp edgs[300005];
vector<int>mk;
void dfs(int x,int p){
	siz[x]=1,mk.push_back(x);
	for(int i=0;i<road[x].size();i++)if(road[x][i]!=p)dfs(road[x][i],x),siz[x]+=siz[road[x][i]],mxsz[x]=max(siz[road[x][i]],mxsz[x]);
}
long long ans;
int main(){
	int t=read();
	while(t--){
		n=read(),ans=0;
		for(int i=1;i<=n;i++)road[i].clear();
		for(int i=1;i<n;i++)edgs[i]=mp(read(),read()),road[edgs[i].first].push_back(edgs[i].second),road[edgs[i].second].push_back(edgs[i].first);
		for(int i=1;i<n;i++){
			memset(siz,0,sizeof(siz)),memset(mxsz,0,sizeof(mxsz));
			dfs(edgs[i].first,edgs[i].second),mmxsz=0x7fffffff;
			for(int u=0;u<mk.size();u++){
				mxsz[mk[u]]=max(mxsz[mk[u]],siz[edgs[i].first]-siz[mk[u]]);
				if(mmxsz>mxsz[mk[u]])mmxsz=mxsz[mk[u]],mmxszc.clear(),mmxszc.push_back(mk[u]);
				else if(mmxsz==mxsz[mk[u]])mmxszc.push_back(mk[u]);
			}
			for(int i=0;i<mmxszc.size();i++)ans+=mmxszc[i];
			mk.clear(),mmxszc.clear();
			dfs(edgs[i].second,edgs[i].first),mmxsz=0x7fffffff;
			for(int u=0;u<mk.size();u++){
				mxsz[mk[u]]=max(mxsz[mk[u]],siz[edgs[i].second]-siz[mk[u]]);
				if(mmxsz>mxsz[mk[u]])mmxsz=mxsz[mk[u]],mmxszc.clear(),mmxszc.push_back(mk[u]);
				else if(mmxsz==mxsz[mk[u]])mmxszc.push_back(mk[u]);
			}
			for(int i=0;i<mmxszc.size();i++)ans+=mmxszc[i];
			mk.clear(),mmxszc.clear();
		}
		fout<<ans<<endl;
	}
}
