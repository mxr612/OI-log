#include<iostream>
#include<cstring>
#include<fstream>
#include<cstdio>
#define mod 998244353
using namespace std;
ifstream fin("meal.in");
ofstream fout("meal.out");
namespace fio{
	streambuf*in=fin.rdbuf();
	char bb[1000000],*s=bb,*t=bb;
#define gc() (s==t&&(t=(s=bb)+in->sgetn(bb,1000000),s==t)?EOF:*s++)
	inline int read(){
		int x=0;
		char ch=gc();
		while(ch<48)ch=gc();
		while(ch>=48)x=x*10+ch-48,ch=gc();
		return x;
	}
}using fio::read;
int n,m;
int arr[105][2005];
int sum[2005],sumx[2005];
int dp[105];
int dpxy[2005][105][105];
long long ans;
inline int ksm(int x,int y=998244351){
	int ans=1;
	for(x%=998244353;y;x=1ll*x*x%998244353,y>>=1)if(y&1)ans=1ll*ans*x%998244353;
	return ans;
}
int main(){
	n=read(),m=read();
	for(int i=1;i<=n;i++)for(int u=1;u<=m;u++)arr[i][u]=read();
	for(int i=1;i<=n;i++)for(int u=1;u<=m;u++)sumx[i]+=arr[i][u],sum[u]+=arr[i][u];
	dp[0]=1;
	for(int i=1;i<=n;i++)for(int u=n;u;u--)dp[u]=(dp[u]+1ll*dp[u-1]*sumx[i])%998244353;
	for(int i=1;i<=m;i++){
		dpxy[i][0][0]=1;
		for(int u=1;u<=n;u++){
			for(int j=n;j;j--){
				for(int k=n;k>=j;k--)dpxy[i][j][k]=(1ll*dpxy[i][j-1][k-1]*arr[u][i]+1ll*dpxy[i][j][k]+1ll*dpxy[i][j][k-1]*(sumx[u]-arr[u][i]))%998244353;
			}
			for(int k=n;k;k--)dpxy[i][0][k]=(dpxy[i][0][k]+1ll*dpxy[i][0][k-1]*(sumx[u]-arr[u][i]))%998244353;
		}
	}
	for(int i=2;i<=n;i++){
		ans=(ans+dp[i])%998244353;
		for(int u=1;u<=m;u++)
			for(int j=i/2+1;j<=n;j++)ans=(ans-dpxy[u][j][i]+998244353)%998244353;
	}
	fout<<ans;
}
