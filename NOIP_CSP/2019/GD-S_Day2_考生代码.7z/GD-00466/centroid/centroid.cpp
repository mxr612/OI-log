#include<cstdio>
#include<cctype>
#include<cstring>
#define rd read();
using namespace std;
typedef int long long LL;
const int MAXN=49998;
inline LL read(){
	int x=0;
	char g=getchar();
	bool f=false;
	for(;!isdigit(g);g=getchar())if(g=='-')f=true;
	for(;isdigit(g);g=getchar())x=(x<<3)+(x<<1)+(g^48);
	if(f)return -x;
	return x;
}
inline void write(LL x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar((x%10)|48);
	return;
}
LL T,n;
int head[MAXN],to[MAXN<<1],nex[MAXN<<1],tot=0;
void add(int u,int v){
	to[++tot]=v;
	nex[tot]=head[u];
	head[u]=tot;
	to[++tot]=u;
	nex[tot]=head[v];
	head[v]=tot;
	return;
}
int e[MAXN][2];
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	T=rd;
	while(T--){
		n=rd;
		tot=0;
		memset(head,0,sizeof(head));
		for(int i=1;i<n;++i){
			e[i][0]=rd;
			e[i][1]=rd;
			add(e[i][0],e[i][1]);
		}
		write((n+1)*n/2);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

















