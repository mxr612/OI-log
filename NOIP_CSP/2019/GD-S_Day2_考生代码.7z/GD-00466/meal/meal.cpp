#include<cstdio>
#include<cctype>
#define rd read();
using namespace std;
typedef int long long LL;
const LL MAXN=102,MAXM=2002,MOD=998244353;
inline LL read(){
	int x=0;
	char g=getchar();
	bool f=false;
	for(;!isdigit(g);g=getchar())if(g=='-')f=true;
	for(;isdigit(g);g=getchar())x=(x<<3)+(x<<1)+(g^48);
	if(f)return -x;
	return x;
}
inline void write(LL x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar((x%10)|48);
	return;
}
LL n,m;
LL map[MAXN][MAXM];
int ci[MAXM]={0};
LL ans=0;


void dfs(int hang,int sum,int he){
	if(hang>n){
		if(sum<2)return;
		for(int i=1;i<=m;++i){
			if(ci[i]>(sum>>1))return;
		}
		ans=(ans+he)%MOD;
		return;
	}
	for(int i=1;i<=m;++i){
		if(map[hang][i]){
			++ci[i];
			dfs(hang+1,sum+1,he*map[hang][i]%MOD);
			--ci[i];
		}
	}
	dfs(hang+1,sum,he);
	return;
}

int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=rd;
	m=rd;
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			map[i][j]=rd;
	dfs(1,0,1);
	write(ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

















