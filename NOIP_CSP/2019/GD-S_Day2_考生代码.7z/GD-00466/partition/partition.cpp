#include<cstdio>
#include<cctype>
#define rd read();
using namespace std;
typedef int long long LL;
const int MAXN=500005;
inline LL read(){
	int x=0;
	char g=getchar();
	bool f=false;
	for(;!isdigit(g);g=getchar())if(g=='-')f=true;
	for(;isdigit(g);g=getchar())x=(x<<3)+(x<<1)+(g^48);
	if(f)return -x;
	return x;
}
inline void write(LL x){
	if(x<0)putchar('-'),x=-x;
	if(x>9)write(x/10);
	putchar((x%10)|48);
	return;
}
inline LL minn(LL a,LL A){if(a<A)return a;return A;}

LL a[MAXN];
LL n,type;
LL sum=0;

inline LL jx(int l,int r){
	LL real_ans=sum*sum;
	if(l==r){return real_ans;}
	LL ANS,SUM,TMP=0;
	for(int i=r-l+1;i>=2;--i){
		LL camp=sum/i;
		ANS=0;SUM=0;
		for(int j=l;j<=r;++j){
			SUM+=a[j];
			if(SUM>=camp){
				ANS+=SUM*SUM;
				camp=SUM;
				SUM=0;
			}
		}
		ANS=ANS-camp*camp+(camp+SUM)*(camp+SUM);
		real_ans=minn(real_ans,ANS);
	}
	return real_ans;
}

int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=rd;
	type=rd;
	LL ans=0;
	int l=0;
	for(int i=1;i<=n;++i){
		a[i]=rd;
		if(sum<=a[i])
			ans+=jx(l,i-1),
			l=i,
			sum=a[i];
		else sum+=a[i];
	}
	ans+=jx(l,n);
	write(ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
