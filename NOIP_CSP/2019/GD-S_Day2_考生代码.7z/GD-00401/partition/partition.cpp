#include<bits/stdc++.h>
using namespace std;
int n,type,a[1000000],g[1000000],tot,v;
long long ans;

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	for(int i=1;i<=n;i++)
	scanf("%d",&a[i]);
	v=a[1];
	for(int i=2;i<=n;i++)
	{
		if(i==n)
		{
			if(v>a[i])
			g[++tot]=v+a[i];
			else
			g[++tot]=v,g[++tot]=a[i];
		}
		else if(g[tot]+v<=a[i]&&tot!=0)
		g[tot]+=v;
		else if(v+a[i]<=a[i+1]&&i+1<=n)
		v+=a[i];
		else if(v<g[tot])
		v+=a[i];
		else if(v+a[i]>a[i+1])
		g[++tot]=v,v=a[i];
	}
	for(int i=1;i<=tot;i++)
	ans+=g[i]*g[i];
	printf("%lld",ans);
	return 0;
}
