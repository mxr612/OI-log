#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
#define il inline
#define rg register
#define For(i,a,b) for(rg int i=(a);i<=(b);i++)
typedef long long LL;
typedef unsigned long long u64;
const int N=2019,M=998244353,INF=0x3f3f3f3f,MM=998244351;

il LL fp(LL x){
	if(x==0)return M;
	LL rs=1;
	for(rg int e=MM;e>0;e>>=1){
		if(e&1)rs=rs*x%M;
		x=x*x%M;
	}return rs;
}

int n,m,u[N],nn;
LL a[110][N],aa[110][N],ans,res=1;

int mu;

void find(int x,int k){
	if(x>n)return;
	//puts("<<<");
	For(i,1,m)if((u[i]<nn)&&(a[x][i]!=0)){
		//printf("res:%lld\n",res);
		u[i]++;int lmu=mu;mu=max(mu,u[i]<<1);
		res=(a[x][i]*res)%M;
		//bool f=0;
		//For(j,1,m)if(u[j]>((k+1)>>1)){f=1;break;}
		if((k+1)>=mu)ans=(ans+res)%M;//,printf("res!!!:%lld\n",res);
		find(x+1,k+1);
		res=res*aa[x][i]%M;
		u[i]--;mu=lmu;
		//printf("res:%lld\n",res);
	}   
	find(x+1,k);
	//puts(">>>");
}

int main(){
	freopen("meal.in","r",stdin);freopen("meal.out","w",stdout);

	scanf("%d%d",&n,&m);
	For(i,1,n)
		For(j,1,m){scanf("%lld",&a[i][j]);aa[i][j]=fp(a[i][j]);}
	nn=(n>>1);
	//For(i,1,n)For(j,1,m)printf("%lld %lld\n",a[i][j],aa[i][j]);
	find(1,0);
	printf("%lld",ans);
	

	return 0;

}









