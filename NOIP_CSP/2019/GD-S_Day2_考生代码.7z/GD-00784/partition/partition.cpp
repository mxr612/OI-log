#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
#define il inline
#define rg register
#define For(i,a,b) for(rg int i=(a);i<=(b);i++)
typedef long long LL;
typedef unsigned long long u64;
const int N=40000010,INF=0x3f3f3f3f;
const int M=(1<<30)-1;

int n,a[N],ty;
LL s[N];
il LL lmi(LL a,LL b){return a<b?a:b;}
il LL ep(LL a){return a*a;}
LL res,ans=0x3f3f3f3f3f3f3f3fll;
il void fls(){
	//puts("f(1,0)")  ;
	if(res<ans)ans=res;
}
void f(int x,int m){
	if(x>n)fls();
	if((s[n]-s[x-1])<m)return;
	For(i,x,n){
		LL tt=s[i]-s[x-1];
		if(tt>=m){
			res+=tt*tt;
			f(i+1,tt);
			res-=tt*tt;
		}
	}	
}



int xs,ys,zs,b[N],m,p[100010],l[100010],r[100010];


int main(){
	freopen("partition.in","r",stdin);freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&ty);
	if(ty==0){
		For(i,1,n){
			scanf("%d",&a[i]);
			s[i]=s[i-1]+a[i];   //printf("%lld\n",s[i]);
		}
		f(1,0);
		printf("%lld\n",ans);
	}else{
		scanf("%d%d%d%d%d%d",&xs,&ys,&zs,&b[1],&b[2],&m);
		For(i,1,m)scanf("%d%d%d",&p[i],&l[i],&r[i]);
		For(i,3,n)b[i]=((LL)xs*b[i-1]+(LL)ys*b[i-2]+zs)&M;
		For(i,1,m){
			For(j,p[i-1],p[i])a[j]=(b[j]%(r[i]-l[i]+1))+l[i];
		}
	}

	
	return 0;

}









