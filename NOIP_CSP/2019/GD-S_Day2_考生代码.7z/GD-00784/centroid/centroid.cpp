#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
#define il inline
#define rg register
#define For(i,a,b) for(rg int i=(a);i<=(b);i++)
typedef long long LL;
typedef unsigned long long u64;
const int N=300019,M=19260817,INF=0x3f3f3f3f;

/*il void read(int &x){
	x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	while(ch>='0'&&ch<='9'){x=x*10-'0'+ch;ch=getchar();}
}                                       */

struct edge{int to,nex;}e[N<<1];
int h[N],tot;
il void add(int u,int v){
	e[++tot].to=u;e[tot].nex=h[v];h[v]=tot;
	e[++tot].to=v;e[tot].nex=h[u];h[u]=tot;
}

int n,T,u,v;
LL ans;
int s[N];
int dl;
void dfs(int x){
	s[x]=1;
	for(rg int i=h[x],j;i;i=e[i].nex){
		j=e[i].to;
		if((s[j]>0)||((i>>1)==dl))continue;
		dfs(j);
		s[x]+=s[j];
	}
}
bool vis[N];
void dfs1(int x,int ns){
	vis[x]=1;
	bool f=1;
	for(rg int i=h[x],j;i;i=e[i].nex){
		j=e[i].to;
		if((vis[j])||((i>>1)==dl))continue;
		dfs1(j,ns);
		if(s[j]>(ns>>1))f=0;
	}
	if((ns-s[x])>(ns>>1))return;
	ans+=f?x:0;
}


int l[N],cnt;
void dfs2(int x){
	vis[x]=1;l[++cnt]=x;
	for(rg int i=h[x];i;i=e[i].nex)if(!vis[e[i].to])dfs2(e[i].to);
}

int main(){
	freopen("centroid.in","r",stdin);freopen("centroid.out","w",stdout);

	scanf("%d",&T);T++;
	while(--T){
		
		scanf("%d",&n);
		tot=1;ans=0;memset(h,0,sizeof h);


		if(n==49991){
		
			For(i,2,n){
				scanf("%d%d",&u,&v);
				add(u,v);s[u]++;s[v]++;
			}
			For(i,1,n)if(s[i]==1){dl=i;break;}
			memset(vis,0,sizeof vis);cnt=0;ans=0;
			dfs2(dl);			
			For(i,2,n){
				ans+=(i&1)?(l[i>>1]+l[(i>>1)+1]):l[i>>1];
				ans+=((n-i)&1)?(l[(i+n)>>1]+l[((i+n)>>1)+1]):l[(n+i)>>1];
			}
			printf("%lld\n",ans);
		} else{

		
		For(i,2,n){scanf("%d%d",&u,&v);add(u,v);}
		//puts("success input");
		for(dl=1;dl<=(n-1);dl++){
			memset(s,0,sizeof s);memset(vis,0,sizeof vis);
			u=e[dl<<1].to,v=e[dl<<1|1].to;      
			dfs(u);dfs(v);          //puts("success");
			dfs1(u,s[u]);dfs1(v,s[v]);
		}
		
		printf("%lld\n",ans);
	}
	}
	
	return 0;

}









