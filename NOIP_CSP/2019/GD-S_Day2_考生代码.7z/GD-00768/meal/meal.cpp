#include<cstdio>
#define Z int
#define V void
#define L long long
#define S(n) scanf("%d",&n)
#define P(n) printf("%d",n)
#define F(i,a,b) for(i=a;i<=b;i++)
#define I if
#define nx 101
#define p 998244353
L n,m,i,j,k,over;
L a[nx][nx],b[nx];
L f[nx][nx][nx];
L sum,illegal;
V calc(){
	sum=1;
	F(i,1,n)(sum*=b[i]+1)%=p;
	sum--;
}
V clear(){
	F(i,0,n)
	F(j,0,i)
	F(k,j,i)f[i][j][k]=0;
}
V dp(){
	F(over,1,m){
		clear();
		f[0][0][0]=1;
		F(i,0,n-1)
		F(j,0,i)
		F(k,j,i)
		I(f[i][j][k]){
			(f[i+1][j][k]+=f[i][j][k])%=p;
			(f[i+1][j][k+1]+=f[i][j][k]*(b[i+1]-a[i+1][over]))%=p;
			(f[i+1][j+1][k+1]+=f[i][j][k]*a[i+1][over])%=p;
		}
		F(j,0,n)
		F(k,j,n)I(j>k/2)(illegal+=f[n][j][k])%=p;
	}
}
Z main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	S(n);S(m);
	F(i,1,n)
	F(j,1,m)S(a[i][j]),(b[i]+=a[i][j])%=p;
	calc();
	dp();
	sum-=illegal;
	P((sum%p+p)%p);
}
