#include<cstdio>
#include<cstring>
#define Z int
#define V void
#define L long long
#define S(n) scanf("%d",&n)
#define P(n) printf("%lld\n",n)
#define M(f) memset(f,0,sizeof f)
#define F(i,a,b) for(i=a;i<=b;i++)
#define G(k,x) for(k=last[x];k;k=next[k])
#define W while
#define I if
#define E else
#define B break
#define nx (Z)(3e5)
#define mx (Z)(6e5)
L t,n,i,ban,x[nx],y[nx];
L last[nx],next[mx],r[mx],flag[mx],l;
L sz[nx],szsum;
L deg[nx],count[nx],dfn[nx],kth[nx],root,me,cnt[nx];
L ans;
V ins(L x,L y){
	r[++l]=y;
	next[l]=last[x];
	last[x]=l;
}
V clear(){
	M(last),M(next),M(r),l=0;
	M(deg),M(count),M(dfn),M(cnt);
	ans=0;
}
V search(L x,L me){
	szsum++;
	L k;
	G(k,x)I(r[k]^me&&!flag[k])search(r[k],x);
}
V dfs(L x,L me){
	sz[x]=1;
	L k,ok=1;
	G(k,x)
	I(r[k]^me&&!flag[k]){
		dfs(r[k],x);
		sz[x]+=sz[r[k]];
		I(sz[r[k]]>szsum/2)ok=0;
	}
	I(szsum-sz[x]>szsum/2)ok=0;
	I(ok)ans+=x;
}
V calc(L pt){
	szsum=0;
	search(pt,0);
	dfs(pt,0);
}
V seperate(){
	flag[ban*2-1]=flag[ban*2]=1;
	L k;
	F(k,1,n)sz[k]=0;
	calc(x[ban]);
	calc(y[ban]);
	flag[ban*2-1]=flag[ban*2]=0;
}
V bf(){F(ban,1,n-1)seperate();}
V chain(){
	F(i,1,n)I(deg[i]==1)root=i;
	i=root,me=0;
	W(dfn[0]<n){
		kth[dfn[i]=++dfn[0]]=i;
		L k;
		G(k,i)I(r[k]^me)B;
		me=i,i=r[k];
	}
	F(i,1,n-1){
		I(i%2)cnt[kth[i/2+1]]++;
		E cnt[kth[i/2]]++,cnt[kth[i/2+1]]++;
		I((n-i)%2)cnt[kth[(i+1+n)/2]]++;
		E cnt[kth[(i+1+n)/2]]++,cnt[kth[(i+1+n)/2+1]]++;
	}
	F(i,1,n)ans+=i*cnt[i];
}
V btree(){
	F(i,1,n)I(deg[i]==2)root=i;
	L k;
	L son[3];
	son[0]=0;
	G(k,root)son[++son[0]]=r[k];
	F(i,1,n)I(i^root)ans+=i;
	ans+=root*(n+1)/2;
	ans+=(son[1]+son[2])*(n-1)/2;
}
V doit(){
	clear();
	S(n);
	F(i,1,n-1){
		S(x[i]);S(y[i]);
		ins(x[i],y[i]);
		ins(y[i],x[i]);
		deg[x[i]]++,deg[y[i]]++;
	}
	F(i,1,n)count[deg[i]]++;
	I(n<=2000)bf();
	E I(count[1]==2&&count[2]==n-2)chain();
	E btree();
	P(ans);
}
Z main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	S(t);
	W(t--)doit();
}
