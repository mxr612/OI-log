#include<cstdio>
#include<cstring>
#define Z int
#define L long long
#define S(n) scanf("%d",&n)
#define P(n) printf("%lld",n)
#define M(f) memset(f,127,sizeof f)
#define F(i,a,b) for(i=a;i<=b;i++)
#define W while
#define sm(a,b) (a<b?a:b)
#define I if
#define R return
#define nx 5001
#define inf (41e17)
#define init 9187201950435737471
L n,tp,i,j,k,rc;
L a[nx],pre[nx],last;
L f[nx][nx],fast[nx][nx],jump,ans;
L sqr(L x){R x*x;}
L _(L l,L r){R pre[r]-pre[l-1];}
Z main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	S(n);S(tp);
	F(i,1,n)S(a[i]),pre[i]=pre[i-1]+a[i];
	M(f),M(fast);
	f[0][0]=0;
	fast[1][1]=0;
	F(i,1,n){
		jump=i+1;
		F(j,i,n){
			fast[i][j]=sm(fast[i][j],fast[i][j-1]);
			I(fast[i][j]<init)f[i][j]=fast[i][j]+sqr(_(i,j));
			W(_(i,j)>_(j+1,jump)&&jump<n)jump++;
			I(_(i,j)<=_(j+1,jump))fast[j+1][jump]=sm(fast[j+1][jump],f[i][j]);
		}
	}
	ans=inf;
	F(i,1,n)ans=sm(ans,f[i][n]);
	P(ans);
}
