#include<cstdio>
#define mo 998244353
long long a[50][4];
long long f[50][50][50][50];
long long g[50][50][50];
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++) scanf("%lld",&a[i][j]);
	if (m==3)
	{
		f[0][0][0][0]=1;
		for (int i=1;i<=n;i++)
			for (int j=0;j<=i;j++)
				for (int k=0;k<=i;k++)
				{
					if (j+k>i) break;
					for (int l=0;l<=i;l++)
					{
						if (j+k+l>i) break;
						f[i][j][k][l]=f[i-1][j][k][l];
						if (j!=0) f[i][j][k][l]+=f[i-1][j-1][k][l]*a[i][1];
						if (k!=0) f[i][j][k][l]+=f[i-1][j][k-1][l]*a[i][2];
						if (l!=0) f[i][j][k][l]+=f[i-1][j][k][l-1]*a[i][3];
						f[i][j][k][l]%=mo;
					}
				}
		long long s=0;
		for (int i=0;i<=n;i++)
			for (int j=0;j<=n;j++)
				for (int k=0;k<=n;k++)
				{
					int t=i+j+k;
					if (t<=n && t>=2 && i<=t/2 && j<=t/2 && k<=t/2) s=(s+f[n][i][j][k])%mo;
				}
		printf("%lld\n",s);
	} else
	if (m==2)
	{
		g[0][0][0]=1;
		for (int i=1;i<=n;i++)
			for (int j=0;j<=i;j++)
				for (int k=0;k<=i;k++)
				{
					if (j+k>i) break;
					g[i][j][k]=g[i-1][j][k];
					if (j!=0) g[i][j][k]+=g[i-1][j-1][k]*a[i][1];
					if (k!=0) g[i][j][k]+=g[i-1][j][k-1]*a[i][2];
					g[i][j][k]%=mo;
				}
		long long s=0;
		for (int i=0;i<=n;i++)
			for (int j=0;j<=n;j++)
				{
					int t=i+j;
					if (t<=n && t>=2 && i<=t/2 && j<=t/2) s=(s+g[n][i][j])%mo;
				}
		printf("%lld\n",s);
	}
	return 0;
}

