#include<cstdio>
long long a[5010];
long long f[5010][5010];
long long g[5010][5010];
long long sum[5010];
long long s[5010][5010];
long long min(long long a,long long b)
{
	return a<b?a:b;
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int n,type;
	scanf("%d%d",&n,&type);
	for (int i=1;i<=n;i++) scanf("%lld",&a[i]),sum[i]=sum[i-1]+a[i];
	for (int i=1;i<=n;i++)
		for (int j=i;j<=n;j++) s[i][j]=sum[j]-sum[i-1]; 
	for (int i=1;i<=n;i++)
	{
		g[i+1][i]=9000000000000000000ll;
		for (int j=i;j>=1;j--)
		{
			if (s[j][i]<a[j-1])
			{
				f[i][j]=9000000000000000000ll; g[j][i]=g[j+1][i];
				continue;
			}
			int l=1; int r=j-1; long long p=s[j][i];
			while (l<r)
			{
				int mid=(l+r)/2;
				if (s[mid][j-1]<=p) r=mid; else l=mid+1;
			}
			f[i][j]=p*p+g[r][j-1];
			g[j][i]=min(g[j+1][i],f[i][j]);
		}
	}
	printf("%lld\n",g[1][n]);
	return 0;
}
