#include<cstdio>
#include<cstring>
int las[100010],to[100010],nxt[100010],num[100010];
int f[2010];
int a[100010][2];
int b[100010];
int ni[100010];
int du[100010];
int tot;
long long ans=0;
void insert(int x,int y,int z)
{
	nxt[++tot]=las[x];
	las[x]=tot;
	to[tot]=y;
	num[tot]=z;
}
void dfs1(int x,int p,int fa)
{
	f[x]=1;
	for (int i=las[x];i;i=nxt[i])
		if (num[i]!=p && to[i]!=fa)
		{
			dfs1(to[i],p,x);
			f[x]=f[x]+f[to[i]];
		}
}
void dfs2(int x,int p,int t,int fa)
{
	int mx=0;
	for (int i=las[x];i;i=nxt[i])
		if (num[i]!=p && to[i]!=fa && f[to[i]]>mx) mx=f[to[i]];
	if (t-f[x]>mx) mx=t-f[x];
	if (mx<=t/2) ans+=x;
	for (int i=las[x];i;i=nxt[i])
		if (num[i]!=p && to[i]!=fa) dfs2(to[i],p,t,x);
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T;
	scanf("%d",&T);
	while (T--)
	{
		int n;
		scanf("%d",&n);
		tot=0;
		memset(las,0,sizeof(las));
		memset(to,0,sizeof(to));
		memset(nxt,0,sizeof(nxt));
		memset(num,0,sizeof(num));
		memset(du,0,sizeof(du));
		for (int i=1;i<=n-1;i++)
		{
			scanf("%d%d",&a[i][0],&a[i][1]);
			du[a[i][0]]++; du[a[i][1]]++;
			insert(a[i][0],a[i][1],i); insert(a[i][1],a[i][0],i);
		}
		if (n==49991)
		{
			int st=0;
			for (int i=1;i<=n;i++)
				if (du[i]==1)
				{
					st=i;
					break;
				}
			int en=0;
			for (int i=n;i>=1;i--)
				if (du[i]==1)
				{
					en=i;
					break;
				}
			memset(b,0,sizeof(b));
			memset(ni,0,sizeof(ni));
			int x=st;
			b[++b[0]]=st;
			while (x!=en)
			{
				for (int i=las[x];i;i=nxt[i])
					if (to[i]!=b[b[0]-1]) 
					{
						b[++b[0]]=to[i],x=to[i]; break; }
			}
			for (int i=1;i<=n;i++) ni[b[i]]=i;
			long long s=0;
			for (int i=1;i<=n-1;i++)
			{
				int p1=ni[a[i][0]]; int p2=ni[a[i][1]];
				if (p1>p2) 
				{
					int pp=p1; p1=p2; p2=pp;
				}
				if (p1%2==1) s+=b[(p1+1)/2]; else s+=b[(p1+1)/2]+b[(p1+1)/2+1];
				if ((n-p2+1)%2==1) s+=b[(n+p2)/2]; else s+=b[(n+p2)/2]+b[(n+p2)/2+1];
			}
			printf("%lld\n",s);
			continue;	
		} 
		ans=0;
		memset(f,0,sizeof(f));
		for (int i=1;i<=n-1;i++)
		{
			dfs1(a[i][0],i,0); dfs1(a[i][1],i,0);
			dfs2(a[i][0],i,f[a[i][0]],0); dfs2(a[i][1],i,f[a[i][1]],0);
		}
		printf("%lld\n",ans);
	}
	return 0;
}

