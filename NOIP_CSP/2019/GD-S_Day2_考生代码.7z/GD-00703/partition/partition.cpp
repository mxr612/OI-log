#include<bits/stdc++.h>
#define ll long long
#define fo(i,a,b) for(ll i=a;i<=b;i++)
#define N 5005
using namespace std;
ll n,ty,a[N*100],qz[N*100],x,f[N][N],ans,y,z,b[N],xx,yy,zz,m,w,g[N][N],ff[N*100],u,v;
ll get(ll x,ll y)
{	
	if(x==0)return 0;
	if(a[x]>y)return -1;
	ll head=1,tail=x,mid=(head+tail)>>1;
	while(head<tail)
	{
		if(qz[x]-qz[mid-1]>y)
			head=mid+1;
		else
			tail=mid;
		mid=(head+tail)>>1;
	}
	return tail;
}
int main()
{
	freopen("partition.in","r",stdin);freopen("partition.out","w",stdout);
	scanf("%lld%lld",&n,&ty);
	if(ty==0&&n<=5000)
	{
		fo(i,1,n)scanf("%lld",&a[i]),qz[i]=qz[i-1]+a[i];		
		memset(f,125,sizeof f);
		f[1][1]=a[1]*a[1],x=1;
		memset(g,125,sizeof g);
		g[1][1]=f[1][1];
		memset(g[0],0,sizeof g[0]);
		fo(i,2,n)
		{
			fo(j,1,i)
			{
				w=get(j-1,(qz[i]-qz[j-1]));
				if(w==-1)continue;
				f[i][j]=g[j-1][w]+(qz[i]-qz[j-1])*(qz[i]-qz[j-1]);
			}
			g[i][i]=f[i][i];
			for(int j=i-1;j>=1;j--)g[i][j]=min(g[i][j+1],f[i][j]);
		}
		ans=1<<31;
		ans=ans*ans;
		fo(i,1,n)ans=min(ans,f[n][i]);
		printf("%lld",ans);
		return 0;
	}
	fo(i,1,n)scanf("%lld",&a[i]),qz[i]=qz[i-1]+a[i];
	ff[1]=1,x=1;
	fo(i,2,n)
	{
		while(qz[i]-qz[x]>=qz[x]-qz[ff[x]-1])x++;
		ff[i]=x;
	}
	x=n;
	u=1;
	while(x!=0)
	{
		v=qz[x]-qz[ff[x]-1];
		ans=ans+v*v;
		x=ff[x]-1;
	}
	printf("%lld",ans);
	return 0;
	
}
