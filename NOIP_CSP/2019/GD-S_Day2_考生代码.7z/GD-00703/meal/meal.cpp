#include<bits/stdc++.h>
#define ha 998244353
#define N 105
#define M 2005
#define ll long long
#define fo(i,a,b) for(ll i=a;i<=b;i++)
using namespace std;
ll n,m,a[N][M],sum[N],f[N][N][N],ans,u;
int main()
{
	freopen("meal.in","r",stdin);freopen("meal.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	fo(i,1,n)
		fo(j,1,m)
			scanf("%lld",&a[i][j]),sum[i]=(sum[i]+a[i][j])%ha;
	ans=sum[1]+1;
	fo(i,2,n)ans=ans*(sum[i]+1)%ha;
	fo(i,1,m)
	{
		f[1][0][0]=1,f[1][0][1]=(sum[1]-a[1][i]+ha)%ha,f[1][1][0]=a[1][i];		
		fo(j,2,n)
		{
			u=(sum[j]-a[j][i]+ha)%ha;
			fo(k,0,j)fo(l,0,j-k)
	f[j][k][l]=(f[j-1][k-1][l]*a[j][i]%ha+f[j-1][k][l-1]*u%ha+f[j-1][k][l])%ha;
		}
		fo(k,1,n)
			fo(l,0,k-1)
				ans=(ans-f[n][k][l]+ha)%ha;
	}
	printf("%lld",ans-1);
}
