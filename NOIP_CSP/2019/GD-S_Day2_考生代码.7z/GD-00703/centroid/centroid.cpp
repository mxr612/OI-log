#include<bits/stdc++.h>
#pragma GCC opitmize("O3")
#pragma G++ opitmize("O3")
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define N 600005
#define ll long long
using namespace std;
ll siz[N],last[N],nex[N],tov[N],fa[N],ans,uuu,bz[N],bz2[N],n,tt,tot,x,y,t[N],d[N],a[N],rt;
void lian(ll x,ll y)
{
	tot++,tov[tot]=y,nex[tot]=last[x],last[x]=tot;
	tot++,tov[tot]=x,nex[tot]=last[y],last[y]=tot;
}
void doit(ll x,ll y)
{
	if((y-x+1)%2==0)
	{
		ll z=(y-x+1)/2+x;
		bz[z]++,bz[z-1]++;
		return;
	}
	if((y-x+1)%2==1)
	{
		ll z=(y-x+1)/2+x;
		bz[z]++;
		return;
	}
}
void dfs(ll x,ll y)
{
	siz[x]=1;	
	for(ll i=last[x];i;i=nex[i])
	{
		if(tov[i]==y)continue;
		fa[tov[i]]=x;
		dfs(tov[i],x);
		siz[x]+=siz[tov[i]];
	}
}
void get(ll x,ll y)
{
	ans+=x;
	bz2[x]=0;
	for(ll i=last[x];i;i=nex[i])
	{
		if(tov[i]==y)continue;
		get(tov[i],x);
		if(siz[tov[i]]>siz[uuu]/2)bz2[x]=1;
	}
	if(siz[uuu]-siz[x]>siz[uuu]/2)bz2[x]=1;
	ans=ans-bz2[x]*x;
}
void get2(ll x,ll y)
{
	ans+=x;
	bz2[x]=0;
	for(ll i=last[x];i;i=nex[i])
	{
		if(tov[i]==y)continue;
		if(tov[i]==uuu)continue;
		get2(tov[i],x);
		if(siz[tov[i]]-bz[tov[i]]*siz[uuu]>(n-siz[uuu])/2)bz2[x]=1;
	}
	if(n-(siz[x]+(1-bz[x])*siz[uuu])>(n-siz[uuu])/2)bz2[x]=1;
	if(bz2[x]==0)t[x]++;
	ans=ans-bz2[x]*x;
}
int main()
{
	freopen("centroid.in","r",stdin);freopen("centroid.out","w",stdout);
	scanf("%lld",&tt);
	while(tt--)
	{
		scanf("%lld",&n);		
		memset(last,0,sizeof last),tot=0;memset(d,0,sizeof d);
		fo(i,1,n-1)
			scanf("%lld%lld",&x,&y),lian(x,y),d[x]++,d[y]++;
		if(n==262143)
		{
			fo(i,1,n)if(d[i]==2)
			{
				ans=i*131072;
				for(ll j=last[i];j;j=nex[j])ans=ans+131071*tov[j];
			}
			printf("%lld\n",ans);
			continue;
		}
		if(n==49991) 
		{
			fo(i,1,n)
			{
				if(d[i]==1)
				{
					rt=i;
					break;
				}
			}
			x=rt,a[1]=x;
			fo(i,2,n)
			{
				for(ll j=last[x];j;j=nex[j])
				{
					if(tov[j]==a[i-2])continue;
					a[i]=tov[j];
				}
				x=a[i];
			}
			memset(bz,0,sizeof bz);
			fo(i,1,n-1)doit(1,i),doit(i+1,n);
			fo(i,1,n)ans=ans+a[i]*bz[i];
			printf("%lld\n",ans);
			continue;
		}
		ans=0;
		dfs(1,0);
		fo(i,2,n)
		{
			memset(bz,0,sizeof bz);
			x=i,uuu=i;
			while(x!=1)x=fa[x],bz[x]=1;
			get(i,fa[i]);
			get2(1,0);
		}
		printf("%lld\n",ans);
	}
}
