#include<cstdio>
#include<cstring>
const int maxn=299995+2;
int n,T,cnt,head[maxn],dis[maxn],ans,t[2],sk[2][maxn];
bool col[maxn];
struct DEL{int x,y;}p[maxn],x;
struct EDGE{int v,nxt;}edge[maxn<<1];
inline void add(int u,int v){
	edge[++cnt].v=v;
	edge[cnt].nxt=head[u];
	head[u]=cnt;
}
inline void stt(){
	memset(head,0,sizeof(head)); cnt=0;
	memset(edge,0,sizeof(edge)); ans=0;
	memset(col,0,sizeof(col));
}
void dfs(int u,int fa,bool cl){
	col[u]=cl;
	for(int i=head[u];i;i=edge[i].nxt)
		if(edge[i].v!=fa){
			if(u==x.x&&edge[i].v==x.y)continue;
			if(u==x.y&&edge[i].v==x.x)continue;
			dis[edge[i].v]=dis[u]+1;
			dfs(edge[i].v,u,cl);
		}
}
void dfss(int u,int fa,int end,bool cl,int k){
//	printf("%d %d %d %d %d\n",u,fa,end,cl,k);
	sk[cl][++sk[cl][0]]=u;
	if(u==end){
//		printf("inint!!!\n");
		for(int i=1;i<=sk[cl][0];i++){
			int xk=sk[cl][i];
			if(k%2==1&&dis[xk]==(k+1)/2){
				t[cl]+=xk;
//				printf("xk=%d\n",xk);
				break;
			}
			else if(k%2==0&&k/2==dis[xk]){
				t[cl]+=xk+sk[cl][i+1];
//				printf("xkkk==%d %d\n",xk,sk[cl][i+1]);
				break;
			}
		}
		return ;
	}
	for(int i=head[u];i;i=edge[i].nxt)
		if(edge[i].v!=fa){
			if(u==x.x&&edge[i].v==x.y)continue;
			if(u==x.y&&edge[i].v==x.x)continue;
			dfss(edge[i].v,u,end,cl,k);
		}
	sk[cl][0]--;
}
inline int cal(){
	int dy=0,a=0,b=0,ans1=0,ans2=0,rs1=0,rs2=0;
	dis[x.x]=dis[x.y]=1;
	dfs(x.x,0,1);// u, fa, col
	dfs(x.y,0,0);
	for(int i=1;i<=n;i++){
		if(col[i]){
			if(dis[i]>dis[a]) a=i;
		}
		else{
			if(dis[i]>dis[b]) b=i;
		}
	}
//	printf("ab=%d %d\n",a,b);
	dis[a]=dis[b]=1;
	dfs(a,0,1);
	dfs(b,0,0);
	for(int i=1;i<=n;i++){
		if(col[i]){
			if(dis[i]>dis[ans1]) ans1=i;
		}
		else{
			if(dis[i]>dis[ans2]) ans2=i;
		}
	}
	t[0]=t[1]=0; sk[0][0]=sk[1][0]=0;
//	printf("ans=%d %d\n",ans1,ans2);
	dfss(a,-1,ans1,1,dis[ans1]);
	dfss(b,-1,ans2,0,dis[ans2]);
//	for(int i=1;i<=n;i++)printf("%d:%d\n",i,col[i]);
//	printf("del:%d %d:%d %d\n",x.x,x.y,rs1,rs2);
//	printf("t==%d %d\n",t[0],t[1]);
	return t[0]+t[1];
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		stt(); scanf("%d",&n);
		for(int i=1,u,v;i<n;i++){
			scanf("%d%d",&u,&v);
			add(u,v); add(v,u);
			p[i].x=u; p[i].y=v;
		}
		for(int i=1;i<n;i++){
			x=p[i];
			memset(dis,0,sizeof(dis));
			memset(col,0,sizeof(col));
			ans+=cal();
		}
		printf("%d\n",ans);
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
/*
2
5
1 2
2 3
2 4
3 5
7
1 2
1 3
1 4
3 5
3 6
6 7
*/
