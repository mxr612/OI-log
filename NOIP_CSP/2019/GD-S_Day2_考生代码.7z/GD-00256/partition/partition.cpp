#include<cstdio>
const int maxn=4e7+101;
typedef unsigned long long ll;
ll a[maxn],sum[maxn],f[5001][5001];
int tp,n;
struct DP{
	ll f; int k;
}dp[maxn];
inline ll minn(ll a,ll b){
	return a<b?a:b;
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&tp);
	if(tp==0){
		for(int i=1;i<=n;i++)scanf("%llu",&a[i]),sum[i]=sum[i-1]+a[i];
//		dp[1].f=a[1]*a[1]; dp[1].k=1;
//		for(int i=2;i<=n;i++){
//			dp[i].f=0x7ffffffff;
//			for(int j=0;j<i;j++)
//				if(sum[i]-sum[j]>=sum[j-1]-sum[dp[j].k]&&dp[j].f+(sum[i]-sum[j])*(sum[i]-sum[j])<=dp[i].f)
//					dp[i].f=dp[j].f+(sum[i]-sum[j])*(sum[i]-sum[j]),dp[i].k=j;
////				if(dp[j].f+(sum[i]-sum[j])*(sum[i]-sum[j])<dp[i].f)
////					dp[i].f=dp[j].f+(sum[i]-sum[j])*(sum[i]-sum[j]);
//			printf("%llu ",dp[i].f);
//		}
//		printf("\n%llu\n",dp[n].f);
		for(int i=1;i<=n;i++)
			for(int j=1;j<=i;j++)
				f[j][i]=4e18;
		for(int i=1;i<=n;i++) f[1][i]=sum[i]*sum[i];
		for(int i=2;i<=n;i++)
			for(int j=1;j<=i;j++){
//				f[j][i]=minn();
				for(int k=1;k<j;k++)
					if(sum[i]-sum[j-1]>=sum[j-1]-sum[k-1])
						f[j][i]=minn(f[j][i],f[k][j-1]+(sum[i]-sum[j-1])*(sum[i]-sum[j-1]));
			//	printf("%d %d:%llu\n",j,i,f[j][i]);
			}
		ll ans=4e18;
		for(int i=1;i<=n;i++)ans=minn(ans,f[i][n]);
		printf("%llu\n",ans);
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
