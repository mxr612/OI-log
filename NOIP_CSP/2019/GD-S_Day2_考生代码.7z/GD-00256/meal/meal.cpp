#include<cstdio>
typedef long long ll;
const ll mod=998244353;
ll f[101],a[101][1001],ans,sum[1001];//,sumn[101],summ[1001];
int n,m;
void dfs(int x,ll tot,int k){
	if(x==n){
		for(int i=1;i<=m;i++)
			if(sum[i]>k/2)return;
		ans=(ans+tot)%mod;
		return;
	}
	dfs(x+1,tot,k);
	for(int i=1;i<=m;i++)
		if(a[x+1][i]){
			sum[i]++;
			dfs(x+1,(tot*a[x+1][i])%mod,k+1);
			sum[i]--;
		}
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)
			scanf("%lld",&a[i][j]);//,sumn[i]+=a[i][j],f[0][j]=1;
	}
//	for(int i=1;i<=m;i++)
//		for(int j=1;j<=n;j++)
//			summ[i]+=a[j][i],f[j][0]=1;
//	f[0]=1;
//	for(int i=1;i<=n;i++) printf("%lld ",sumn[i]);puts("");
//	for(int i=1;i<=m;i++) printf("%lld ",summ[i]);puts("");
	dfs(0,1ll,0); printf("%lld",ans-1);
	fclose(stdin); fclose(stdout);
	return 0;
}
/*
5 5
1 0 0 1 1
0 1 0 1 0
1 1 1 1 0
1 0 1 0 1
0 1 1 0 1
*/
