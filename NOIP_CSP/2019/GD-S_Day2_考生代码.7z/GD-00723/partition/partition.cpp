#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

typedef long long ll;
const int MAXN=5005;
const ll INF=4e18+1;
ll a[MAXN],sum[MAXN],dp[MAXN][MAXN];
int n,type;
ll ans=INF;

signed main(void)
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>type;
	for(int i=1;i<=n;i++)
		scanf("%lld",a+i);
	
	for(int i=1;i<=n;i++)
		sum[i]=sum[i-1]+a[i];
		
	for(int i=0;i<=n;i++)
		for(int j=0;j<=n;j++)
			dp[i][j]=INF;
	for(int i=1;i<=n;i++)
		dp[i][0]=sum[i]*sum[i];
	
	for(int j=1;j<=n;j++)
	{
		ll mn=INF;
		for(int i=j+1,k=j;i<=n;i++)
		{
			while(k&&sum[j]-sum[k-1]<=sum[i]-sum[j])
				mn=min(mn,dp[j][--k]);
			dp[i][j]=mn+(sum[i]-sum[j])*(sum[i]-sum[j]);
		}
	}
		
	for(int i=0;i<=n;i++)
		ans=min(ans,dp[n][i]);
	cout<<ans<<endl;
	
	return 0;
}
