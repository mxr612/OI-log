#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

typedef long long ll;
const int MAXN=41,MAXM=4,MAXC=21,p=998244353;
int a[MAXN][MAXM];
ll dp[MAXN][MAXN][MAXC][MAXC][MAXC];
int n,m;
ll ans;

inline ll DP(int k,int x,int c1,int c2,int c3)
{
	if(~dp[k][x][c1][c2][c3])	return dp[k][x][c1][c2][c3];
	if(c1+c2+c3>k)	return 0;
	if(c1>k/2||c2>k/2||c3>k/2)	return 0;
	if(x>n) return c1+c2+c3==k;
	
	dp[k][x][c1][c2][c3]=0;
	if(a[x][1])	dp[k][x][c1][c2][c3]+=DP(k,x+1,c1+1,c2,c3);
	if(a[x][2])	dp[k][x][c1][c2][c3]+=DP(k,x+1,c1,c2+1,c3);
	if(a[x][3])	dp[k][x][c1][c2][c3]+=DP(k,x+1,c1,c2,c3+1);
	return dp[k][x][c1][c2][c3];
}

signed main(void)
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&a[i][j]);
	
	memset(dp,-1,sizeof dp);
	
	for(int i=2;i<=n;i++)
		ans=(ans+DP(i,1,0,0,0))%p;
	cout<<ans<<endl;
	
	return 0;
}
