#include<iostream>
#include<cstdio>
using namespace std;
int a[1001][2001],n,m,b[20001];
long long ans=0;
void dfs(int t,int x,int y,int num,int sum,int csp)
{
	if(sum==t)
	{
		ans+=csp;
		ans=ans%998244353;
		return;
	}
	if(x>n||y>m) return;
	for(int i=x+1;i<=n;++i)
	  for(int j=1;j<=m;++j)
	  {
	  	if(b[j]==1&&num+1<=t/2)
	  		dfs(t,i,j,num+1,sum+1,csp*a[i][j]);		  		 	  	
		if(b[j]==0)
		{
			b[j]=1;
			dfs(t,i,j,num,sum+1,csp*a[i][j]);
			b[j]=0;
		}
		  
	  }	    
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;++i)
	  for(int j=1;j<=m;++j)
	    cin>>a[i][j];
	for(int i=2;i<=n;++i)
	  for(int j=1;j<=n;++j)
	    for(int k=1;k<=m;++k)
	    {
	    	b[k]=1;
	    	dfs(i,j,k,1,1,a[j][k]);
	    	b[k]=0;
		}	    	
	cout<<ans;
}
