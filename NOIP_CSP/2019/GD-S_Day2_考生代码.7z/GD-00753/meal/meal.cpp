#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
const long long maxn=998244353;
int n,m,ans=0;
int num[2001];
long long w[101][2001];
bool find(int x,int y)
{
	if(num[y]>=x/2) return true;
	return false;
}
int search(int x,int y1,int y2,int z)
{
	if(!w[y1][y2]) return 0;
	if(x==z) return w[y1][y2];
	else
	{
		int k=0;
		num[y2]++;
		for(int a=1;a<=m;a++)
		{
			if(find(x,a)) continue;
			for(int b=y1+1,tmp;b<=n-x+z+1;b++)
			if(w[b][a])
			{
				tmp=search(x,b,a,z+1);
				k+=tmp;
			}
		}
		num[y2]--;
		return (k*w[y1][y2])%maxn;
	}
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	memset(num, 0 ,sizeof num);
	scanf("%d%d",&n,&m);
	for(int a=1;a<=n;a++)
	 for(int b=1;b<=m;b++) scanf("%lld",&w[a][b]);
	for(int a=2;a<=n;a++)
	for(int b=1;b<=n-a+1;b++)
	for(int c=1;c<=m;c++)  ans=(ans+search(a,b,c,1))%maxn;
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
