#include <cstdio>
using namespace std;
long long n,t;
bool bz[500010];
unsigned long long ans,a[500010];
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf ("%lld %lld",&n,&t);
	if (t==0){
		for (int i=1;i<=n;i++)
			scanf ("%lld",&a[i]);
		if (a[1]>a[2]){
			a[2]+=a[1];
			a[1]=a[2];
			bz[1]=1;
		}
		for (int i=2;i<n;i++){
			if (a[i]<a[i-1]){
				if (a[i-1]+a[i]>a[i+1]){
					a[i+1]+=a[i];
					a[i]=a[i+1];
				}
				else{
					a[i-1]+=a[i];
					a[i]=a[i-1];
				}
				bz[i]=1;
			}
		}
		if (a[n]<a[n-1]){
			a[n-1]+=a[n];
			a[n]=a[n-1];
			bz[n]=1;
		}
		for (int i=1;i<=n;i++){
			printf("%llu ",a[i]);
			if (bz[i]==0)
				ans+=a[i]*a[i];
		}
		printf("\n%llu",ans);
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
