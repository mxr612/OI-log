#include <cstdio>
using namespace std;
int n,m,a[110][1100],ans;
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf ("%d %d",&n,&m);
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
			scanf ("%d",&a[i][j]);
	for (int i=1;i<=n;i++)
	for (int j=1;j<=m;j++){
		for (int k=i+1;k<=n;k++)
		for (int l=1;l<=m;l++)
			if (j!=l)
				ans+=a[i][j]*a[k][l];
	}
	printf("%d",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
