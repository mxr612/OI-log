#include<bits/stdc++.h>
using namespace std;
const int maxn=40000000;
const long long inf=0x7fffffffffffffff;
int n,type,a[maxn+5];
int p,k[maxn+5],sumk[maxn+5];//p�Ƿָ��ĸ�����k[i]�ֱ��ʾ�����ָ���λ��,sumk[i]��ʾ����[k[i-1]+1,k[i]]֮���Ԫ�غ� 
long long suma2,suma[maxn+5];
inline int read(){
	int x=0;
	char c=getchar();
	bool flag=0;
	while(!isdigit(c)&&c!='-')
		c=getchar();
	if(c=='-'){
		flag=1;
		c=getchar();
	}
	do{
		x=(x<<3)+(x<<1)+(48^c);
		c=getchar();
	}while(isdigit(c));
	return ((flag)?(-x):(x));
}
inline void Input(){
	n=read();
	type=read();
	int i;
		for(i=1;i<=n;++i)
			a[i]=read();
}
long long Dfs(int last,long long lastsum,int now,int num){//���������ָ���λ�õķ���,����һ����Сֵ,������Լ��仯 
	if(!num)//û�ָ��������ˣ������Ժ󶼵���һ�������� 
		return (suma[n]-suma[last])*(suma[n]-suma[last]);
	//�зָ����Է���
	long long res=inf,temp;
	if(n-now>num)//��ǰ�㲻����
		res=min(res,Dfs(last,lastsum,now+1,num));
	//��ǰ�����
	if(num==1){
		if(suma[n]-suma[now]>=suma[now]-suma[last]&&suma[now]-suma[last]>=lastsum)
			res=min(res,(suma[now]-suma[last])*(suma[now]-suma[last])+Dfs(now,suma[now]-suma[last],now+1,0));
	}
	else{
		if(suma[now]-suma[last]>=lastsum){//��֤�Ϸ�
			temp=Dfs(now,suma[now]-suma[last],now+1,num-1);
			if(temp!=inf)
				res=min(res,(suma[now]-suma[last])*(suma[now]-suma[last])+temp);
		}
	}
	return res;
}
inline void Work(){
	int i;
	for(i=1;i<=n;++i){
		suma[i]=suma[i-1]+a[i];
		suma2+=a[i]*a[i];
	}
	long long ans=suma[n]*suma[n];
	for(p=1;p<n;++p){
		ans=min(Dfs(0,0,1,p),ans);
	}
	printf("%lld",ans);
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	Input();
	Work();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
#include<bits/stdc++.h>
using namespace std;
const int maxn=5000;
const long long inf=0x3f3f3f3f3f3f3f3f;
int n,type;
long long a[maxn+5],suma[maxn+5],suma2[maxn+5],dp[maxn+5][maxn+5];//suma��ǰ׺�ͣ�suma2��ƽ���� 
inline int read(){
	int x=0;
	char c=getchar();
	bool flag=0;
	while(!isdigit(c)&&c!='-')
		c=getchar();
	if(c=='-'){
		flag=1;
		c=getchar();
	}
	do{
		x=(x<<3)+(x<<1)+(48^c);
		c=getchar();
	}while(isdigit(c));
	return ((flag)?(-x):(x));
}
inline void Input(){
	n=read();
	type=read();
	for(int i=1;i<=n;++i)
		a[i]=read();
}
inline void Work(){
	int i,k,j;
	for(i=1;i<=n;++i){
		suma[i]=suma[i-1]+a[i];
		suma2[i]=suma2[i-1]+a[i]*a[i];
	}
	memset(dp,0x3f,sizeof(dp));
	for(i=1;i<=n;++i)
		dp[i][0]=(suma[n]-suma[i-1])*(suma[n]-suma[i-1]);
	long long ans=dp[1][0];
	for(k=1;k<n;++k){
		dp[n-k][k]=suma2[n]-suma2[n-k-1];//���е㶼�Ƿָ�� 
		for(i=n-k-1;i;--i){
			for(j=i;j<=n-k;++j)
				dp[i][k]=min(dp[i][k],(suma[j]-suma[i-1])*(suma[j]-suma[i-1])+dp[j+1][k-1]);
		}
		ans=min(ans,dp[1][k]);
	}
	printf("%lld",ans);
}
int main(){
	freopen("partition1.in","r",stdin);
//	freopen("partition.out","w",stdout);
	Input();
	Work();
//	fclose(stdin);
//	fclose(stdout);
	return 0;
}*/
