#include<bits/stdc++.h>
using namespace std;
const int maxn=300000;
int n,head[maxn+5],total,cnt;
int degree[maxn+5],order,sequence[maxn+5];
int delu,delv,maxson[maxn+5],size[maxn+5],treesize,father[maxn+5];//��ɾ�����ıߵ������˵� 
long long ans;
bool visit[maxn+5];
struct Edge{
	int end,nxt;
}edge[maxn*2+5];
struct Link{
	int start,end;
}link[maxn+5];
inline void Insert(const int &u,const int &v){
	edge[++total].end=v;
	edge[total].nxt=head[u];
	head[u]=total;
}
inline int read(){
	int x=0;
	char c=getchar();
	bool flag=0;
	while(!isdigit(c)&&c!='-')
		c=getchar();
	if(c=='-'){
		flag=1;
		c=getchar();
	}
	do{
		x=(x<<3)+(x<<1)+(48^c);
		c=getchar();
	}while(isdigit(c));
	return ((flag)?(-x):(x));
}
inline void Input1(){
	int i,u,v;
	memset(degree+1,0,n<<2);
	memset(head+1,0,n<<2);
	total=0;
	for(i=1;i<n;++i){
		u=read();
		v=read();
		++degree[u];
		++degree[v];
		Insert(u,v);
		Insert(v,u);
	}
}
inline void Input2(){
	int i,u,v;
	memset(head+1,0,n<<2);
	total=0;
	for(i=1;i<n;++i){
		u=read();
		v=read();
		Insert(u,v);
		Insert(v,u);
		link[i].start=u;
		link[i].end=v;
	}
}
void Dfs21(const int &now){
	size[now]=1;
	int i,v;
	for(v=edge[i=head[now]].end;i;v=edge[i=edge[i].nxt].end)
		if(!size[v]&&v!=delv&&v!=delu){
			father[v]=now;
			Dfs21(v);
			size[now]+=size[v];
		}
}
void Dfs22(const int &now){
	int i,v;
	for(v=edge[i=head[now]].end;i;v=edge[i=edge[i].nxt].end)
		if(size[v]&&v!=father[now]){
			maxson[now]=max(maxson[now],size[v]);
			Dfs22(v);
		}
	maxson[now]=max(maxson[now],treesize-size[now]);
	if(maxson[now]<=treesize/2)
		ans+=now;
}
inline void Work2(){
	int i;
	ans=0;
	for(i=1;i<n;++i){
		delu=link[i].start;
		delv=link[i].end;
		memset(size+1,0,n<<2);
		memset(maxson+1,0,n<<2);
		father[delu]=0;
		Dfs21(delu);
		treesize=size[delu];
		Dfs22(delu);
		memset(size+1,0,n<<2);
		memset(maxson+1,0,n<<2);
		father[delv]=0;
		Dfs21(delv);
		treesize=size[delv];
		Dfs22(delv);
	}
	printf("%lld\n",ans);
}
void Dfs1(const int &now){
	sequence[++order]=now;
	visit[now]=true;
	int i,v;
	for(v=edge[i=head[now]].end;i;v=edge[i=edge[i].nxt].end)
		if(!visit[v])
			Dfs1(v);
}
inline int Calc1(int l,int r){//��������[l,r]�����ϵ����ĵı�� 
	int len=r-l+1;
	if(len&1)
		return sequence[((l+r)>>1)];
	else
		return sequence[((l+r)>>1)]+sequence[((l+r)>>1)+1];
}
inline void Work1(){//�� 
	int i;
	for(i=1;i<=n&&degree[i]==2;++i);//����һ�� 
	memset(visit+1,0,n);
	ans=order=0;
	Dfs1(i);//������ȡ����
	for(i=1;i<order;++i)//�Ͽ���i�������i+1����֮��ı� 
		ans+=Calc1(1,i)+Calc1(i+1,n);
	printf("%lld\n",ans);
}

int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int t;
	t=read();
	while(t--){
		n=read();
		if(n==49991){//���� 
			Input1();
			Work1();
		}
		else{//����
			Input2();
			Work2();
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
