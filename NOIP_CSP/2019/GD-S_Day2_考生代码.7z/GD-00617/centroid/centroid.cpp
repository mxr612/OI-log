#include<cstdio>
using namespace std;
#define re register
#define in re int
#define il inline
#define rr read()
#define ll long long
#define int ll
#define wr putchar('\n')
#define bl putchar(' ')
il int read()
{
	re char ch;re bool f=0;while((ch=getchar())<'0'||ch>'9')(ch=='-')&&(f=1);
	in x=ch^'0';while((ch=getchar())>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^'0');
	return f?-x:x;
}
il void print(in x)
{
	if(x<0)putchar('-'),x=-x;
	if(x>=10)print(x/10);
	putchar(x%10^'0');
}
#define mm 50001
#define mn 100001
#define max(x,y) (x>y?x:y)
struct edge{
	int from,nex,to;
}ma[mn];
int head[mm],al,siz[mm],m,ans;
il void add(in x,in y){ma[++al].nex=head[x],ma[head[x]=al].to=y;ma[al].from=x;}
void dfs(in u,in fa)
{
	in maxsiz=0;siz[u]=1;
	for(in i=head[u];i;i=ma[i].nex)
	{
		in v=ma[i].to;
		if(v==fa)continue;
		dfs(v,u);
		maxsiz=max(maxsiz,siz[v]);
		siz[u]+=siz[v];
	}
	maxsiz=max(maxsiz,m-siz[u]);
	if(maxsiz<=(m>>1))ans+=u;
}
void dfs1(in u,in fa)
{
	++m;
	for(in i=head[u];i;i=ma[i].nex)
	{
		in v=ma[i].to;
		if(v==fa)continue;
		dfs1(v,u);
	}
}
signed main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	in Q=rr;
	while(Q--)
	{
		in n=rr;al=0;ans=0;
		for(in i=1;i<=n;++i)head[i]=0;
		for(in i=1;i<n;++i)
		{
			in x=rr,y=rr;
			add(x,y),add(y,x);
		}
		for(in i=1;i<=al;i+=2)
		{
			m=0;
			dfs1(ma[i].from,ma[i].to);
			dfs(ma[i].from,ma[i].to);
			m=n-m;dfs(ma[i].to,ma[i].from);
		}
		print(ans),wr;
	}
	return 0;
}
