#include<cstdio>
using namespace std;
#define re register
#define in re int
#define il inline
#define rr read()
#define ll long long
#define int ll
#define wr putchar('\n')
#define bl putchar(' ')
il int read()
{
	re char ch;re bool f=0;while((ch=getchar())<'0'||ch>'9')(ch=='-')&&(f=1);
	in x=ch^'0';while((ch=getchar())>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^'0');
	return f?-x:x;
}
il void print(in x)
{
	if(x<0)putchar('-'),x=-x;
	if(x>=10)print(x/10);
	putchar(x%10^'0');
}
#define mn 101
#define mk 51
#define mm 2001
#define ha 998244353
int ma[mn][mm],num[mm],n,m,o,ans;
void dfs(in x,in alans,in cnt)
{
	if(x>n)
	{
		in r=cnt>>1;
		for(in i=1;i<=m;++i)
			if(num[i]>r)return;
		ans+=alans;
		if(ans>=ha)ans-=ha;
		return;
	}
	if(x<n||(x==n&&cnt))dfs(x+1,alans,cnt);
	for(in i=1,r;i<=m;++i)
		if(ma[x][i]&&num[i]<o)
		{
			++num[i];r=ma[x][i]*alans;
			if(r>=ha)r%=ha;
			dfs(x+1,r,cnt+1);
			--num[i];
		}
}
signed main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=rr,m=rr,o=n>>1;
	for(in i=1;i<=n;++i)
		for(in j=1;j<=m;++j)ma[i][j]=rr;
	dfs(1,1,0);
	print(ans),wr;
	return 0;
}
