#include<cstdio>
using namespace std;
#define re register
#define in re int
#define il inline
#define rr read()
#define ll long long
#define int ll
#define wr putchar('\n')
#define bl putchar(' ')
il int read()
{
	re char ch;re bool f=0;while((ch=getchar())<'0'||ch>'9')(ch=='-')&&(f=1);
	in x=ch^'0';while((ch=getchar())>='0'&&ch<='9')x=(x<<1)+(x<<3)+(ch^'0');
	return f?-x:x;
}
il void print(in x)
{
	if(x<0)putchar('-'),x=-x;
	if(x>=10)print(x/10);
	putchar(x%10^'0');
}
#define mm 500001
#define min(x,y) (x<y?x:y)
int sum[mm],ma[mm],res,ans=4e18+5,n;
void dfs(in star,in lasum)
{
	if(res>ans)return;
	if(star>n)
	{
		ans=min(ans,res);
		return;
	}
	for(in j=star;j<=n;++j)
	{
		in x=sum[j]-sum[star-1];
		if(x<lasum)continue;
		res+=x*x;
		dfs(j+1,x);
		res-=x*x;
	}
}
signed main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=rr;in type=rr;
	for(in i=1;i<=n;++i)ma[i]=rr,sum[i]=sum[i-1]+ma[i];
	for(in i=1;i<=n;++i)
	{
		res=sum[i]*sum[i];
		if(res>=ans)break;
		dfs(i+1,sum[i]);
	}
	print(ans),wr;
	return 0;
}
