#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const long long mod=998244353;
const int N=110,M=2010;
long long n,m,i,j,k,tot,ans,s,t,x,y,z,st;
long long f[N][N],g[N][N][M],a[N][M],h[N];
void read(long long &a) {
	a=0; char c=getchar();
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9') {a=a*10-48+c; c=getchar();}
}
int main() {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	
	read(n); read(m);
	for (i=1;i<=n;i++) {
		h[i]=0;
		for (j=1;j<=m;j++) {
			read(a[i][j]);
			h[i]=h[i]+a[i][j];
		}
		h[i]%=mod;
	}
	
	for (i=0;i<=n;i++) f[i][0]=1;
	for (i=1;i<=n;i++) {
		for (j=1;j<=i;j++) {
			f[i][j]=(f[i-1][j]+f[i-1][j-1]*h[i])%mod;
		}
	}
	
	for (i=1;i<=m;i++) g[0][0][i]=1;
	for (t=1;t<=n;t++) {
		for (i=t;i>=1;i--) {
			st=1; if (st<i-n/2) st=i-n/2;
			for (j=st;j<=i;j++) {
				for (k=1;k<=m;k++) {
					g[i][j][k]=(g[i][j][k]+g[i-1][j][k]*(h[t]-a[t][k]+mod)+g[i-1][j-1][k]*a[t][k])%mod;
				}
			}
			for (k=1;k<=m;k++) g[i][0][k]=(g[i][0][k]+g[i-1][0][k]*(h[t]-a[t][k]+mod))%mod;
		}
	}
	
	ans=0;
	for (i=1;i<=n;i++) {
		ans+=f[n][i];
		for (j=i/2+1;j<=i;j++) {
			for (k=1;k<=m;k++) {
				ans+=mod-g[i][j][k];
			}
		}
		ans%=mod;
	}
	
	printf("%lld\n",ans);
	
	return 0;
}
