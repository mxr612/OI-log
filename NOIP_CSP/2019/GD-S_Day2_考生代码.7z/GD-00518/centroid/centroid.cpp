#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int N=300010;
int n,m,i,j,k,tot,ans,t,x,y,z,T,root;
int q[N*2][2],nex[N*2],head[N],d[N],dep[N];
bool p,bz[N];
long long s;
void read(int &a) {
	char c=getchar(); a=0;
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9') {a=a*10-48+c; c=getchar();}
	return;
}
void dg2(int i) {
	bz[i]=true;
	int j=head[i];
	while (j>0) {
		if (!bz[q[j][1]]) {
			dep[q[j][1]]=dep[i]+1;
			dg2(q[j][1]);
		}
		j=nex[j];
	}
}
int main() {
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	
	read(T);
	for (t=1;t<=T;t++) {
		memset(head,0,sizeof(head));
		memset(d,0,sizeof(d)); memset(bz,false,sizeof(bz));
		
		read(n);
		for (i=1;i<=n-1;i++) {
			read(q[i][0]); read(q[i][1]);
			q[i+n-1][0]=q[i][1]; q[i+n-1][1]=q[i][0];
			d[q[i][0]]++; d[q[i][1]]++;
		}
		for (i=1;i<=2*n-2;i++) {
			nex[i]=head[q[i][0]];
			head[q[i][0]]=i;
		}
		p=true;
		for (i=1;i<=n;i++) {
			if (d[i]==1) root=i;
			if (d[i]>2) p=false;
		}
		if (p==true) {
			s=0;
			dep[root]=1; dg2(root);
			for (i=1;i<=n;i++) {
				x=dep[i];
				if (n-x>x-2&&x-2>=0) s+=(long long)i;
				if (n-x>x-1) s+=(long long)i;
				if (n-x>x) s+=(long long)i;
				if (x-1>n-x-1&&n-x-1>=0) s+=(long long)i;
				if (x-1>n-x) s+=(long long)i;
				if (x-1>n-x+1) s+=(long long)i;
			}
			printf("%lld\n",s);
		}
		else {
		}
	}
	
	return 0;
}
