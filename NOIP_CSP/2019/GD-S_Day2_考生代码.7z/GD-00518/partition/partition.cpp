#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int N=5010;
const long long maxlong=9223372036854775807ll;
long long n,m,i,j,k,tot,ans,t,x,y,z,type;
long long f[N][N],h[N][N],a[N],s[N];
void read(long long &a) {
	a=0; char c=getchar();
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9') {a=a*10-48+c; c=getchar();}
	return;
}
long long sqr(long long x) {return x*x;}
int main() {
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	
	read(n); read(type);
	if (type==0) {
		if (n<=5000) {
			s[0]=0;
			for (i=1;i<=n;i++) {read(a[i]); s[i]=s[i-1]+a[i];}
			for (i=1;i<=n;i++) {
				k=i+1;
				for (j=i;j<=n;j++) {
					while (k<n&&s[j]-s[i-1]>s[k]-s[j]) k++;
					if (s[k]-s[j]>=s[j]-s[i-1]) h[i][j]=k;
				}
			}
			
			for (i=1;i<=n;i++)
				for (j=1;j<=n;j++) f[i][j]=maxlong;
			
			for (i=1;i<=n;i++) {
				for (j=i;j<=n;j++) {
					if (f[i][j-1]!=maxlong) {
						x=f[i][j-1]+sqr(a[j])+2*a[j]*(s[j-1]-s[i-1]);
						if (f[i][j]>x) f[i][j]=x;
					}
					if (h[i][j]==0||f[i][j]==maxlong) continue;
					x=f[i][j]+sqr(s[h[i][j]]-s[j]);
					if (f[j+1][h[i][j]]>x) f[j+1][h[i][j]]=x;
				}
			}
			ans=maxlong;
			for (i=1;i<=n;i++) if (f[i][n]<ans) ans=f[i][n];
			printf("%lld\n",ans);
		}
	} 
	
	return 0;
}
