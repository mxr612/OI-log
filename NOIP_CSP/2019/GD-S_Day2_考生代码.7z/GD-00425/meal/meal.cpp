#include<cstdio>
#include<cstring>
using namespace std;
int an[1000],d1[200005],d2[200005],d3[200005],len,gg,n,m,mp[105][2005],flag[2005],vis[105],ans;
void bfs(int x,int lim,int v){
	if(x > lim){
		ans = (ans+v)%998244353;
		return;
	}
		for(int i = 1; i <= len; ++i){
			if(vis[d1[i]] == 1 || flag[d2[i]]+1 > lim/2) continue;
			vis[d1[i]] = 1;
			flag[d2[i]]++;
			bfs(x+1,lim,v*d3[i]);
			vis[d1[i]] = 0;
			flag[d2[i]]--;
		}
}
int calc(int x){
	int s = 1;
	if(x == 0) return 1;
	for(int i = 1; i <= x; ++i) s *= i;
	return s;
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 1; i <= n; ++i)
		for(int j = 1; j <= m; ++j){
			scanf("%d",&mp[i][j]);
			len++;
			d1[len] = i;
			d2[len] = j;
			d3[len] = mp[i][j];
		}
	for(int k = 2; k <= n; ++k){
		ans = 0;
		memset(vis,0,sizeof(vis));
		memset(flag,0,sizeof(flag));
		bfs(1,k,1);
		an[k] = ans/calc(k);
	}
	int gg = 0;
	for(int i = 2; i <= n; ++i) gg += an[i];
	printf("%d",gg);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
