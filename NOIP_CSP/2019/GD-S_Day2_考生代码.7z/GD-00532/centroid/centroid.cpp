#include<cstdio>
#include<cstring>
#define N 300001
using namespace std;
int total1,times,n;
bool bz[N],side[N];
int maxs[N],size[N];
int xs[N],ys[N],bian[N];
int next[N],head[N],edge[N];
void insert(int x,int y)
{
	total1++;
	next[total1]=head[x];
	head[x]=total1;
	edge[total1]=y;
}
void dfs(int x,int k,bool bo)
{
	side[x]=bo;
	maxs[x]=0;
	size[x]=1;
	for (int i=head[x];i;i=next[i])
	{
		int y=edge[i];
		if ((!bz[i])||y==k) continue;
		dfs(y,x,bo);
		size[x]+=size[y];
		if (maxs[x]<size[y]) maxs[x]=size[y];
	}
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int times;
	scanf("%d",&times);
	while (times)
	{
		times--;
		scanf("%d",&n);
		memset(head,0,sizeof(head));memset(next,0,sizeof(next));memset(edge,0,sizeof(edge));
		total1=1;
		for (int i=1;i<n;i++) 
		{
			int x,y;
			bian[i]=total1+1;
			scanf("%d%d",&x,&y);
			xs[i]=x,ys[i]=y;
			insert(x,y);insert(y,x);
		}
		memset(bz,true,sizeof(bz));
		int ans=0;
		for (int i=1;i<n;i++)
		{
			bz[bian[i]]=bz[bian[i]^1]=false;
			for (int j=1;j<=n;j++) size[j]=maxs[j]=0;
			for (int j=1;j<=n;j++) side[j]=false;
			dfs(xs[i],0,true);
			dfs(ys[i],0,false);
			bz[bian[i]]=bz[bian[i]^1]=true;
			for (int j=1;j<=n;j++)
			{
				int p=0;
				if (side[j]) p=size[xs[i]]-size[j];
				else	p=size[ys[i]]-size[j];
				if (maxs[j]<p) maxs[j]=p;
				if (maxs[j]<=(p+size[j])/2) ans+=j;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
