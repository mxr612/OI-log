#include<cstdio>
#define N 4000001
using namespace std;
int father[N];
long long a[N],size[N],qz[N],f[101][50001];
int n,type;
long long min(long long x,long long y)
{
	if (x<y) return  x;
	return y;
}
int getfather(int x)
{
	if (father[x]==x) return x;
	return getfather(father[x]);
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	if (n<=50)
	{
		
		for (int i=1;i<=n;i++) 
			scanf("%lld",&a[i]);
		for (int i=1;i<=n;i++) qz[i]=qz[i-1]+a[i];
		int sum=0;
		for (int i=1;i<=n;i++) sum+=a[i];
		for (int i=1;i<=n;i++)
			for (int j=0;j<=sum;j++) f[i][j]=1e9;
		f[0][0]=1;
		for (int i=1;i<=n;i++)
		{
			for (int j=1;j<=sum;j++)
			{
				for (int k=1;k<=i;k++)
				{
					if (qz[i]-qz[k-1]!=j) continue;
					for (int p=0;p<=j;p++)
					{
						f[i][j]=min(f[i][j],f[k-1][p]+(j*j));
						if(i==n&&j==163&&f[i][j]==42450)
						{
							sum++;sum--;
						}
					}
				}
			}
		}
		long long mins=1e9;
			for (int j=1;j<=sum;j++)
			{
			//	if (f[n][j]==42450)
			//	printf("%d %d\n",j,f[n][j]);
				mins=min(mins,f[n][j]);
			}
		printf("%lld\n",mins);
		return 0;
	}
	if (type==0)
	{
		for (int i=1;i<=n;i++) 
			scanf("%lld",&a[i]);
		int last=0;
		for (int i=0;i<=n;i++) father[i]=i,size[i]=a[i];
		a[n+1]=1e18;
		for (int i=1;i<=n;i++)
		{
			if (i==n)
			{
				i++;i--;                
			}
			int u=getfather(last);
			int v=getfather(i);
			if (size[u]<=size[v])
			{
				last=v;continue;
			}
			if (size[u]<a[i+1])
			{
				father[i]=u;
				size[u]+=size[v];
			}
			else 
			{
				father[i]=i+1;
				size[i+1]+=size[v];	
			}
		}
		last=0;
		long long ans=0;
		for (int i=1;i<=n;i++)
		{
			int u=getfather(i);
		//	if (u!=last) printf("%d ",size[u]);
			if (u!=last) ans=ans+size[u]*size[u],last=u;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
