#include<cstdio>
#include<cstring>
#define N 101
#define M 2001
#define mod 998244353
using namespace std;
int n,m;
int a[N][M];
long long sum[N],f[N][N][N],g[N][N];
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++) scanf("%d",&a[i][j]);
	memset(sum,0,sizeof(sum));
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++) sum[i]=(sum[i]+a[i][j])%mod;
	long long ans=0;
	memset(g,0,sizeof(g));
	g[0][0]=1;
	for (int i=1;i<=n;i++)
	{
		g[i][0]=g[i-1][0];
		for (int j=1;j<=n;j++)
			g[i][j]=(g[i-1][j]+g[i-1][j-1]*sum[i]%mod)%mod;
	}
	for (int i=1;i<=n;i++)
		ans=(ans+g[n][i])%mod;
	for (int i=1;i<=m;i++)
	{
		for (int j=0;j<=n;j++)
			for (int k=0;k<=n;k++) f[0][j][k]=0;
		for (int j=0;j<=n;j++)
			f[j][0][0]=1;
		for (int j=1;j<=n;j++)
		{
			for (int k=1;k<=j;k++)
			{
				int start=k/2-(n-j);
				if (start<=0) start=0;
				for (int p=start;p<=k;p++)
				{
					f[j][k][p]=f[j-1][k][p];
					f[j][k][p]=(f[j][k][p]+f[j-1][k-1][p]*(sum[j]-a[j][i])%mod);
					if (f[j][k][p]>mod) f[j][k][p]-=mod;
					if (p!=0)
					{
						f[j][k][p]=(f[j][k][p]+f[j-1][k-1][p-1]*a[j][i]%mod);
						if (f[j][k][p]>mod) f[j][k][p]-=mod;
					}
				} 
			}
		}
		long long total=0;
		for (int j=1;j<=n;j++)
		{
			for (int k=j/2+1;k<=j;k++) total=(total+f[n][j][k])%mod;
		}
		ans=(ans-total+mod)%mod;
	}
	printf("%lld\n",ans);
//	printf("%d\n",sizeof(f)/(2<<10));
	return 0;
}
