#include<iostream>
#include<stdio.h>
using namespace std;
int t,n,fa[50000],x,y,a,b;
long long ans;
void huan(){
	int tmp=x;
	x=y,y=tmp;
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1;i<n;++i){
			scanf("%d%d",&x,&y);
			if(x>y) huan();
			fa[y]=x;
		}
		ans=0;
		for(int i=1;i<n;++i){
			x=i,y=n-i;
			if(x%2==0){
				a=x/2,b=x/2+1;
				ans=ans+a+b;
			}
			else{
				a=x/2+1;
				ans+=a;
			}
			if(y%2==0){
				a=y/2,b=y/2+1;
				ans=ans+a+b+2*x;
			}
			else{
				a=y/2+1;
				ans=ans+a+x;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
