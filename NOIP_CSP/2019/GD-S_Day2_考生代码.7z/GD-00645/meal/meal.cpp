#include<iostream>
#include<stdio.h>
#define mo 998244353
using namespace std;
long long k,n,m,a[105][2005],p,u[105],ans;
void dfs(long long d,long long g,long long flag){
	if(flag>=k){
		ans=(ans+g)%mo;
		return;
	}
	if(d>n) return;
	for(int i=1;i<=m;++i){
		if(!a[d][i] || u[i]+1>p) continue;
		u[i]++;
		dfs(d+1,(g*a[d][i])%mo,flag+1);
		u[i]--;
	}
	if(k-flag<=n-d) dfs(d+1,g,flag);
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			scanf("%lld",&a[i][j]);
		}
	}
	for(k=2;k<=n;++k){
		p=k/2;
		dfs(1,1,0);
	}
	cout<<ans;
	return 0;
}
