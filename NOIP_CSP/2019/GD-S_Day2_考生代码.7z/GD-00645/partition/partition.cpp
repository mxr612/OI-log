#include<iostream>
#include<stdio.h>
#define N 40000005
using namespace std;
int u[N],n,a[N],type,flag=1,f,k;
unsigned long long ans=-1,tmp=0;
void dfs(int d,int g){
	if(d>n){
		if(g<=0){
			f=1,k=0,tmp=0;
			for(int i=1;i<=n;++i){
				if(u[i]) continue;
				tmp+=a[i]*a[i];
				if(a[i]<a[k]) f=0;
				k=i;
			}
			if(tmp<=ans && f) flag=1,ans=tmp;
		}
		return;
	}
	if(a[d]>=a[d-1]) dfs(d+1,g);
	else if(g){
		if(d>1){
			a[d-1]+=a[d];
			u[d]=1;
			dfs(d+1,g-1);
			u[d]=0;
			a[d-1]-=a[d];
		}
		if(d<n){
			a[d+1]+=a[d];
			u[d]=1;
			dfs(d+1,g-1);
			u[d]=0;
			a[d+1]-=a[d];
		}	
	}
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	if(!type){
		for(int i=1;i<=n;++i) scanf("%d",&a[i]);
	}
	for(int i=1;i<=n;++i){
		if(a[i]<a[i-1]) flag=0;
	}
	if(flag){
		ans=0;
		for(int i=1;i<=n;++i)
			ans=ans+a[i]*a[i];
		cout<<ans;
		return 0;
	}
	for(int c=1;c<n;++c){
		dfs(1,c);
		if(flag){
			cout<<ans;
			return 0;
		}
	}
	return 0;
}
