#include<cstdio>
#include<cstring>
#define RI register int

const int MAXN=300000;//299995

int book[MAXN],book1[MAXN],head[MAXN];
int id=1,n,t,ii,io,ans,num=1,tn;
int flag;

struct edge{
	int i;
	int o;
	int next;
}edge[MAXN];

void add(int i,int o){
	edge[id].o=o;
	edge[id].i=i;
	edge[id].next=head[i];
	head[i]=id;
	id++;
}

int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&t);
	for(RI ti=0;ti<t;ti++){
		id=1;
		ans=0;
		scanf("%d",&n);
		for(RI i=1;i<=n-1;i++){
			scanf("%d %d",&ii,&io);
			add(ii,io);
		}
		for(RI d=1;d<id;d++){
			ans+=(1+edge[d].i)/2+(edge[d].o+n)/2+((1+edge[d].i)%2 ? 1+(1+edge[d].i)/2 : 0)+((n+edge[d].o)%2 ? (n+edge[d].o)/2+1 :0);
		}
		printf("%d\n",ans);
	}
	return 0;
}
