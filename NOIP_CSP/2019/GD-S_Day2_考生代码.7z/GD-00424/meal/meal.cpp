#include<cstdio>
#define RI register int

using namespace std;

const int MAXN=110,MAXM=2010,MOD=998244353;
int menu[MAXN][MAXM],nbook[MAXN],mbook[MAXM];
int n,m;
long long ans,tans;

void dfs(int step,int total,int lasti){
	if(step>total){
		ans=(ans+tans)%MOD;
		return;
	}
	for(RI i=lasti+1;i<=n;i++){ //ö�ٷ��� 
		for(RI j=1;j<=m;j++){ //ö��ʳ�� 
			if(menu[i][j]>0 && mbook[j]<total/2){
				tans*=menu[i][j];
				mbook[j]++;
				dfs(step+1,total,i);
				mbook[j]--;
				tans/=menu[i][j];
			}
		}
	}
}

int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(RI i=1;i<=n;i++){
		for(RI j=1;j<=m;j++){
			scanf("%d",&menu[i][j]);
		}
	}
	for(RI total=2;total<=n;total++){ //�ܹ������� 
		tans=1;
		dfs(1,total,0);
	}
	printf("%lld",ans);
	return 0;
}
