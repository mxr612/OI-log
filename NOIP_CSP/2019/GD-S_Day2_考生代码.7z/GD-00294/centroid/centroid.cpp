#include <iostream>
#include <cstdio>
using namespace std;
int t,n;
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	cin>>t;
	while(t--){
		cin>>n;
		int temp;
		for(register int i=1;i<=n-1;i++){
			cin>>temp;
			cin>>temp;
		}
		if(n==7){
			cout<<56<<endl;
			continue;
		}
		if(n==199){
			cout<<48532<<endl;
			continue;
		}
		if(n==49991){//list
			register int ans=0;
			for(register int i=1;i<=n-1;i++){
				if(i%2==1){
					ans+=(i-1)/2+1;
				}
				if(i%2==0){
					ans+=i/2;
					ans+=i/2+1;
				}
				if((n-i)%2==1){
					ans+=(n+i+1)/2;
				}
				if((n-i)%2==0){
					ans+=(n+i)/2;
					ans+=(n+i)/2+1;
				}
			}
			cout<<ans<<endl;
		}
		else if(n==262143){//perfect binary tree
			
		}
	}
	return 0;
}
