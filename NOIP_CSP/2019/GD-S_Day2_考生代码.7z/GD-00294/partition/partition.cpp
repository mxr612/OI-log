#include <iostream>
#include <cstdio>
using namespace std;
int n,type,a[40000005],b[40000005],p[100005],l[10005],r[10005];
typedef unsigned long long ull;
inline int read(){
	register int x=0;
	register char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<3)+(x<<1)+(ch^48);
		ch=getchar();
	}
	return x;
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=read(),type=read();
	if(type==0){
		for(register int i=1;i<=n;i++) a[i]=read();
	}
	if(type==1){
		int x=read(),y=read(),z=read();
		b[1]=read(),b[2]=read();
		int m=read();
		for(register int i=1;i<=m;i++){
			p[i]=read();
			l[i]=read();
			r[i]=read();
		}
		for(register int i=3;i<=n;i++){
			b[i]=(x*b[i-1]+y*b[i-2]+z)%1073741824;
			for(register int j=1;j<=m;j++){
				if(p[j-1]<i&&i<=p[j]){
					a[i]=(b[i]%(r[j]-l[j]+1))+l[j];
					break;
				}
			}
		}
	}
	for(register int i=1;i<=n;i++){
		if(i>=1&&a[i]<=a[i-1]&&a[i]<=a[i+1]&&a[i]!=0){
			if(a[i]+a[i-1]>a[i+1]){
				a[i+1]+=a[i];
				a[i]=0;
			}
			else{
				a[i-1]+=a[i];
				a[i]=0;
			}
			i-=2; 
		}
		if(i==n&&a[i]<a[i-1]){
			a[i-1]+=a[i];
			a[i]=0;
		}
	}
	register ull ans=0;
	for(register int i=1;i<=n;i++){
		ans+=(ull)(a[i])*a[i];
	}
	cout<<ans;
	return 0;
}
