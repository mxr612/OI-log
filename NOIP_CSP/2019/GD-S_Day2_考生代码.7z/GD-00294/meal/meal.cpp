#include <iostream>
#include <cstdio>
using namespace std;
typedef unsigned long long ull;
int n,m,k,a[105][1005],counter[1005],per[105];
ull ans;
inline int read(){
	register int x=0;
	register char ch=getchar();
	while(ch<'0'||ch>'9') ch=getchar();
	while(ch>='0'&&ch<='9'){
		x=(x<<3)+(x<<1)+(ch^48);
		ch=getchar();
	}
	return x;
}
void dfs(const int x){
	if(x==n){
		if(k<=1) return;
		register ull res=1;
		for(register int i=1;i<=x;i++){
			if(per[i]==0) continue;
			if(a[i][per[i]]==0) return;
			if(counter[per[i]]>k/2) return;
			res*=a[i][per[i]];
			res%=998244353;
		}
		ans+=res;
		ans%=998244353;
		return;
	}
	for(register int i=0;i<=m;i++){
		counter[i]++;
		per[x+1]=i;
		if(i) k++;
		dfs(x+1);
		if(i) k--;
		counter[i]--;
	}
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read(),m=read();
	for(register int i=1;i<=n;i++){
		for(register int j=1;j<=m;j++){
			a[i][j]=read();
		}
	}
	dfs(0);
	cout<<ans;
	return 0;
} 
/*
5 5
1 0 0 1 1
0 1 0 1 0
1 1 1 1 0
1 0 1 0 1
0 1 1 0 1
*/
