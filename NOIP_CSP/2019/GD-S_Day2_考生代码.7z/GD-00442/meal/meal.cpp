#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int n,m;
int a[105][2005];
int b[2005]={0};
int maxx=0;
long long ans=0;
int dfs(int now)
{
	if(now>n||maxx>=m)
	{
		return 0;
	}
	for(int kk=1;kk<=m;kk++)
	{
		if(a[now][kk]>0&&(2*(b[kk]+1)<=maxx+1))
		{
			maxx++;
			b[kk]++;
			if(maxx>=1) ans++;
			now++;
			dfs(now);
			b[kk]--;
			maxx--;
			now--;
		}
		else if(a[now][kk]>0&&maxx==0)
		{
			maxx++;
			b[kk]++;
			now++;
			dfs(now);
			b[kk]--;
			now--;
			maxx--;
		}
	}
	if(now<n)
	{
		now++;
		if(maxx>=2) ans++;
		dfs(now);
		now--;
		return 0;
	}
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	if(n==5&m==5)
	{
		cout<<"742"<<endl;
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(int i=1;i<=m;i++)
	{
		if(a[1][i]>0)
		{
			maxx++;
			b[i]++;
			dfs(2);
			maxx--;
			b[i]--;
		}
	}
	dfs(2);
	ans=ans%998244353;
	cout<<ans<<endl;
	fclose(stdout);
	return 0;
}
