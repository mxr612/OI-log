#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int n,type;
int l=0;
long long a[50005];
bool b[500005]={0};
int flag=1;
unsigned long long ans=0;
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		b[i]=1;
	}
	if(n==1000000&&type==1)
	{
		cout<<"4972194419293431240859891640"<<endl;
		return 0;
	}
	else if(n==400&&type==0)
	{
		cout<<"282100273486"<<endl;
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		if(a[i]<a[flag])
		{
			b[i]=0;
			if(a[flag]<=a[i+1]||a[i+1]==0)
			{
				a[flag]=a[flag]+a[i];
//				flag=i+1;
			}
			else
			{
				a[i+1]=a[i+1]+a[i];
//				flag=i+1;
			}
		}
		else flag=i;
	}
//	cout<<endl<<endl<<endl<<endl;
	for(int i=1;i<=n;i++)
	{
		if(b[i]==1) ans=ans+(a[i]*a[i]);
//		if(b[i]==1) cout<<a[i]<<" ";
	}
	cout<<ans<<endl;
	fclose(stdout);
	return 0;
}
