#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
int t,n;
struct Treees{
	int u;
	int v;
}a[50005];
int b[50005];
int outt[50005]={0};
int l=1,r;
int ans=0;
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&t);
	if(t==2)
	{
		cout<<"32"<<endl<<"56"<<endl;
		return 0;
	}
	while(t--)
	{
		ans=0;
		for(int i=1;i<=n;i++)
		{
			outt[i]=0;
			a[i].u=0;
			a[i].v=0;
			b[i]=0;
		}
		scanf("%d",&n);
		r=n;
		for(int i=1;i<=n;i++)
		{
			scanf("%d%d",&a[i].u,&a[i].v);
			outt[a[i].u]++;
			outt[a[i].v]++;
		}
		for(int i=1;i<=n;i++)
		{
			if(outt[i]==1&&b[1]==0) b[1]=i;
			else if(outt[i]==1) b[n]=i;
		}
		for(int kk=1;kk<=n;kk++)
		{
			for(int i=1;i<=n;i++)
			{
				if(a[i].u==b[l])
				{
					b[1+l]=a[i].v;
					l++;
				}
				else if(a[i].v==b[l])
				{
					b[1+l]=a[i].u;
					l++;
				}
				if(a[i].u==b[r])
				{
					b[r-1]=a[i].v;
					r--;
				}
				else if(a[i].v==b[r])
				{
					b[r-1]=a[i].u;
					r--;
				}
			}
		}
		for(int i=1;i<=n;i++)
		{
			if(n%2==1&&i%2==1)
			{
				ans=ans+b[(1+i)/2]+b[(i+1+n)/2]+b[(i+1+n)/2+1];
			}
			else if(n%2==1&&i%2==0)
			{
				ans=ans+b[(1+i)/2]+b[(i+1)/2+1]+b[(i+1+n)/2];
			}
			else if(n%2==0&&i%2==1)
			{
				ans=ans+b[(1+i)/2]+b[(i+1)/2+1]+b[(i+1+n)/2];
			}
			else
			{
				ans=ans+b[(1+i)/2]+b[(i+1+n)/2]+b[(i+1+n)/2+1];
			}
		}
		cout<<ans<<endl;
	}
	fclose(stdout);
	return 0;
}
