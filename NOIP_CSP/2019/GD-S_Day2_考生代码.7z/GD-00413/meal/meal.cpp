#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#define LL long long
#define db double
#define ms(i, j) memset(i, j, sizeof i)
#define FN2 "meal"
using namespace std;

namespace flyinthesky {
	
	const LL MO = 998244353;
	
	int n, m, gg[42][12];
	LL dp[42][42][42][42];

	void clean() {
	}
	void solve() {
		
		clean();
		scanf("%d%d", &n, &m);
		for (int i = 1; i <= n; ++i) {
			for (int j = 1; j <= m; ++j) {
				scanf("%d", &gg[i][j]);
			}
		}
		dp[0][0][0][0] = 1;
		m = 3;
		for (int i = 1; i <= n; ++i) {
			/*dp[i][1][0][0] = gg[i][1];
			dp[i][0][1][0] = gg[i][2];
			dp[i][0][0][1] = gg[i][3];*/
			for (int a = 0; a <= n; ++a) {
				for (int b = 0; b <= n; ++b) {
					for (int c = 0; c <= n; ++c) {
						(dp[i][a][b][c] += dp[i - 1][a][b][c]) %= MO; 
						if (a >= 1) (dp[i][a][b][c] += (dp[i - 1][a - 1][b][c] * gg[i][1]) % MO) %= MO;
						if (b >= 1) (dp[i][a][b][c] += (dp[i - 1][a][b - 1][c] * gg[i][2]) % MO) %= MO;
						if (c >= 1) (dp[i][a][b][c] += (dp[i - 1][a][b][c - 1] * gg[i][3]) % MO) %= MO;
					}
				}
			}
		}
		LL ans = 0;
		for (int k = 2; k <= n; ++k) {
			for (int a = 0; a <= k / 2; ++a) {
				for (int b = 0; b <= k / 2; ++b) {
					for (int c = 0; c <= k / 2; ++c) {
						if (a + b + c == k) (ans += dp[n][a][b][c]) %= MO;
					}
				}
			}
		}
		printf("%lld\n", ans);
	}

}
int main() {
	freopen(FN2".in", "r", stdin); freopen(FN2".out", "w", stdout);
	flyinthesky::solve();
	return 0;
}
