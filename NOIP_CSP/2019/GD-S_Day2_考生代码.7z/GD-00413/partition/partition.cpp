#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#define LL long long
#define db double
#define ms(i, j) memset(i, j, sizeof i)
#define FN2 "partition"
using namespace std;

namespace flyinthesky {

	int n, ty, b[5005];
	LL ans = 5e18;
	
	void dfs(int a, LL sum, LL lst, LL cst) {
		if (a == n + 1) {
			if (sum < lst) return ;
			cst += sum * sum;
			ans = min(ans, cst);
			return ;
		}
		dfs(a + 1, sum + b[a], lst, cst);
		if (sum >= lst) dfs(a + 1, b[a], sum, cst + sum * sum);
	}

	void clean() {
	}
	void solve() {
		
		clean();
		scanf("%d%d", &n, &ty);
		for (int i = 1; i <= n; ++i) scanf("%d", &b[i]);
		dfs(1, 0, 0, 0);
		printf("%lld\n", ans);
	}

}
int main() {
	freopen(FN2".in", "r", stdin); freopen(FN2".out", "w", stdout);
	flyinthesky::solve();
	return 0;
}
