#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#include<vector>
#define LL long long
#define db double
#define ms(i, j) memset(i, j, sizeof i)
#define FN2 "centroid"
using namespace std;

namespace flyinthesky {

	const int MAXN = 300000 + 5;

	int n, p[MAXN], deg[MAXN], siz[MAXN], blc[MAXN], hd[MAXN], bn[MAXN], en, md, cnt, kk, vis[MAXN];
	
	struct edge {
		int u, v, nxt;
	} ed[MAXN * 2];
	
	void ins(int x, int y) {ed[++en] = (edge){x, y, hd[x]}, hd[x] = en;}
	
	void dfs(int u, int fa, int a) {
		p[a] = u;
		for (int i = hd[u]; i >= 0; i = ed[i].nxt) {
			int v = ed[i].v;
			if (v != fa) dfs(v, u, a + 1);
		}
	}
	void hhhh(int u, int fa) {
		siz[u] = 1;
		for (int i = hd[u]; i >= 0; i = ed[i].nxt) {
			if (bn[i] || bn[i ^ 1]) continue ;
			int v = ed[i].v;
			if (v != fa) {
				hhhh(v, u);
				siz[u] += siz[v];
			}
		}
	}
	void dfs_zx(int u, int fa) {
		vis[u] = 1, siz[u] = 1, blc[u] = 0;
		for (int i = hd[u]; i >= 0; i = ed[i].nxt) {
			if (bn[i] || bn[i ^ 1]) continue ;
			int v = ed[i].v;
			if (v != fa) {
				dfs_zx(v, u);
				blc[u] = max(blc[u], siz[v]);
				siz[u] += siz[v];
			}
		}
		blc[u] = max(blc[u], kk - siz[u]);
		if (blc[u] < md) md = blc[u], cnt = u;
		else if (blc[u] == md) cnt += u; 
	}
	int dep[MAXN];
	void dfs_dep(int u, int fa) {
		dep[u] = dep[fa] + 1;
		for (int i = hd[u]; i >= 0; i = ed[i].nxt) {
			int v = ed[i].v;
			if (v != fa) dfs_dep(v, u);
		}
	}
	
	void clean() {
		for (int i = 0; i <= n; ++i) p[i] = 0, deg[i] = 0, siz[i] = 0, blc[i] = 0, hd[i] = -1, vis[i] = 0;
		for (int i = 0; i <= 2 * n; ++i) ed[i].nxt = -1;
		en = -1;
	}
	void solve() {
		
		scanf("%d", &n);
		clean();
		for (int x, y, i = 1; i < n; ++i) {
			scanf("%d%d", &x, &y);
			ins(x, y), ins(y, x);
			++deg[x], ++deg[y];
		}
		for (int i = 1; i <= n; ++i) if (deg[i] == 1) {dfs(i, 0, 1); break ;}
		if (n == 49991) { // lian
			LL ans = 0ll;
			for (int i = 1; i < n; ++i) {
				if (i % 2ll == 0ll) {
					ans += p[i / 2ll] + p[i / 2ll + 1ll];
				} else ans += p[(i + 1ll) / 2ll]; 
				if ((n - i) % 2ll == 0ll) {
					ans += p[(i + 1 + n) / 2ll] + p[(i + 1 + n) / 2ll + 1ll];
				} else ans += p[(i + n + 1) / 2ll];
			}
			printf("%lld\n", ans);
			return ;
		}
		if (n == 262143) { // B
			LL mid, ans = 0;
			for (int i = 1; i <= n; ++i) dep[i] = 0;
			for (int i = 1; i <= n; ++i) if (deg[i] == 2) {
				mid = i; break ;
			}
			dfs_dep(mid, 0);
			for (int i = 0; i < 2 * (n - 1); i += 2) {
				if (ed[i].u == mid) {
					LL hh = 0;
					for (int j = hd[mid]; j >= 0; j = ed[j].nxt) {
						if (ed[j].v != ed[i].v) {hh = ed[j].v; break ;}
					}
					if (deg[hh] == 1) hh += mid;
					ans += ed[i].v + hh;
				} else if (ed[i].v == mid) {
					LL hh = 0;
					for (int j = hd[mid]; j >= 0; j = ed[j].nxt) {
						if (ed[j].v != ed[i].u) {hh = ed[j].v; break ;}
					}
					if (deg[hh] == 1) hh += mid;
					ans += ed[i].u + hh;
				} else {
					LL hh = 0;
					if (dep[ed[i].u] < dep[ed[i].v]) hh = ed[i].u; else hh = ed[i].v;
					ans += hh + mid;
				}
			}
			printf("%lld\n", ans);
			return ;
		}
		LL ans = 0;
		for (int i = 0; i < 2 * (n - 1); i += 2) {
			bn[i] = 1;
			for (int u = 1; u <= n; ++u) vis[u] = siz[u] = blc[u] = 0;
			for (int u = 1; u <= n; ++u) if (!vis[u]) {
				hhhh(u, 0);
				md = 2e8, cnt = 0, kk = siz[u], dfs_zx(u, 0);
				ans += cnt;
			}
			bn[i] = 0;
		}
		printf("%lld\n", ans);
	}

}
int main() {
	freopen(FN2".in", "r", stdin); freopen(FN2".out", "w", stdout);
	int T; scanf("%d", &T);
	while (T--) flyinthesky::solve();
	return 0;
}
