#include<cstdio>
#include<cstring>
using namespace std;

void read_int (int &a) {
	char c=getchar(); a=0;
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9') a=(a<<1)+(a<<3)-48+c,c=getchar();
	return;
}

struct node {
	int point,next;
	bool able;
} r[600003]; int tot,last[300002];

void link (int x,int y) {
	r[++tot].point=y; r[tot].next=last[x]; last[x]=tot; r[tot].able=true;
	r[++tot].point=x; r[tot].next=last[y]; last[y]=tot; r[tot].able=true;
	return;
}

int n,size[300002];


int use[300002],flag=0;
int track[300002],_i[300002],top;

int get_size (int root) {
	int left=0,right=1;
	track[1]=root;
	use[root]=++flag;
	while (left<right) {
		++left;
		for (int i=last[track[left]];i;i=r[i].next)
		if (use[r[i].point]!=flag&&r[i].able) {
			track[++right]=r[i].point;
			use[r[i].point]=flag;
		}
	} return right;
}

int calc (int root) {
	int n=get_size(root),ans=0,value;
	track[top=1]=root;
	_i[top]=last[root];
	size[root]=-1;
	while (top) {
		if (_i[top]) {
			if (r[_i[top]].able&&~size[r[_i[top]].point]) {
				track[top+1]=r[_i[top]].point;
				_i[top+1]=last[r[_i[top]].point];
				_i[top]=r[_i[top]].next;
				size[track[++top]]=-1;
				continue;
			}
			_i[top]=r[_i[top]].next;
			continue;
		}
		value=size[track[top]]=0;
		for (int i=last[track[top]];i;i=r[i].next)
		if (~size[r[i].point]&&r[i].able) {
			if (value<size[r[i].point])
				value=size[r[i].point];
			size[track[top]]+=size[r[i].point];
		}
		++size[track[top]];
		if (value<n-size[track[top]])
			value=n-size[track[top]];
		if (value<=n/2)
			ans+=track[top];
		--top;
	} return ans;
}

int degree[300002];
bool special_type () {
	int root,s1=0,s2=0;
	for (int i=1;i<=n;i++) {
		if (degree[i]==1) ++s1,root=i;
		if (degree[i]==2) ++s2;
	}
	if (s1!=2||s2!=n-2) return false;
	top=1; track[1]=root;
	use[root]=++flag;
	for (int p=1;p<n;p++)
		for (int i=last[track[p]];i;i=r[i].next)
		if (use[r[i].point]!=flag) {
			use[r[i].point]=flag;
			track[p+1]=r[i].point;
		}
	long long ans=0;
	for (int i=1;i<n;i++) {
		if (i%2==0) ans+=track[i/2]+track[i/2+1];
		else ans+=track[i/2+1];
		if ((n-i)%2==0) ans+=track[i+(n-i)/2]+track[i+(n-i)/2+1];
		else ans+=track[i+(n-i)/2+1];
	} printf("%lld\n",ans);	return true; 
}

void solve () {
	read_int(n); tot=1;
	for (int i=1;i<=n;i++)
		last[i]=size[i]=degree[i]=0;
	int x,y;
	for (int i=1;i<n;i++) {
		read_int(x); read_int(y);
		++degree[x]; ++degree[y];
		link(x,y);
	}
	
	if (special_type()) return;
	
	long long ans=0;
	for (int i=1;i<n;i++) {
		r[i<<1].able=false;
		r[i<<1|1].able=false;
		ans+=calc(r[i<<1].point)+calc(r[i<<1|1].point);
		r[i<<1].able=true;
		r[i<<1|1].able=true;
	} printf("%lld\n",ans); return;
}

int main () {
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	
	int T; read_int(T);
	while (T--)
		solve();
	
	fclose(stdin); fclose(stdout);
	return 0;
}
