#include<cstdio>
using namespace std;

const int mod=998244353;

void read_int (int &a) {
	char c=getchar(); a=0;
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9') a=(a<<1)+(a<<3)-48+c,c=getchar();
	return;
}

int n,m,ans,a[102][2002],sum[102];
int p[102],f[102][52][52];

void init () {
	for (int i=1;i<=n;i++)
		for (int j=0;j<=n;j++)
			for (int p=0;p<=n;p++)
				f[i][j][p]=0;
	f[0][0][0]=1;
	return;
}

int main () {
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	
	read_int(n); read_int(m);
	for (int i=1;i<=n;i++) {
		sum[i]=0;
		for (int j=1;j<=m;j++)
			read_int(a[i][j]),
			sum[i]+=a[i][j];
	}
	
	for (int now=1;now<=m;now++) {
		init();
		for (int p=0;p<n;p++)
			for (int j=0;j<=n/2;j++)
				for (int i=0;i<=n-j;i++)
				if (f[p][i][j]) {
					if (i<n) {
						f[p+1][i+1][j]+=((long long)f[p][i][j]*a[p+1][now])%mod;
						if (f[p+1][i+1][j]>=mod)
							f[p+1][i+1][j]-=mod;
					}
					if (j<n/2) {
						f[p+1][i][j+1]+=((long long)f[p][i][j]*(sum[p+1]-a[p+1][now]))%mod;
						if (f[p+1][i][j+1]>=mod)
							f[p+1][i][j+1]-=mod;
					}
					f[p+1][i][j]+=f[p][i][j];
					if (f[p+1][i][j]>=mod)
						f[p+1][i][j]-=mod;
				}
		for (int j=0;j<=n/2;j++)
			for (int i=j+1;i<=n;i++)
			if (f[n][i][j]&&i+j<=n) {
				ans-=f[n][i][j];
				if (ans<0) ans+=mod;
			}
	}
	
	p[0]=1;
	for (int i=0;i<n;i++) {
		p[i+1]=p[i];
		for (int j=1;j<=m;j++) {
			p[i+1]+=((long long)p[i]*a[i+1][j])%mod;
			if (p[i+1]>=mod) p[i+1]-=mod;
		}
	}
	
	(ans+=p[n]-1)%=mod;
	printf("%d",(ans+mod)%mod);
	
	
	fclose(stdin); fclose(stdout);
	return 0;
}
