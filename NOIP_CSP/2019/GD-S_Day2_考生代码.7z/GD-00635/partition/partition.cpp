#include<cstdio>
using namespace std;

int n,type,a[int(4e7)+2];
long long sum[402],f[402][402];

void read_int (int &a) {
	char c=getchar(); a=0;
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9') a=(a<<1)+(a<<3)-48+c,c=getchar();
	return;
}

long long min (const long long &a,const long long &b) { return a<b?a:b; }

long long solve () {
	long long ans=sum[n]*sum[n];
	for (int i=1;i<=n;i++)
		for (int j=0;j<i;j++)
			f[i][j]=ans;
	for (int i=1;i<=n;i++)
		f[i][0]=sum[i]*sum[i];
	for (int i=1;i<=n;i++)
		for (int j=i-1;j>=0;j--)
		if (f[i][j]) {
			for (int p=n;p>i;p--) {
				if (sum[p]-sum[i]<sum[i]-sum[j])
					break;
				f[p][i]=min(f[p][i],f[i][j]+(sum[p]-sum[i])*(sum[p]-sum[i]));
				if (p==n) ans=min(ans,f[p][i]);
			}
		}
	return ans;
}

int main () {
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	
	read_int(n); read_int(type);
	if (type==0) {
		for (int i=1;i<=n;i++)
			read_int(a[i]),
			sum[i]=sum[i-1]+a[i];
	} else {
		
	}
	
	if (n<=400) printf("%lld",solve());
	else {
	}
	
	
	fclose(stdin); fclose(stdout);
	return 0;
}
