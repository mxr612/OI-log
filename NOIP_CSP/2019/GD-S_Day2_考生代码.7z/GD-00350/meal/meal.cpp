#include <iostream>
#include <cstdio>
#include <cmath>
#define LL long long

const int maxn=45;
const LL mod=998244353;

using namespace std;

int n,m;
LL a[maxn][maxn],f[maxn][maxn][maxn][maxn],g[maxn][maxn][maxn];
LL ans;

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++)
	{
		for (int j=1;j<=m;j++) scanf("%lld",&a[i][j]);
	}
	if (m==2)
	{
		g[0][0][0]=1;
		for (int i=1;i<=n;i++)
		{
			for (int j=0;j<=n/2;j++)
			{
				for (int k=0;k<=n/2;k++)
				{
					g[i][j][k]=(g[i][j][k]+g[i-1][j][k])%mod;
					g[i][j+1][k]=(g[i][j+1][k]+g[i-1][j][k]*a[i][1]%mod)%mod;
					g[i][j][k+1]=(g[i][j][k+1]+g[i-1][j][k]*a[i][2]%mod)%mod;
				}
			}
		}
		for (int i=1;i<=n/2;i++) ans=(ans+g[n][i][i])%mod;
	}	
	if (m==3)
	{
		f[0][0][0][0]=1;
		for (int i=1;i<=n;i++)
		{
			for (int j=0;j<=n/2;j++)
			{
				for (int k=0;k<=n/2;k++)
				{
					for (int l=0;l<=n/2;l++)
					{
						f[i][j][k][l]=(f[i][j][k][l]+f[i-1][j][k][l])%mod;
						f[i][j+1][k][l]=(f[i][j+1][k][l]+f[i-1][j][k][l]*a[i][1]%mod)%mod;
						f[i][j][k+1][l]=(f[i][j][k+1][l]+f[i-1][j][k][l]*a[i][2]%mod)%mod;
						f[i][j][k][l+1]=(f[i][j][k][l+1]+f[i-1][j][k][l]*a[i][3]%mod)%mod;
					}
				}
			}
		}		
		for (int i=0;i<=n/2;i++)
		{
			for (int j=0;j<=n/2;j++)
			{
				for (int k=0;k<=n/2;k++)
				{
					if ((i==0) && (j==0) && (k==0)) continue;
					int ad=(i+j+k)/2;
					if ((i<=ad) && (j<=ad) && (k<=ad)) ans=(ans+f[n][i][j][k])%mod;
				}
			}
		}
	}
	printf("%lld",ans);
}
