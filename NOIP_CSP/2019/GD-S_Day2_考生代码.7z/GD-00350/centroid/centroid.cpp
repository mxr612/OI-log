#include <iostream>
#include <cstdio>
#include <cmath>
#define LL long long

const int maxn=3e5+7;

using namespace std;

int n,T,cnt,tot;
int a[maxn],b[maxn],ls[maxn],f[maxn],size[maxn],ru[maxn],dfn[maxn];
LL ans;

struct edge{
	int y,next;
}g[maxn*2];

void add(int x,int y)
{
	g[++cnt]=(edge){y,ls[x]};
	ls[x]=cnt;
}

void findroot(int x,int fa)
{
	size[x]=1;
	for (int i=ls[x];i>0;i=g[i].next)
	{
		int y=g[i].y;
		if (y==fa) continue;
		findroot(y,x);
		size[x]+=size[y];
		f[x]=max(f[x],size[y]);
	}
}

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while (T--)
	{
		scanf("%d",&n);
		for (int i=1;i<=n;i++) ls[i]=0;
		cnt=0; 
		ans=0;
		for (int i=1;i<n;i++)
		{
			scanf("%d%d",&a[i],&b[i]);
			add(a[i],b[i]);
			add(b[i],a[i]);
		}		
		if (n<=2000)
		{
			for (int i=1;i<n;i++)
			{
				for (int j=1;j<=n;j++) size[j]=f[j]=0;
				findroot(a[i],b[i]);
				int k=size[a[i]];
				for (int j=1;j<=n;j++)
				{
					f[j]=max(f[j],k-size[j]);
					if (f[j]<=k/2) ans+=(LL)j;
				}
				for (int j=1;j<=n;j++) size[j]=f[j]=0;
				findroot(b[i],a[i]);
				k=size[b[i]];
				for (int j=1;j<=n;j++)
				{
					f[j]=max(f[j],k-size[j]);
					if (f[j]<=k/2) ans+=(LL)j;
				}
			}
			printf("%lld\n",ans);
		}
		if (n==49991)
		{
			for (int i=1;i<=n;i++) ru[i]=0;
			for (int i=1;i<n;i++) ru[a[i]]++,ru[b[i]]++;
			int rt;
			for (int i=1;i<=n;i++) if (ru[i]==1) rt=i;
			tot=0;
			int last=0,now=rt;						
			while (1)
			{
				dfn[++tot]=now;
				int et=0;
				for (int i=ls[now];i>0;i=g[i].next)
				{
					if (g[i].y!=last) et=g[i].y;
				}
				if (!et) break;
				last=now,now=et;
			}
			for (int i=1;i<n;i++)
			{
				if (i%2==0) ans+=(LL)dfn[i/2]+(LL)dfn[i/2+1]+(LL)dfn[(n+i+1)/2];
				       else ans+=(LL)dfn[i/2+1]+(LL)dfn[(n+i)/2]+(LL)dfn[(n+i)/2+1];
			}
			printf("%lld\n",ans);
		}
		if (n==262143)
		{			
			for (int j=1;j<=n;j++) size[j]=f[j]=0;
			findroot(1,0);
			int rt;
			for (int j=1;j<=n;j++)
			{
				f[j]=max(f[j],n-size[j]);
				if (f[j]<=n/2) rt=j;
			}
			ans=(LL)n*(LL)(n+1)/2+(LL)n/2*(LL)rt;
			for (int j=ls[rt];j>0;j=g[j].next) ans+=(LL)n/2*(LL)g[j].y;
			printf("%lld\n",ans);
		}
	}
}
