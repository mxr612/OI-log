#include <iostream>
#include <cstdio>
#include <cmath>
#define LL long long

const int maxn=5e5+7;
const LL inf=2e18;

using namespace std;

int n,typ,head,tail;
LL a[maxn],f[maxn],g[maxn],q[maxn];

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&typ);
	for (int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		a[i]+=a[i-1];
		f[i]=inf;
	}	
	head=tail=1;
	q[1]=0;
	for (int i=1;i<=n;i++)
	{
		while ((head<tail) && (g[q[head+1]]+a[q[head+1]]<=a[i])) head++;
	    f[i]=f[q[head]]+(a[i]-a[q[head]])*(a[i]-a[q[head]]);
		g[i]=a[i]-a[q[head]];
		while ((head<=tail) && (g[q[tail]]+a[q[tail]]>=g[i]+a[i])) tail--;
		q[++tail]=i;
	}
	printf("%lld",f[n]);
}
