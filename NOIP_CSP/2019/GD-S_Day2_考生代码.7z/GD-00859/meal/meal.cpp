#include<cstdio>
#include<iostream>
using namespace std;
int n,m,ans;
int mymod=998244353;
int a[120][10];
int f[120][10];
int fu2=3,fu3[4]={3,5,6,7};//11||||011  110  101  111
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)
	{
		scanf("%d",&a[i][j]);
		f[i][(1<<(j-1))]=a[i][j];
	}
	/*for(int i=1;i<=n;i++)
	{for(int j=1;j<=4;j=j<<1)
	printf("%d ",f[i][j]);
		printf("\n");
	}*/
	if(m==2)
	{
		for(int i=2;i<=n;i++)
		{
		
		for(int j=1;j<i;j++)
		{
		for(int k=1;k<=2;k=k<<1) 
		f[i][fu2]+=(f[i][k]*f[j][fu2^k])%mymod;	
		}
		
		ans=(ans+f[i][fu2])%mymod;
		}
		printf("%d",ans);
	}
	else if(m==3)
	{
		for(int i=2;i<=n;i++)
		{
			for(int j=1;j<i;j++)
			{
				for(int p=0;p<=2;p++)
			{
				for(int k=1;k<=4;k=k<<1)
				{
				if((fu3[p]&k)!=0)
				{
				f[i][fu3[p]]+=(f[i][k]*f[j][fu3[p]^k])%mymod;
				//printf("[%d][%d]   f[%d][%d]=%d   f[%d][%d]=%d\n",i,fu3[p],i,k,f[i][k],j,fu3[p]^k,f[j][fu3[p]^k]);
				}
				}
			}			
			}	
			for(int p=0;p<=2;p++)
			{
			//printf("f[%d][%d]=%d\n",i,fu3[p],f[i][fu3[p]]);
			ans=(ans+f[i][fu3[p]])%mymod;
			}
		}
		
		for(int i=3;i<=n;i++)
		{
			for(int j=2;j<i;j++)
			{
				for(int k=1;k<=4;k=k<<1)
				{
					f[i][fu3[3]]+=(f[i][k]*f[j][k^fu3[3]])%mymod;
				}	
			}
			ans=(ans+f[i][fu3[3]])%mymod;
		}
		printf("%d",ans);
	}
}
