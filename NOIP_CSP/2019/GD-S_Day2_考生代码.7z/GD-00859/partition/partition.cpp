#include<cstdio>
#include<iostream>
using namespace std;
int n,tt;
long long a[5005],tot,ans=5e18;
//int lujing[2000],h=1;
void dfs(int i, long long pq, long long p,long long tot)
{
	if(tot>ans) return;
	if(i==n)
	{
		ans=tot;
		/*for(int i=1;i<=h;i++)
		{
			printf("%d ",lujing[i]);
		}
		printf("%d\n",p);*/
		return;
	}
	long long sm1=0,sm2=p;
	for(int j=i+1;j<=n;j++)
	{
		sm1+=a[j];
		if(sm1>=p) 
		{
		//h++;lujing[h]=p;
		dfs(j,p,sm1,tot+sm1*sm1);
		//h--;
		}
		/*if(p==19&&sm1==9)
		printf("$#\n");*/
		
		sm2+=a[j];
		if(sm2>=pq)
		{
		//h++;lujing[h]=pq;
		dfs(j,pq,sm2,tot+2*p*sm1+sm1*sm1);
		//h--;
		}
	}
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&tt);
	for(int i=1;i<=n;i++)
	scanf("%lld",&a[i]);
	
	dfs(1,0,a[1],a[1]*a[1]);
	
	printf("%lld",ans);
	
}
