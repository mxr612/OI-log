#include<cstdio>
#define MO 998244353
#define RI register int
int dp[41][1<<5],n,m,map[41][6],ans;
bool flag[1<<5];
void dfs(int a,int b,int c,int d)
{
	if(d==0) return;
	if(a==n)
	{
		if(b==c && b!=0) ans=(ans+d)%MO;
		return;
	}
	dfs(a+1,b+1,c,d*map[a+1][1]%MO);
	dfs(a+1,b,c+1,d*map[a+1][2]%MO);
	dfs(a+1,b,c,d);
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(RI i=1;i<=n;++i)
		for(RI j=1;j<=m;++j)
			scanf("%d",&map[i][j]);
	if(n<=3)
	{
	dp[0][0]=1;
	for(RI i=1;i<(1<<m);i<<=1)
		flag[i]=1;
	for(RI i=1;i<=n;++i)
	{
		for(RI j=m;j;--j)
		{
			for(RI k=0;k<(1<<m);++k)
			{
				if(k&(1<<(m-j))) continue;
				dp[i][k|(1<<(m-j))]=(dp[i][k|(1<<(m-j))]+dp[i-1][k]*map[i][j])%MO;
			}
		}
		for(RI k=0;k<(1<<m);++k)
			dp[i][k]=(dp[i][k]+dp[i-1][k])%MO;
	}
	for(RI i=1;i<(1<<m);++i)
		if(!flag[i])ans=(ans+dp[n][i])%MO;
	}
	else
	{
		dfs(1,1,0,map[1][1]);
		dfs(1,0,1,map[1][2]);
		dfs(1,0,0,1);
	}
	printf("%d",ans%MO);
	return 0;
}
