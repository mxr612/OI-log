#include<cstdio>
#define ULL unsigned long long
#define RI register int
int n,in,l[500001];
ULL dp[500001][2];
ULL sum(int a,int b)
{
	ULL out=0;
	for(;a<=b;++a)
		out+=(ULL)l[a];
	return out;
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d %d",&n,&in);
	for(RI i=1;i<=n;++i)
		scanf("%d",&l[i]);
	dp[1][0]=l[1]*l[1];
	dp[1][1]=l[1];
	for(RI i=2;i<=n;++i)
	{
		dp[i][0]=1000000000000000000;
		for(RI j=i-1;j>=0;--j)
		{
			ULL cun=sum(j+1,i);
			if(dp[j][1]<=cun && dp[i][0]>dp[j][0]+cun*cun)
			{
				dp[i][0]=dp[j][0]+cun*cun;
				dp[i][1]=cun;
			}
		}
	}
	printf("%llu",dp[n][0]);
	return 0;
}
