#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
const int N=100+10,M=2000+10;
const ll mod=998244353ll;
ll a[N][M],ans;int n,nn,m,p[M],v[N],t[N][M];
void dfs(int k,int last,int mx,ll sum)
{
	if(mx<=(k-1)/2&&k>1)ans=(ans+sum)%mod;
	if(k==n+1)return;
	for(int j=last+1;j<=nn;j++)
	{
		int kk=v[j];
		for(int i=1;i<=t[j][0];i++)
			if(p[t[j][i]]<nn/2)
			{
				p[t[j][i]]++;
				dfs(k+1,j,max(mx,p[t[j][i]]),(sum*a[kk][t[j][i]])%mod);
				p[t[j][i]]--;
			}
	}
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);nn=0;
	for(int i=1;i<=n;i++)
	{
		bool bk=0;
		for(int j=1;j<=m;j++)
		{
			scanf("%lld",&a[i][j]);
			if(a[i][j])bk=1;
		}
		if(bk)v[++nn]=i;
		for(int j=1;j<=m;j++)if(a[i][j])t[nn][++t[nn][0]]=j;
	}
	dfs(1,0,0,1ll);printf("%lld\n",ans);
	return 0;
}
