#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef unsigned long long ll;
const int N=4e7+10;const ll inf=0x3f3f3f3full;
ll s[N],a[N];int n;
ll deal0()
{
	ll ans=inf;
	for(int i=1;i<=n;i++)
	{
		ll p=s[i],sum=p*p,lp=p,last=i;bool bk=1;
		if(sum>ans)continue;
		for(int j=i+1;j<=n;j++)
		{
			ll c=s[j]-p;if(c<lp)continue;last=j;if(s[n]-s[j]<c)break;
			sum+=c*c;if(sum>ans){bk=0;break;}lp=c;p=s[j];
			ans=min(ans,sum+(s[n]-s[j])*(s[n]-s[j]));
		}
		if(last==n&&bk)ans=min(ans,sum);
	}
	return ans;
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int type;scanf("%d%d",&n,&type);
	if(!type)
	{
		ll x;for(int i=1;i<=n;i++)scanf("%llu",&a[i]),s[i]=s[i-1]+a[i];
		printf("%llu\n",deal0());
	}
	else
	{
		
	}
	return 0;
}
