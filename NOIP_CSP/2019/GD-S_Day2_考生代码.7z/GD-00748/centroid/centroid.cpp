#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
const int N=299995+10;
struct node{int x,y,next;}a[2*N];int len,last[N];
inline void ins(int x,int y)
{
	len++;a[len].x=x;a[len].y=y;
	a[len].next=last[x];last[x]=len;
}
int d[N],mx,mx2,b1,b2,v[N],tot,ttt;
void dfs(int x)
{
	tot++;if(d[x]>mx)b2=b1,b1=x,mx2=mx,mx=d[x];
	for(int k=last[x];k;k=a[k].next)
	{
		int y=a[k].y;
		if(v[y]!=ttt){v[y]=ttt;dfs(y);}
	}
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T,n;scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);int bk=0;ll ans=0ll;ttt=0;
		memset(d,0,sizeof(d));
		memset(v,0,sizeof(v));
		len=0;memset(last,0,sizeof(last));
		for(int i=1;i<n;i++)
		{
			int x,y;scanf("%d%d",&x,&y);
			ins(x,y);ins(y,x);d[x]++;d[y]++;if(d[x]>2||d[y]>2)bk=1;
		}
		if(!bk)
		{
			int x=0;
			for(int i=1;i<=n;i++)if(d[i]==1){x=i;break;}
			for(int i=2;i<=n;i++)
			{
				for(int k=last[x];k;k=a[k].next)
					if(!v[a[k].y]){v[a[k].y]=1;x=a[k].y;break;}
				if(!(n%2)&&i==n/2)d[x]--;
				else if(!(n%2)&&i==n/2+1){d[x]--;break;}
				else if(n%2&&i==n/2+1){d[x]--;break;}
			}
			for(int i=1;i<=n;i++)d[i]++;
			for(int i=1;i<=n;i++)ans=ans+ll(d[i]*i);
			printf("%lld\n",ans);
		}
		else
		{
			for(int i=1;i<=len;i+=2)
			{
				ttt++;
				v[a[i].x]=v[a[i].y]=ttt;
				mx=mx2=tot=0;dfs(a[i].x);
				if(tot%2)ans+=ll(b1);else ans+=ll(b1+b2);
				mx=mx2=tot=0;dfs(a[i].y);
				if(tot%2)ans+=ll(b1);else ans+=ll(b1+b2);
			}
			printf("%d\n",ans);
		}
	}
	return 0;
}
