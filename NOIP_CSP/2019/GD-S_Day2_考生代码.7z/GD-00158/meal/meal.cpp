#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int n,m;//2<=n<=100,2<=m<=2000
int a[105][2005];
int used[2005];
long long fangan(int k,int k0,int i0,int j0){
	long long ans=0,value=a[i0][j0];
	if(k==1)return value;
	for(int i=i0-1;i>=1;i--){
		for(int j=1;j<=m;j++){
			if(used[j]<k0/2){
				used[j]++;
				ans+=(value*fangan(k-1,k0,i,j))%998244353;
				used[j]--;
			}
		}
	}
	return ans%998244353;
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	long long ans=0;
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)
			cin>>a[i][j];
	}
	for(int k =2;k<=n;k++){
		for(int i=k;i<=n;i++){
			 for(int j=1;j<=m;j++){
			 	used[j]++;
			 	ans+=fangan(k,k,i,j);
			 	ans%=998244353;
				used[j]--;
			 }
		}
	}
	cout<<ans; 
	cin>>n;
	fclose(stdin);fclose(stdout);
	return 0;
}
