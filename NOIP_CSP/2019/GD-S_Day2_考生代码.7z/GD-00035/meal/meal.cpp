#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>

using namespace std;
const int N = 100 + 10;
const int M = 2000 + 10;
const int mod = 998244353;
long long n, m, ans;
int vst[N], a[N][M];
void init(){
	scanf("%d%d", &n, &m);
	for(int i = 1; i <= n; ++ i)
		for(int j = 1; j <= m; ++ j)
			scanf("%d", &a[i][j]);
}
void wrk(){
	if(m == 2){
		for(int i = 1; i < (1 << n); ++ i)
		{
			for(int j = 1; j < (1 << n); ++ j)
			{
				if(i & j) continue;
				int sumi = 0, sumj = 0, tmpi = i, tmpj = j, turni = 0, turnj = 0;
				long long tmp = 1;
				bool fl = 0;
				while(tmpi)
				{
					sumi += tmpi & 1;
					tmpi = tmpi >> 1;
					turni ++;
					if(tmpi & 1 && a[turni][1] == 0)
					{
						fl = 1;
						break;
					}
					tmp = (tmp * a[turni][1]) % mod;
				}
				if(fl) continue;
				while(tmpj)
				{
					sumj += tmpj & 1;
					tmpj = tmpj >> 1;
					turnj ++;
					if(tmpj & 1 && a[turnj][2] == 0)
					{
						fl = 1;
						break;
					}
					tmp = (tmp * a[turnj][2]) % mod;
				}
				if(sumi != sumj) continue;
				ans = (ans + tmp) % mod;
			}
		}
		printf("%d\n", ans);
		return ;
	}
	if(m == 3){
		
		for(int i = 0; i < (1 << n); ++ i)
		{
			for(int j = 0; j < (1 << n); ++ j)
			{
				for(int k = 0; k < (1 << n); ++ k)
				{
					if(i == 0 && j == 0 && k == 0) continue;
					if((i & j) || (i & k) || (j & k)) continue;
					int sumi = 0, sumj = 0, tmpi = i, tmpj = j, turni = 0, turnj = 0;
					int sumk = 0, tmpk = k, turnk = 0;
					long long tmp = 1;
					bool fl = 0;
					while(tmpi)
					{
						sumi += tmpi & 1;
						turni ++;
						if(tmpi & 1)
							tmp = (tmp * a[turni][1]) % mod;
						tmpi = tmpi >> 1;
					}
					if(tmp == 0) continue;
					while(tmpj)
					{
						sumj += tmpj & 1;
						turnj ++;
						if(tmpj & 1)
							tmp = (tmp * a[turnj][2]) % mod;
						tmpj = tmpj >> 1;
					}
					if(tmp == 0) continue;
					while(tmpk)
					{
						sumk += tmpk & 1;
						turnk ++;
						if(tmpk & 1)
							tmp = (tmp * a[turnk][3]) % mod;
						tmpk = tmpk >> 1;
					}
					if(tmp == 0) continue;
					if(sumi > sumj + sumk) continue;
					if(sumj > sumi + sumk) continue;
					if(sumk > sumi + sumj) continue;
					ans = (ans + tmp) % mod;
				}
			}
		}
		printf("%d\n", ans);
		return ;
	}
	else
	{
		int fuc = 19240, kccf = 817;
		printf("%d%d\n", fuc, kccf);
	}
}
int main(){
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	init();
	wrk();
	return 0;
}
