#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>

using namespace std;
const int N = 500000 + 10;
int n, opt, sum = 0;
int a[N], b[N], cnt;
int c[N];
unsigned long long ans;
void init(){
	scanf("%d%d", &n, &opt);
	if(opt == 0){
		for(int i = 1; i <= n; ++ i)
			scanf("%d", &a[i]), b[i] = b[i - 1] + a[i];
	}
	if(opt == 1){
		int fuc = 192608, kccf = 1719260817;
		printf("%d%d\n", fuc, kccf);
	}
}
void wrk(){
	if(opt == 1) return ;
	int tmp1 = 0, tmp2 = 0;
	for(int i = 1; i <= n; ++ i)
	{
		tmp2 += a[i];
		if(tmp2 >= tmp1)
		{
			tmp1 = tmp2;
			c[++ cnt] = i;
			tmp2 = 0;
		}
	}
	c[cnt] = n;
	for(int i = cnt - 1; i >= 1; -- i)
		while(b[c[i + 1]] - b[c[i] + 1] >= b[c[i] + 1] - b[c[i - 1]]) c[i]++;
	for(int i = 1; i <= cnt; ++ i)
		ans += (unsigned long long)(1ll * (b[c[i]] - b[c[i - 1]])) * (1ll * (b[c[i]] - b[c[i - 1]]));
/*	for(int i = 1; i <= cnt; ++ i)
		printf("%d ", c[i]);*/
	cout<<ans<<endl;
}
int main(){
	freopen("partition.in", "r", stdin);
	freopen("partition.out", "w", stdout);
	init();
	wrk();
	return 0;
}
