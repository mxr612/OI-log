#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cmath>
using namespace std;
const int N = 300000 + 10;
const int M = 600000 + 10;
int t, n;
long long ans;
int cnt = 0, nxt[M], head[N], to[M];
void addline(int u, int v){
	to[++ cnt] = v;
	nxt[cnt] = head[u];
	head[u] = cnt;
}
int siz[N], tmpn, d[N];
void init(){
	for(int i = 0; i <= n; ++ i)
		head[i] = 0, siz[i] = 0, d[i] = 0;
	for(int i = 0; i <= cnt; ++ i)
		nxt[i] = 0;
	cnt = 0, ans  = 0;
	scanf("%d", &n);
	for(int i = 1; i < n; ++ i)
	{
		int u, v;
		scanf("%d%d", &u, &v);
		addline(u, v);
		addline(v, u);
	}
}
void dfs(int x, int fa){
	siz[x] = 1;
	for(int i = head[x]; i; i = nxt[i]){
		int y = to[i];
		if(y == fa) continue;
		siz[x] += siz[y];
		d[y] = d[x] + 1;
		dfs(y ,x);
	}
}
int siz1[N], maxp1[N];
void dfs1(int x, int fa){
	siz1[x] = 1;
	for(int i = head[x]; i; i = nxt[i]){
		int y = to[i];
		if(y == fa) continue;
		dfs1(y, x);
		siz1[x] += siz1[y];
		maxp1[x] = max(maxp1[x], siz1[y]);
	}
	maxp1[x] = max(maxp1[x], tmpn - siz1[x]);
	if(maxp1[x] <= tmpn / 2) ans = (long long)((long long)x + ans);
	maxp1[x] = 0;
}
void wrk(){
	d[1] = 1;
	dfs(1, 0);
	for(int i = 1; i <= n; ++ i)
	{
		for(int j = head[i]; j; j = nxt[j])
		{
			int x = i, y = to[j];
			if(d[x] > d[y]) continue;//h[x] < h[y]
			tmpn = siz[y];
			dfs1(y, x);
			tmpn = n - siz[y];
			dfs1(x, y);
		}
	}
	printf("%d\n", ans);
}
int main(){
	freopen("centroid.in", "r", stdin);
	freopen("centroid.out", "w", stdout);
	scanf("%d", &t);
	while(t --)
	{
		init();
		wrk();
	}
	return 0;
}
