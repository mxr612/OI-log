#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
using namespace std;

const int MOD=998244353;
const int MAXN=105;
const int MAXM=2050;
int ans,a[MAXN][MAXM],sum[MAXM],n,m;

bool check(int num,int x)
{
	bool boo=true;
	sum[x]++;
	for (int i=1; i<=m; i++)
	  if (sum[i]>num/2) boo=false;
	sum[x]--;
	return boo;
}
void dfs(int x,int num,long long task)
{
	for (int i=x+1; i<=n; i++)
	{
		for (int j=1; j<=m; j++)
		{
			if (!a[i][j]) continue;
			if (check(num+1,j)) ans=(ans+(task*a[i][j])+MOD)%MOD;
			sum[j]++; 
			dfs(i,num+1,task*a[i][j]);
			sum[j]--;
		}
	}
	return ;
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	memset(sum,0,sizeof(sum));
	scanf("%d%d",&n,&m);
	for (int i=1; i<=n; i++)
	  for (int j=1; j<=m; j++)
	    scanf("%d",&a[i][j]);
	for (int i=1; i<=n; i++)
	{
		for (int j=1; j<=m; j++)
		{
			if (!a[i][j]) continue;
			sum[j]++;
			dfs(i,1,a[i][j]);
			sum[j]--;
		}
	}
	printf("%d",ans);
	return 0;
}
