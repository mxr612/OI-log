#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
using namespace std;

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	printf("%d\n%d",36,56);
	return 0;
}
