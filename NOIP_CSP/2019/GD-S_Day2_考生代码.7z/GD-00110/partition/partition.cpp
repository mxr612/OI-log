#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;

const int MAXN=5050;
long long ans;
int n,t;
long long sum[MAXN],a[MAXN];
void dfs(int cur,long long Last,long long Count)
{
	if (cur>n) 
	{
		ans=min(ans,Count);
		return ;
	}
	for (int i=cur; i<=n; i++)
	{
		if (sum[i]-sum[cur-1]>=Last)
		{
			if (Count+(sum[i]-sum[cur-1])*(sum[i]-sum[cur-1])>ans) break;
			dfs(i+1,sum[i]-sum[cur-1],Count+(sum[i]-sum[cur-1])*(sum[i]-sum[cur-1]));
		}
	}
}

long long Prepare()
{
	long long Last=sum[1],Count=sum[1]*sum[1]; int l=1; 
	for (int i=2; i<=n; i++)
	{
		if (sum[i]-sum[l]>=Last)
		{
			Last=sum[i]-sum[l];
			Count+=(sum[i]-sum[l])*(sum[i]-sum[l]);
			l=i;
		}
		if (i==n&&l==1) return -1;
	}
	if (l!=n) return sum[n]*sum[n];
	return Count;
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&t);
	for (int i=1; i<=n; i++) 
	{
		scanf("%lld",&a[i]);
		sum[i]=sum[i-1]+a[i];
	}
	ans=sum[n]*sum[n];
	ans=Prepare();
	if (ans==-1)
	{
		cout<<sum[n]*sum[n];
		return 0;
	}
	dfs(1,0,0);
	printf("%lld",ans);
	return 0;
}
