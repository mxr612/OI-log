#include<cstdio>
#include<vector>

using std::vector;

const int N=3000000;

namespace tree_solve
{
	int n,stree[N],father[N],depth[N],ndep=0;
	long long sum=0;
	vector<int> edge[N];
	
	inline void swap(int &a,int &b)
	{
		int tmp=a;
		a=b,b=tmp;
	}
	
	inline int lca(int a,int b)
	{
		if(depth[a]<depth[b])swap(a,b);
		if(depth[a]>depth[b])
		{
			while(depth[a]!=depth[b])
				a=father[a];
		}
		while(a!=b)
		{
			a=father[a];
			b=father[b];
		}
		return a;
	}
	
	void build_dfs(int fa)
	{
//		printf("build_dfs(%d)\n",fa);
		for(int i=0;i<edge[fa].size();++i)
		{
			if(edge[fa][i]==father[fa])continue;
			father[edge[fa][i]]=fa;
			depth[edge[fa][i]]=ndep;
			++ndep;
			build_dfs(edge[fa][i]);
			--ndep;
			stree[fa]+=stree[edge[fa][i]];
		}
	}
	
//	void ga_dfs(int fa,int root)
//	{
//		int cmps=stree[root]/2;
//		if(fa==root)
//		{
//			int flag=0;
//			for(int i=0;i<edge[fa].size();++i)
//			{
//				int son=edge[fa][i];
//				if(son==father[fa])continue;
//				if(stree[son]>cmps)
//				{
//					flag=1;
//					break;
//				}
//			}
//			if(!flag)sum+=fa;
//		}
//		else if(stree[fa]-1<=cmps&&stree[root]-stree[fa]<=cmps)
//		{
//			sum+=fa;
//		}
//		//TODO:opt
//		for(int i=0;i<edge[fa].size();++i)
//		{
//			if(edge[fa][i]==father[fa])continue;
//			ga_dfs(edge[fa][i],root);
//			ga_dfs(edge[fa][i],edge[fa][i]);
//		}
//	}

	void ga_get()
	{
		for(int root=1;root<=n;++root)
		for(int fa=1;fa<=n;++fa)
		{
			if(lca(root,fa)==root)
			{
				int cmps=stree[root]/2;
				if(fa==root)
				{
					int flag=0;
					for(int i=0;i<edge[fa].size();++i)
					{
						int son=edge[fa][i];
						if(son==father[fa])continue;
						if(stree[son]>cmps)
						{
							flag=1;
							break;
						}
					}
					if(!flag)sum+=fa;
				}
				else if(stree[fa]-1<=cmps&&stree[root]-stree[fa]<=cmps)
				{
					sum+=fa;
				}
			}
			else
			{
				int ori=root;
				root=1;
				int cmps=(stree[root]-stree[ori])/2;
				if(fa==root)
				{
					int flag=0;
					for(int i=0;i<edge[fa].size();++i)
					{
						int son=edge[fa][i];
						if(son==father[fa])continue;
						if(stree[son]>cmps)
						{
							flag=1;
							break;
						}
					}
					if(!flag)sum+=fa;
				}
				else if(stree[fa]-1<=cmps&&(stree[root]-stree[ori])-stree[fa]<=cmps)
				{
					sum+=fa;
				}
			}
		}
	}
	
	void solve()
	{
		sum=0,ndep=0;
//		printf("start\n");
		scanf("%d",&n);
		for(int i=1;i<=n;++i)
		{
			edge[i].erase(edge[i].begin(),edge[i].end());
		}
		for(int i=1;i<n;++i)
		{
			int a,b;
			scanf("%d%d",&a,&b);
			edge[a].push_back(b);
			edge[b].push_back(a);
			stree[i]=1;
		}
		stree[n]=1;
		father[1]=1;
		build_dfs(1);
		ga_get();
		printf("%lld\n",sum);
	}
}

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T;
	scanf("%d",&T);
	for(int i=0;i<T;++i)tree_solve::solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
