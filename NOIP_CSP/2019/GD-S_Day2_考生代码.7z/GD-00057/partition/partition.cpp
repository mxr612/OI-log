#include<cstdio>
#include<deque>
#include<algorithm>

using namespace std;

const int N=500010;
unsigned long long btree[N];
unsigned long long n,tp,a[N],linkk[N],summa[N];

inline int lowbit(int x){return x&-x;}

void add(int an,unsigned long long x)
{
	for(unsigned long long i=an+1;i<=n;i+=lowbit(i))
		btree[i]+=x;
}

unsigned long long sum(int an)
{
	unsigned long long ans=0;
	for(int i=an+1;i>0;i-=lowbit(i))
		ans+=btree[i];
	return ans;
}

//void hass()
//{
//	int lnn=unique(b,b+n)-b;
//	sort(b,b+lnn);
//	for(int i=0;i<n;++i)
//	{
//		a[i]=lower_bound(b,b+lnn,a[i])-b+1;
//		add(i,a[i]);
//	}
//}

unsigned long long add_best(int x)
{
	if(x==n)return 0;
	if(x==n-1)return a[n-1]*a[n-1];
	unsigned long long ans=0;
	for(int i=x;i<n;++i)
	{
		unsigned long long now=sum(i)-sum(x-1);
		now*=now;
		unsigned long long nexp=add_best(i+1);
		if(now+nexp>ans)ans=now+nexp;
	}
	return ans;
}

void baoli(int x)
{
	//add from x-1 to i
	unsigned long long ans=add_best(x-1);
	if(x>=2)summa[n-1]=ans+summa[x-2];
	else summa[n-1]=ans;
}

int main()
{
	freopen("partition1.in","r",stdin);
//	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&tp);
	for(int i=0;i<n;++i)
	{
		scanf("%llu",&a[i]);
		add(i,a[i]);
//		a[i]=tmp;
//		b[i]=tmp;
	}
//	hass();
//	for(int i=0;i<n;++i)linkk[i]=i;
	if(n==1)
	{
		printf("%d",a[0]*a[0]);
		return 0;
	}
	if(n==2)
	{
//		unsigned long long xxa=a[0]*a[0];
		if(a[0]<=a[1])
		{
			printf("%d",a[0]*a[0]+a[1]*a[1]);
			return 0;
		}
		else
		{
			printf("%d",(a[0]+a[1])*(a[0]+a[1]));
			return 0;
		}
	}
	unsigned long long last=a[0];
	summa[0]=a[0]*a[0];
	for(int i=1;i<n;++i)
	{
		if(a[i]<last)
		{
			baoli(i);
			break;
		}
		summa[i]=summa[i-1]+a[i]*a[i];
		last=a[i];
	}
	printf("%llu",summa[n-1]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
