#include<cstdio>

const int N=110,M=2010,MOD=998244353;
int n,m,a[N][M],k[N],used[M];

//kn:total an:now
void dfs(int kn,int an,int nowk,int addnum)
{
//	printf("dfs(%d,%d,%d,%d)\n",kn,an,nowk,addnum);
	if(nowk==kn+1)
	{
		k[kn]+=addnum;
		k[kn]%=MOD;
//		printf("add k[%d] %d \nM={",kn,addnum);
//		for(int i=0;i<m;++i)printf("%d,",k[i]);
//		printf("}\n");
		return;
	}
	for(int i=an;i<n;++i)
	{
		for(int j=0;j<m;++j)
		{
//			printf("used[%d]=%d\na[%d][%d]=%d\n",j,used[j],i,j,a[i][j]);
			if(used[j]>=(kn+1)/2)continue;
			if(a[i][j])
			{
				++used[j];
				dfs(kn,i+1,nowk+1,addnum*a[i][j]%MOD);
				--used[j];
			}
		}
	}
}

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;++i)
		for(int j=0;j<m;++j)
			scanf("%d",&a[i][j]);
	for(int i=1;i<n;++i)
		dfs(i,0,0,1);
	int sum=0;
	for(int i=1;i<n;++i)
		sum=(sum+k[i])%MOD;
	printf("%d",sum%MOD);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
