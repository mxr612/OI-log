#include <cstdio>
#define ll long long
using namespace std;

const int N = 40;
const int M = 5;
const ll mo = 998244353;
int n,m,a[N][M],q[N][2],k,vis[M];
ll ans;

int read()
{
	int x = 0,w = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {if (ch == '-') w = -1; ch = getchar();}
	while (ch >= '0' && ch <= '9') {x = x * 10 + ch - '0'; ch = getchar();}
	return x * w;
}

void dfs(int x,int have)
{
	if (have >= k)
	{
		ll res = 1;
		for (int i = 1; i <= have; i ++) res = res * a[q[i][0]][q[i][1]] % mo;
		ans = (ans + res) % mo;
		return;
	}
	if (k - have < n - x + 1) dfs(x + 1,have); else if (k - have != n - x + 1) return;
	for (int i = 1; i <= m; i ++)
		if (a[x][i] && vis[i] + 1 <=  k / 2)
		{
			vis[i] ++;
			q[have + 1][0] = x;
			q[have + 1][1] = i;
			dfs(x + 1,have + 1);
			q[have + 1][0] = 0;
			q[have + 1][1] = 0;
			vis[i] --;
		}
}

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n = read(),m = read();
	for (int i = 1; i <= n; i ++)
		for (int j = 1; j <= m; j ++) a[i][j] = read();
	for (k = 2; k <= n; k ++) dfs(1,0);
	printf("%lld\n",ans);
	return 0;
}
