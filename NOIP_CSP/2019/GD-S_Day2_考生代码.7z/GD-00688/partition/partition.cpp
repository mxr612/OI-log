#include <cstdio>
#include <cstring>
#define ll long long
using namespace std;

const int N = 5e3 + 10;
const ll inf = 4e18;
int n,typ,a[N];
ll f[N],sum[N],ss[N];

int read()
{
	int x = 0,w = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {if (ch == '-') w = -1; ch = getchar();}
	while (ch >= '0' && ch <= '9') {x = x * 10 + ch - '0'; ch = getchar();}
	return x * w;
}

ll min(ll a,ll b) {return a < b ? a : b;}

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	for (int i = 0; i < N; i ++) f[i] = ss[i] = inf;
	n = read(),typ = read();
	for (int i = 1; i <= n; i ++) a[i] = read(),sum[i] = sum[i - 1] + 1ll * a[i];
	f[0] = ss[0] = 0;
	for (int j = 0; j <= n; j ++)
		for (int i = j + 1; i <= n; i ++)
		{
			if (sum[i] - sum[j] < ss[j]) continue;
			ll p = f[j] + (sum[i] - sum[j]) * (sum[i] - sum[j]);
			if (p < f[i]) f[i] = p,ss[i] = sum[i] - sum[j];
		}
	for (int i = 1; i <= n; i ++) printf("%lld ",f[i]);
	printf("%lld\n",f[n]);
	return 0;
}
