#include <cstdio>
#include <cstring>
#define ll long long
using namespace std;

const int N = 3e5;
struct Edge{
	int to,next;
} f[N << 1];
ll ans;
int n,T,cnt,tot,head[N],u[N],v[N],size[N],SIZ[N],id[N];

int read()
{
	int x = 0,w = 1;
	char ch = getchar();
	while (ch < '0' || ch > '9') {if (ch == '-') w = -1; ch = getchar();}
	while (ch >= '0' && ch <= '9') {x = x * 10 + ch - '0'; ch = getchar();}
	return x * w;
}

int max(int a,int b) {return a > b ? a : b;}

void add(int u,int v)
{
	f[++ cnt].to = v;
	f[cnt].next = head[u];
	head[u] = cnt;
}

void dfs(int u,int k,int fa)
{
	int mx = 0;
	size[u] = 1;
	for (int i = head[u]; i; i = f[i].next)
	{
		if (fa == f[i].to || i == k * 2 || i == k * 2 - 1) continue;
		dfs(f[i].to,k,u);
		size[u] += size[f[i].to];
		if (size[f[i].to] > mx) mx = size[f[i].to];
	}
	mx = max(mx,tot - size[u]);
	if (mx <= tot / 2) ans += 1ll * u;
}

void DFS(int u,int fa)
{
	id[++ tot] = u;
	SIZ[u] = 1;
	for (int i = head[u]; i; i = f[i].next)
	{
		if (f[i].to == fa) continue;
		DFS(f[i].to,u);
		SIZ[u] += SIZ[f[i].to];
	}
}

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	T = read();
	while (T --)
	{
		ans = 0;
		cnt = 0;
		memset(head,0,sizeof head);
		memset(SIZ,0,sizeof SIZ);
		n = read();
		for (int i = 1; i < n; i ++) u[i] = read(),v[i] = read(),add(u[i],v[i]),add(v[i],u[i]);
		tot = 0;
		DFS(1,0);
		if (n < 2000)
		{
			for (int i = 1; i < n; i ++)
			{
			 	memset(size,0,sizeof size);
			 	if (SIZ[u[i]] < SIZ[v[i]]) tot = SIZ[u[i]]; else tot = n - SIZ[v[i]];
			 	dfs(u[i],i,0);
			 	tot = n - tot;
			 	dfs(v[i],i,0);
			}
			printf("%lld\n",ans);
		} else
		{
			for (int i = 1,s1,s2; i < n; i ++)
			{
				s1 = i,s2 = n - i;
				if (s1 & 1) ans += 1ll * id[i / 2 + 1]; else ans += 1ll * (id[i / 2 + 1] + id[i / 2]);
				if (s2 & 1) ans += 1ll * id[(i + 1 + n) / 2]; else ans += 1ll * (id[(i + 1 + n) / 2] + id[(i + 1 + n) / 2 + 1]);
			}
			printf("%lld\n",ans);
		}
	}
	return 0;
}
