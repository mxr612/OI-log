#include<cstdio>
#include<vector>
#include<cstring>
using namespace std;
inline int read()
{
	int ret=0,flag=1;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')flag=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		ret=(ret<<3)+(ret<<1)+c-'0';
		c=getchar();
	}
	return ret*flag;
}
const int N=300000;
int n,t,d[N][2],dep[N],ans=0;
vector<int>e[N];
inline void dfs(int x,int f,int dd)
{
	if(e[x][0]==f)dep[dd+1]=e[x][1],dfs(e[x][1],x,dd+1);
	else dep[dd+1]=e[x][0],dfs(e[x][0],x,dd+1);
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	t=read();
	while(t--)
	{
		n=read();
		for(int i=1;i<n;i++)
		{
			int u=read(),v=read();
			d[i][0]=u;d[i][1]=v;
			e[u].push_back(v);
			e[v].push_back(u);
		}
		if(n=49991)
		{
			int m1;
			for(int i=1;i<=n;i++)if(e[i].size()==1)m1=i;
			dep[m1]=1;
			dfs(m1,0,1);
			for(int i=1;i<n;i++)
			{
				if(i%2)ans+=dd[(i+1)/2]+dd[n/2+((i+1)/2)]+dd[n/2+1+(i+1)/2];
				else ans+=dd[1+(i-2)/2]+dd[2+(i-2)/2];
			}
			printf("%d\n",ans);
		}
	}
	return 0;
}
