#include<cstdio>
using namespace std;
inline int read()
{
	int ret=0,flag=1;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')flag=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		ret=(ret<<3)+(ret<<1)+c-'0';
		c=getchar();
	}
	return ret*flag;
}
const int mod=998244353;
int a[101][2001],n,m;
int v[2001],ans=0;
inline void dfs(int x,int k,int now)
{
	if(x==n)return;
	dfs(x+1,k,now);
	for(int i=1;i<=m;i++)
	{
		if(v[i]+1>m/2)continue;
		if(a[x+1][i])
		{
			bool ok=0;
			v[i]++;
			for(int j=1;j<=m;j++)if(v[j]>(k+1)/2){ok=1;break;}
			if(!ok)ans=(a[x+1][i]*now%mod+ans)%mod;
			dfs(x+1,k+1,a[x+1][i]*now%mod);
			v[i]--;
		}
	}
	return;
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=read();m=read();
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)a[i][j]=read();
	dfs(0,0,1);
	printf("%d",ans);
	return 0;
}
