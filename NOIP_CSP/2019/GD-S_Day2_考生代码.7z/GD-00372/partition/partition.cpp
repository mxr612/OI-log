#include<cstdio>
#include<stack>
using namespace std;
typedef unsigned long long ll;
inline ll read()
{
	ll ret=0;
	char c=getchar();
	while(c<'0'||c>'9')
		c=getchar();
	while(c>='0'&&c<='9')
	{
		ret=(ret<<3)+(ret<<1)+c-'0';
		c=getchar();
	}
	return ret;
}
const int mod=1073741824;
int n,type,tot=0;
ll a[40000002],f[40000001],ans;
ll x,y,z,b[40000001],m;
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=(int)read();type=(int)read();
	if(!type)for(int i=1;i<=n;i++)a[i]=read();
	else
	{
		x=read();y=read();z=read();
		b[1]=read();b[2]=read();m=read();
		for(int i=3;i<=n;i++)b[i]=(((x*b[i-1]%mod+y*b[i-2]%mod)%mod)+z)%mod;
	}
	for(int i=1;i<=n;i++)
	{
		if(i==1)f[++tot]=a[1];
		else if(a[i]>=f[tot])f[++tot]=a[i];
		else if(i==n)f[tot]+=a[i];
		else
		{
			if(f[tot]<a[i+1])f[tot]+=a[i];
			else f[++tot]=a[i]+a[i+1],i++;
		}
	}
	for(int i=tot;i;i--)if(f[i]<f[i-1])f[i-1]+=f[i],tot--;
	for(int i=1;i<=tot;i++)ans+=f[i]*f[i];
	printf("%lld",ans);
	return 0;
}
