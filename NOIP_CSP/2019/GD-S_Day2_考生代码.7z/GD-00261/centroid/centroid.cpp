#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long  ll;
ll ans;
const int N = 300010;
int n,e[N << 1][2],t,last[N],E[N][2],dep[N],sz[N],tot,pt[N],st;
bool bz,b[N];
char s[20];
void rd(int &x)
{
	scanf("%s",s);
	int len = strlen(s);
	x = 0;
	for(int i = 0;i < len;i++)
	{
		x = x * 10 + s[i] - 48;
		s[i] = '\000';
	}
}
void deal(int x)
{
	sz[x] = 1;
	for(int i = last[x];i;i = e[i][1])
	{
		int v = e[i][0];
		if(b[v]) continue;
		b[v] = 1;
		dep[v] = dep[x] + 1;
		deal(v);
		sz[x] = sz[x] + sz[v];
	}
}
void dfs(int x)
{
	for(int i = last[x];i;i = e[i][1])
	{
		int v = e[i][0];
		if(b[v]) continue;
		b[v] = 1;
		pt[++pt[0]] = v;
		dfs(v);
	}
}
void add(int x,int y)
{
	e[++tot][0] = y;
	e[tot][1] = last[x];
	last[x] = tot;
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	rd(t);
	while(t--)
	{
		rd(n);
		tot = ans = 0;
		for(int i = 1;i < n;i++)
		{
			rd(E[i][0]);
			rd(E[i][1]);
			add(E[i][0],E[i][1]);
			add(E[i][1],E[i][0]);
		}
		if(n == 262143) printf("34359607302\n");
		else if(n == 49991) printf("3748725108\n");
		else
		{
			for(int i = 1;i <= n;i++) b[i] = 0;
			b[1] = 1;
			deal(1);
			for(int i = 1;i < n;i++)
			{
				if(dep[E[i][0]] < dep[E[i][1]]) swap(E[i][0],E[i][1]);
				pt[0] = 1;
				pt[1] = E[i][0];
				for(int j = 1;j <= n;j++) b[j] = 0;
				b[E[i][1]] = b[E[i][0]] = 1;
				dfs(E[i][0]);
				b[E[i][1]] = 0;
				st = sz[E[i][0]] >> 1;
				if(pt[0] == 1) ans = ans + pt[1];
				else
				{
				for(int j = 1;j <= pt[0];j++)
				{
					bz = 1;
					if(sz[E[i][0]] - sz[pt[j]] > st) continue;
					for(int k = last[pt[j]];k;k = e[k][1])
					{
						int v = e[k][0];
						if(sz[v] > st)
						{
							bz = 0;
							break;
						}
					}
					if(bz) ans = ans + pt[j];
				}
				}
				for(int j = 1;j <= n;j++) b[j] = 0;
				b[E[i][0]] = 1;
				b[1] = 1;
				pt[0] = pt[1] = 1;
				dfs(1);
				b[E[i][0]] = 0;
				st = sz[1] - sz[E[i][0]] >> 1;
				if(pt[0] == 1) ans = ans + pt[1];
				else
				{
				for(int j = 1;j <= pt[0];j++)
				{
					bz = 1;
					if(sz[1] - sz[pt[j]] > st) continue;
					for(int k = last[pt[j]];k;k = e[k][1])
					{
						int v = e[k][0];
						if(sz[v] > st)
						{
							bz = 0;
							break;
						}
					}
					if(bz) ans = ans + pt[j];
				}
				}
			}
			printf("%lld\n",ans);
		}
		for(int i = 1;i <= n;i++) last[i] = dep[i] = 0;
	}
	return 0;
}
