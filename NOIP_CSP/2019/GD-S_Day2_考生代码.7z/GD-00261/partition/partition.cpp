#include<cstdio>
#include<cstring>
using namespace std;
typedef long long  ll;
ll a[500010],cnt,ans,tp,st,an,l,r,A;
int n;
char s[20];
void rd(ll &x)
{
	scanf("%s",s);
	int len = strlen(s);
	x = 0;
	for(int i = 0;i < len;i++)
	{
		x = x * 10 + s[i] - 48;
		s[i] = '\000';
	}
}
void bl(int x,int val,ll an)
{
	if(an >= ans) return;
	if(x > n)
	{
		ans = an;
		return;
	}
	int sum = 0;
	for(int i = x;i <= n;i++)
	{
		sum = sum + a[i];
		if(sum >= val) bl(i + 1,sum,an + sum * sum);
	}
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d",&n);
	rd(tp);
	if(tp == 0)
	{
		for(int i = 1;i <= n;i++) rd(a[i]);
		if(n <= 50)
		{
			ans = 9223372036854775807;
			bl(1,0,0);
			printf("%lld",ans);
			return 0;
		}
		ans = 9223372036854775807;
		for(int i = 1;i < n;i++)
		{
			st = st + a[i];
			l = 0;
			r = 400000000000000000;
			while(l < r - 1)
			{
				ll mid = (l + r) >> 1;
				A = st * st;
				cnt = st;
				an = 0;
				if(i == 2) printf("%lld %lld ",l,r);
				for(int j = i + 1;j <= n;j++)
				{
					if(an - cnt + a[j] > mid)
					{
						an = an + a[j];
						A = A + an * an;
						cnt = an - a[j];
						an = 0;
					if(i == 2) printf("%d ",j);
					}
					else an = an + a[j];
				}
				if(an < cnt && an != 0) l = mid;
				else
				{
					r = mid;
					if(A < ans) ans = A;
				}
				if(i == 2) printf("\n");
			}
		}
		printf("%lld",ans);
	}
	return 0;
}
