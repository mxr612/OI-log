#include<cstdio>
#include<cstring>
using namespace std;
typedef long long  ll;
int n,m,ml[2010];
ll a[110][2010],ans,p = 998244353;
char s[20];
void rd(ll &x)
{
	scanf("%s",s);
	int len = strlen(s);
	x = 0;
	for(int i = 0;i < len;i++)
	{
		x = x * 10 + s[i] - 48;
		s[i] = '\000';
	}
}
void dfs(int x,int meal,ll sol)
{
	if(x > n)
	{
		for(int i = 1;i <= m;i++) if(ml[i] > (meal >> 1)) return;
		if(meal > 1) ans = (ans + sol) % p;
		return;
	}
	for(int i = 1;i <= m;i++)
	{
		if(ml[i] >= (meal + n - x + 1 >> 1) || a[x][i] == 0) continue;
		ml[i]++;
		dfs(x + 1,meal + 1,sol * a[x][i] % p);
		ml[i]--;
	}
	dfs(x + 1,meal,sol);
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i = 1;i <= n;i++)
	{
		for(int j = 1;j <= m;j++) rd(a[i][j]);
	}
	dfs(1,0,1);
	printf("%lld",ans);
	return 0;
}
