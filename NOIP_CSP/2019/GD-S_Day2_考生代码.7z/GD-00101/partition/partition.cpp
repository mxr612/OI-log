#include<bits/stdc++.h>
#include<queue>;
using namespace std;

const int N = 500005;
queue<long long> q;
queue<long long> p;
//priority <int> p;
//priority <int , vector <int> , greater<int> > p;

int type;
long long n;

long long a[N];
long long maxn[N];
long long ans;
//long long 
long long first_,end_;


int ge;

void Solve()
{
		int k = 0;
		for(int i = n ; i >= 1 ; i = i-k)
		{
			k = 0;
			if(q.front() >= maxn[i])
			{
				p.push(q.front());
				ge++;
				q.pop();
				k = 1;
			}
			else
			{
				long long r = 0;
				while(r < maxn[i-k])
				{
					long long t = q.front();
					q.pop();
					r += t;
					k++;
					end_++;
				}
				p.push(r);
				ge++;
			}
		}
}





int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin >> n >> type;
	if(type == 0)
	{
		for(int i = 1 ; i <= n ; i++)
		{
			scanf("%lld",&a[i]);
			if(a[i] >= maxn[i-1])
			{
				maxn[i] = a[i];
			}
			else
			{
				maxn[i] = maxn[i-1];
			}
		}
		
		for(int i = n ; i >= 1 ; i--)
		{
			q.push(a[i]);
		}
		
		Solve();
		
		for(int i = 1 ; i <= ge ; i++)
		{
			ans += p.front()*p.front();
			p.pop();
		}
		
		
	}
	

	
	
	printf("%lld",ans);
	
	return 0;
}
