#include<bits/stdc++.h>
using namespace std;

int a[105][2005];
int n,m;
long long ans;
long long sum = 1;
int cai[2005]; 
int flag = 1;

void Solve(int dao,int xdi,int ydi,int duo,int shen)
{
	//cout << "shen = " << shen << endl;
	if(shen!=dao && xdi == n+1)
	{
		return ;
	}
	if(shen == dao)
	{
		ans += sum;
		ans = ans % 998244353;
		//cout << "ans = " << ans << endl;
		return ;
	}
	for(int i = xdi +1 ; i <= n ; i++)
	{
		for(int j = 1 ; j <= m ; j++)
		{
			if(a[i][j] == 0)
			{
				continue;
			}
			if(cai[j] < duo)
			{
				long long t;
				sum *= a[i][j];
				if(sum >= 998244353&&flag)
				{
					long long h = sum;
					sum = sum % 998244353;
					t = h - sum;
					flag = 0;
				}
				shen++;
				cai[j]++;
				//cout << "a[i][j]" << "i = " << i << "  j = " << j << "  " << a[i][j] << " sum = " << sum << endl;
				Solve(dao,i,j,duo,shen);
				if(flag == 0)
				{
					flag = 1;
					sum = (sum+t) / a[i][j];
				}
				else
				{
					sum = sum/a[i][j];
				}
				shen--;
				cai[j]--;
			}
			
		}
	}
	return ;
}


int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin >> n >> m;
	for(int i = 1 ; i <= n ; i++)
	{
		for(int j = 1 ; j <= m ; j++)
		{
			cin >> a[i][j]; 
		}
	}
	
	for(int i = 2 ; i <= n ; i++)
	{
		int maxn = i/2;
		for(int r = 1 ; r <= n && ((n-r+1)>=i); r++)
		{
			for(int j = 1 ; j <= m ; j++)
			{
				if(a[r][j] == 0)
				{
					continue;
				}
				sum *= a[r][j];
				cai[j] = 1;
				Solve(i,r,j,maxn,1);
				cai[j] = 0;
				sum = 1;
			}	
		}
	}
	
	printf("%lld\n",ans);
	
	
	
	
	return 0;
}
