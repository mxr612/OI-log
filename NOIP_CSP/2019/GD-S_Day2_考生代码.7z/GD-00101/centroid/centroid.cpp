#include<bits/stdc++.h>
using namespace std;
int a[5000][5000];

int t;

int main()
{
	cin >> t;
	
	whlie(t>=1)
	{
		freopen("centroid.in","r",stdin);
		freopen("centroid.out","w",stdout);
		cin >> n;
		for(int i = 1 i <n ;i++)
		{
			int c ,int b;
			cin >> c >> b;
			a[c][b] = 1;
		}
		cout << 1;
		t--;
	}
	
	
	return 0;
}
