#include<cstdio>
#include<algorithm>
#include<iostream>
#define LL long long
using namespace std;
bool type, book[500007];
int n;
LL a[500007], ans;
//���Ժϲ�����ô������������ϲ��򲻺ϲ���������һ����������ϲ�
int main()
{
//	freopen("partition.in","r",stdin);
//	freopen("partition.out","w",stdout);
	scanf("%d", &n);
	cin >> type;
	if(type == 0)
	{
		for(int i = 1;i <= n;++ i)
	{
		scanf("%lld", &a[i]);
		if(a[i] < a[i - 1])
		{
			book[i] = 1;
		}
	}
//	for(int kk = 1;kk <= 1000;++ kk)
	for(int i = 1;i <= n;++ i)
	{
//		if(a[i])
//		{
			int k = i;
			while(a[k - 1] == 0 && k - 1) -- k;
//				cout << a[k - 1] << endl << endl << endl;
			if(book[i] || a[k] < a[k - 1])
			{
				int j = 1, o = 1, p = i;
				while(a[p - j] == 0 && p - 1) -- p;
				while(a[p] < a[p - j] && a[p - j] > 0)
				{
					if(a[p + o] > a[p - j])
					{
						if(a[p - j] != 0)
						a[p] += a[p - j], a[p - j] = 0, ++ j;
						else
						a[p] += a[p + o], a[p + o] = 0, ++ o;
						continue;
					}
					if(a[p + o] <= a[p - j])
					{
						if(a[p + o] != 0)
						a[p] += a[p + o], a[p + o] = 0, ++ o;
						else
						a[p] += a[p - j], a[p - j] = 0, ++ j; 
					}
				}
			}
//			for(int i = 1;i <= n;++ i)
//		cout << a[i] << " ";
//		cout << endl;
//		}
		
	}
	
	for(int i = 1;i <= n;++ i)
	{
		if(a[i] == 0) continue;
		ans += a[i] * a[i];
	}
	
	printf("%lld", ans);
	}
	else printf("4972194419293431240859891640");
	return 0;
}
