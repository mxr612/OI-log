#include<cstdio>
#include<algorithm>
#include<iostream>
#define LL long long
using namespace std;
const int MAXN = 107, MAXM = 1007, mod1 = 998244353;
bool pt[MAXN][MAXM], pt1[MAXN];
int n, m, vge[MAXM];
LL ans;
struct node
{
	int zero;
	LL num[MAXM];
}a[MAXN];
inline bool cmp1(node a, node b)
{
	return a.zero < b.zero;
}
void dfs(int method/*һ��Ҫѡ������*/, int lie/*����*/,int all, int sum/*�˻�*/, int hang/*���� + Ŀǰѡ�˼�����*/)
{
	if(all == method)
	{
		ans = ans % mod1 + sum % mod1;
		return;
	}
	for(int j = hang;j <= n;++ j)
	{
		
	for(int i = 1;i <= m;++ i)
	{
		if(a[hang].zero == 0 || pt1[j] || a[j].num[i] == 0 || pt[j][i] || vge[i] + 1 > (method >> 1))continue;
		pt[j][i] = 1;
		pt1[j] = 1;
		++ vge[i];
		dfs(method, i, all + 1, sum % mod1 * a[j].num[i] % mod1, j);
		-- vge[i];
		pt1[j] = 0;
		pt[j][i] = 0;
	}
	
	}
}
int main()
{
//	freopen("meal.in","r",stdin);
//	freopen("meal.out","w",stdout);
	scanf("%d%d", &n, &m);
	for(int i = 1;i <= n;++ i)
	{
		for(int j = 1;j <= m;++ j)
		{
			scanf("%lld", &a[i].num[j]);
			if(a[i].num[j] > 0)++ a[i].zero;
		}
	}
	sort(a + 1, a + 1 + n, cmp1);
	
	for(int i = 2;i <= n;++ i)
	{
		dfs(i, 1, 0, 1, 1);
	}
	printf("%lld", ans);
	return 0;
}
