#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;

long long f[51][51000];
long long s[101];
long long ans;
int n,Ty;
long long a[101];

long long Sqr(long long x)	{
	return x*x;
}

bool Min(long long x,long long y)	{
	return x<y;
}

int main()	{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	memset(f,0,sizeof(f));
	memset(s,0,sizeof(s));
	scanf("%d%d",&n,&Ty);
	for (int i=1;i<=n;++i)
		scanf("%lld",&a[i]);
	for (int i=1;i<=n;++i)
		s[i]=s[i-1]+a[i];
	for (int i=1;i<=n;++i)
		for (int k=0;k<=s[i-1];++k)	
			for (int j=0;j<=i-1;++j)	
			if (f[j][k]!=0||(j==0&&k==0)){
				if (s[i]-s[j]>=k) 
					if (f[i][s[i]-s[j]]==0) f[i][s[i]-s[j]]=f[j][k]+Sqr(s[i]-s[j]);
					else if (Min(f[j][k]+Sqr(s[i]-s[j]),f[i][s[i]-s[j]]))
							f[i][s[i]-s[j]]=f[j][k]+Sqr(s[i]-s[j]);
			}
	ans=0;
	for (int k=1;k<=s[n];++k)
		if (ans==0) ans=f[n][k];
		else if (f[n][k]!=0&&Min(f[n][k],ans)) ans=f[n][k];
	printf("%lld",ans);
	return 0;
}
