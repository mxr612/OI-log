#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;

long long INF=998244353;
int n,m;
long long a[110][2100];
long long s[110];
long long ans;
long long f[110][110][110];
long long f0[110][110];
long long total[110];
long long w[110];
int u;

int main()	{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	memset(s,0,sizeof(s));
	ans=0;
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;++i)
		for (int j=1;j<=m;++j)	{
			scanf("%lld",&a[i][j]);
			s[i]+=a[i][j];
		}	
	for (int i=1;i<=n;++i) 
		w[i]=s[i];
	memset(f,0,sizeof(f));
	for (int i=0;i<=n;++i)
		f0[i][0]=1;
	for (int i=1;i<=n;++i)	
		for (int j=1;j<=n;++j)
			f0[i][j]=((f0[i-1][j-1]*s[i]%INF)%INF+f0[i-1][j])%INF;
			
	memset(total,0,sizeof(total));
	for (int i=1;i<=n;++i) 
		total[i]=f0[n][i];		
	
	memset(f,0,sizeof(f));
	
	for (int p=1;p<=m;++p)	{
		for (int i=1;i<=n;++i) 
			s[i]-=a[i][p];
		memset(f,0,sizeof(f));
		for (int i=0;i<=n;++i) 
			for (int k=0;k<=n;++k)
				f[i][0][0]=1;
		for (int i=1;i<=n;++i)	{
			for (int k=1;k<=i;++k)	{
				for (int j=0;j<=k;++j)	{
					f[i][k][j]=(f[i-1][k-1][j-1]*a[i][p]%INF+f[i-1][k-1][j]*s[i]%INF+f[i-1][k][j])%INF;
				}
			}
		}
		for (int i=1;i<=n;++i)	{
			u=i/2+1;
			for (int j=u;j<=n;++j)	{
				total[i]=(total[i]-f[n][i][j])%INF;
			}
		}
		for (int i=1;i<=n;++i)
			s[i]+=a[i][p];
	}
	for (int i=1;i<=n;++i)
		ans=(ans+total[i])%INF;
	ans=(ans%INF+INF)%INF;
	printf("%lld",ans);
	return 0;
}
