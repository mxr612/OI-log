#include<bits/stdc++.h>
using namespace std;
int n,t;
inline int read(){
	int x=0,f=0;
	char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=1;c=getchar();}
	while(c>='0'&&c<='9'){
		x=(x<<3)+(x<<1)+c-'0';
		c=getchar();
	}
	return f?-x:x;
}
int a[405],sum[405];
long long ans=1000000000000000;
int tot[405];
void dfs(int b,int c,int d,int e){
	if(d==n+1){
		if(b!=n-1)tot[++c]=sum[n]-sum[b];
		if(tot[c]<tot[c-1]){
			tot[c-1]+=tot[c];
			c--;
		}
		long long to=0;
		for(int i=1;i<=c;i++){
			to+=tot[i]*tot[i]; 
		}
		ans=min(ans,to);
		return;
	}
	if(e==1){
		tot[c]=sum[d]-sum[b];
		if(tot[c]>=a[b]&&tot[c]>=tot[c-1]){
			b=d;
			dfs(b,c,d+1,0);
			dfs(b,c+1,d+1,1);
		}
		return;
	}
	dfs(b,c,d+1,0);
	dfs(b,c+1,d+1,1);
	return;
}
#define rr read()
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=rr,t=rr;
	for(int i=1;i<=n;i++){
		a[i]=rr;
		sum[i]=sum[i-1]+a[i];
	}
	for(int i=1;i<=n;i++){
		dfs(0,1,i,1);
	}
	cout<<ans;
	return 0;
}

