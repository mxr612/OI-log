#include<bits/stdc++.h>
using namespace std;
inline int read(){
	int x=0,f=0;
	char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=1;c=getchar();}
	while(c>='0'&&c<='9'){
		x=(x<<3)+(x<<1)+c-'0';
		c=getchar();
	}
	return f?-x:x;
}
int anss=0,n,m;
#define rr read()
#define mo 998244353
int a[105][2005];
int cn[105],hn[2005];
void dfs(int x,int y){
	cn[x]=y;
	hn[y]++;
	if(y!=0&&a[x][y]==0){
		hn[y]--;
		return;
	}
	if(y!=0&&hn[y]>((n-hn[0])/2)){
		hn[y]--;
		return;
	}
	if(x==n){
		if(hn[0]>=n-1){
			hn[y]--;
			return;	
		}
		for(int i=1;i<=m;i++){
			if(hn[i]>(n-hn[0])/2){
				hn[y]--;
				return;
			}
		}
		long long tot=1,flag=0;
		for(int i=1;i<=n;i++){
			if(a[i][cn[i]]==0&&cn[i]){
				flag=0;
				break;
			}
			if(a[i][cn[i]]!=0){
				tot*=a[i][cn[i]];
				tot%=mo;
				flag=1;
			}
		}
		if(flag)anss+=tot;
		anss%=mo;
		hn[y]--;
		return;
	}
	for(int i=0;i<=m;i++){
		dfs(x+1,i);
	}
	hn[y]--;
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=rr,m=rr;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			a[i][j]=rr;
		}
	}
	for(int i=0;i<=m;i++){
		dfs(1,i);
	}
	cout<<anss;
	return 0;
}
