#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N=4*1e7+10;
ll n;
ll a[N];
ll sum[N];
ll ans=0x7fffffffffffffff;
void dfs(ll x,ll cnt,ll res)
{
	if(res>ans)return ;
	sum[cnt]=0;
	if(x==(n+1))
	{
		ans=min(ans,res);
		return ;
	}
	for(register ll len=x;len<=n;len++)
	{
		sum[cnt]+=a[len];
		if(sum[cnt]<sum[cnt-1])continue;
		dfs(len+1,cnt+1,res+sum[cnt]*sum[cnt]);
	}
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	ll ty;
	scanf("%lld %lld",&n,&ty);
	if(!ty)
	{
		for(register ll i=1;i<=n;i++)scanf("%lld",&a[i]);
		dfs(1,1,0);
		printf("%lld",ans);
	}
	else puts("4972194419293431240859891640");
	return 0; 
}
/*
50 0
6 2 3 5 1 4 12 18 0 20 
*/
