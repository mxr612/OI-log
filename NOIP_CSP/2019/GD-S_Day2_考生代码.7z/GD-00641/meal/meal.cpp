#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N=110,mod=998244353;
ll n,m;
ll dp[N][N][N];
ll sum[N];
ll a[N][N];
ll ans;
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	ans=1ll;
	for(register ll i=1ll;i<=n;i++)
	{
		for(register ll j=1ll;j<=m;j++)
		{
			scanf("%lld",&a[i][j]);
			sum[i]+=a[i][j];
		}
		ans=ans*(sum[i]+1ll)%mod;
	}
	for(register ll i=1ll;i<=m;i++)
	{
		memset(dp,0,sizeof(dp));
		dp[0][0][0]=1ll;
		for(register ll j=1ll;j<=n;j++)
		{
			for(register ll k=0ll;k<=n;k++)
			{
				for(register ll l=0ll;l<=n;l++)
				{
					if(l&&(sum[j]-a[j][i]))dp[j][k][l]=(dp[j][k][l]+dp[j-1ll][k][l-1ll]*(sum[j]-a[j][i])+mod)%mod;
					if(a[j][i])dp[j][k][l]=(dp[j][k][l]+dp[j-1ll][k-1ll][l]*a[j][i]+mod)%mod;
					dp[j][k][l]=(dp[j][k][l]+dp[j-1ll][k][l]+mod)%mod;
				}
			}
		}
		for(register ll j=1ll;j<=n;j++)
			for(register ll k=0ll;k<j;k++)
				ans=(ans-dp[n][j][k]+mod)%mod;
	}
	ans=(ans-1ll+mod)%mod;
	printf("%lld",ans);
	return 0;
}
/*
3 3
1 2 3
4 5 0
6 0 0
*/
/*
5 5
1 0 0 1 1
0 1 0 1 0
1 1 1 1 0
1 0 1 0 1
0 1 1 0 1
*/
/*
15 3
60 25 75
160 53 102
231 219 100
215 122 124
230 115 13
134 180 146
83 2 77
116 141 5
202 184 18
210 76 8
147 149 25
99 119 232
177 18 176
85 206 209
96 223 13
*/
