#include<bits/stdc++.h>
using namespace std;
const int N=300010;
int n,cnt=0;
int to[N<<1],nxt[N<<1],head[N];
int si,mid;
void add(int u,int v)
{
	to[++cnt]=v;
	nxt[cnt]=head[u];
	head[u]=cnt;
}
struct edge
{
	int x,y;
}e[N];
int siz[N];
int tot=0;
long long ans=0ll;
void dfs(int u,int cant,int fa)
{
	if(tot==2)return ;
	bool flag=0;
	if((si-siz[u])>mid)return ;
	for(int i=head[u];i;i=nxt[i])
	{
		int v=to[i];
		if(v==cant||v==fa)continue;
		if(siz[v]>mid)
		{
			flag=1;
			break;
		}
	}
	if(!flag)
	{
		ans=ans+1ll*u;
		tot++;
		if(tot==2)return;
	}
	for(int i=head[u];i;i=nxt[i])
	{
		int v=to[i];
		if(v==fa||v==cant)continue;
		dfs(v,cant,u);
		if(tot==2)return ;
	}
}
long long d[N];
void search(int u,int fa,int cant,int dep)
{
	siz[u]=1;
	d[dep]=1ll*u;
	for(int i=head[u];i;i=nxt[i])
	{
		int v=to[i];
		if(v==fa||v==cant)continue;
		search(v,u,cant,dep+1);
		siz[u]+=siz[v];
	}
}
int st[N];
int f[N];
void update(int u,int del)
{
	if(!u)return ;
	st[++st[0]]=siz[f[u]];
	siz[f[u]]-=del;
	update(f[u],del);
}
void modify(int u,int now)
{
	if(!u)return ;
	siz[f[u]]=st[now];
	modify(f[u],now+1);
}
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(!isdigit(ch))
	{
		if(ch=='-')f=-1;
		ch=getchar();	
	}
	while(isdigit(ch))
	{
		x=(x<<3)+(x<<1)+(ch^48);
		ch=getchar();
	}
	return x*f;
}
int app[N];
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int t,a,b;
	t=read();
	while(t--)
	{
		ans=0ll;
		cnt=0;
		memset(head,0,sizeof(head));
		n=read();
		for(register int i=1;i<n;i++)
		{
			a=read(),b=read();
			add(a,b),add(b,a);
			e[i].x=a,e[i].y=b;
		}
		if(n<=50000&&n>2000) 
		{
			memset(d,0,sizeof(d));
			memset(app,0,sizeof(app));
			int rt;
			for(register int i=1;i<n;i++)app[e[i].x]++,app[e[i].y]++;
			for(register int i=1;i<=n;i++)
			{
				if(app[i]==1)
				{
					rt=i;
					break;
				}
			}
			search(rt,0,0,1);
			for(register int i=1;i<n;i++)
			{
				int xx=e[i].x,yy=e[i].y;
				if(siz[xx]<siz[yy])swap(xx,yy);
				int si=siz[rt]-siz[yy];
				if(si&1)ans+=d[(si+1)>>1];
				else ans+=d[(si>>1)]+d[(si>>1)+1];
				int pos=siz[rt]-siz[yy]+1;
				if(siz[yy]&1)ans+=d[pos+(siz[yy]>>1)];
				else ans+=d[pos+(siz[yy]>>1)]+d[pos+(siz[yy]>>1)-1];
			}
		}
		else 
		{
			memset(f,0,sizeof(f));
			search(1,0,0,1);
			f[1]=0;
			for(int i=1;i<n;i++)
			{
				int xx=e[i].x,yy=e[i].y;
				if(siz[xx]>siz[yy])f[yy]=xx;
				else f[xx]=yy;
			}
			for(register int i=1;i<n;i++)
			{
				st[0]=0;
				int xx=e[i].x,yy=e[i].y;
				if(siz[xx]<siz[yy])swap(xx,yy);
				update(yy,siz[yy]);
				tot=0,si=siz[1],mid=floor(si>>1);
				dfs(1,yy,0);
				tot=0,si=siz[yy],mid=floor(si>>1);
				dfs(yy,xx,0);
				modify(yy,1);
			}
		}
		printf("%lld\n",ans);
	}	
	return 0;
}
/*
2
5
1 2
2 3
2 4
3 5
7
1 2
1 3
1 4
3 5
3 6
6 7
*/
/*
1
8
4 2
4 7
1 7
3 5
2 8
3 6
5 1
*/
