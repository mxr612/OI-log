#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#define ll long long
using namespace std;
int n,m;
const ll mod=998244353;
ll a[120][2400];
int num[2400],gun;
//ll dp[2][21][21][21];
ll ans;
inline void dfs(int x,ll sum,int g){
	if(x==n+1){
		for(int i=1;i<=m;++i) if(num[i]>(g/2)){
			return;
		}
		ans=(ans+sum)%mod;
		return;
	}
	for(int i=0;i<=m;++i){
		if(i!=0&&!a[x][i]) continue;
		if(i==0){
			dfs(x+1,sum,g);
		}
		else{
			if(num[i]+1>((n-x+g+1)/2)) continue;
			num[i]++;
			dfs(x+1,(sum*a[x][i])%mod,g+1);
			num[i]--;
		}
	}
	return;
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	register int i,j;
	for(i=1;i<=n;++i){
		for(j=1;j<=m;++j) scanf("%lld",&a[i][j]);
	}
//	if(n*m<=30){
		for(i=1;i<=n;++i){
        	for(j=1;j<=m;++j){
	        	if(a[i][j]){
		        	num[j]++;
	    	     	dfs(i+1,a[i][j]%mod,1);
	    	     	num[j]--;
	        	}
        	}
        }
//	}
	printf("%lld\n",ans);
	return 0;
}
/*
5 5
1 0 0 1 1
0 1 0 1 0
1 1 1 1 0
1 0 1 0 1
0 1 1 0 1
*/
