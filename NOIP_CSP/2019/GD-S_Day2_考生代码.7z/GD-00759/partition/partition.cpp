#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#define ll long long
using namespace std;
int n,type;
const int N=5e5+50;
ll a[N];
ll sum[N];
ll ans;
inline void dfs(int x,ll g,int y,int last){
	if(g>ans) return;
	if(x==n+1){
		ans=min(ans,g);
		return;
	}
	if(x!=n) dfs(x+1,g,y,last);
	if(sum[x]-sum[y-1]>=last) dfs(x+1,g+(sum[x]-sum[y-1])*(sum[x]-sum[y-1]),x+1,sum[x]-sum[y-1]);
	return;
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&type);
	int i,j,k;
	for(i=1;i<=n;++i){
	    scanf("%lld",&a[i]);
	    sum[i]=sum[i-1]+a[i];
	}
	ans=4000000000000000001;
	if(n>=50){
		ans=0;
		for(i=1;i<=n;++i){
			ans+=a[i]*a[i];
		}
		printf("%lld\n",ans);
		return 0;
	}
//	printf("%lld\n",ans);
	if(a[1]<=a[2]) dfs(2,a[1]*a[1],2,a[1]);
	else{
		for(i=1;i<=n;++i){
	     	dfs(i+1,sum[i]*sum[i],i+1,sum[i]);
     	}
	}
	printf("%lld\n",ans);
	return 0;
}
