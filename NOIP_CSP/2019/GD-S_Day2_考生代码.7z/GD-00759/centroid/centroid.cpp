#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#define ll long long
using namespace std;
int n,t,T,m;
const int N=3e5+50;
int s[N*3],sl[N*3],sen[N*3];
bool cut[N*3];
int d[N],q,q1,dl[N],dep[N];
int rd[N];
int siz[N];
void add(int j,int k){
	s[++t]=k;
	sl[t]=sl[j];
	sl[j]=t;
	sen[t]=j;
	s[t+m]=j;
	sl[t+m]=sl[k];
	sl[k]=t+m;
	sen[t+m]=k;
	return;
}
ll ans;
int ass,p;
ll hole[3];
void dfs(int x,int y){
	siz[x]=1;
	for(int i=sl[x];i;i=sl[i]){
		int de=s[i];
		if(de==y) continue;
		if(cut[i]) continue;
		dfs(de,x);
		siz[x]+=siz[de];
	}
	return;
}
bool ask(int x){
	dfs(x,0);
	for(int i=sl[x];i;i=sl[i]){
		int de=s[i];
		if(cut[i]) continue;
		if(siz[de]>(siz[x]/2)) return 0;
	}
	return 1;
}
void work(int x){
	q=0;q1=0;
	d[++q]=x;
	dl[q]=0;
	while(q1<q){
		int u=d[++q1];
		if(ask(u)){
			hole[p++]=u;
			if(p>1) break;
		}
		for(int i=sl[u];i;i=sl[i]){
			int de=s[i];
			if(cut[i]) continue;
			if(de==d[dl[q1]]) continue;
			d[++q]=de;
			dl[q]=q1;
		}
	}
}
ll top(int x){
	p=0;
	for(int i=0;i<=2;++i) hole[i]=0;
	work(x);
//	cout<<ass<<" "<<hole[0]<<" "<<hole[1]<<endl;
	return hole[0]+hole[1];
}
bool vis[N];
int next[N];
void bfs(int x){
	q=0;q1=0;
	d[++q]=x;
	for(int i=1;i<=n;++i) dep[i]=0x3f3f3f3f,vis[i]=0;
	dep[x]=0;
	int tot=0,ge;
	while(q1<q){
		int u=d[++q1];
//		cout<<u<<endl;
		for(int i=sl[u];i;i=sl[i]){
			int de=s[i];
//			if(u==2) cout<<dep[de]<<" "<<dep[u]<<endl;
			if(dep[de]>dep[u]+1){
				dep[de]=dep[u]+1;
				d[++q]=de;
				if(tot<dep[de]){
					tot=dep[de];
					ge=de;
				}
			}
		}
	}
//	cout<<ge<<endl;
	vis[ge]=1;
	q=0;q1=0;
	d[++q]=ge;
	while(q1<q){
		int u=d[++q1];
		for(int i=sl[u];i;i=sl[i]){
	    	int de=s[i];
//	    	cout<<de<<endl;
	     	if(vis[de]) continue;
	     	vis[de]=1;
	     	next[u]=de;
	     	d[++q]=de;
    	}
	}
	ans=ge*2+d[q]*2;
	if(n%2==0){
		ans+=(d[(q/2)]*2+d[(q/2)+1]*2);
		for(int i=2;i<q;++i){
			if(i==q/2||i==(q/2)+1) continue;
			ans+=d[i]*3;
		}
	} 
	else{
		ans+=(d[(q/2)+1]*2);
		for(int i=2;i<q;++i){
			if(i==(q/2)+1) continue;
			ans+=d[i]*3;
		}
	}
	return;
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	int i,j,k;
	bool flag=0;
	while(T--){
		scanf("%d",&n);t=n;m=n-1;ans=0;
		for(i=1;i<=n;++i) s[i]=i,sl[i]=0;
		for(i=1;i<n;++i){
			scanf("%d%d",&j,&k);
			rd[j]++;rd[k]++;
			add(j,k);
		}
		for(i=1;i<=n;++i) if(rd[i]>2){
			flag=1;break;
		} 
		if(!flag){
			bfs(1);
			printf("%lld\n",ans);
			continue;
		}
		for(i=n+1;i<=t;++i){
			int de=s[i];
			int de1=sen[i];
			cut[i]=1;cut[i+m]=1;
			ans+=top(de)+top(de1);
//			cout<<ans<<endl;
			cut[i]=0;cut[i+m]=0;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
/*
2
5
2 4
3 1
5 1
3 4
7
1 2
1 3
1 4
3 5
3 6
6 7
*/
