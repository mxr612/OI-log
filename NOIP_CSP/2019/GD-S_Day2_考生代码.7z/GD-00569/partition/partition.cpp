#include <bits/stdc++.h>
using namespace std;
int a[5007];
int n,type;
unsigned long long minans=9223372036854775807;
unsigned long long ans;
void f(unsigned long long k1,unsigned long long sum1)
{
	unsigned long long sum2=0;
	unsigned long long mem=ans;
	for (int k2=k1+1;k2<=n;k2++)
	{
		ans=mem;
		sum2+=a[k2];
		ans+=sum2*sum2;
		if (sum2>=sum1)
		{
			if (k2==n)
			{
				minans=min(ans,minans);
			}
			else f(k2,sum2);
		}
	}
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>type;
	for (int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	f(0,0);
	cout<<minans;
	return 0;
}
