#include <bits/stdc++.h>
using namespace std;
int a[107][2007];
int n_[107],m_[2007];
int ans=0;
int fans=1;
int n,m;
int f(int k,int l)
{
	for (int i=l+1;i<=n;i++)
	{
		for (int j=1;j<=m;j++)
		{
			if (n_[i]!=0 && m_[j]!=0 && a[i][j]!=0)
			{
				n_[i]--;m_[j]--;
				int mem=fans;
				fans*=a[i][j];fans%=998244353;
				a[i][j]--;
				if (k==1)  
				{
					ans+=fans;
					ans%=998244353;
				}
				else
					f(k-1,i);
				n_[i]++;m_[j]++;a[i][j]++;
				fans=mem;
			}
		}
	}
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
			cin>>a[i][j];
	memset(n_,1,sizeof(n_));
	for (int k=2;k<=n;k++)
	{
		for (int i=1;i<=m;i++)  m_[i]=k/2;
		f(k,0);
	}
	cout<<ans;
	return 0;
}
