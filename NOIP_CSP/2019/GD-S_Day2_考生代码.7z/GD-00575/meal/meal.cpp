#include <iostream>
#include <cstdio>
#include <cstring>
#define ll long long
using namespace std;
const int maxn=105;
const int mod=988244353;
int n,m,mos;
int used[maxn];
ll ans,a[maxn][maxn];
inline ll read(){
	char c=getchar();
	ll s=0;
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9'){
		s=s*10+c-'0';
		c=getchar();
	}
	return s;
} 
void dfs(int now,int k,ll cnt){
	if (!k){
		ans=(ans+cnt)%mod;
		return;	
	}
	for (int j=now;j<=n-k+1;++j)
	for (int i=1;i<=m;++i){
		if (a[j][i]&&(used[i]+1<=mos/2)){
			++used[i];
			dfs(j+1,k-1,(cnt*a[j][i])%mod);
			--used[i];
		}
	}
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;++i)
		for (int j=1;j<=m;++j){
			a[i][j]=read();
		}
	for (int i=2;i<=n;++i){
		mos=i;
		dfs(1,i,1);
	}
	cout<<ans%mod<<endl;
	return 0;
}
