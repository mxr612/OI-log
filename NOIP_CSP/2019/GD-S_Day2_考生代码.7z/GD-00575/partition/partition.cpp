#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector>
#define ll long long
using namespace std;
const int maxn=500005;
ll temp,x,ans,n,tp,cnt=1;
ll a[maxn];
vector<int> num[maxn];
inline ll sq(ll a){return a*a;}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%lld%lld",&n,&tp);
	scanf("%lld",&a[1]);
	for (int i=2;i<=n;++i){
		scanf("%lld",&x);
		if (x+temp>=a[cnt]) {
		num[cnt+1].push_back(x);
		a[++cnt]=x+temp,temp=0;
		}
		else{
			temp+=x;
			num[cnt+1].push_back(x);
			if (temp>a[cnt]) a[++cnt]=temp,temp=0;
		}
	}
	if (temp) {
	a[cnt]+=temp;
	num[cnt].push_back(temp);
	}
	for (int i=2;i<=cnt;++i){
		for (int j=0;j<num[i].size();++j){
			if (a[i-1]+num[i][j]*2<=a[i]){
				a[i-1]+=num[i][j];
				a[i]-=num[i][j];
			}
			else break;
		}
	}
	for (int i=1;i<=cnt;++i){
		ans+=sq(a[i]);
	}
	cout<<ans;
	return 0;
}
