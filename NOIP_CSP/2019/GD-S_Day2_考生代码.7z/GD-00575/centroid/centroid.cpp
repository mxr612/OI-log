#include <iostream>
#include <cstdio>
#include <cstring>
#define rint register int
using namespace std;
const int maxn=300005;
int T,n,ans;
int head[maxn],num,rd[maxn];
struct node{
	int to,nxt;
}e[maxn*2];
inline int read(){
	char c=getchar();
	int s=0;
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9') {
		s=s*10+c-'0';
		c=getchar();
	}
	return s;
}
void add(int from,int to){
	++num;
	e[num].nxt=head[from];
	e[num].to=to;
	head[from]=num;
}
int id1,id2,maxrd=-1;
void work(int x,int fa,int deny){
	if (rd[x]>maxrd) {
	maxrd=rd[x];id1=x;
	}
	else if(rd[x]==maxrd){
		id2=x;
	}
	for (rint i=head[x];i;i=e[i].nxt){
		int to=e[i].to;
		if (to==fa||to==deny) continue;
		work(to,x,deny);
	}
}
void dfs(int x,int fa){
	for (rint i=head[x];i;i=e[i].nxt){
		int to=e[i].to;
		if (to==fa) continue;
		--rd[x];--rd[to];
		work(x,0,to);
		maxrd=-1;
		ans+=id1+id2;
		id1=0;id2=0;
		work(to,0,x);
		maxrd=-1;
		ans+=id1+id2;
		id1=0;id2=0;
		++rd[x];++rd[to];
		dfs(to,x);
	}
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	T=read();
	int l,r;
	while (T--){
		n=read();
		for (rint i=1;i<n;++i){
			l=read();r=read();
			add(l,r);
			add(r,l);
			++rd[l];
			++rd[r];
		}
		dfs(1,0);
		printf("%d\n",ans);
		ans=0;
		for (rint i=1;i<=n;++i){
			e[i].nxt=0;
			e[i].to=0;
			head[i]=0;
			rd[i]=0;
		}
		num=0;
	}
	return 0;
}
