#include<cstdio>
#include<cstring>
using namespace std;
const int mod=998244353;
int ri()
{
	char c=getchar();int s=0;
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9')s=(s<<1)+(s<<3)+c-'0',c=getchar();
	return s;
}
int n,m,a[110][2100];
int sum[2100],mb,ans;
void dfs(int now,int s)
{
	if(s==mb)
	{
		ans=(ans+1)%mod;
		return;
	}
	if(now==n+1)return;
	for(int i=1;i<=m;i++)if(a[now][i]&&sum[i]<mb/2)
	{
		sum[i]++;
		dfs(now+1,s+1);
		sum[i]--;
	}
	dfs(now+1,s);
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	n=ri();m=ri();
	for(int i=1;i<=n;i++)
	for(int j=1;j<=m;j++)a[i][j]=ri();
	memset(sum,0,sizeof(sum));ans=0;
	for(int i=2;i<=n;i++)
	{
		mb=i;
		dfs(1,0);
	}
	printf("%d\n",ans);
	return 0;
}
