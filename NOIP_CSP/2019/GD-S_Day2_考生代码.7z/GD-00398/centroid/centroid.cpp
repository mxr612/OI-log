#include<cstdio>
#include<cstring>
using namespace std;
int ri()
{
	char c=getchar();int s=0;
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9')s=(s<<1)+(s<<3)+c-'0',c=getchar();
	return s;
}
typedef long long LL;
int n;
struct bian
{
	int y,next;
}a[610000];int last[310000],len;
void ins(int x,int y)
{
	a[++len].y=y;
	a[len].next=last[x];last[x]=len;
}
int cnt[310000],fa[310000];
void getcnt(int x)
{
	cnt[x]=1;
	for(int k=last[x];k;k=a[k].next)
	{
		int y=a[k].y;
		if(y==fa[x])continue;
		fa[y]=x;
		getcnt(y);
		cnt[x]+=cnt[y];
	}
}
int sum;
LL ans;
void dfs(int x)
{
	if((sum-cnt[x])>sum/2)return;
	ans+=(LL)x;
	for(int k=last[x];k;k=a[k].next)
	{
		int y=a[k].y;
		if(y==fa[x])continue;
		if(cnt[y]>sum/2)
		{
			ans-=(LL)x;
			break;
		}
	}
	for(int k=last[x];k;k=a[k].next)
	{
		int y=a[k].y;
		if(y==fa[x])continue;
		dfs(y);
	}
}
int sta[310000],top,jd,son[310000];
void dfs2(int x)
{
	if(x==0)return;
	sta[++top]=x;
	son[fa[x]]=x;
	for(int k=last[x];k;k=a[k].next)
	{
		int y=a[k].y;
		if(y==fa[x]||y==jd)continue;
		if(cnt[y]-(y==son[x])*cnt[jd]>sum/2)return;
	}
	if((sum-(cnt[x]-cnt[jd]))<=sum/2)ans+=(LL)x;
	dfs2(fa[x]);
}
void dfs3(int x)
{
	if((sum-cnt[x])>sum/2)return;
	ans+=(LL)x;
	for(int k=last[x];k;k=a[k].next)
	{
		int y=a[k].y;
		if(y==fa[x])continue;
		if(cnt[y]>sum/2)
		{
			ans-=(LL)x;
			break;
		}
	}
	for(int k=last[x];k;k=a[k].next)
	{
		int y=a[k].y;
		if(y==fa[x])continue;
		dfs3(y);
	}
}
int lowbit(int x){return x&(-x);}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int t=ri();
	while(t--)
	{
		n=ri();
		if(n==1)
		{
			puts("0");
			continue;
		}
		memset(last,0,sizeof(last));len=0;
		memset(cnt,0,sizeof(cnt));
		for(int i=1;i<n;i++)
		{
			int x=ri(),y=ri();
			ins(x,y);ins(y,x);
			cnt[x]++;cnt[y]++;
		}
		int A=0;
		for(int i=1;i<=n;i++)
		{
			if(cnt[i]==1)A++;
		}
		if(A<=2)
		{
			int dd;
			for(int i=1;i<=n;i++)if(cnt[i]==1){dd=i;break;}
			sta[top=1]=dd;
			int ff=0;
			do
			{
				int tt=dd;
				dd=(a[last[dd]].y==ff)?(a[a[last[dd]].next].y):(a[last[dd]].y);
				ff=tt;
				sta[++top]=dd;
			}while(a[last[dd]].next);
			LL nn=(LL)n;
			ans=nn*(nn+1)/2*3-(LL)sta[1]-(LL)sta[top];
			if(n&1)
			{
				ans-=(LL)sta[n/2+1];
			}
			else
			{
				ans-=(LL)sta[n/2]-(LL)sta[n/2+1];
			}
			printf("%lld\n",ans);
			continue;
		}
		/*if(n+1-lowbit(n+1)==0&&2*A-1==n&&!bk)
		{
			fa[1]=0;dep[1]=1;dfs4(1);
			ans=(LL)0;
			for(int i=2;i<=n;i++)
			{
				ans+=(LL)i;
				int sum=n-cnt[i];
				int lls=2*dep[fa[i]]-1;
			}
		}*/
		fa[1]=0;getcnt(1);
		ans=(LL)0;
		for(int i=2;i<=n;i++)
		{
			sum=cnt[i];
			ans+=(LL)i;
			for(int k=last[i];k;k=a[k].next)
			{
				int y=a[k].y;
				if(y==fa[i])continue;
				if(cnt[y]>sum/2)
				{
					ans-=(LL)i;
					break;
				}
			}
			for(int k=last[i];k;k=a[k].next)
			{
				int y=a[k].y;
				if(y==fa[i])continue;
				dfs(y);
			}
			sum=n-cnt[i];jd=son[fa[i]]=i;top=0;dfs2(fa[i]);
			while(top)
			{
				int x=sta[top--];
				for(int k=last[x];k;k=a[k].next)
				{
					int y=a[k].y;
					if(y==fa[x]||y==son[x])continue;
					dfs3(y);
				}
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
