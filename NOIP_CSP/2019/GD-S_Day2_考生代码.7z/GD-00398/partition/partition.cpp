#include<cstdio>
#include<cstring>
using namespace std;
typedef long long LL;
const LL inf=(LL)9e18;
int ri()
{
	char c=getchar();int s=0,zf=1;
	while(c<'0'||c>'9')
	{
		if(c=='-')zf=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')s=(s<<1)+(s<<3)+c-'0',c=getchar();
	return s*zf;
}
LL mymin(LL x,LL y){return x<y?x:y;}
int n,ty,a[510000];
LL sum[510000],ans,lans;
void dfs(int ls,int now)
{
	if(now==n+1)
	{
		ans=mymin(lans,ans);
		return;
	}
	int l=now,r=n,mid,ss=n+1;
	while(l<=r)
	{
		mid=(l+r)>>1;
		if(sum[mid]-sum[now-1]>=ls)ss=mid,r=mid-1;
		else l=mid+1;
	}
	if(ss==n+1)return;
	for(int i=ss;i<n&&sum[n]-sum[i]>=sum[i]-sum[now-1];i++)
	{
		LL c=sum[i]-sum[now-1];
		lans+=c*c;
		dfs(c,i+1);
		lans-=c*c;
	}
	LL c=sum[n]-sum[now-1];
	lans+=c*c;
	dfs(c,n+1);
	lans-=c*c;
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=ri();ty=ri();
	if(ty==0)
	{
		sum[0]=(LL)0;
		for(int i=1;i<=n;i++)
		{
			a[i]=ri();
			sum[i]=sum[i-1]+(LL)a[i];
		}
		ans=inf;
		for(int i=1;i<=n&&(i==n||sum[n]-sum[i]>=sum[i]);i++)
		{
			lans=sum[i]*sum[i];
			dfs(sum[i],i+1);
		}
		printf("%lld\n",ans);
	}
	else puts("4972194419293431240859891640");
	return 0;
}
