#include<cstdio>
#include<algorithm>
using namespace std;
long long sum,n,m,a[1001][1001],t[1001],mo=998244353;
void dg(int x,int z,long long y)
{
	if(x>n)
	{
		if(z==0) return;
		int bz=0;
		for (int i=1;i<=m;i++)
			if(t[i]>z/2)
			{
				bz=1;
				break;
			}
		if(bz==0)
			sum=(sum+y)%mo;
		return;
	}
	dg(x+1,z,y);
	for (int i=1;i<=m;i++)
	{
		t[i]++;
		dg(x+1,z+1,(y*a[x][i])%mo);
		t[i]--;
	}
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%lld %lld",&n,&m);
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
			scanf("%lld",&a[i][j]);
	sum=0;
	dg(1,0,1);
	printf("%lld\n",sum);
	return 0;
}
