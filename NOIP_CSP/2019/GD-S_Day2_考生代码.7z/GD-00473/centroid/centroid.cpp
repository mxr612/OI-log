#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int t,n,bz,sum,u,v,en[600001],last[600001],next[600001],tot,time[600001],deep[600001],ch[600001],x[600001],y[600001];
void add(int x,int y)
{
	en[++tot]=y;
	next[tot]=last[x];
	last[x]=tot;
	time[y]++;
}
void dg(int x)
{
	int p=last[x];
	while (p>0)
	{
		if(deep[en[p]]==0)
		{
			deep[en[p]]=deep[x]+1;
			ch[deep[en[p]]]=en[p];
			dg(en[p]);
		}
		p=next[p];
	}
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&t);
	while (t>0){
	memset(last,0,sizeof(last));
	memset(next,0,sizeof(next));
	memset(en,0,sizeof(en));
	memset(ch,0,sizeof(ch));
	memset(time,0,sizeof(time));
	scanf("%d",&n);
	tot=0,sum=0;
	for (int i=1;i<n;i++)
	{
		scanf("%d %d",&x[i],&y[i]);
		add(x[i],y[i]),add(y[i],x[i]);
	}
	for (int i=1;i<=n;i++)
		if(time[i]==1)
		{
			bz=i;
			break;
		}
	deep[bz]=1;
	ch[1]=bz;
	dg(bz);
	for (int i=1;i<n;i++)
	{
		u=deep[x[i]],v=deep[y[i]];
		if(u<v)
		{
			if(u%2==1) sum+=ch[(1+u)/2];
			else sum+=ch[u/2]+ch[u/2+1];
			if(v%2==n%2) sum+=ch[(v+n)/2];
			else sum+=ch[(v+n)/2]+ch[(v+n)/2+1];
		}
		else
		{
			if(v%2==1) sum+=ch[(1+v)/2];
			else sum+=ch[v/2]+ch[v/2+1];
			if(u%2==n%2) sum+=ch[(u+n)/2];
			else sum+=ch[(u+n)/2]+ch[(u+n)/2+1];
		}
	}
	printf("%d\n",sum);
	t--;}
	return 0;
}
//@zhuajin1SHIJIAN7
