#include<cstdio>
#include<algorithm>
using namespace std;
long long n,type,x,ans,sum[1000001],f[1000001],a[1000001];
long long sqr(long long x){return x*x;}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%lld %lld",&n,&type);
	for (int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		sum[i]=sum[i-1]+a[i];
	}
	f[1]=0;
	for (long long i=2;i<=n;i++)
		for (long long j=0;j<i;j++)
			if(sum[i]-sum[j]>=sum[j]-sum[f[j]])
				f[i]=max(f[i],j);
	int p=n;
	while (p>0)
	{
		ans+=sqr(sum[p]-sum[f[p]]);
		p=f[p];
	}
	printf("%lld\n",ans);
	return 0;
}
