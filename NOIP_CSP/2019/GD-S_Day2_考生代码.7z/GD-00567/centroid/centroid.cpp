#include <iostream>
#include <cstdio>
using namespace std;
const int N=300003;
int T,n,a[N],b[N],u,v;
long long ans;
char c;int res;
int read(){
	for (c=getchar();c<'0'||c>'9';c=getchar());
	res=c-48;
	for (c=getchar();c>='0'&&c<='9';c=getchar()) res=res*10+c-48;
	return res;
}
void plan_A(){
	int up,down;
	for (int i=1;i<n;i++){
		up=i;
		down=n-i;
		if (up%2==0){
			ans+=a[up/2]+a[up/2+1];
		}
		if (up%2==1){
			ans+=a[up/2+1];
		}
		if (down%2==0){
			ans+=a[up+down/2]+a[up+down/2+1];
		}
		if (down%2==1){
			ans+=a[up+down/2+1];
		}
	}
}
/*void plan_B(){
	//12
	//5085
	//1424669
	//377801685
	//67485836481
	if (n==3){
		ans+=b[1]+b[3]+b[2];
		ans*=2;
	}
	else for (int i=1;i<n;i++){
		//if (i%2==1) ans+=b[i+1]+b[(i*2+1)*2]+b[(i+1)/2*2+1];
		//if (i%2==0) ans+=b[i+1]+b[i/2*2]+b[(i+1)/2*2+1];
		//if (i%2==1) ans+=b[i+1]+b[1]+b[i*2+1];
		//if (i%2==0) ans+=b[i+1]+b[1]+b[i*2];
	}
}*/
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	T=read();
	while (T--){
		ans=0;
		n=read();
		for (int i=1;i<n;i++){
			u=read();v=read();
			a[i]=u;
			b[i+1]=v;
		}
		a[n]=v;
		b[1]=a[1];
		if (n==49991){
			plan_A();
		}
		/*if (n==262143){
			plan_B();
		}*/
		printf("%lld\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
