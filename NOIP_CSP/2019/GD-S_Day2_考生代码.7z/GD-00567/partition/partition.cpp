#include <iostream>
#include <cstdio>
using namespace std;
const int N=40000005;
const int inf=99999999;
int n,type,a[N],p[N],inv[N];
long long ans;
char c;int res;
int read(){
	for (c=getchar();c<'0'||c>'9';c=getchar());
	res=c-48;
	for (c=getchar();c>='0'&&c<='9';c=getchar()) res=res*10+c-48;
	return res;
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	n=read();type=read();
	if (!type){
		for (int i=1;i<=n;i++){
			a[i]=read();
			p[i]=i-1;
		}
	}
	else{
		int x,y,z,b1,b2,m;
		x=read();y=read();z=read();b1=read();b2=read();m=read();
	}
	for (int i=2;i<n;i++){
		if (p[i+1]!=i) continue;
		if (a[p[i]]>a[i]&&a[i]<=a[i+1]){
			if (a[p[i]]<a[i+1]){
				a[p[i]]=a[p[i]]+a[i];
				p[i+1]=i-1;
				inv[i]=1;
			}
			else{
				a[i]=a[i]+a[i+1];
				p[i+2]=i;
				inv[i+1]=1;
			}
		}
	}
	if (a[p[n]]>a[n]){
		a[p[n]]+=a[n];
		inv[n]=1;
	}
	for (int i=1;i<=n;i++){
		if (!inv[i]){
			ans+=1ll*a[i]*a[i];
		}
	}
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
