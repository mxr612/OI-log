#include <iostream>
#include <cstdio>
using namespace std;
const int MO=998244353;
const int N=105;
const int M=2005;
int n,m,a[N][M],ans;
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++){
		for (int j=1;j<=m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for (int i=1;i<=m;i++){
		for (int j=1;j<=m;j++){
			if (i==j) continue;
			ans+=a[1][i]*a[2][j];
		}
	}
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
