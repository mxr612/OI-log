#include<iostream>
#define MAX 300001
using namespace std;
int to[2*MAX],nxt[2*MAX],loca[2*MAX],d[MAX],deep[MAX],hash[MAX],top,n,T,x,y,DEL;
int bian[2*MAX][2],belong[MAX],sizex,sizey,Size[MAX];
bool is_lian;
long long ans;
void Push(int x,int y){
	to[++top]=y;nxt[top]=loca[x];loca[x]=top;
	to[++top]=x;nxt[top]=loca[y];loca[y]=top;
	d[x]++;d[y]++;
}
void INIT(){
	for(int i=1;i<=MAX;i++)loca[i]=d[i]=0;
	top=0,ans=0,is_lian=1;
}
void solve_lian(){
	int now,cnt=2;
	for(int i=1;i<=n;i++)deep[i]=hash[i]=0;
	for(int i=1;i<=n;i++)if(d[i]==1){
		now=i;
		deep[i]=1;
		hash[1]=i;
		break;
	}
	now=to[loca[now]];
	while(d[now]==2){
		deep[now]=cnt;
		hash[cnt]=now;
		if(deep[to[loca[now]]])now=to[nxt[loca[now]]];
		else now=to[loca[now]];
		cnt++;
	}
	deep[now]=n;
	hash[n]=now;
	for(int i=1;i<n;i++){//DEL:i->i+1  [1,i]&[i+1,n]
		ans+=hash[(1+i)/2];
		ans+=hash[(i+1+n)/2];
		if((1+i)%2)ans+=hash[(1+i)/2+1];
		if((1+i+n)%2)ans+=hash[(1+i+n)/2+1];
	}
}
void dfs(int now,int fa){
	Size[now]=1;
	for(int i=loca[now];i;i=nxt[i])if(to[i]!=fa){
		if(i==DEL||i==(DEL^1))continue;
		dfs(to[i],now);
		Size[now]+=Size[to[i]];
	}
}
bool Build(int x){
	dfs(x,0);
	for(int i=loca[x];i;i=nxt[i]){
		if(i==DEL||i==(DEL^1))continue;
		if(2*(Size[to[i]])>Size[x])return 0;
	}
	return 1;
}
void solve_smalln(){
	for(int i=1;i<=top;i+=2){
		DEL=i;
		for(int j=1;j<=n;j++)if(Build(j)){
			ans+=j;
		}
	}
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	cin>>T;
	while(T--){
		cin>>n;
		INIT();
		for(int i=1;i<n;i++){
			cin>>x>>y;Push(x,y);bian[i][0]=x;bian[i][1]=y;
		}
		for(int i=1;i<=n;i++)if(d[i]>2)is_lian=0;
		if(is_lian)solve_lian();
		else if(n<=2000)solve_smalln();
		cout<<ans<<endl;
	}
}
