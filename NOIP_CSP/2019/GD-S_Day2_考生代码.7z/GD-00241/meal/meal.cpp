#include<iostream>
#include<cstdio>
#define mod 998244353
using namespace std;
int n,m;
long long a[101][2001],s[101],ans;
long long dp2[101][205];
long long DP(int x){
	for(int i=0;i<=n;i++)for(int j=0;j<=202;j++)dp2[i][j]=0;
	dp2[0][100]=1;
	for(int i=0;i<n;i++){
		for(int j=0;j<=200;j++){
			if(dp2[i][j]){
				if(j>0){
					dp2[i+1][j-1]+=dp2[i][j]*((s[i+1]+mod-a[i+1][x])%mod)%mod;
					dp2[i+1][j-1]%=mod;
				}
				dp2[i+1][j]+=dp2[i][j];
				dp2[i+1][j+1]+=dp2[i][j]*a[i+1][x];
				dp2[i+1][j]%=mod;
				dp2[i+1][j+1]%=mod;
			}
		}
	}
	long long tmp=0;
	for(int i=101;i<=202;i++)tmp+=dp2[n][i];
	return tmp%mod;
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			cin>>a[i][j];
			s[i]=(s[i]+a[i][j])%mod;
		}
	}
	ans=1;
	for(int i=1;i<=n;i++)ans=(ans*(s[i]+1))%mod;
	for(int i=1;i<=m;i++)ans=(ans+mod-DP(i))%mod;
	cout<<(ans+mod-1)%mod;
	return 0;
}
