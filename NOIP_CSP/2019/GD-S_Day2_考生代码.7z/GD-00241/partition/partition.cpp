#include<algorithm>
#include<iostream>
#include<cstdio>
#define inf 4e18
using namespace std;
int n,type;
unsigned long long a[5001],s[5001],dp[5001][5001],pf[5001],spf[5001],ans,Change[5001][5001];
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	cin>>n>>type;
	if(type==1){
		return 0;
	}
	for(int i=1;i<=n;i++){
		cin>>a[i];
		s[i]=s[i-1]+a[i];
		pf[i]=a[i]*a[i];
		spf[i]=spf[i-1]+pf[i];
		ans+=pf[i];
	}
	for(int i=1;i<=n;i++)Change[i][1]=0;
	for(int j=1;j<=n;j++){
		for(int i=j;i<=n;i++){
			Change[i][j]=Change[i-1][j-1]+2*a[i]*(s[i-1]-s[i-j]);
			if(Change[i][j]>inf)Change[i][j]=inf;
		}
	}
	for(int i=0;i<=n;i++)for(int j=0;j<=n;j++)dp[i][j]=inf;
	dp[1][1]=0;
	for(int i=2;i<=n;i++){
		for(int j=1;j<=i;j++){
			if(a[i]<s[i-1]-s[i-1-j])break;
			dp[i][1]=min(dp[i][1],dp[i-1][j]);
		}
		for(int j=2;j<i;j++){
			if(Change[i][j]>inf)break;
			for(int k=0;k<=i-j;k++){
				if(s[i]-s[i-j]<s[i-j]-s[i-j-k])break;
				if(dp[i-j][k]!=inf)dp[i][j]=min(dp[i][j],dp[i-j][k]);
			}
			if(dp[i][j]>inf)dp[i][j]=inf;
			dp[i][j]+=Change[i][j];
			if(dp[i][j]>inf)dp[i][j]=inf;
		}
		dp[i][i]=Change[i][i];
	}
	unsigned long long Min=inf;
	for(int i=1;i<=n;i++)Min=min(Min,dp[n][i]);
	cout<<ans+Min;
}
