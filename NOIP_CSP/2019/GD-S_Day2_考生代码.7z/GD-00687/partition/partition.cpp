#include<bits/stdc++.h>
#define N 5050
using namespace std;
typedef long long ll;
ll ans=0ll,now=0ll;
int n,ty,a[N],g[N];
ll f[N],s[N];
int main(){
	freopen("partition.in","r",stdin),freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&ty),s[0]=0;
	if (ty==0) for (int i=1;i<=n;i++) scanf("%d",&a[i]),s[i]=s[i-1]+a[i];
	for (int i=1;i<=n;i++){
		//j=0;
		g[i]=1,f[i]=s[i]*s[i];
		for (int j=1;j<i;j++){
			if (s[i]-s[j] < s[j]-s[g[j]-1]) continue;
			if (f[j]+(s[i]-s[j])*(s[i]-s[j]) <= f[i]) f[i]=f[j]+(s[i]-s[j])*(s[i]-s[j]),g[i]=j+1;
		}
	}
	printf("%lld\n",f[n]);
}
