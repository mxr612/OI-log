#include<bits/stdc++.h>
#define p 998244353
#define N 105
#define M 2019
#define re(x) (x+100)
using namespace std;
typedef long long ll;
int a[N][M],n,m;
ll s[N],ans1=1ll,ans2=0ll,ans;
ll f[N][2*N],X,Y;
int main(){
	freopen("meal.in","r",stdin),freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++){
		s[i]=0ll;
		for (int j=1;j<=m;j++) scanf("%d",&a[i][j]),s[i]=(s[i]+a[i][j])%p;
		ans1=ans1*(s[i]+1)%p;
	}
	ans1=(ans1-1)%p;
	for (int j=1;j<=m;j++){
		memset(f,0,sizeof(f)),f[0][re(0)]=1ll;
		for (int i=1;i<=n;i++) 
		{
			X=a[i][j],Y=(s[i]-a[i][j]+p)%p;
			if (i==1){
				f[1][re(1)]=X;
				f[1][re(-1)]=Y;
				f[1][re(0)]=1ll;
				continue;
			}
			for (int k=-n;k<=n;k++){
				f[i][re(k)] = (f[i][re(k)] + f[i-1][re(k)])%p; //��ѡ
				if ((k!=-n) && (X!=0)) f[i][re(k)] = (f[i][re(k)] + f[i-1][re(k-1)]*X%p)%p; //ѡ��Ҫ 
				if ((k!=n) && (Y!=0)) f[i][re(k)] = (f[i][re(k)] + f[i-1][re(k+1)]*Y%p)%p; //ѡ���� 
			} 	
		}
		for (int k=1;k<=n;k++) ans2=(ans2+f[n][re(k)])%p;
	}
	ans=(ans1-ans2+p)%p;
	printf("%lld\n",ans);
}
