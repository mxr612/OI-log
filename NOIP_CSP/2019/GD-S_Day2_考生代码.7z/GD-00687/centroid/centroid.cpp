#include<bits/stdc++.h>
#define N 300000
#define add(u,v) to[++top]=head[u],head[u]=top,w[top]=v
#define For(x) for(int h=head[x],o=w[h];h;o=w[h=to[h]])
using namespace std;
typedef long long ll;
int top,head[N*2],to[N*2],w[N*2],sz[N];
int n,T,u[N],v[N],d[N];
int bo,st,a[N*2],rtop,si;    //for A&B
int mtop,ma[100],mb[100],dep; //for B
ll ans,cnt,t[40];
inline void dfs(int x,int fa){
	sz[x]=1;
	For(x) if (o!=fa) dfs(o,x),sz[x]+=sz[o];
}
inline void dfs2(int x,int fa,int rt){
	int tmp=sz[rt]-1,flag=1;
	For(x) if (o!=fa){
		dfs2(o,x,rt),tmp-=sz[o];
		if (sz[o]>(sz[rt]/2)) flag=0;
	}
	if (tmp>(sz[rt]/2)) flag=0;
	if (flag) ans+=x,cnt+=x;
}
inline void dfs3(int x,int fa){
	a[++rtop]=x;
	For(x) if (o!=fa) {dfs3(o,x);}
}
inline void dfs4(int x,int fa){
	dep++;
	For(x)if (o!=fa){
		mtop++,ma[mtop]=x,mb[mtop]=o,dfs4(o,x);
		break;
	}
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	t[0]=1ll;
	for (int i=1;i<=27;i++) t[i]=t[i-1]*2;
	while (T--){
		scanf("%d",&n);
		top=0,memset(head,0,sizeof(head)),memset(to,0,sizeof(to)),memset(w,0,sizeof(w));
		ans=0,memset(sz,0,sizeof(sz)),bo=1,memset(d,0,sizeof(d));
		for (int i=1;i<n;i++){
			scanf("%d%d",&u[i],&v[i]),add(u[i],v[i]),add(v[i],u[i]);
			d[u[i]]++,d[v[i]]++;
		}
		
		
		for (int i=1;i<=n;i++) if (d[i]>=3) bo=0;
		if (bo){   //A
			for (int i=1;i<=n;i++) if (d[i]==1){st=i;break;}
			rtop=0,dfs3(st,0);
			for (int i=1;i<n;i++){
				if ((i%2)==1) ans+=a[(i+1)/2];else ans+=a[i/2]+a[i/2+1];
				si=n-i;
				if ((si%2)==1) ans+=a[i+(si+1)/2];else ans+=a[i+si/2]+a[i+1+si/2]; 
			}
			printf("%lld\n",ans);
			continue;
		}
		
		
		if (n>=2000){//B
			for (int i=1;i<=n;i++) if (d[i]==2){st=i;break;}
			mtop=0,dep=0;
			dfs4(st,0);
			for (int i=1;i<=mtop;i++){
				cnt=0ll;
				dfs(ma[i],mb[i]),dfs(mb[i],ma[i]);
				dfs2(ma[i],mb[i],ma[i]),dfs2(mb[i],ma[i],mb[i]);
				ans=ans+t[i]*cnt;
			}
			printf("%lld\n",ans);
			continue;
		}
		
		
		for (int i=1;i<n;i++){
			dfs(u[i],v[i]),dfs(v[i],u[i]);
			dfs2(u[i],v[i],u[i]);
			dfs2(v[i],u[i],v[i]);
		}
		printf("%lld\n",ans);
	}
}
