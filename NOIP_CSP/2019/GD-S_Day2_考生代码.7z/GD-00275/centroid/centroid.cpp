#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
using namespace std;
int n;
struct node
{
	int x,y,next;
}a[200005];int len,last[100005];
void ins(int x,int y)
{
	a[++len].x=x;a[len].y=y;
	a[len].next=last[x];last[x]=len;
}
bool b[200005];
int root_finder(int x,int fa)
{
	if(a[last[x]].next==0)return x;
	for(int k=last[x];k;k=a[k].next)
	{
		int y=a[k].y;
		if(b[y])
		{
			b[y]=0;
			return root_finder(y,x);
		}
	}
}
int main()
{
	freopen("centroid3.in","r",stdin);
	int T;scanf("%d",&T);
	while(T--)
	{
		len=0;memset(last,0,sizeof(last));
		memset(a,0,sizeof(a));memset(b,1,sizeof(b));
		int n,x,y;
		scanf("%d",&n);
		for(int i=1;i<n;i++)
		{
			scanf("%d%d",&x,&y);
			ins(x,y);ins(y,x);
		}
		int root=root_finder(1,1);
		printf("%lld\n",1ll*(n%2?n*2-3:n*3-4));
	}
	return 0;
}
