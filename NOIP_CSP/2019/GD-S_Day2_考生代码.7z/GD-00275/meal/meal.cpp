#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long LL;
int n,m,ans,mod,total;LL x;
int a[105][2005],v[2005];
bool b[105][2005];
void dfs(int k,int r,int d)
{
	if(k==0){ans+=d;ans%=mod;}
	else if(r==n+1||n-r+1<k)return;
	else
	{
		for(int i=1;i<=m;i++)
		if(v[i]<total/2&&a[r][i]!=0&&b[r][i]==1)
		{
			v[i]++;
			b[r][i]=0;
			x=d==0?(1ll*a[r][i]%mod):(1ll*a[r][i]*d)%mod;
			dfs(k-1,r+1,(int)x);
			b[r][i]=1;
			v[i]--;
		}
		dfs(k,r+1,d);
	}
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	memset(b,1,sizeof(b));
	ans=0;mod=998244353;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&a[i][j]);
	for(int k=2;k<=n;k++)total=k,dfs(k,1,0);
	printf("%d\n",ans);
	return 0;
}
