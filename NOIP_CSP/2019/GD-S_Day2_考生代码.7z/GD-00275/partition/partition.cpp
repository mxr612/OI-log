#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<iostream>
#include<algorithm>
using namespace std;
typedef long long LL;
int n,type;LL ans;
int a[5005];LL sum[5005];
int find(int st,int x)
{
	int l=st,r=n,to=-1;
	while(l<=r)
	{
		int mid=l+r>>1;
		int d=sum[mid]-sum[st-1];
		if(d>=x)
		{
			to=mid;
			r=mid-1;
		}
		else l=mid+1;
	}
	return to;
}
void dfs(int r,int d,int last,LL s)
{
	if(r==n+1)
	{
		if(ans>s+d*d)ans=s+d*d;
		return;
	}
	int R=r;
	if(d+a[r]<last)
	{
		int end=find(r,last);
		if(end==-1)return;R=end;
	}
	for(int i=R;i<=n;i++)dfs(i+1,0,d+sum[i]-sum[r-1],s+(d+sum[i]-sum[r-1])*(d+sum[i]-sum[r-1]));
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	ans=4e18;
	scanf("%d%d",&n,&type);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		sum[i]=sum[i-1]+a[i];
	}
	dfs(1,0,0,0);
	printf("%lld\n",ans);
	return 0;
}
