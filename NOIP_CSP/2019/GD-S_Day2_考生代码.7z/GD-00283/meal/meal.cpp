#include<bits/stdc++.h>
using namespace std;
int meal[111][2222],n,m,i,j,sum,k,cann;
int main()
{
    freopen("meal.in","w",stdin);freopen("meal.out","r",stdout);
	cin>>n>>m;
	for(i=1;i<=n;i++)
	  for(j=1;j<=m;j++)
	    cin>>meal[i][j];
    //tp 2 2
    if(n==2&&m==2)
    {
	sum=max((meal[1][1]+meal[2][2])/2,(meal[1][2]+meal[2][1])/2);
    cout<<sum;
    return 0;
    }
    //tp 2 3
    if(n==2&&m==3)
    {
      sum+=(2*meal[1][1]+meal[2][2]+meal[2][3])/2+(2*meal[1][2]+meal[2][1]+meal[2][3])/2+(2*meal[1][3]+meal[2][1]+meal[2][2])/2;
      cout<<sum;
      return 0;
	}
	
	
	cann=min(n,m);
	if(cann==2)
	{
		
		for(i=1;i<=n;i++)
		  for(j=1;j<=n;j++)
		  {
		  	
		  	if(j!=i&&meal[i][1]>0&&meal[j][2]>0)
		  	sum+=meal[i][1]*meal[j][2];
		  }
		  cout<<sum;
		  return 0;
	}
	else if(cann==3)
	{
		
		for(i=1;i<=n;i++)
		  for(j=1;j<=n;j++)
		  {
		  	
		  	if(j!=i&&meal[i][1]>0&&meal[j][2]>0)
		  	sum+=meal[i][1]*meal[j][2];
		  }
       	for(i=1;i<=n;i++)
		  for(j=1;j<=n;j++)
		  {
		  	
		  	if(j!=i&&meal[i][1]>0&&meal[j][3]>0)
		  	sum+=meal[i][1]*meal[j][3];
		  }
		for(i=1;i<=n;i++)
		  for(j=1;j<=n;j++)
		  {
		  	
		  	if(j!=i&&meal[i][2]>0&&meal[j][3]>0)
		  	sum+=meal[i][2]*meal[j][3];
		  }
		for(k=1;k<=n;k++)
		  for(i=1;i<=n;i++)
		    for(j=1;j<=n;j++)
		    {
		    if(j!=i&&k!=i&&j!=k&&meal[i][1]>0&&meal[j][2]>0&&meal[k][3]>0)
		  	sum+=meal[i][1]*meal[j][2]*meal[k][3];
			}
			cout<<sum;
			return 0;
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
	  

