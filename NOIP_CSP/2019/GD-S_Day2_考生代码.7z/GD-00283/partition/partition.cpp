#include<bits/stdc++.h>
using namespace std;
int n,ty,i,ans;
long long codee;
struct node{
	int num;
	int q;
}f[55555];
bool cmp(node a,node b)
{
	if(a.num!=b.num)
	return a.num<b.num;
	else return a.q<b.q;
}

int main()
{
    freopen("partition","w",stdin);freopen("partition","r",stdout);
	cin>>n>>ty;
	for(i=1;i<=n;i++)
	{
		f[i].q=i;
		cin>>f[i].num;
	}
	
	sort(f+1,f+n+1,cmp);
	
	for(i=1;i<=n;i++)
	{
		if(f[i].q!=i&&f[i].num!=0)
		{
			if(f[i-1].num==0)
			{
				f[i].num+=f[i+1].num;
				f[i+1].num=0;
				ans++;
				sort(f+1,f+n+1-ans,cmp);
				f[i].q=i;
			}
			else
			{
				if((f[i-1].num+f[i].num)>(f[i+1].num+f[i].num))
				{
				f[i].num+=f[i+1].num;
				f[i+1].num=0;
				f[i].q=i;
				ans++;
				sort(f+1,f+n+1-ans,cmp);
				}
				else
				{
				f[i].num+=f[i-1].num;
				f[i-1].num=0;
				ans++;
				sort(f+1,f+n+1-ans,cmp);
				f[i].q=i;
			    }
			}
		}
	}
    for(i=1;i<=n;i++)
    codee+=pow(f[i].num,2);
    cout<<codee;
    fclose(stdin);fclose(stdout);
    return 0;
}
