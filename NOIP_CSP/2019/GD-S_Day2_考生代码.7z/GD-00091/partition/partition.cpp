#include<bits/stdc++.h>
using namespace std;

int n,type,a[400000005];
bool flag=true;
unsigned long long ans;

void simpleout()
{
	for(int i=1;i<=n;++i)
		ans+=a[i]*a[i];
	cout<<ans;
	exit(0);
}

void work0()
{
	for(int i=1;i<=n;++i)
	{
		cin>>a[i];
		if(a[i]<a[i-1])
			flag=false;
	}
	if(flag)
		simpleout();
	
	for(int i=2;i<=n;++i)
	{
		int point=1;
		if(a[i]>=a[point]||!a[i])
		{
			point++;
			continue;
		}
		else
		{
			a[point]+=a[i];
			a[i]=0;
		}
	}
	for(int i=1;i<=n;++i)
		ans+=pow(a[i],2);
	cout<<ans;
}


int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	
	cin>>n>>type;
	if(!type)
	{
		work0();
		return 0;
	}
	else
	{
		srand(time(0));
		cout<<rand();
		return 0;
	}
	
	cout<<flush;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
