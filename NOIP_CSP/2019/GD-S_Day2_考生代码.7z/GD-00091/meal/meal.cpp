#include<bits/stdc++.h>
using namespace std;

int n,m,a[105][505];//dp[45][505][505];
long long ans;
/*
struct nodee{
	int val;
	int anss;
	int used[505];
}node[105][2005];
*/
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	

	cin>>n>>m;
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			cin>>a[i][j];
		
	/*		
	for(int i=1;i<=m;++i)
		node[1][i].anss=node[1][i].val;
	
	for(int i=1;i<=n;++i)
	{
		for(int j=1;j<=m;++j)
		{
			if(!node[i][j].val)
				continue;
			ans+=(i==1?0:node[i][j].anss%998244353);
			if(i==n)
				continue;
			for(int k=1;k<=m;++k)
			{
				if(node[i+1][k].used[k]+1>(i>>1))
					continue;
				node[i+1][k].used[k]++;
				node[i+1][k].anss+=(node[i+1][k].val*node[i][j].val)%998244353;
			}
		}
	}
	*/
	
	for(int i=1;i<n;++i)
	{
		for(int j=1;j<=m;++j)
		{
			for(int k=1;k<=m;++k)
			{
				if(k==j)
					continue;
				ans+=a[i][j]*a[i+1][k];
			}
		}
	}
	
	cout<<ans%998244353;
	
	cout<<flush;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
