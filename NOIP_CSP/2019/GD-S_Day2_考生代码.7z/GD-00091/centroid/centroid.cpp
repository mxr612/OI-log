#include<bits/stdc++.h>
using namespace std;



int main()
{
	freopen(".in","r",stdin);
	freopen(".out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	
	
	srand(time(0));
	cout<<rand();
	
	
	cout<<flush;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
