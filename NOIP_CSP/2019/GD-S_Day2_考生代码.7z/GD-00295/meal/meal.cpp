#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

int a[105][2050], pic[205], m, n;

ll output = 0, mod = 998244353;

void dfs(int dep, ll ans, int end, int now, int last){
	if(dep > n || now == end){
		output += ans;
		output %= mod;
		return;
	}
	for(int i = last; i <= n; i++) 
	for(int j = 1; j <= m; j++) if(pic[j] < (end>>1) && a[i][j]){
		pic[j]++;
		dfs(dep+1, ans*1ll*a[i][j]%mod, end, now+1, i+1);
		pic[j]--;
	}
}

int main(){
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	scanf("%d %d", &n, &m);
	for(int i = 1; i <= n; i++)
	for(int j = 1; j <= m; j++) scanf("%d", &a[i][j]);
	for(int i = 2; i <= n; i++){
		dfs(1, 1ll, i, 0, 1);
	}
	printf("%lld", output);
}
