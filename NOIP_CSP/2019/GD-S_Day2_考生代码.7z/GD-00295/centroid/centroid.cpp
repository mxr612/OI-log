#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

struct node{
	int t, nxt;
}edge[700050];

int head[300050], cnt, siz[300050], maxs[300050], siz2[300050], tnrt, nrt, n;
ll tot;
int mson1, mson2, max1, max2;
ll output = 0;

void add(int u, int v){
	edge[++cnt] = (node){v, head[u]};
	head[u] = cnt;
}

void getsiz(int u, int fa){
	for(int i = head[u]; i; i = edge[i].nxt){
		int v = edge[i].t;
		if(v == fa) continue;
		getsiz(v, u);
		siz[u] += siz[v];
	}
	siz[u]++;
}

void getroot(int u, int fa, int hsiz){
	for(int i = head[u]; i; i = edge[i].nxt){
		int v = edge[i].t;
		if(v == fa) continue;
		getroot(v, u, hsiz);
		maxs[u] = max(maxs[u], siz[v]);
	}
	maxs[u] = max(hsiz-siz[u], maxs[u]);
	if(maxs[u] < maxs[tnrt]) tnrt = u, tot = tnrt;
	else if(maxs[u] == maxs[tnrt]) tot += u;
}

void setsiz(int u, int fa){
	for(int i = head[u]; i; i = edge[i].nxt){
		int v = edge[i].t;
		if(v == fa) continue;
		setsiz(v, u);
		siz2[u] += siz2[v];
	}
	siz2[u]++;
}

int dfans(int u, int fa, int del, int p){
	int ans = 1000050, maxson = 0;
	for(int i = head[u]; i; i = edge[i].nxt){
		int v = edge[i].t;
		if(fa == v || fa == p) continue;
		ans = min(ans, dfans(v, u, del, p));
		maxson = max(siz2[v], maxson);
	}
	ans = min(ans, max(n - del - siz2[u], maxson));
	return ans;
}

int getans(int del, int flag, int p){
	int tmax = 0, pmax, tson, k1, k2;
	if(flag == 1) {
		tson = mson2;
		tmax = max(max2, max1-del);
	}
	else tmax = max1;
	if(p!=mson1) k1 = dfans(mson1, nrt, del, p);
	else k1 = 1000050;
	if(p!=mson2) k2 = dfans(mson2, nrt, del, p);
	else k2 = 1000050;
	if(k1 < k2) tson = mson1;
	else tson = mson2;
	pmax = min(k2, k1);
	if(tmax < pmax) return nrt;
	else if(tmax > pmax) return tson;
	else return nrt + tson;
}

void dfs(int u, int fa, int flag){
	for(int i = head[u]; i; i = edge[i].nxt){
		int v = edge[i].t;
		if(v == fa) continue;
		output += getans(siz2[v], (bool)(flag||(v == mson1)), v);
		memset(siz, 0, sizeof(siz));
		memset(maxs, 0, sizeof(maxs));
		maxs[0] = siz[0] = 1000050;
		tot = tnrt = 0;
		getsiz(v, u);
		getroot(v, u, siz[v]);
		output += tot;
		dfs(v, u, (bool)(flag||(v == mson1)));
	}
}

int main(){
	freopen("centroid.in", "r", stdin);
	freopen("centroid.out", "w", stdout);
	int T;
	scanf("%d", &T);
	while(T--){
		memset(siz, 0, sizeof(siz));
		memset(siz2, 0, sizeof(siz2));
		memset(edge, 0, sizeof(edge));
		memset(head, 0, sizeof(head));
		memset(maxs, 0, sizeof(maxs));
		cnt = 0, tot = 0, nrt = 0;
		output = 0;
		max1 = 0, max2 = 0;
		mson1 = 0, mson2 = 0;
		scanf("%d", &n);
		for(int u, v, i = 1; i < n; i++){
			scanf("%d %d", &u, &v);
			add(u, v);
			add(v, u);
		}
		memset(siz, 0, sizeof(siz));
		maxs[0] = siz[0] = 1000050, tnrt = 0;
		getsiz(1, 0);
		getroot(1, 0, n);
		nrt = tnrt;
		setsiz(nrt, 0);
		for(int i = head[nrt]; i; i = edge[i].nxt) {
			int v = edge[i].t;
			if(max1 < siz2[v]) max2 = max1, mson2 = mson1, max1 = siz2[v], mson1 = v;
			else if(max2 < siz2[v]) max2 = siz2[v], mson2 = v;
		}
		dfs(nrt, 0, 0);
		printf("%lld\n", output);
	}
}
