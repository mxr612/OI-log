#include<cstdio>
#include<cstring>
#define ll unsigned long long
using namespace std;
inline int read()
{
	int x=0;char c=getchar();
	while(c>'9' || c<'0')c=getchar();
	while(c>='0' && c<='9')x=(x<<3)+(x<<1)+(c^'0'),c=getchar();
	return x;
}
struct node{int x,y,next;}a[600000];
int len=0,last[300000];
void ins(int x,int y)
{
	len++;
	a[len].x=x;a[len].y=y;
	a[len].next=last[x];last[x]=len;
}
int n,tt;
ll s;
int k1,k2,k3,st,ed,rt;
int d[310000],du[310000];
inline int find(int x,int f)
{
	d[x]=d[f]+1;if(d[x]==(n+1)>>1)return x;
	for(int k=last[x];k;k=a[k].next)
	{
		int y=a[k].y;
		if(y^f)return find(y,x);
	}
}
inline void fucking_tree(int x,int f)
{
	d[x]=d[f]+1;
	for(int k=last[x];k;k=a[k].next)
	{
		int y=a[k].y;
		if(y^f)fucking_tree(y,x);
	}
}
inline int mmax(int x,int y){return x>y?x:y;}
int main()
{
	freopen("centroid.in","r",stdin);freopen("centroid.out","w",stdout);
	tt=read();
	while(tt--)
	{
		n=read();
		memset(du,0,sizeof du);
		len=0;memset(last,0,sizeof last);
		for(int i=1;i<n;i++)
		{
			int x=read(),y=read();
			ins(x,y);ins(y,x);
			du[x]++;du[y]++;
		}
		k1=k2=k3=d[0]=0;s=0;
		for(int i=1;i<=n;i++)
		{
			if(du[i]==1)++k1,st=i;
			if(du[i]==2)++k2,rt=i; 
			if(du[i]==3)++k3;
		}
		if(k1+k2==n && k1==2)
		{
			if(n&1)
			{
				int xx=find(st,0),ed;
				for(int i=1;i<=n;i++)s+=(ll)i*3;
				for(int i=1;i<=n;i++)if(du[i]==1){ed=i;break;}
				s=s-st-ed-xx;
			}
			else for(int i=1;i<=n;i++)s+=(ll)i*2;
			printf("%llu\n",s);
			continue;
		}
		else if(k2==1 && k1==k2+k3+1 && k1+k2+k3==n);
		{
			fucking_tree(rt,0);
			int mxd=0;
			for(int i=1;i<=n;i++)mxd=mmax(mxd,d[i]);
			int id=1<<(mxd-1);
			for(int i=1;i<=n;i++)
			{
				if(d[i]==1 || d[i]==2)s+=(ll)i*id;
				else s+=(ll)i;
			}
			printf("%llu\n",s);
			continue;
		}
	}
	return 0;
}
