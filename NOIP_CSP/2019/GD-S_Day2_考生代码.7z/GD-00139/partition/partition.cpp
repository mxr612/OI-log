#include<cstdio>
#include<cstring>
using namespace std;
int n,tt,a[11000],t[11000],k=0,s=0;
int main()
{
	freopen("partition.in","r",stdin);freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&tt);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	for(int i=1;i<n;i++)
	{
		if(a[i+1]<a[i])t[++k]=a[i]+a[i+1],i++;
		else t[++k]=a[i];
	}
	for(int i=1;i<=k;i++)s+=t[i]*t[i];
	printf("%d",s);
	return 0;
}
