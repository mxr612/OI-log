#include<cstdio>
#include<cstring>
using namespace std;
#define mod 998244353
#define ll long long
int n,m,a[110][2100];
ll s=0;
int lucky_me[1100];
inline int mmax(int x,int y){return x>y?x:y;}
inline void dfs(int k,int l,ll nn,int mx)
{
	if(mx>(n>>1))return;
	if(k>=2 && mx<=(k>>1))s=(s+nn)%mod;
	for(int i=l+1;i<=n;++i)
		for(int j=1;j<=m;++j)
			if(a[i][j])
			{
				++lucky_me[j];
				dfs(k+1,i,nn*(ll)a[i][j]%mod,mmax(mx,lucky_me[j]));
				--lucky_me[j];
			}
}
int main()
{
	freopen("meal.in","r",stdin);freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d",&a[i][j]);
	dfs(0,0,1,0);
	printf("%lld",s);
	return 0;
}
/*
5 5
1 0 0 1 1
0 1 0 1 0
1 1 1 1 0
1 0 1 0 1
0 1 1 0 1
*/
