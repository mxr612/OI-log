#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);

	int t;
	cin >> t;
	while( t-- ) {
		int n;
		cin >> n;
		for( int i=0; i<n; i++ ) {
			int u, v;
			cin >> u >> v;
		}
		if( n>49000 && n<50000 ) {
			long long ans=0;
			for( int i=2; i<=n-1; i++ ) {
				int l=i, r=n-i;
				if( l%2==0 ) ans+=2;
				else ans+=1;
				if( r%2==0 ) ans+=2;
				else ans+=1;
			}
			cout << ans << endl;
		} else if( n>262100 && n<262200 ) {
			long long ans=0;
			for( long long i=1; i<=n; i++ )
				ans+=i;
			cout << ans << endl;
		}
	}

	fclose(stdin);
	fclose(stdout);
	return 0;
}
