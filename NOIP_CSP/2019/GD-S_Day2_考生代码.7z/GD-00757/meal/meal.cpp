#include <bits/stdc++.h>
using namespace std;
const int mod=998244353;
long long a[110][2100];
int num[110];
int n, m;
inline void add()
{
	int p=1;
	++num[p];
	while( num[p]>m ) {
		num[p]=0;
		num[++p]++;
	}
	return;
}
void print()
{
	cout << "Num = ";
	for( register int i=1; i<=n; i++ )
		cout << num[i];
	cout << endl;
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);

	long long ans=0;
	cin >> n >> m;
	for( register int i=1; i<=n; i++ )
		for( int j=1; j<=m; j++ )
			cin >> a[i][j];
	while( num[n+1]==0 ) {
		int cnt[110]= {};
		int maxn=0, tot=0;
		long long tmp=1;
		for( register int i=1; i<=n; i++ ) {
			if( num[i]>0 ) {
				tmp*=a[i][num[i]];
				tmp%=mod;
				++cnt[num[i]];
				++tot;
				maxn=max(cnt[num[i]],maxn);
			}
		}
		if( tmp==0 || tot==0 || maxn>tot/2 ) {
			add();
			continue;
		}
		add();
		ans+=tmp;
		ans%=mod;
	}
	cout << ans << endl;

	fclose(stdin);
	fclose(stdout);

	return 0;
}
