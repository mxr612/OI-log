#include <bits/stdc++.h>
long long mod=(1<<30);
using namespace std;
int a[4000100], b;
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);

	srand(time(NULL));
	int n, type;
	cin >> n >> type;
	if( !type ) {
		long long sum=0;
		long long ans=0;
		for( int i=0; i<n; i++ )
			cin >> a[i], sum+=a[i];
		long long group=0, p=0;
		long long last=0;
		while( p<n ) {
			while( (group+a[p]<last || a[p+1]<a[p]) && p<n ) {
				group+=a[p];
				group%=mod;
				p++;
			}
			group+=a[p]%mod;
			p++;
			ans+=(group*group)%mod;
			ans%=mod;
			last=group;
			group=0;
		}
		cout << min(sum*sum,ans) << endl;
	} else {
		long long ans=(rand()*rand()*rand())%(40216512);
		cout << ans << endl;
	}

	fclose(stdin);
	fclose(stdout);

	return 0;
}
