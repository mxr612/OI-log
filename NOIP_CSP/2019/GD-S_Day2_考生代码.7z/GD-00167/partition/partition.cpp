#include<bits/stdc++.h>
#define ll long long
#define For(i,l,r) for(register ll i=l;i<=r;i++)
#define rep(i,l,r) for(register ll i=l;i>=r;i--)
using namespace std;
const ll N=5e3+10;
ll n,type,inf;
ll a[N],dp[N][N],sum[N];

inline ll read(ll &x){
	x=0; ll f=1; char ch=getchar();
	while(ch<'0' || ch>'9'){ if(ch=='-') f=-1; ch=getchar(); }
	while('0'<=ch && ch<='9'){ x=x*10+ch-'0'; ch=getchar(); }
	x*=f;
}

int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	read(n),read(type);
	For(i,1,n) read(a[i]),sum[i]=sum[i-1]+a[i];
	memset(dp,0x7f,sizeof(dp)); inf=dp[0][0];
	For(i,0,n) dp[i][0]=sum[i]*sum[i];
	
	For(i,1,n){
		For(j,1,i-1){
			ll lim=sum[i]-sum[j];
			rep(k,j-1,0){ 
				if(sum[j]-sum[k]>lim) break;    
				dp[i][j]=min(dp[i][j],dp[j][k]+lim*lim);
			}
		}
	}
	
	ll ans=inf;
	For(i,0,n) ans=min(ans,dp[n][i]);
	printf("%lld",ans);
	
}
