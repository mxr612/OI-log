#include<bits/stdc++.h>
#define ll long long
#define rll register long long
#define For(i,l,r) for(register ll i=l;i<=r;i++)
using namespace std;

const ll N=110,M=2010,mod=998244353;
ll n,m,tot;
ll a[N][M],pw[30],vis[N][M],op[M];

void dfs(ll dep){
	if(dep>n){
		ll ans=1,cnt=0;
		for(rll i=1;i<=m;i++) op[i]=0;
		for(rll i=1;i<=n;i++){
			for(rll j=1;j<=m;j++){
				if(vis[i][j]){ ans=ans*a[i][j]%mod,op[j]++,cnt++; break; } 
			}
		}
		if(!cnt) return;
		for(rll i=1;i<=m;i++) if(op[i]>cnt/2) return;
		tot=(tot+ans)%mod;
		return;
	}
	dfs(dep+1);
	for(rll i=1;i<=m;i++){
		if(a[dep][i]!=0){
			vis[dep][i]=1;
			dfs(dep+1);
			vis[dep][i]=0;
		}
	}
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(rll i=1;i<=n;i++) for(rll j=1;j<=m;j++) scanf("%lld",&a[i][j]);
	if(n<=40 && m<=5){
		dfs(1);
		printf("%lld",(tot%mod+mod)%mod);
	
	}
}

