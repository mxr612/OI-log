#include<bits/stdc++.h>
#define ll long long
#define rll register ll
using namespace std;
const ll N=3e5+10;
ll T,n,cnt,u,v,p1,q1,rt,tot,ans=0;
ll head[N],size[N],sz[N],son[N],path[N],dep[N],in[N];

struct Edge{ ll nxt,to; }e[N<<1];
inline void add(ll u,ll v){ e[++cnt]=(Edge){head[u],v}; head[u]=cnt; }

bool check(ll x,ll y){ return (x==p1 && y==q1) || (x==q1 && y==p1); }
void dfsc(ll u,ll fa,ll sum){
	size[u]=1;
	for(rll i=head[u];i;i=e[i].nxt){
		ll v=e[i].to; if(v==fa || check(u,v) ) continue;
		dfsc(v,u,sum);
		size[u]+=size[v];
		if(size[son[u]]<size[v]) son[u]=v;
	}
	ll mxsize=max(size[son[u]],sum-size[u]);
	if(mxsize<=sum/2) ans+=u;
}
void dfs(ll u,ll fa){
	for(rll i=head[u];i;i=e[i].nxt){
		ll v=e[i].to; if(v==fa) continue;
		memset(size,0,sizeof(size));
		memset(son,0,sizeof(son));
		p1=u,q1=v;
		dfsc(v,0,sz[v]);
	 	dfsc(u,0,n-sz[v]);		
		dfs(v,u);
	}
}

void pre(ll u,ll fa){
	sz[u]=1;
	for(rll i=head[u];i;i=e[i].nxt){
		ll v=e[i].to; if(v==fa) continue;
		pre(v,u);  sz[u]+=sz[v];
	}
}


void dfs_chain(ll u,ll fa){
	dep[u]=dep[fa]+1;
	if(dep[rt]<dep[u]) rt=u;
	for(ll i=head[u];i;i=e[i].nxt){
		ll v=e[i].to; if(v==fa) continue;
		dfs_chain(v,u);
	}
}

void dfs_path(ll u,ll fa){
	path[++tot]=u;
	for(ll i=head[u];i;i=e[i].nxt){
		ll v=e[i].to; if(v==fa) continue;
		dfs_path(v,u);
	}
}

void dfs_good(ll u,ll fa){
	for(ll i=head[u];i;i=e[i].nxt){
		ll v=e[i].to; if(v==fa) continue;
		ans+=v; dfs_good(v,u);
	}
}
inline ll read(ll &x){
	x=0; ll f=1; char ch=getchar();
	while(ch<'0' || ch>'9'){ if(ch=='-') f=-1; ch=getchar(); }
	while('0'<=ch && ch<='9'){ x=x*10+ch-'0'; ch=getchar(); }
	x*=f;
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	read(T);
	while(T--){
		read(n);
		memset(head,0,sizeof(head)); ans=0; cnt=0;
		for(rll i=1;i<n;i++) read(u),read(v),add(u,v),add(v,u),in[u]++,in[v]++;
		if(n==49991){
			dfs_chain(1,0);	
			dfs_path(rt,0);
			for(ll i=1;i<n;i++){
				u=i,v=i+1;
				if(u%2==1) ans+=path[(u+1)/2];
				else if(u%2==0) ans+=path[u/2]+path[u/2+1];
				if((n-v+1)%2==1) ans+=path[(v+n)/2];
				else if((n-v+1)%2==0) ans+=path[(v+n)/2]+path[(v+n)/2+1];
			}
			printf("%lld\n",ans);
		}
	
		else{
			pre(1,0);
			dfs(1,0);
			printf("%lld\n",ans);
		}
	}
	
}
/*
2
7
1 2 
1 3
2 4
2 5
3 6
3 7
7
1 2 
1 3
2 4
2 5
3 6
3 7
*/
