#include<cstdio>
#include<cstring>
#define N 110
#define M 2010
#define P 998244353
using namespace std;
int n,m,ans=0;
int a[N][M],d[M];
inline bool check(int g)
{
	for (int i=1;i<=m;++i) if (d[i]>g) return 0;
	return 1;
}
inline int mod(int x){return x==P?0:x;}
void dfs(int p,int x,int y)
{
	if (y==p)
	{
		if (check(p/2)) ans=mod(ans+1);
		return;
	}
	if (x>n) return;
	for (int i=1;i<=m;++i) 
		if (a[x][i])
		{
			d[i]+=a[x][i];
			dfs(p,x+1,y+1);
			d[i]-=a[x][i];
		}
	dfs(p,x+1,y);
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d %d",&n,&m);
	for (int i=1;i<=n;++i)
		for (int j=1;j<=m;++j)
			scanf("%d",&a[i][j]);
	for (int h=2;h<=n;++h) memset(d,0,sizeof d),dfs(h,1,0);
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
