#include<cstdio>
#include<cstring>
#define N 300010
using namespace std;
int T,n,tt,sl,sr;
int st[N],a[N],b[N],sz[N],ms[N],bz[N];
struct edge{int to,nt;}e[N<<1];
inline void add(int u,int v){e[++tt].to=v,e[tt].nt=st[u],st[u]=tt;}
inline int max(int x,int y){return x>y?x:y;}
void dfs(int x,int dad,int no,int fg)
{
	bz[x]=fg;
	sz[x]=1;
	if (fg) ++sl;
	else ++sr;
	for (int l=st[x];l;l=e[l].nt)
	{
		int en=e[l].to;
		if (en^dad && en^no) dfs(en,x,no,fg),sz[x]+=sz[en],ms[x]=max(ms[x],sz[en]);
	}
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while (T--)
	{
		memset(e,0,sizeof e);
		memset(st,0,sizeof st);
		tt=0;
		scanf("%d",&n);
		int ans=0;
		for (int i=1;i<n;++i) scanf("%d %d",a+i,b+i),add(a[i],b[i]),add(b[i],a[i]);
		for (int i=1;i<n;++i)
		{
			memset(sz,0,sizeof sz);
			memset(ms,0,sizeof ms);
			memset(bz,0,sizeof bz);
			sl=0,sr=0;
			dfs(a[i],0,b[i],1);
			dfs(b[i],0,a[i],0);
			for (int j=1;j<=n;++j)
			{
				int o=(bz[j]?sl:sr);
				if (ms[j]<=o/2 && o-sz[j]<=o/2) ans+=j;
			}
		}
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
