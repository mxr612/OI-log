#include<cstdio>
#include<cstring>
#define N 40000010
#define ll long long
#define INF 0x7f7f7f7f
using namespace std;
ll n,tp,t=1,w=1;
ll f[N],g[N],a[N];
inline void read(ll &g)
{
	g=0;register char c=getchar();
	while (c<'0' || c>'9') c=getchar();
	while (c>='0' && c<='9') g=g*10+(c&15),c=getchar();
}
inline ll min(ll x,ll y){return x<y?x:y;}
inline ll sqr(ll x){return x*x;}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	read(n),read(tp);
	a[0]=0;
	for (int i=1;i<=n;++i) read(a[i]),a[i]+=a[i-1];
	memset(f,INF,sizeof f);
	f[0]=0;
	g[0]=0;
	for (int i=1;i<=n;++i)
		for (int j=0;j<=i;++j)
		{
			ll o=(j==0?0:a[j-1]),p=(j==0?0:g[j-1]),h=(j==0?0:f[j-1]);
			if (a[i]-o>=p && h+sqr(a[i]-o)<f[i])
				f[i]=h+sqr(a[i]-o),g[i]=a[i]-o;
		}
	printf("%lld",f[n]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
