#include<cstdio>
#include<iostream>
#include<cstring>
#include<cstdlib>
using namespace std;
#define R register
#define I inline
I void rd(R int &x)
{
	x=0;R char c=getchar();R int fl=1;
	while (!isdigit(c)){if (c=='-') fl=-1;c=getchar();}
	while (isdigit(c)){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=fl;
}
I void print(R int x)
{
	if (x>9) print(x/10);
	putchar(x%10^48);
}
int cur,T,n,cnt,ans,
	a[300005],b[300005],head[300005],siz[300005];
struct EDGE{
	int t,next;
}e[600005];
I void add(int a,int b)
{
	cur++;
	e[cur].t=b;
	e[cur].next=head[a];
	head[a]=cur;
}
I void DFS(R int u,R int fa)
{
	siz[u]=1;
	R bool OK=1;
	for (R int h=head[u];h!=-1;h=e[h].next)
	{
		R int v=e[h].t;
		if (v==fa) continue;
		DFS(v,u);
		if (siz[v]>cnt/2) OK=0;
		siz[u]+=siz[v];
	}
	if (cnt-siz[u]>cnt/2) OK=0;
	if (OK) ans+=u;
}
I void DFS2(R int u,R int fa)
{
	cnt++;
	for (R int h=head[u];h!=-1;h=e[h].next)
	{
		R int v=e[h].t;
		if (v==fa) continue;
		DFS2(v,u);
	}
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	rd(T);
	while (T--)
	{
		rd(n);
		memset(head,-1,sizeof head);
		memset(e,0,sizeof e);
		ans=0;
		for (R int i=1;i<n;i++)
		{
			rd(a[i]);rd(b[i]);
			add(a[i],b[i]);add(b[i],a[i]);
		}
		for (R int i=1;i<n;i++)
		{
			cnt=0;
			memset(siz,0,sizeof siz);
			DFS2(a[i],b[i]);
			DFS(a[i],b[i]);
			cnt=n-cnt;
			DFS(b[i],a[i]);
		}
		print(ans);putchar('\n');
	}
	return 0;
}
