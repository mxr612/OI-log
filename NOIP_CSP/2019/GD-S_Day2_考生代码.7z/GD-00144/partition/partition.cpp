#include<cstdio>
#include<iostream>
#include<cstring>
#include<cstdlib>
using namespace std;
#define R register
#define I inline
typedef long long LL;
I void rd(R LL &x)
{
	x=0;R char c=getchar();R int fl=1;
	while (!isdigit(c)){if (c=='-') fl=-1;c=getchar();}
	while (isdigit(c)){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=fl;
}
I void print(R LL x)
{
	if (x>9) print(x/10);
	putchar(x%10^48);
}
I LL sqr(LL x)
{
	return x*x;
}
#define INF 41000000000000000ll
LL n,ty;
LL ans,a[5005];
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	rd(n);rd(ty);
	for (int i=1;i<=n;i++)
	{
		rd(a[i]);
	}
	a[n+1]=INF;
	for (int i=1;i<=n;i++)
	{
		if (a[i]<a[i-1])
		{
			if (a[i-1]+a[i]<=a[i+1]||i==n)
			{
				a[i]+=a[i-1];
				a[i-1]=0;
			}
			else
			{
				a[i+1]+=a[i];
				a[i]=0;
			}
		}
	}
	for (int i=1;i<=n;i++)
		ans+=sqr(a[i]);
	print(ans);
	return 0;
}
