#include<cstdio>
#include<iostream>
#include<cstring>
#include<cstdlib>
using namespace std;
#define R register
#define I inline
typedef long long LL;
I void rd(R int &x)
{
	x=0;R char c=getchar();R int fl=1;
	while (!isdigit(c)){if (c=='-') fl=-1;c=getchar();}
	while (isdigit(c)){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=fl;
}
I void print(R LL x)
{
	if (x>9) print(x/10);
	putchar(x%10^48);
}
int n,m,half,
	a[105][2005];
LL ans,
	f[105][55][55],
	g[105][55][55][55];
#define P 998244353
#define M(x) ((x)%=P)
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	rd(n);rd(m);
	for (int i=1;i<=n;i++)
		for (int j=1;j<=m;j++)
			rd(a[i][j]);
	half=(n>>1);
	if (m==2)
	{
		f[0][0][0]=1;
		for (int i=1;i<=n;i++)
			for (int x=0;x<=half;x++)
				for (int y=0;y<=half;y++)
					M(f[i][x][y]=(x?f[i-1][x-1][y]:0)*a[i][1]+(y?f[i-1][x][y-1]:0)*a[i][2]+f[i-1][x][y]);
		for (int i=0;i<=half;i++)
			for (int j=0,sum;j<=half;j++)
				if ((sum=i+j)>1&&(i<=(sum>>1))&&(j<=(sum>>1)))
					ans+=f[n][i][j];
		print(ans);printf("\n");
	}
	else
	if (m==3)
	{
		g[0][0][0][0]=1;
		for (int i=1;i<=n;i++)
			for (int x=0;x<=half;x++)
				for (int y=0;y<=half;y++)
					for (int z=0;z<=half;z++)
						M(g[i][x][y][z]=(x?g[i-1][x-1][y][z]:0)*a[i][1]+(y?g[i-1][x][y-1][z]:0)*a[i][2]+(z?g[i-1][x][y][z-1]:0)*a[i][3]+g[i-1][x][y][z]);
		for (int i=0;i<=half;i++)
			for (int j=0;j<=half;j++)
				for (int k=0,sum;k<=half;k++)
					if ((sum=i+j+k)>1&&i<=(sum>>1)&&j<=(sum>>1)&&k<=(sum>>1))
						M(ans+=g[n][i][j][k]);
		print(ans);printf("\n");
	}
	return 0;
}
