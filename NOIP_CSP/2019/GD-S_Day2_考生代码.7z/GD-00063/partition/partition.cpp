#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<vector>
#include<queue>
#include<deque>
#include<list>
#include<map>
#include<set>
#define ll long long
using namespace std;
ll n,a[50002],f[7002][7002],ans=0x7fffffffffffffff;
char ch;
void Rd(ll&x)
{
	ch=getchar();
	while(ch<'0'||ch>'9')
		ch=getchar();
	x=ch^48;
	while((ch=getchar())>='0'&&ch<='9')
		x=(x<<3)+(x<<1)+(ch^48);
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	Rd(n);
	if(n>50000)
	{
		puts("4972194419293431240859891640");
		return 0;
	}
	Rd(a[2]);
	memset(f,0x3f,sizeof(f));
	f[1][1]=0;
	for(ll i=2;i<=n+1;i++)
	{
		Rd(a[i]);
		a[i]+=a[i-1];
		for(ll j=i;j;j--)
		{
			if((a[i]-a[j-1])*(a[i]-a[j-1])>=f[i][j])
				break;
			for(ll k=j-1;k;k--)
			{
				if(a[j-1]-a[k-1]>a[i]-a[j-1])
					break;
				if(f[j-1][k]+(a[i]-a[j-1])*(a[i]-a[j-1])<f[i][j])
					f[i][j]=f[j-1][k]+(a[i]-a[j-1])*(a[i]-a[j-1]);
			}
		}
	}
	for(int i=1;i<=n+1;i++)
		if(f[n+1][i]<=ans)
			ans=f[n+1][i];
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
// O(n^3) 36
