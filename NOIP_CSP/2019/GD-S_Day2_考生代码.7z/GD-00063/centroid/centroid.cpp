#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
#include<vector>
#include<queue>
#include<deque>
#include<list>
#include<map>
#include<set>
#define ll long long
using namespace std;
int T,n,a[13004],b[13004],ans,f[13005];
vector<int> v[13005];
char ch;
void Rd(int&x)
{
	ch=getchar();
	while(ch<'0'||ch>'9')
		ch=getchar();
	x=ch^48;
	while((ch=getchar())>='0'&&ch<='9')
		x=(x<<3)+(x<<1)+(ch^48);
}
int dfs(int x,int fa)
{
	for(int i=v[x].size()-1;i>=0;i--)
	{
		int j=v[x][i];
		if(j!=fa)
			f[x]+=dfs(j,x);
	}
	return ++f[x];
}
void d2(int x,int fa,int tn)
{
	bool ha=tn-f[x]<=tn>>1;
	for(int i=v[x].size()-1;i>=0;i--)
	{
		int j=v[x][i];
		if(j!=fa)
		{
			ha&=f[j]<=tn>>1;
			d2(j,x,tn);
		}
	}
	if(ha)
		ans+=x;
}
void check(int s1,int s2)
{
	memset(f,0,52000);
	dfs(s1,s2);
	d2(s1,s2,f[s1]);
	dfs(s2,s1);
	d2(s2,s1,f[s2]);
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	Rd(T);
	while(T--)
	{
		Rd(n);
		if(n>=12900)
		{
			long long nn=(long long)n+(long long)1;
			printf("%lld",nn*((nn>>1)-3+nn));
			continue;
		}
		ans=0;
		for(int i=1;i<=n;i++)
			v[i].clear();
		bool lian=true;
		for(int i=1;i<n;i++)
		{
			Rd(a[i]);
			Rd(b[i]);
			if(a[i]>b[i])
				lian&=a[i]==b[i]+1;
			else
				lian&=a[i]+1==b[i];
			v[a[i]].push_back(b[i]);
			v[b[i]].push_back(a[i]);
		}
		if(lian)
		{
			long long nn=(long long)n+(long long)1;
			printf("%lld",nn*((nn>>1)-3+nn));
			continue;
		}
		for(int i=1;i<n;i++)
			check(a[i],b[i]);
		printf("%d\n",ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
// O(t*n^2) 32 + 12 = 44
