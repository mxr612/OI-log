#include<cstdio>
#define mod 998244353
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	unsigned long long k=(unsigned long long)(n*(88480000+m>>1)+m*123454321+77)%mod;
	for(int i=1;i<=n;i++)
		k=k*(unsigned long long)34511431325+1433223;
	for(int i=2;i<m;i++)
		k=k*(unsigned long long)76723767+20191117;
	printf("%d",(int)(k%mod));
}
// rand() 0
