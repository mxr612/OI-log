#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int MAXN = 4e7 + 10;
inline ll read()
{
	
	ll x = 0, f = 1;
	char c = getchar();
	while (!isdigit(c))
	{
		if (c == '-') f = -1;
		c = getchar();
	}
	while (isdigit(c))
	{
		x = (x << 3) + (x << 1) + (c & 15);
		c = getchar();
	}
	return x * f;
}
ll data[MAXN];
ll n, mode;
int main()
{
	freopen("partition.in", "r", stdin);
	freopen("partition.out", "w", stdout);
	n = read();
	mode = read();
	for (int i = 1; i <= n; i++)
	{
		data[i] = read();
	}
	//�����̰��
	//�ҵ��ȵ�ǰ��������ݻ�Ҫ�����С�� 
	ll curMax = -1;
	int line = 0;
	ll sum = 0;
	ll ans = 0;
	while (line <= n)
	{
		if (sum + data[line + 1] >= curMax)
		{
			line++;
			sum += data[line];
			ans += sum * sum;
			curMax = sum;
			sum = 0;
		} else {
			line++;
			sum += data[line];
		}
	}
	cout << ans << endl;
	return 0;
}
