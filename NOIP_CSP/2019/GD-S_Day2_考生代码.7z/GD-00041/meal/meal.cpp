#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int MAXN = 120;
const int MAXM = 2020;
const ll mod = 998244353;
int n, m;
ll ans = 0;
ll cur = 1;
int maxn = 0;
int recipe[MAXN][MAXM];
int used[MAXM];
inline ll fast_exp(ll b, ll e)
{
	ll cur = b, ans = 1;
	for(;e;e >>= 1)
	{
		if (e & 1)
		{
			ans = (ans * cur) % mod;
		}
		cur = (cur * cur) % mod;
	}
	return ans % mod;
}
inline int read()
{
	int x = 0, f = 1;
	char c = getchar();
	while (!isdigit(c))
	{
		if (c == '-') f = -1;
		c = getchar();
	}
	while (isdigit(c))
	{
		x = (x << 3) + (x << 1) + (c & 15);
		c = getchar();
	}
	return x * f;
}
void dfs(int method, int dishCnt)
{
	if (method == n + 1)
	{
		if (used[maxn] <= (dishCnt >> 1) && dishCnt > 1)
		{
			ans = (ans + cur) % mod;
			return;
		} else {
			return;
		}
	}
	dfs(method + 1, dishCnt);
	for (int j = 1; j <= m; j++)
	{
		if (recipe[method][j] == 0) continue;
		bool replaced = false;
		int temp = 0;
		used[j]++;
		if (used[j] > used[maxn])
		{
			temp = maxn;
			maxn = j;
			replaced = true;
		}
		cur = (cur * recipe[method][j]) % mod;
		dfs(method + 1, dishCnt + 1);
		cur = (cur * fast_exp(recipe[method][j], mod - 2)) % mod;
		used[j]--;
		if (replaced)
		{
			maxn = temp;
		}
	}
}
int main()
{
	freopen("meal.in", "r", stdin);
	freopen("meal.out", "w", stdout);
	n = read();
	m = read();
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
		{
			recipe[i][j] = read();
		}
	}
	dfs(1, 0);
	cout << ans << endl;
	return 0;
}
