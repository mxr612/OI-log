#include <bits/stdc++.h>
using namespace std;
const int MAXN = 3e5 + 10;
inline int read()
{
	
	int x = 0, f = 1;
	char c = getchar();
	while (!isdigit(c))
	{
		if (c == '-') f = -1;
		c = getchar();
	}
	while (isdigit(c))
	{
		x = (x << 3) + (x << 1) + (c & 15);
		c = getchar();
	}
	return x * f;
}
int T;
struct edge{
	int u, v, next;
}graph[MAXN * 2];
int edgeCnt = 0;
int head[MAXN];
int n;
void addEdge(int u, int v)
{
	graph[++edgeCnt].u = u;
	graph[edgeCnt].v = v;
	graph[edgeCnt].next = head[u];
	head[u] = edgeCnt;
}
int cent_sum = 0;
int newSiz[MAXN];
int newFa[MAXN];
int U;
int V;
void determineSize1(int u, int f)
{
	newSiz[u] = 1;
	newFa[u] = f;
	for (int e = head[u]; e; e = graph[e].next)
	{
		int v = graph[e].v;
		if (v == f || v == V) continue;
		determineSize1(v, u);
		newSiz[u] += newSiz[v];
	}
}
void determineSize2(int u, int f)
{
	newSiz[u] = 1;
	newFa[u] = f;
	for (int e = head[u]; e; e = graph[e].next)
	{
		int v = graph[e].v;
		if (v == f || v == U) continue;
		determineSize2(v, u);
		newSiz[u] += newSiz[v];
	}
}
void dfs2(int u, int rt)
{
	int max_block = newSiz[rt] - newSiz[u];
	for (int e = head[u]; e; e = graph[e].next)
	{
		int v = graph[e].v;
		if (v == newFa[u] || v == V) continue;
		max_block = max(max_block, newSiz[v]);
	}
	if (max_block <= (newSiz[rt] >> 1))
	{
		cent_sum += u;
	}
	for (int e = head[u]; e; e = graph[e].next)
	{
		int v = graph[e].v;
		if (v == newFa[u] || v == V) continue;
		dfs2(v, rt);
	}
}
void dfs3(int u, int rt)
{
	int max_block = newSiz[rt] - newSiz[u];
	for (int e = head[u]; e; e = graph[e].next)
	{
		int v = graph[e].v;
		if (v == newFa[u] || v == U) continue;
		max_block = max(max_block, newSiz[v]);
	}
	if (max_block <= (newSiz[rt] >> 1))
	{
		cent_sum += u;
	}
	for (int e = head[u]; e; e = graph[e].next)
	{
		int v = graph[e].v;
		if (v == newFa[u] || v == U) continue;
		dfs3(v, rt);
	}
}
int inDeg[MAXN];
int findHead()
{
	for (int i = 1; i <= edgeCnt; i++)
	{
		inDeg[graph[i].v]++;
	}
	for (int i = 1; i <= n; i++)
	{
		if (inDeg[i] == 1)
		{
			return i;
		}
	}
}
int ti = 0;
int has[MAXN];//�����ʾ��i��λ�����ĸ���. 
void linkDfs(int u, int f)
{
	has[++ti] = u;
	for (int e = head[u]; e; e = graph[e].next)
	{
		int v = graph[e].v;
		if (v == f) continue;
		linkDfs(v, u);
	}
}
int main()
{
	freopen("centroid.in", "r", stdin);
	freopen("centroid.out", "w", stdout);
	T = read();
	while (T--)
	{
		memset(graph, 0, sizeof(graph));
		edgeCnt = 0;
		cent_sum = 0;
		memset(head, 0, sizeof(head));
		n = read();
		for (int i = 1; i <= n - 1; i++)
		{
			int u = read(), v = read();
			addEdge(u, v);
			addEdge(v, u);
		}
		if (n % 10 == 1)
		{
			memset(inDeg, 0, sizeof(inDeg));
			memset(has, 0, sizeof(has));
			int h = findHead();
			ti = 0;
			linkDfs(h, h);
			//�ָ�㣺�ֳ�1..i��i+1...n�⼸�� 
			for (int i = 1; i <= n - 1; i++)
			{
				if (i % 2)
				{
					cent_sum += has[((i >> 1) + 1)];
				} else {
					cent_sum += has[(i >> 1)] + has[(i >> 1) + 1];
				}
				if ((n - i) % 2)
				{
					cent_sum += has[(n + i + 1) >> 1];
				} else {
					cent_sum += has[(n + i + 1) >> 1] + has[((n + i + 1) >> 1) + 1];
				}
			}
		} else {
			for (int i = 1; i <= edgeCnt; i += 2)
			{
				U = graph[i].u;
				V = graph[i].v;
				determineSize1(U, U);
				determineSize2(V, V);
				dfs2(U, U);
				dfs3(V, V);
			}
		}
		cout << cent_sum << endl;
	}
	return 0;
}
//I am thinking about you at this moment, Gracie. Do not fail me.
