#include<iostream>
#include<cstdio>
#define ll long long
using namespace std;
int f[410][10010];
int a[500010];
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	ll ans=0;
	int n,type;
	cin>>n>>type;
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	a[n+1]=0x7fffffff;
	int k=0;
	for(int i=1;i<=n;i++){
//		cout<<k<<" ";
		if(a[i]<k){
			if(a[i+1]>k) k+=a[i];
			else{
				ans+=1ll*k*k;
				k=a[i]+a[i+1];
				i+=1;
			}
		}
		else{
			ans+=k*k;
			k=a[i];
		}
	}
	cout<<ans+1ll*k*k;
	return 0;
}
