#include<iostream>
#include<cstdio>
#include<cstring>
#define maxn 50000
#define ll long long
#define MEM(a) memset(a,0,sizeof(a))
using namespace std;
int head[maxn],dfn[maxn],link[maxn*2],to[maxn*2],b[maxn*2];
int tot=0,minx,maxx;
void add(int x,int y){
	link[++tot]=head[x];
	to[tot]=y;
	head[x]=tot;
}
void dfs(int x,int fa,char flag){
	dfn[x]=dfn[fa]+flag;
	b[dfn[x]]=x;
	minx=min(minx,dfn[x]);
	maxx=max(maxx,dfn[x]);
	for(int i=head[x];i;i=link[i]){
		int u=to[i];
		if(u!=fa){
			dfs(u,x,flag);
			break;
		}
	}
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T,x,y;
	cin>>T;
	while(T--){
		MEM(head);MEM(dfn);MEM(link);MEM(to);MEM(b);
		ll ans=0;
		int n;
		cin>>n;
		for(int i=1;i<n;i++){
			scanf("%d%d",&x,&y);
			add(x,y);
			add(y,x);
		}
		maxx=minx=n;
		dfn[1]=n;
		b[n]=1;
		dfs(to[head[1]],1,1);
		if(link[head[1]]) dfs(to[link[head[1]]],1,-1);
		for(int i=minx;i<maxx;i++){
			int A=i-minx+1,B=maxx-i;
			if(A%2) ans+=b[A/2+minx];
			else ans+=b[A/2+minx-1]+b[A/2+minx];
//			cout<<i<<" "<<ans<<" ";
			if(B%2) ans+=b[B/2+i+1];
			else ans+=b[B/2+i]+b[B/2+i+1];
//			cout<<ans<<endl;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
