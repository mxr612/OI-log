#include<iostream>
#include<cstdio>
#define ll long long
using namespace std;
const ll MOD=998244353;
ll ans;
int n,m,a[110][2010];
bool vis[110];
void dfs(int x,ll t,int flag){
	if(x==m&&!flag) return ;
	if(x==m+1) return ;
	dfs(x+1,t,flag);
	for(int i=1;i<=n;i++){
		if(vis[i]||a[i][x]==0) continue;
		vis[i]=1;
		dfs(x+1,t*a[i][x],flag+1);
		if(flag){
//			cout<<x<<" "<<i<<" "<<t*a[i][x]<<endl;
			ans+=(t*1LL*a[i][x])%MOD;
			ans%=MOD;
		}
		vis[i]=0;
	}
}
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	dfs(1,1,0);
	cout<<ans;
	return 0;
}
