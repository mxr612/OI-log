#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 100010;

typedef long long ll;

inline void read(int &x)
{
	char ch = getchar(); x = 0;
	for(;ch < '0' || ch > '9';) ch = getchar();
	for(;ch >= '0' && ch <= '9';) x = x * 10 + (ch ^ '0'), ch = getchar();
}

struct Edge{ int to,nxt,id; } g[N << 1];
int last[N],cnt = 0,pos,tt = 0;
int n,sz[N],u[N],v[N],fa[N],T,G,tot[N],f[N],num[N];
ll ans;

void add(int u,int v,int k) { g[++cnt] = (Edge){ v,last[u],k }, last[u] = cnt; }
void Add_Edge(int u,int v,int k) { add(u,v,k), add(v,u,k); }

void dfs(int x,int j)
{
	sz[x] = 1;
	for(int i = last[x];i;i = g[i].nxt)
		if(g[i].id != j && g[i].to != fa[x]) 
			fa[g[i].to] = x, dfs(g[i].to,j), sz[x] += sz[g[i].to];
}

void dfs2(int x,int rt,int j)
{
	int tmp = 0,fg = 1;
	for(int i = last[x];i;i = g[i].nxt)
		if(g[i].to != fa[x] && g[i].id != j) dfs2(g[i].to,rt,j);
	for(int i = last[x];i;i = g[i].nxt) 
		if(g[i].to != fa[x] && sz[g[i].to] > sz[rt] / 2 && g[i].id != j) { fg = 0; break; }
	if(sz[rt] - sz[x] > sz[rt] / 2) fg = 0;
	G += fg ? x : 0;
}

int calc(int rt,int tag)
{
	G = 0, dfs(rt,tag), dfs2(rt,rt,tag);
	return G;
}

void dfs1(int x)
{
	sz[x] = 1; f[++tt] = x, num[x] = tt;
	for(int i = last[x];i;i = g[i].nxt)
		if(g[i].to != fa[x]) fa[g[i].to] = x, dfs1(g[i].to), sz[x] += sz[g[i].to];
}

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	
	for(read(T);T--;ans = 0,tt = 0)
	{
		read(n), memset(g,0,sizeof g), cnt = 0, memset(sz,0,sizeof sz);
		memset(last,0,sizeof last), memset(fa,0,sizeof fa), memset(tot,0,sizeof tot);
		memset(f,0,sizeof f), memset(num,0,sizeof num);
		for(int i = 1;i < n; ++ i)
			read(u[i]), read(v[i]), Add_Edge(u[i],v[i],i), ++tot[u[i]], ++tot[v[i]];
		if(n < 2000)
		{
			for(int i = 1;i < n; ++ i)
			{
				memset(sz,0,sizeof sz), memset(fa,0,sizeof fa);
				ans = ans + calc(u[i],i);
				ans = ans + calc(v[i],i);
			}
			printf("%lld\n",ans);
		}
		else
		{
			memset(sz,0,sizeof sz), memset(fa,0,sizeof fa);
			for(int i = 1;i <= n; ++ i)
				if(tot[i] == 1) { pos = i; break; }
			dfs1(pos);
			for(int i = 1;i < n; ++ i)
			{
				int x = u[i],y = v[i];
				if(fa[y] != x) swap(x,y);
				if(sz[y] % 2 == 1) ans += f[num[y] + sz[y] / 2]; 
				else ans += f[num[y] + sz[y] / 2] + f[num[y] + sz[y] / 2 - 1];
				if((sz[pos] - sz[x] + 1) % 2 == 1) ans += f[(sz[pos] - sz[x] + 1) / 2 + 1];
				else ans += f[(sz[pos] - sz[x] + 1) / 2] + f[(sz[pos] - sz[x] + 1) / 2 + 1];
			}
			printf("%lld\n",ans);
		}
	}
	
	fclose(stdin); fclose(stdout);
	return 0;
}
