#include <cstdio>
#include <cstring>
using namespace std;

const int N = 110;
const int mod = 998244353;

inline void read(int &x)
{
	char ch = getchar(); x = 0;
	for(;ch < '0' || ch > '9';) ch = getchar();
	for(;ch >= '0' && ch <= '9';) x = x * 10 + (ch ^ '0'), ch = getchar();
}

struct Things{ int x,y; } p[N];
int n,m,a[N][N],tag[N],vis[N],tot[N],cnt = 0,ans = 0,b[N];

void calc(int k)
{
	memset(tot,0,sizeof tot);
	for(int i = 1;i <= k; ++ i)
	{
		++tot[p[b[i]].y];
		if(tot[p[b[i]].y] > k / 2) return;
	}
	ans = (ans + 1) % mod;
}

void dfs(int cur,int x,int lim)
{
	if(x > lim) { calc(lim); return; }
	for(int i = cur + 1;i <= cnt; ++ i)
		if(!vis[i] && !tag[p[i].x]) 
			b[x] = i, vis[i] = 1, tag[p[i].x] = 1, dfs(i,x + 1,lim),
			b[x] = 0, vis[i] = 0, tag[p[i].x] = 0;
}

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	
	read(n), read(m);
	for(int i = 1;i <= n; ++ i)
		for(int j = 1;j <= m; ++ j)
		{
			read(a[i][j]);
			for(int k = 1;k <= a[i][j]; ++ k) p[++cnt] = (Things){ i,j };
		}
	for(int i = 2;i <= n; ++ i) 
		memset(tag,0,sizeof tag), memset(vis,0,sizeof vis), memset(b,0,sizeof b), dfs(0,1,i);
	
	printf("%d\n",ans);
	fclose(stdin); fclose(stdout);
	return 0;
}
