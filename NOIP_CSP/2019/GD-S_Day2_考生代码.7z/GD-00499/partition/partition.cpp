#include <cstdio>
#include <cstring>
using namespace std;

typedef long long ll;

const int N = 1010;
const ll INF = 0x3f3f3f3f3f3f3f3f;

inline ll min(ll a,ll b) { return a < b ? a : b; }

inline ll S(ll x) { return x * x; }

inline void read(int &x)
{
	char ch = getchar(); x = 0;
	for(;ch < '0' || ch > '9';) ch = getchar();
	for(;ch >= '0' && ch <= '9';) x = x * 10 + (ch ^ '0'), ch = getchar();
}

int n,a[N],m;
ll f[N][N],sum[N],ans;

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	
	read(n), read(m), ans = INF;
	for(int i = 1;i <= n; ++ i) read(a[i]), sum[i] = sum[i - 1] + a[i];
	for(int i = 0;i <= n; ++ i) 
		for(int j = 0;j <= n; ++ j) f[i][j] = INF; f[0][0] = 0;
	
	for(int i = 1;i <= n; ++ i)
		for(int j = 0;j <= i; ++ j)
			for(int k = 0;k <= j; ++ k) 
				if(sum[i] - sum[j] >= sum[j] - sum[k]) f[i][j] = min(f[i][j],f[j][k] + S(sum[i] - sum[j]));
				
	for(int i = 0;i <= n; ++ i) ans = min(ans,f[n][i]);
	printf("%lld",ans);
	fclose(stdin); fclose(stdout);
	return 0;
}
