#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int T,n,x,y,head[499910],xu[499910],tot,v[499910],du[499910],s,son[499910],cnt,where[499910],dad[499910],d[499910],that[499910][3];
unsigned long long ass=0;
bool bj[499910];
struct bb
{
	int fro,to,nex;
}a[499910<<1];
void ins(int x,int y)
{
	tot++;
	a[tot].fro=x;
	a[tot].nex=head[x];
	a[tot].to=y;
	head[x]=tot;
}
int dfs(int x,int fro)
{
	bj[x]=false;
	cnt++;
	xu[cnt]=x;
	where[x]=cnt;
	for(int i=head[x]; i; i=a[i].nex)
	if(bj[a[i].to]) son[x]+=dfs(a[i].to,x);
	son[x]++;
	return son[x];
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		cnt=0;
		scanf("%d",&n);
		for(int i=1; i<=n; i++) du[i]=0;
		for(int i=1; i<=n-1; i++)
		{
			scanf("%d%d",&x,&y);
			ins(x,y);
			ins(y,x);
			that[i][1]=x;
			that[i][2]=y;
			du[x]++;
			du[y]++;
		}
		for(int i=1; i<=n; i++)
		if(du[i]==1)
		{
			s=i;
			break;
		}
		for(int i=1; i<=n; i++) bj[i]=true;
		son[s]=dfs(s,0)+1;
		ass=0;
		{
			for(int i=1; i<=n-1; i++)
			{
				x=that[i][1];
				y=that[i][2];
				if(where[x]>where[y]) swap(x,y);
				if(!((1+where[x])&1)) ass+=xu[(1+where[x])/2];
				else ass+=(xu[(1+where[x])/2]+xu[(1+where[x])/2+1]);
				if(!((n+where[y])&1)) ass+=xu[(n+where[y])/2];
				else ass+=(xu[(n+where[y])/2]+xu[(n+where[y])/2+1]);
			}
			cout<<ass<<endl;
		}
	}
}
