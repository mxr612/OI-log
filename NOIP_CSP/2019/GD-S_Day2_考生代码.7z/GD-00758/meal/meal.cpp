#include<iostream>
#include<cstdio>
#define ll long long
using namespace std;
const unsigned ll N=998244353;
int n,m,aa,bb,cc;
unsigned ll a[210][2100],ass,as,f[50][50][50][50];
int pd(int i)
{
	int ass=0;
	while(i)
	{
		i=(i-1) & i;
		ass++;
	}
	return ass;
}
void dfs(int x,int tot,ll as)
{
	if(x>n)
	{
		if(aa<=tot/2 && bb<=tot/2 && cc<=tot/2 && tot>=2) ass=(as+ass)%N;
		return;
	}
	dfs(x+1,tot,as);
	if(aa+1<=((n-x+tot+1)>>1) && a[x][1]!=0)
	{
		aa++;
		dfs(x+1,tot+1,(as*a[x][1])%N);
		aa--;
	}
	if(bb+1<=((n-x+tot+1)>>1) && a[x][2]!=0)
	{
		bb++;
		dfs(x+1,tot+1,(as*a[x][2])%N);
		bb--;
	}
	if(cc+1<=((n-x+tot+1)>>1) && a[x][3]!=0)
	{
		cc++;
		dfs(x+1,tot+1,(as*a[x][3])%N);
		cc--;
	}
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	cin>>n>>m;
	for(int i=1; i<=n; i++)
	for(int j=1; j<=m; j++) scanf("%lld",&a[i][j]);
	dfs(1,0,1);
	cout<<ass;
}
