#include<iostream>
#include<cstdio>
#define ll long long
using namespace std;
int n,m,type;
unsigned ll ass1,ass2;
ll a[510000],nex[510000],b[510000];
bool bj;
void init()
{
	for(int i=1; i<=n; i++) a[i]=b[i],nex[i]=i+1;
	nex[n]=0;
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	
	cin>>n>>type;
	for(int i=1; i<=n; i++) scanf("%lld",&b[i]);
	init();
	
	for(int i=1; i; i=nex[i])
	{
		while(a[i]>a[nex[i]] && nex[nex[i]]!=0)
		{
			a[nex[i]]+=a[nex[nex[i]]];
			nex[nex[i]]=nex[nex[nex[i]]];
		}
	}
	bj=true;
	for(int i=1; i; i=nex[i])
	{
		if(a[i]>a[nex[i]] && nex[i]!=0)
		{
			bj=false;
			break;
		}
	}
	if(bj)
	for(int i=1; i; i=nex[i])
	{
		ass1+=a[i]*a[i];
	}
	init();
	
	for(int i=1; i<=n; i++)
	{
		while(a[i]>a[nex[i]] && nex[i]!=0)
		{
			a[i]+=a[nex[i]];
			nex[i]=nex[nex[i]];
		}
	}
	
	bj=true;
	for(int i=1; i; i=nex[i])
	if(a[i]>a[nex[i]]&& nex[i]!=0)
	{
		bj=false;
		break;
	}
	if(bj)
	for(int i=1; i; i=nex[i])
	{
		ass2+=a[i]*a[i];
	}
	if(ass2 && !ass1) cout<<ass2;
	else
	if(ass1 && !ass2) cout<<ass1;
	else
	cout<<min(ass1,ass2);
}
