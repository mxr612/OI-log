#include<cstring>
#include<cstdio>
#include<vector>
#define N 2001
#define LL long long
using namespace std;

int T,n;LL ans,d[N];
vector<LL>a;bool g[N][N];
struct Edge{int u,v;}e[N];
LL vsize(int u,int fa){
	LL sum=1ll;
	for(int v=1;v<=n;++v){
		if(!g[u][v]||v==fa)continue;
		sum+=vsize(v,u);
	}
	return sum;
}
void dfs(int u,int fa,LL td){
	d[u]=1ll;bool flag=true;
	for(int v=1;v<=n;++v){
		if(!g[u][v]||v==fa)continue;
		dfs(v,u,td);d[u]+=d[v];
		if(d[v]>(td>>1ll))flag=false;
	}
	if(flag&&(td-d[u])<=(td>>1ll))
		a.push_back(u);
}
LL check(int x,LL td){
	memset(d,0,sizeof(d));
	a.clear();dfs(x,-1,td);LL sum=0ll;
	for(int i=0,lena=a.size();i<lena;++i)
		sum+=a[i];
	return sum;
}
int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	
	scanf("%d",&T);
	while(T--){
		memset(g,0,sizeof(g));
		memset(e,0,sizeof(e));
		scanf("%d",&n);ans=0ll;
		for(int i=1;i<n;++i){
			scanf("%d%d",&e[i].u,&e[i].v);
			int u=e[i].u,v=e[i].v;
			g[u][v]=g[v][u]=1;
		}
		for(int i=1;i<n;++i){
			int u=e[i].u,v=e[i].v;
			g[u][v]=g[v][u]=0;
			LL vs=vsize(u,-1);
			ans+=check(u,vs)+check(v,n-vs);
			g[u][v]=g[v][u]=1;
		}
		printf("%lld\n",ans);
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
