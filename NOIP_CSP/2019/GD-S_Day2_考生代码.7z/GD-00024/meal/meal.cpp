#include<cstring>
#include<cstdio>
#define Min(a,b) (a<b?a:b)
#define N 101
#define M 201
#define MOD 998244353

int n,m,ans,a[N][M],tot[M],f[N][M][N*M];
int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;++i)
		for(int j=1;j<=m;++j)
			scanf("%d",&a[i][j]);
	for(int i=1;i<=m;++i){
		tot[i]=a[1][i];
		f[1][i][1]=tot[i]?1:0;
//		f[1][i][0]=1;
	}
	for(int i=2;i<=n;++i){
		for(int j=1;j<=m;++j){
			tot[j]+=a[i][j];
			int mxk=Min((i>>1),tot[j]);
			for(int k=0;k<=mxk;++k){
				for(int l=1;l<=m;++l){
					if(l==j){
						if(a[i][j]&&k>0)
							f[i][j][k]=(f[i][j][k]+f[i-1][j][k-1])%MOD;
						if(!a[i][j])
							f[i][j][k]=(f[i][j][k]+f[i-1][j][k])%MOD;
					}else{
						for(int h=0;h<=i-k;++h)
							f[i][j][k]=(f[i][j][k]+f[i-1][l][h])%MOD;
					}
				}
				ans=(ans+f[i][j][k])%MOD;
			}
		}
	}
	printf("%d\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
