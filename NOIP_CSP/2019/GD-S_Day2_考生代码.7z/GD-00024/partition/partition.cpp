#include<cstring>
#include<cstdio>
#define N 5001
#define Min(a,b) (a<b?a:b)
#define LL long long

LL n,typ,ans,sum[N],f[N][N],g[N][N];
LL cal(LL i,LL j){
	return (sum[i]-sum[j])*(sum[i]-sum[j]);
}
int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	
	scanf("%lld%lld",&n,&typ);
	if(typ==0){
		memset(f,0x3f,sizeof(f));ans=f[0][0];
		memset(g,0,sizeof(g));
		for(LL i=1;i<=n;++i){
			scanf("%lld",&sum[i]);
			sum[i]+=sum[i-1];
			g[1][i]=sum[i];
			f[1][i]=sum[i]*sum[i];
		}
		for(LL i=2;i<=n;++i){
			for(LL j=i;j<=n;++j){
				for(LL k=i-1;k<j;++k){
					if(g[i-1][k]<=sum[j]-sum[k]){
						LL m=f[i-1][k]+cal(j,k);
						if(f[i][j]>m){
							f[i][j]=m;g[i][j]=sum[j]-sum[k];
						}
					}
				}
			}
		}
		for(LL i=1;i<=n;++i)
			ans=Min(ans,f[i][n]);
		printf("%lld",ans);
	}else{
		printf("0\n");
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
