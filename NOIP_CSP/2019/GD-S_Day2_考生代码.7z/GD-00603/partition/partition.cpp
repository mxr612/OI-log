#include<cstdio>
using namespace std;
int n,Type;
int A[50010],a[50010];
long long ans=0x3f3f3f;
long long Sum[50010];
void dfs(int x)
{
	if(x==1)
	{
		long long temp=0;
		for(int i=1;i<=n;i++)
			temp+=a[i]*a[i];
		if(temp<ans)
			ans=temp;
		return ;
	}
	for(int i=x;i>=1;i--)
		if(a[i]<a[i-1] && a[i]!=0)
		{
			int temp1=a[i],temp2=a[i-1];
			a[i]=0;
			a[i-1]=Sum[i]-Sum[i-2];
			bool flag=false;
			for(int j=i;j<=n;j++)
				if(a[j]!=0)
				{
					if(a[j]<a[i-1])
					{
						flag=true;
						dfs(j);
					}
					break;
				}
			if(!flag)
				dfs(i-1);
			a[i]=temp1;
			a[i-1]=temp2;
			
			int idx=-1;
			for(int j=i+1;j<=n;j++)
				if(a[j]!=0)
				{
					idx=j;
					int temp1=a[i],temp2=a[idx];
					a[i]=Sum[idx]-Sum[i-1];
					a[idx]=0;
					dfs(i);
					a[i]=temp1;
					a[idx]=temp2;
					break;
				}
		}
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d", &n, &Type);
	if(Type==0)
	{
		for(int i=1;i<=n;i++)
		{
			scanf("%d", &A[i]);
			a[i]=A[i];
			Sum[i]=Sum[i-1]+A[i];
		}
		dfs(n);
		printf("%lld", ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
