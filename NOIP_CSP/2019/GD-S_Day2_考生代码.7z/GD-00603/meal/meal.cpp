#include<cstdio>
using namespace std;
const int mod=998244353;
int n,m;
int a[110][2010],vis[2010];
long long ans;
void dfs(int Ldep,int Nx,long long sum,int Ndep)
{
	if(sum==0)	
		return ;
	if(Ndep==Ldep)
	{
		ans+=sum;
		ans%=mod;
		return ;
	}
	for(int i=Nx+1;i<=n;i++)
		for(int j=1;j<=m;j++)
			if(a[i][j]!=0 && vis[j]<(Ldep/2))
			{
				vis[j]++;
				long long temp=(sum*a[i][j])%mod;
				dfs(Ldep,i,temp,Ndep+1);
				vis[j]--;
			}
}
int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d", &n, &m);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			scanf("%d", &a[i][j]);
	for(int k=2;k<=n;k++)
	{
		for(int i=1;i<=(n-k+1);i++)
			for(int j=1;j<=m;j++)
			{
				if(a[i][j]!=0)
				{
					vis[j]++;
					dfs(k,i,a[i][j],1);
					vis[j]--;	
				}
			}
	}
	printf("%lld", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
