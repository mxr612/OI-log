#include <cstdio>
#define N 6000
#define ll long long
#define inf 1e18
using namespace std;

ll f[N][N], sum[N], ans;
int n, a[N];

ll fmin(ll x, ll y){return x < y ? x : y;}

int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int type;
	scanf("%d%d", &n, &type);
	for (int i = 1; i <= n; i++)
	{
		scanf("%d", &a[i]);
		sum[i] = sum[i - 1] + a[i];
		for (int j = 1; j <= n; j++) f[i][j] = inf;
		f[i][i] = sum[i] * sum[i];
	}
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= i; j++)
		{
			ll tmp = (sum[i] - sum[i - j]) * (sum[i] - sum[i - j]);
			for (int k = 1; k <= i - j; k++)
				if (sum[i] - sum[i - j] >= sum[i - j] - sum[i - j - k])
					f[i][j] = fmin(f[i][j], f[i - j][k] + tmp);
				else break;
		}
	ll ans = inf;
	for (int i = 1; i <= n; i++) ans = fmin(ans, f[n][i]);
	printf("%lld", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
