#include <cstdio>
#include <algorithm>
#define N 5000
using namespace std;

struct arr
{
	int x, y;
}num[N];
int f[N],a[N][N],fa[N],size[N],ff[N],n;
bool v[N],vis[N];

void dfs(int now, int ls, int xx, int yy)
{
	fa[now] = ls;
	v[now] = true;
	size[yy]++;
	ff[now] = yy;
	for (int i = 1; i <= a[now][0]; i++)
		if (!v[a[now][i]])
		{
			if ((now == num[xx].x) && (a[now][i] == num[xx].y)) continue;
			if ((now == num[xx].y) && (a[now][i] == num[xx].x)) continue;
			dfs(a[now][i], now, xx, yy);
			f[now] += f[a[now][i]];
		}
}

int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T;
	scanf("%d", &T);
	while(T--)
	{
		scanf("%d", &n);
		for (int i = 1; i <= n; i++) a[i][0] = 0;
		for (int i = 1; i < n; i++)
		{
			scanf("%d%d", &num[i].x, &num[i].y);
			a[num[i].x][++a[num[i].x][0]] = num[i].y;
			a[num[i].y][++a[num[i].y][0]] = num[i].x;
		}
		int ans = 0;
		for (int i = 1; i < n; i++)
		{
			for (int j = 1; j <= n; j++)
			{
				f[j] = 1;
				v[j] = false;
				size[j] = 0;
			}
			dfs(num[i].x, 0, i, num[i].x);
			dfs(num[i].y, 0, i, num[i].y);
			bool fl;
			for (int j = 1; j <= n; j++)
			{
				fl = true;
				for (int k = 1; k <= a[j][0]; k++)
				{
					if ((j == num[i].x) && (a[j][k] == num[i].y)) continue;
					if ((a[j][k] == num[i].x) && (j == num[i].y)) continue;
					if ((a[j][k] != fa[j]) && (f[a[j][k]] > size[ff[a[j][k]]] / 2))
					{
						fl = false;
						break;
					}
				}
				if (f[ff[fa[j]]] - f[j] > size[ff[fa[j]]] / 2) fl = false;
				if (fl || size[ff[j]] == 1) ans += j;              
			}
		}
		printf("%d\n", ans);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
