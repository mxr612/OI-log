#include <cstdio>
#define ll long long
#define N 3000
#define mo 998244353
using namespace std;

int a[N][N],cnt[N],n,m;
ll ans;

void dfs(int x, int now, int mx, ll s)
{
	if (x > mx)
	{
		ans = (ans + s) % mo;
		return;
	}
	if (now > n) return;
	dfs(x, now + 1, mx, s);
	for (int i = 1; i <= m; i++)
		if (cnt[i] + 1 <= mx / 2 && a[now][i] != 0)
		{
			cnt[i]++;
			dfs(x + 1, now + 1, mx, s * a[now][i] % mo);
			cnt[i]--;
		}
}

int main()
{
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			scanf("%d", &a[i][j]);
	for (int i = 2; i <= n; i++)
		dfs(1, 1, i, 1);
	printf("%lld", ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
