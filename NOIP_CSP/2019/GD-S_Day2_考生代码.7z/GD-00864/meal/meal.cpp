#include<cstdio>
#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("meal.in");
ofstream fout("meal.out");
const long long mod=998244353;
long long n,m,a[110][1010],nu[1010],ans;
void dfs(long long x,long long nw,long long k,long long re){
	if(n-x+1+nw<k) return;
	for(int i=1;i<=m;i++){
		if(a[x][i]&&nu[i]*2+2<=k){
			if(nw+1==k) ans=(ans+re*a[x][i])%mod;
			else{
				nu[i]++;
				for(int j=x+1;j<=n;j++) dfs(j,nw+1,k,re*a[x][i]%mod);
				nu[i]--;
			}
		}
	}
	return;
}
int main(){
	fin>>n>>m;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=m;j++)
			fin>>a[i][j];
	for(int i=2;i<=n;i++)
		for(int j=1;j<=n;j++)
			dfs(j,0,i,1);
	fout<<ans<<endl;
	return 0;
}

