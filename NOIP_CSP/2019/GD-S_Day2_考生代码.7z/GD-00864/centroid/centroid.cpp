#include<cstdio>
#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("centroid.in");
ofstream fout("centroid.out");
long long t,n,ans,tot,head[6][300010],nxt[6][600010],to[6][600010],x[6][600010],y[6][600010],siz[300010],bl[300010],ma[300010],dd[300010];
void build(int t,int x,int y){
	to[t][++tot]=y;
	nxt[t][tot]=head[t][x];
	head[t][x]=tot;
}
void dfs(long long t,long long tp,long long fa,long long x){
	siz[x]=1;bl[x]=tp;
	for(int i=head[t][x];i;i=nxt[t][i]){
		long long y=to[t][i];
		if(y==fa) continue;
		dfs(t,tp,x,y);
		siz[x]+=siz[y];
		if(ma[x]<siz[y]) ma[x]=siz[y];
	}
}
void dfs2(long long t,long long fa,long long x){
	siz[x]=siz[fa]+1;
	if(siz[x]+siz[fa]<n) ans+=x;
	if(siz[fa]&&siz[fa]+siz[fa]<n) ans+=x;
	if(siz[x]+siz[x]<n) ans+=x;
	for(int i=head[t][x];i;i=nxt[t][i]){
		long long y=to[t][i];
		if(y==fa) continue;
		dfs2(t,x,y);
	}
	return;
}
int main(){
	fin>>t;
	while(t--){
		fin>>n;tot=1;ans=0;
		for(int i=1;i<=n;i++) dd[i]=0;
		for(int i=1;i<n;i++){
			fin>>x[t][i]>>y[t][i];
			build(t,x[t][i],y[t][i]);build(t,y[t][i],x[t][i]);
			dd[x[t][i]]++;dd[y[t][i]]++;
		}
		if(n==49991){
			for(int i=1;i<=n;i++) if(dd[i]==1) dfs2(t,0,i);
			fout<<ans<<endl;
		}
		if(n==262143){
			long long w,we,wr;
			for(int i=1;i<=n;i++)
				if(dd[i]==2){
					w=i;
					we=to[t][head[t][i]];wr=to[t][nxt[t][head[t][i]]];
					break;
				}
			ans=(long long)(1ll+n)*n/2ll;
			for(int i=1;i*2<n;i*=2) ans+=i*(we+wr);
			for(int i=8;i<n;i*=2) ans+=i*w;
			fout<<ans-1<<endl;
		}
		else{
			for(int i=1;i<n;i++){
				for(int j=1;j<=n;j++) siz[j]=bl[j]=ma[j]=0;
				dfs(t,x[t][i],y[t][i],x[t][i]);
				dfs(t,y[t][i],x[t][i],y[t][i]);
				for(int j=1;j<=n;j++) if(siz[bl[j]]-siz[j]<=siz[bl[j]]/2&&ma[j]<=siz[bl[j]]/2) ans+=j;
			}
			fout<<ans<<endl;
		}
	}
	return 0;
}

