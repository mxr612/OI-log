#include<cstdio>
#include<iostream>
#include<fstream>
using namespace std;
ifstream fin("partition.in");
ofstream fout("partition.out");
unsigned long long n,tp,a[5000100],s[5000100],dp[5000100],sz[5000100];
int main(){
	fin>>n>>tp;
	if(!tp) for(int i=1;i<=n;i++){fin>>a[i];s[i]=s[i-1]+a[i];}
	for(int i=1;i<=n;i++){
		dp[i]=4611686018427387903;
		for(int j=0;j<i;j++){
			if(sz[j]<=s[i]-s[j]&&dp[j]+(s[i]-s[j])*(s[i]-s[j])<dp[i]){
				sz[i]=s[i]-s[j];dp[i]=dp[j]+(s[i]-s[j])*(s[i]-s[j]);
			}
			else{
				if(sz[i]>s[i]-s[j]&&dp[j]+(s[i]-s[j])*(s[i]-s[j])==dp[i]) sz[i]=s[i]-s[j];
			}
		}
	}
	fout<<dp[n]<<endl;
	return 0;
}

