#include<bits/stdc++.h>
#define N 40000001
using namespace std;
long long ans=LONG_LONG_MAX;
int n;
long long a[N],sum[N];
void dfs(int i,long long pre,long long s)
{
	if(i==n+1)
	{
		ans=min(ans,s);
		return;
	}
	for(int j=i; j<=n; j++)
	{
		if(sum[j]-sum[i-1]>=pre)
		{
			dfs(j+1,sum[j]-sum[i-1],s+(sum[j]-sum[i-1])*(sum[j]-sum[i-1]));
		}
	}
}
int main()
{
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	int type;
	scanf("%d%d",&n,&type);
	for(int i=1; i<=n; i++)
	{
		scanf("%lld",&a[i]);
		sum[i]=sum[i-1]+a[i];
	}
	dfs(1,0,0);
	printf("%lld",ans);
}
