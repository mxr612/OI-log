#include<bits/stdc++.h>
#define N 300001
using namespace std;
long long ans;
int size[N],new_size[N];
struct Edge
{
	long long u;
	long long v;
	int id;
}edge[N];
vector<Edge> g[N];
void dfs(int u,int fa)
{
	size[u]=1;
	for(int i=0;i<(int)g[u].size();i++)
	{
		long long v=g[u][i].v;
		if(v!=fa)
		{
			dfs(v,u);
			size[u]+=size[v];
		}
	}
}
void re_dfs(int u,int fa,int total_size,int banned)
{
	new_size[u]=1;
	int max_child=0;
	for(int i=0;i<(int)g[u].size();i++)
	{
		long long v=g[u][i].v;
		int id=g[u][i].id;
		if(v!=fa&&id!=banned)
		{
			re_dfs(v,u,total_size,banned);
			new_size[u]+=new_size[v];
			max_child=max(max_child,new_size[v]);
		}
	}
	if(max_child<=(total_size/2)&&(total_size-new_size[u])<=(total_size/2))
	{
		ans+=u;
	}
}
int main()
{
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--)
	{
		ans=0;
		memset(g,0,sizeof(g));
		int n;
		scanf("%d",&n);
		for(int i=1;i<n;i++)
		{
			scanf("%lld%lld",&edge[i].u,&edge[i].v);
			edge[i].id=i;
			g[edge[i].u].push_back((Edge){edge[i].u,edge[i].v,i});
			g[edge[i].v].push_back((Edge){edge[i].v,edge[i].u,i});
		}
		dfs(1,-1);
		for(int i=1;i<n;i++)
		{
			memset(new_size,0,sizeof(new_size));
			long long u=edge[i].u,v=edge[i].v;
			if(size[u]>size[v])swap(u,v);
			re_dfs(u,-1,size[u],i);
			re_dfs(v,-1,n-size[u],i);
		}
		printf("%lld\n",ans);
	}
}
