#include<bits/stdc++.h>
using namespace std;

const int N=300010;
int T,n;
struct edge{
	int y,next;
}s[N<<1];
int first[N],len=0,in[N],a[N],son[N],mmax[N];
bool tf[N<<1];

void ins(int x,int y){
	s[len++]=(edge){y,first[x]};first[x]=len-1;
	s[len++]=(edge){x,first[y]};first[y]=len-1;
	in[x]++;in[y]++;
}

namespace subtask1{
	void solve(){
		int rt;
		for(int i=1;i<=n;i++) if(in[i]==1) {rt=i;break;}
		a[1]=rt;int now=s[first[rt]].y;a[2]=now;a[0]=2;
		while(in[now]!=1){
			if(s[first[now]].y==a[a[0]-1]) a[++a[0]]=s[s[first[now]].next].y,now=a[a[0]];
			else a[++a[0]]=s[first[now]].y,now=a[a[0]];
		}
		long long ans=0;
		for(int i=1;i<n;i++){
			ans+=a[i/2+1];
			if((i&1)==0) ans+=a[i/2];
			ans+=a[(n-i)/2+1+i];
			if(((n-i)&1)==0) ans+=a[(n-i)/2+i];
		}
		printf("%lld\n",ans);
	}
}

long long ans=0;

void dfs(int x,int fa){
	son[x]=1;mmax[x]=0;
	for(int i=first[x];i!=-1;i=s[i].next) if(s[i].y!=fa) dfs(s[i].y,x),mmax[x]=max(mmax[x],son[s[i].y]),son[x]+=son[s[i].y];
}

void get_ans(int x,int fa,int tot){
	if(mmax[x]<=tot/2 && tot-son[x]<=tot/2) ans+=x;
	for(int i=first[x];i!=-1;i=s[i].next) if(s[i].y!=fa) get_ans(s[i].y,x,tot);
}

void solve(){
	int sz1,sz2;ans=0;
	for(int i=0;i<(n-1)*2;i+=2){
		dfs(s[i].y,s[i^1].y),dfs(s[i^1].y,s[i].y);
		get_ans(s[i].y,s[i^1].y,son[s[i].y]),get_ans(s[i^1].y,s[i].y,son[s[i^1].y]);
	}
	printf("%lld\n",ans);
}

int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		int x,y;
		memset(first,-1,sizeof(first));len=0;
		memset(in,0,sizeof(in));
		for(int i=1;i<n;i++) scanf("%d %d",&x,&y),ins(x,y);
		if(n==49991) subtask1::solve();
		else solve();
	}
}
