#include<bits/stdc++.h>
using namespace std;

const int N=500010;
int n,type;
int a[N];
long long sum[N];
long long ans=4e18;

void dfs(int x,int last,long long lastt,long long tot){
	if(tot>ans) return ;
	if(x==n+1){ans=tot;return ;}
	if(x!=n) dfs(x+1,last,lastt,tot);
	if(lastt<=(sum[x]-sum[last])) dfs(x+1,x,sum[x]-sum[last],tot+(sum[x]-sum[last])*(sum[x]-sum[last]));
}

int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d %d",&n,&type);
	for(int i=1;i<=n;i++) scanf("%d",&a[i]),sum[i]=sum[i-1]+a[i];
	dfs(1,0,0,0);
	printf("%lld\n",ans);
}
