#include<bits/stdc++.h>
using namespace std;

const int N=110,M=1010;
long long fac[N],inv[N];
int n,m;
int a[N][M];
long long f[2][N][N];
long long tot[N];
const long long mod=998244353;
long long ans;

int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d %d",&n,&m);ans=1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++)
			scanf("%d",&a[i][j]),tot[i]+=a[i][j];
		tot[i]%=mod;(ans*=tot[i]+1)%=mod;
	}
	for(int i=1;i<=m;i++){
		memset(f,0,sizeof(f));
		f[0][0][0]=1;
		int op=0;
		for(int j=1;j<=n;j++){op^=1;
			memset(f[op],0,sizeof(f[op]));
			for(int p=0;p<=j;p++)
				for(int b=0;p+b<=j;b++){
					f[op][p][b]=f[op^1][p][b];
					if(p) f[op][p][b]+=f[op^1][p-1][b]*a[j][i];
					if(b) f[op][p][b]+=f[op^1][p][b-1]*(tot[j]-a[j][i]+mod)%mod;
					f[op][p][b]%=mod;
				}
		}
		for(int k=1;k<=n;k++)
			for(int j=k/2+1;j<=k;j++)
				ans+=mod-f[op][j][k-j];
		ans%=mod;
	}
	printf("%lld\n",(ans+mod-1)%mod);
}
