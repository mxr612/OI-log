#include<bits/stdc++.h>
using namespace std;

int head[50005],cnt,sta[50005],size[50005],T,n,m,U[50005],V[50005],x,y,ans;

struct edge{
	int to,nxt;
}e[100005];

void add(int u,int v){
	e[++cnt]=(edge){v,head[u]};
	head[u]=cnt;
}

void dfs(int u,int fa){
	size[u]=1;
	for(int i=head[u];i;i=e[i].nxt){
		int v=e[i].to;
		if(v==fa) continue;
		sta[++sta[0]]=v;
		dfs(v,u);
		size[u]+=size[v];
	}
}

bool check(int u){
	if(size[x]-size[u]>n/2) return 0;
	for(int i=head[u];i;i=e[i].nxt){
		int v=e[i].to;
		if(size[v]>size[u]) continue;
		if(size[v]>n/2) return 0;
	}
	return 1;
}

int main(){
	freopen("centroid.in","r",stdin);
	freopen("centroid.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		ans=cnt=0;
		memset(head,0,sizeof(head));
		scanf("%d",&n);
		for(int i=1,u,v;i<n;i++){
			scanf("%d%d",&u,&v);
			add(u,v);add(v,u);
			U[i]=u,V[i]=v;
		}
		for(int i=1;i<n;i++){
			x=U[i],y=V[i];
			sta[sta[0]=1]=x;
			memset(size,0,sizeof(size));
			dfs(x,y);
			for(int i=1;i<=sta[0];i++) if(check(i)){ans+=i;break;}
			sta[sta[0]=1]=y;
			memset(size,0,sizeof(size));
			dfs(y,x);x=y;
			for(int i=1;i<=sta[0];i++) if(check(i)){ans+=i;break;}
		}
		printf("%d\n",ans);
	}
	return 0;
}
