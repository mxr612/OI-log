#include<bits/stdc++.h>
#define ll long long
using namespace std;

int cnt[2005],a[105][2005],n,m;ll ans,mod=998244353;

void dfs(int dep,ll tot,int lvl){
	if(dep==n+1){
		if(lvl>1) ans=(ans+tot)%mod;
		return ;
	}
			dfs(dep+1,tot%mod,lvl);
	for(int i=1;i<=m;i++){
		if(a[dep][i]){
			if(cnt[i]+1<=lvl/2||(lvl<2&&cnt[i]<1)){
				cnt[i]++;
				dfs(dep+1,(1ll*tot*a[dep][i])%mod,lvl+1);
				cnt[i]--;
			}
		}
	}
}

int main(){
	freopen("meal.in","r",stdin);
	freopen("meal.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) for(int j=1;j<=m;j++) scanf("%d",a[i]+j);
	dfs(1,1ll,0);
	printf("%lld",ans);
	return 0;
}
