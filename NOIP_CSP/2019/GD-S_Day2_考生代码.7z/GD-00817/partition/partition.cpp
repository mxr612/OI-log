#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;

int n,op;

ull a[500005],ans,lst,num;

void read(ull &x){
	x=0;char c=getchar();
	while(c<'0'||c>'9') c=getchar();
	while(c>='0'&&c<='9') x=(x<<3)+(x<<1)+c-'0',c=getchar();
}

void write(ull x){
	if(x>9) write(x/10);
	putchar(x%10+'0');
}

int main(){
	freopen("partition.in","r",stdin);
	freopen("partition.out","w",stdout);
	scanf("%d%d",&n,&op);
	if(op==0){
		for(int i=1;i<=n;i++) read(a[i]);
		for(int i=1;i<=n;i++){
			num=a[i];
			while(num<lst) num+=a[++i];
			if(i==n-1&&a[i+1]<num) num+=a[++i];
			while(num+a[i+1]<=a[i+2]&&i+2<=n) num+=a[++i];
			ans+=num*num;
			lst=num;
//			printf("%d %d\n",i,ans);
		}
		write(ans);
		return 0;
	}
}
