#include<cstdio>
#include<cstring>
using namespace std;
typedef long long ll;
ll n,k,d[110];
ll a[110],len=101;
void dfs(ll n,ll k)
{
	if(n==1)
	{
		len--,a[len]=(k==1?0:1);
		return;
	}
	if(k>=1&&k<=d[n-1])
	{
		dfs(n-1,k);
		len--,a[len]=0;
	}
	else if(k>=d[n-1]+1&&k<=d[n])
	{
		dfs(n-1,d[n-1]-(k-d[n-1])+1);
		len--,a[len]=1;
	}
}
int main()
{
	freopen("code.in","r",stdin); freopen("code.out","w",stdout);
	scanf("%lld %lld",&n,&k);k++;
	d[0]=1;
	for(int i=1;i<=n;i++) d[i]=d[i-1]*2;
	dfs(n,k);
	for(int i=len;i<=100;i++) printf("%lld",a[i]);
	return 0;
}
