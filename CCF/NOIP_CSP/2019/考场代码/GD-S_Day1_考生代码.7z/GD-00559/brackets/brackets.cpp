#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
ll op=0; //op=0:�� 
char st[500010];
/*
'(':1
')':0
*/
ll n,nt=0,ans=0;
ll sta[500010],top=0;
ll top2,s2[500010];
struct Tree
{
	char c;
	ll fa;
} tr[500010];
bool check(ll l,ll r)
{
	top2=0;
	if(sta[l]==1) s2[++top2]=1;
	if(sta[l]==0) s2[++top2]=0;
	for(int i=l+1;i<=r;i++)
	{
		if(sta[i]==1) s2[++top2]=1;
		if(sta[i]==0)
		{
			if(s2[top2]==1) top2--;
			else if(s2[top2]==0) s2[++top2]=0;
		}
	}
	if(top2==0) return true;
	else return false;
}
int main()
{
	freopen("brackets.in","r",stdin); freopen("brackets.out","w",stdout);
	scanf("%lld",&n); scanf("%s",st+1);
	tr[1].c=(st[1]=='('?1:0);
	for(int i=2;i<=n;i++)
	{
		tr[i].c=(st[i]=='('?1:0);
		scanf("%lld",&tr[i].fa);
		if(tr[i].fa!=i-1) op=1;
	}
	if(op==0)
	{
		ans=0; nt=0;
		if(st[1]=='(') sta[++top]=1;
		if(st[1]==')') sta[++top]=0;
		for(int i=2;i<=n;i++)
		{
			if(st[i]=='(') sta[++top]=1;
			if(st[i]==')') sta[++top]=0;
			for(int j=1;j<=top-1;j++)
				if(check(j,top)==true) nt++;
			ans=ans xor (nt*i);
		}
		printf("%lld",ans);
	}
	return 0;
}
