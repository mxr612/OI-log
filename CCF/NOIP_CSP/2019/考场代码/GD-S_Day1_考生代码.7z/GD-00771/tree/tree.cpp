#include<cstdio>
using namespace std;

int t,n,temp;

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		scanf("%d",&temp);
		if(n==1)
			{printf("1\n");return 0;}
		if(temp==1) printf("2 1 ");
		else printf("1 2 ");
		for(int i=3;i<=n;i++)
			printf("%d ",i);
		printf("\n");
		for(int i=2;i<=n;i++)
			scanf("%d",&temp);
		for(int i=1;i<=2;i++)
			for(int j=1;j<=n-1;j++)
				scanf("%d",&temp);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
