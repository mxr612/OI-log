#include<cstdio>
#include<iostream>
#define ll unsigned long long
using namespace std;

ll n,k;
int a[65];

ll qpow(ll x,ll p)
{
	if(p==1) return x;
	ll t=qpow(x,p/2);
	return t*t*(p&1?x:1);
}

void f(ll i,ll j)
{
	if(i==1)
	{
		a[i]=j-1;
		return;
	}
	ll t=qpow(2,i-1);
	if(j>t)
	{
		a[i]=1;
		f(i-1,t-(j-t)+1);
	}
	else
	{
		a[i]=0;
		f(i-1,j);
	}
}

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	++k;
	f(n,k);
	for(int i=n;i>=1;i--)
		printf("%d",a[i]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
