#include<stack>
#include<cstdio>
#include<string>
using namespace std;

int n,temp,cnt[500001];
int to[500001],head[500001],nxt[500001],dive;
char c[500001];
string ts;

void add(int x,int y)
{
	nxt[++dive]=head[x];
	head[x]=dive;
	to[dive]=y;
}

void dfs(int xc,int fa)
{
	ts.push_back(c[xc]);
	stack<int> sta;
	cnt[xc]=cnt[fa];
	for(int k=0;k<ts.size()-1;k++)
	{
		while(!sta.empty()) sta.pop();
		for(int i=k;i<ts.size();i++)
		{
			if(ts[i]=='(') sta.push(1);
			else
			{
				if(sta.empty())
					{sta.push(1);break;}
				sta.pop();
			}
		}
		if(sta.empty()) ++cnt[xc];
	}
	for(int k=head[xc];k;k=nxt[k])
		dfs(to[k],xc);
	ts.erase(ts.size()-1,1);
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf(" %c",&c[i]);
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&temp);
		add(temp,i);
	}
	dfs(1,-1);
	for(int i=2;i<=n;i++)
		cnt[1]^=(cnt[i]*i);
	printf("%d",cnt[1]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
