#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<string>
using namespace std;
typedef long long ll;
const int N=500005;
int toit[N],head[N],next[N],tot;
bool num[N];
int h[N];
int n;
string strs;
ll ANS;

void add(int x,int y)
{
	toit[++tot]=y;
	next[tot]=head[x];
	head[x]=tot;
}

void dfs(int u,bool pre,int height,ll ans)
{
	
	
	int ooh=height;
	int o1=0,o2=0,o3=0;
	if (height) o1=h[height-1];
	o2=h[height];
	o3=h[height+1];
	
	//kh[dep]=num[u]?'(':')';
	//for (int a=1;a<=dep;++a) cout<<kh[a];
	//printf("\n");
	if (!num[u])
	{
		if (pre)//��(  now) 
		{
			ans+=(++h[height]);
		}
		else if (!pre)//pre)   now)
		{
			
			if (height>=1)
			{
				h[height--]=0;
				ans+=(++h[height]);
			}
			
		}
	}
	else
	{
		height++;
	}
	//printf("h:%d   ",u);
	//for (int a=0;a<=height;++a) printf("%d ",h[a]);
	//printf("\n");
	
	int oh=h[height];
	
	//printf("%d ans:%lld\n",u,ans);
	
	
	ANS^=(u*ans);
	
	//printf("%d %d %lld\n",u,height,ans);
	for (int a=head[u];a;a=next[a])
	{
		int v=toit[a];
		//printf("%d-%d\n",u,v);
		dfs(v,h[u],height,ans);
		h[height]=oh;
	}
	if (ooh) h[ooh-1]=o1;
	h[ooh]=o2;
	h[ooh+1]=o3;
	
	//printf("\nh:%d   ",u);
	//for (int a=0;a<=height;++a) printf("%d ",h[a]);
	//printf("\n");
}

void solve1()
{
	dfs(1,false,0,0);
	printf("%lld",ANS);
}

void solve2()
{
	ll ans=0;
	int height=0;
	for (int a=1;a<=n;++a)
	{
		if (num[a])
		{
			if (a==1||num[a-1]) height++;
		}
		else
		{
			if (num[a-1]!=num[a]) //pre(  bac)
			{
				ans+=++h[height];
				
			}
			else
			{
				
				if (height>1)
				{
					h[height]=0;
					ans+=++h[--height];
				}
			}
		}
		printf("%d %d %lld\n",a,height,ans);
		ANS^=a*ans;
	}
	printf("%lld\n",ANS);
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	cin>>strs;
	for (int a=0;a<n;++a) num[a+1]=(strs[a]=='(');
	bool k=true;
	for (int a=2;a<=n;++a)
	{
		int x;
		scanf("%d",&x);
		add(x,a);
		if (a-x!=1) k=false;
	}
	
	
	if (n<=2000)
	{
		solve1();
	}
	else if (k)
	{
		solve2();
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
