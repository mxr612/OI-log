#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;

typedef unsigned long long ll;
ll n,k,t;
bool ans[100];

void dfs(ll k)
{
	//printf("%lld\n",k);
	if (k==2)
	{
		ans[0]=1;return;
	}
	else if (k==1)
	{
		ans[0]=false;return;
	}
	ll delta=int(log2(k-1));
	ll nxt=(1<<delta+1)+1-k;
	//printf("%lld %lld %lld\n",k,delta,nxt);
	ans[delta]=true;
	dfs(nxt);
}

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	
	dfs(k+1);
	for (int a=n-1;a>=0;--a) printf("%d",ans[a]);
	
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
