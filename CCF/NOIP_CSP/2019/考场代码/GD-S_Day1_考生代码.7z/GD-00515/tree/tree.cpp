#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<queue>
using namespace std;
const int N=2005;
struct node{
	int x,y;
};

node p[N];
int toit[N*2],next[N*2],head[N],tot;
int num[N],n,ans[N],cal[N],number[N],du[N];
bool vis[N];

void add(int x,int y)
{
	toit[++tot]=y;
	next[tot]=head[x];
	head[x]=tot;
}

void check_ans1()
{
	//for (int a=1;a<n;++a) printf("%d ",cal[a]);
	//printf("\n");
	//for (int a=1;a<=n;++a) printf("%d ",num[a]);
	
	for (int a=1;a<=n;++a) number[num[a]]=a;
	
	if (ans[1]==0)
	{
		for (int a=1;a<=n;++a) ans[a]=number[a];
		//printf("*");
	}
	else
	{
		bool k=true;
		for (int a=1;a<=n;++a)
		{
			if (ans[a]>number[a]) break;
			if (ans[a]<number[a])
			{
				k=false;break;
			}
		}
		if (k) for (int a=1;a<=n;++a) ans[a]=number[a];
		//if (k) printf("*");
	}
	//printf("\n");
}

void dfs1(int now)
{
	if (now>=n)
	{
		check_ans1();
		return;
	}
	
	for (int a=1;a<n;++a)
	{
		if (!vis[a])
		{
			cal[now]=a;
			vis[a]=true;
			int num1=num[p[a].x];
			num[p[a].x]=num[p[a].y];
			num[p[a].y]=num1;
			
			dfs1(now+1);
			
			vis[a]=false;
			num1=num[p[a].y];
			num[p[a].y]=num[p[a].x];
			num[p[a].x]=num1;
		}
	}
	
}

void solve1() //n<=10
{
	dfs1(1);
	for (int a=1;a<=n;++a) printf("%d ",ans[a]);
	printf("\n");
}



bool check1()
{
	int num1=0,num2=0;
	for (int a=1;a<=n;++a) if (du[a]==n-1) return true;
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T;
	scanf("%d",&T);
	
	while (T--)
	{
		//printf("\n");
		memset(ans,0,sizeof(ans));
		memset(vis,false,sizeof(vis));
		memset(num,0,sizeof(num));
		scanf("%d",&n);
		bool k=true;
		for (int a=1;a<=n;++a)
		{
			int x;
			scanf("%d",&x);
			num[x]=a;
			number[a]=x;
		}
		for (int a=1;a<n;++a)
		{
			scanf("%d%d",&p[a].x,&p[a].y);
		}
		
		solve1();
		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
