#include<bits/stdc++.h>
using namespace std;
#define MAXN 70
#define LL long long
int n;
LL k;
LL quickEx(LL x,LL y)
{
	LL res=1;
	while(y)
	{
		if(y&1)
		{
			res=res*x;
		}
		x=x*x;
		y>>=1;
	}
	return res;
}
int ans[MAXN];
int tot;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%lld",&n,&k);
	int i;
	for(i=n;i>=1;i--)
	{
		tot++;
		LL tmp=quickEx((LL)2,(LL)i-1)-1;
		if(i==64)
		{
			tmp=quickEx((LL)2,(LL)62)-1+quickEx((LL)2,(LL)62);
		}
		if(k<=tmp)
		{
			ans[tot]=0;
		}
		else
		{
			k=2*(tmp+1)-1-k;
			ans[tot]=1;
		}
	}
	for(i=1;i<=n;i++)
	{
		printf("%d",ans[i]);
	}
	return 0;
}
