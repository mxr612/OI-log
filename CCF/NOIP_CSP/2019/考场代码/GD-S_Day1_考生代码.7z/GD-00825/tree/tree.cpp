#include<bits/stdc++.h>
using namespace std;
#define MAXN 2005
int n;
int ori[MAXN];
int aft[MAXN];
int deg[MAXN];
bool edge[MAXN][MAXN];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		int i,j;
		for(i=1;i<=n;i++)
		{
			scanf("%d",&ori[i]);//��ʼ���ڽڵ��� 
		}
		memset(edge,false,sizeof(edge));
		for(i=1;i<=n-1;i++)
		{
			int x,y;
			scanf("%d%d",&x,&y);
			deg[x]++;deg[y]++;
			edge[x][y]=edge[y][x]=true;
		}
		int root=0;
		for(i=1;i<=n;i++)
		{
			if(deg[i]==n-1)
			{
				root=i;
				break;
			}
		}
		if(root==0||(root==1&&ori[root]==1))
		{
			for(i=1;i<=n;i++)
			{
				printf("%d ",i);
			}
			printf("\n");
			continue;
		}
		else
		{
			int num=ori[root];
			for(i=1;i<=n;i++)//num
			{
				for(j=1;j<=n;j++)//where
				{
					if(edge[ori[i]][root]&&edge[root][j]&&(ori[i]!=root))
					{
						edge[ori[i]][root]=edge[root][ori[i]]=false;
						edge[root][j]=edge[j][root]=false;
						aft[i]=j;aft[num]=ori[i];num=ori[j];
					}
				}
			}
			aft[root]=num;
			for(i=1;i<=n;i++)
			{
				printf("%d ",aft[i]);
			}
			printf("\n");
		}
	}
	return 0;
}
