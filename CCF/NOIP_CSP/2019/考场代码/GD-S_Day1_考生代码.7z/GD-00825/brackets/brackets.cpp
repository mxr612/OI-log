#include<bits/stdc++.h>
using namespace std;
#define MAXN 500005
#define LL long long
int n;
char brac[MAXN];
int fa[MAXN];
vector<int>edge[MAXN];
struct Ins
{
	char ch;
	int id;
};
LL bac[MAXN];
LL dp[MAXN];
LL ans;
stack<Ins>sta;
void dfs(int x)
{
	int tp=0;
	Ins tmp,now;
	tmp.ch=brac[x];tmp.id=x;
	if(brac[x]=='(')
	{
		bac[x]=0;
		dp[x]=dp[fa[x]];
		sta.push(tmp);
		tp=1;
	}
	else
	{
		if(!sta.empty())
		{
			now=sta.top();sta.pop();
			bac[x]=bac[fa[now.id]]+1;
			dp[x]=dp[fa[x]]+1+bac[fa[now.id]];
			tp=2;
		}
		else
		{
			bac[x]=0;
			dp[x]=dp[fa[x]];
		}
	}
	int i;
	for(i=0;i<edge[x].size();i++)
	{
		int v=edge[x][i];
		if(v!=fa[x])
		{
			dfs(v);
		}
	}
	if(tp==1)
	{
		sta.pop();
	}
	else if(tp==2)
	{
		sta.push(now);
	}
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",brac+1);
	int i;
	bool ischain=true;
	for(i=2;i<=n;i++)
	{
		scanf("%d",&fa[i]);
		if(fa[i]!=i-1)
		{
			ischain=false;
		}
		edge[i].push_back(fa[i]);
		edge[fa[i]].push_back(i);
	}
	if(ischain)
	{
		for(i=1;i<=n;i++)
		{
			Ins tmp;
			tmp.ch=brac[i];tmp.id=i;
			if(brac[i]=='(')
			{
				sta.push(tmp);
				bac[i]=0;
				dp[i]=dp[i-1];
			}
			else
			{
				if(!sta.empty())
				{
					Ins now=sta.top();sta.pop();
					bac[i]=bac[now.id-1]+1;
					dp[i]=dp[i-1]+1+bac[now.id-1];
				}
				else
				{
					bac[i]=0;
					dp[i]=dp[i-1];
				}
			}
		}
	}
	else
	{
		dfs(1);
	}
	ans=dp[1];
	for(i=2;i<=n;i++)
	{
		ans^=i*dp[i];
	}
	printf("%lld",ans);
	return 0;
}
