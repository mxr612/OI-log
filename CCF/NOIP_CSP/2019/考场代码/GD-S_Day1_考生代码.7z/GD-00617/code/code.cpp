#include<cstdio>
using namespace std;
#define re register
#define in re int
#define il inline
#define rr read()
#define wr putchar('\n')
#define bl putchar(' ')
#define ll unsigned long long
#define int ll
il int read()
{
	re char ch;while((ch=getchar())<'0'||ch>'9');
	in x=ch^'0';while((ch=getchar())>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^'0');
	return x;
}
void fun(in n,in k)
{
	if(n<=1)
	{
		putchar('0'+k);
		return;
	}
	in o=1ll<<n-1;
	if(k>=o)putchar('1'),fun(n-1,(o<<1)-k-1);
	else putchar('0'),fun(n-1,k);
}
signed main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	in n=rr,k=rr;
	fun(n,k);
	return 0;
}
