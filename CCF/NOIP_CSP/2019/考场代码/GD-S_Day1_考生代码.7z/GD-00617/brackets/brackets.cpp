#include<cstdio>
using namespace std;
#define re register
#define in re int
#define il inline
#define rr read()
#define wr putchar('\n')
#define bl putchar(' ')
#define ll long long
#define int ll
il int read()
{
	re char ch;re bool f=1;while((ch=getchar())<'0'||ch>'9')(ch=='-')&&(f=0);
	in x=ch^'0';while((ch=getchar())>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^'0');
	return f?x:-x;
}
il void print(in x)
{
	if(x<0)x=-x,putchar('-');
	if(x>=10)print(x/10);
	putchar(x%10^'0');
}
#define mm 501
#define max(x,y) (x>y?x:y)
bool sign[mm];
struct edge{
	int nex,to;
}ma[mm];
int head[mm],al,dp[mm];
char ch[mm+2];
il void add(in x,in y){ma[++al].nex=head[x],ma[head[x]=al].to=y;}
void dfs(in u,in alsum,in allen)
{
	for(in i=head[u];i;i=ma[i].nex)
	{
		in v=ma[i].to;
		if(sign[v])dp[v]=dp[u],dfs(v,alsum+1,max(0,allen-1));
		else
		{
			if(alsum)dp[v]=max(dp[u],allen+1),dfs(v,alsum-1,allen+1);
			else dp[v]=dp[u],dfs(v,0,allen);
		}
	}
}
signed main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	in n=rr;scanf("%s",ch);
	for(in i=0;i<n;++i)sign[i+1]=(ch[i]=='(');
	for(in i=2;i<=n;++i)add(rr,i);
	dfs(1,sign[1],0);
	in tans=0;
	for(in i=1;i<=n;++i)tans^=i*dp[i];
	print(tans),wr;
	return 0;
}
