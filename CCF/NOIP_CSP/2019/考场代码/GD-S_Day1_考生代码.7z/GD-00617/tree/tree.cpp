#include<cstdio>
#include<algorithm>
using namespace std;
#define re register
#define in re int
#define il inline
#define rr read()
#define wr putchar('\n')
#define bl putchar(' ')
#define ll long long
//#define int ll
il int read()
{
	re char ch;re bool f=1;while((ch=getchar())<'0'||ch>'9')(ch=='-')&&(f=0);
	in x=ch^'0';while((ch=getchar())>='0'&&ch<='9')x=(x<<3)+(x<<1)+(ch^'0');
	return f?x:-x;
}
il void print(in x)
{
	if(x<0)x=-x,putchar('-');
	if(x>=10)print(x/10);
	putchar(x%10^'0');
}
#define mm 501
struct edge{
	int from,to;
}ma[mm];
int al,n,ans[mm],val[mm],idx[mm];
bool vis[mm];
il void add(in x,in y){ma[++al].from=x,ma[al].to=y;}
il bool cmp()
{
	for(in i=1;i<=n;++i)
		if(ans[i]>idx[i])return 1;
		else if(ans[i]<idx[i])return 0;
	return 0;
}
void dfs(in x)
{
	if(x>=n)
	{
		if(cmp())
			for(in i=1;i<=n;++i)ans[i]=idx[i];
		return;
	}
	for(in i=1;i<=al;++i)
		if(!vis[i])
		{
			idx[val[ma[i].from]]=ma[i].to;idx[val[ma[i].to]]=ma[i].from;
			swap(val[ma[i].from],val[ma[i].to]);
			vis[i]=1;
			dfs(x+1);
			vis[i]=0;
			idx[val[ma[i].from]]=ma[i].to;idx[val[ma[i].to]]=ma[i].from;
			swap(val[ma[i].from],val[ma[i].to]);
		}
}
signed main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	in Q=rr;
	while(Q--)
	{
		n=rr;al=0;
		for(in i=1;i<=n;++i)val[idx[i]=rr]=i,ans[i]=1e9,vis[i]=0;
		for(in i=1;i<n;++i)
		{
			in x=rr,y=rr;
			add(x,y);
		}
		dfs(1);
		for(in i=1;i<=n;++i)print(ans[i]),bl;
		wr;
	}
	return 0;
}

