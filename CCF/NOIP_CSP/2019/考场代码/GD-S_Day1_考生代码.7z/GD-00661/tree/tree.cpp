#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define rep(i,a,b) for(int i=(a);i<=(b);++i)

const int N=2e3+10;
int n;
int u[N],v[N];
int a[N],p[N],ans[N];
int bz[N];

int deg[N];
bool f[N],g[N];

void dfs(int t){
	if(t==n){
		rep(i,1,n)
			p[a[i]]=i;
			
		bool less=0;
		rep(i,1,n){
			if(p[i]<ans[i]){less=1;break;}
			if(p[i]>ans[i]){less=0;break;}
		}
		
		if(less)
			memcpy(ans,p,sizeof ans);
		
		return;
	}
	
	rep(i,1,n-1){
		if(!bz[i]){
			bz[i]=1;
			swap(a[u[i]],a[v[i]]);
			dfs(t+1);
			swap(a[u[i]],a[v[i]]);
			bz[i]=0;
		}
	}
}

int getrank(int x){
	int res=0;
	rep(i,1,x)res+=f[i];
	return res;
}

int getslct(int x){
	int i=0;
	while(x)
		x-=g[++i];
	return i;
}
int main(){
	freopen("tree.in","r",stdin),freopen("tree.out","w",stdout);
	int Case;
	for(scanf("%d",&Case);Case--;){
		scanf("%d",&n);
		rep(i,1,n)
			scanf("%d",p+i),a[p[i]]=i;
			
		rep(i,1,n-1)
			scanf("%d%d",u+i,v+i);
			
		if(n<=10){
			memset(bz,0,sizeof bz);
			ans[1]=n+1;
			dfs(1);
		
			rep(i,1,n)
				printf("%d ",ans[i]);
			puts("");
			
			continue;
		}
		
		memset(deg,0,sizeof deg);
		rep(i,1,n-1)
			++deg[u[i]],++deg[v[i]];
			
		int rt=0;
		rep(i,1,n)
			if(deg[i]==n-1)
				rt=i;
		
		memset(f,1,sizeof f);//val
		memset(g,1,sizeof g);//dot
		rep(i,1,n-1){
			int rk=getrank(a[rt]);
			int x=getslct(rk);
			
			if(x==rt){
				++x;
				while(!g[x])++x;
			}
			
			swap(a[rt],a[x]);
			p[a[rt]]=rt;
			p[a[x]]=x;
			
			f[rk]=0;
			g[x]=0;
		}
		
		rep(i,1,n)
			printf("%d ",p[i]);
		puts("");
	}
	
	return 0;
}
/*
const int N=2e3+5;
int n;
bool uni[N][N];
int a[N],p[N];
int tot,st[N],nex[N+N],to[N+N];
bool Cut[N][N],used[N];
int fa[N],dep[N];
int d[N],q[N];
int sx[N],sy[N];

void link(int x,int y){
	nex[++tot]=st[x],st[x]=tot,to[tot]=y;
}

void prepare(int v,int fat){
	fa[v]=fat;
	dep[v]=dep[fat]+1;
	
	for(int k=st[v];k;k=nex[k])
		if(to[k]-fat)
			prepare(to[k],v);
}

int lca(int x,int y){
	if(dep[x]<dep[y])
		swap(x,y);
	while(dep[x]>dep[y])
		x=fa[x];
	while(x-y)
		x=fa[x],y=fa[y];
	return x;
}

void getuni(int x){
	int h=1,t=1;
	memset(uni[x],0,sizeof uni[x]);
	uni[x][x]=1;
	q[1]=x;
	
	for(;h<=t;++h)
		for(int k=st[q[h]];k;k=nex[k])
			if(!Cut[q[h]][to[k]]&&!uni[x][to[k]]){
				uni[x][to[k]]=1;
				q[++t]=to[k];
			}
}

void cutedge(int x,int y){
	Cut[y][x]=1;
	getuni(x);
	sx[0]=0;
	rep(i,1,n)
		if(uni[x][i])
			sx[++sx[0]]=i;
			
	getuni(y);
	
	rep(i,1,sx[0]){
		int u=sx[i];
		if(uni[x][u]&&!uni[y][u])
			rep(j,1,sx[0]){
				int v=sx[j];
				if(uni[x][v]&&uni[y][v])
					uni[v][u]=0;
			}
	}
}

int main(){
	freopen("tree.in","r",stdin),freopen("tree.out","w",stdout);
	
	int Case;
	for(scanf("%d",&Case);Case--;){
		scanf("%d",&n);
		memset(uni,1,sizeof uni);
		memset(Cut,0,sizeof Cut);
		rep(i,1,n){
			scanf("%d",a+i);
			p[a[i]]=i;
		}
		
		tot=0;
		memset(st,0,sizeof st);
		memset(nex,0,sizeof nex);
		memset(to,0,sizeof to);
		
		rep(i,1,n-1){
			int x,y;
			scanf("%d%d",&x,&y);
			link(x,y),link(y,x);
		}
		
		prepare(1,0);
		
		memset(used,0,sizeof used);
		rep(i,1,n-1){
			int y=n+1;
			int u=p[i];
			
			rep(j,1,n)
				if(!used[j]&&uni[u][j]&&j<y)
					y=j;
			used[y]=1;
			int z=lca(u,y);
			
			d[0]=0;
			for(int x=u;x!=z;x=fa[x])
				d[++d[0]]=x;
				
			d[++d[0]]=z;
			
			for(int x=y;x!=z;x=fa[x])
				++d[0];
			int t=d[0];
			for(int x=y;x!=z;x=fa[x])
				d[t--]=x;
				
			rep(j,1,d[0]-2)
				cutedge(d[j],d[j+1]);
					
			p[i]=y;
		}
		
		rep(i,1,n)
			printf("%d ",p[i]);
		puts("");
	}
}*/
