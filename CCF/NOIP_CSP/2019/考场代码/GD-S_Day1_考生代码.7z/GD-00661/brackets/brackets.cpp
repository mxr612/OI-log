#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define rep(i,a,b) for(int i=(a);i<=(b);++i)

const int N=5e5+10;
int n,mov=5e5;
char s[N];
int a[N];
int fa,st[N],nex[N],to[N];
int cnt[N+N];
ll ans[N],sum;

void link(int x,int y){
	static int t;
	nex[++t]=st[x],st[x]=t,to[t]=y;
}

void dfs(int v){
	int mmr;
	
	if(a[v]){
		--mov;
		++cnt[mov+1];
	}else{
		mmr=cnt[mov];
		cnt[mov]=0;
		++mov;
		ans[v]+=cnt[mov];
	}
	
	for(int k=st[v];k;k=nex[k]){
		ans[to[k]]+=ans[v];
		dfs(to[k]);
	}
	
	if(a[v]){
		++mov;
		--cnt[mov];
	}
	else{
		--mov;
		cnt[mov]=mmr;
	}
}

int main(){
	freopen("brackets.in","r",stdin),freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",s+1);
	rep(i,1,n)
		a[i]=(s[i]=='(');
	rep(i,2,n){
		scanf("%d",&fa);
		link(fa,i);
	}
	
	dfs(1);
	
	rep(i,1,n)sum^=ans[i]*i;
	printf("%lld",sum);
	return 0;
}
