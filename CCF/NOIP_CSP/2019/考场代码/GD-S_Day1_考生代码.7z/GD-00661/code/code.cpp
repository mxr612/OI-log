#include<bits/stdc++.h>
using namespace std;
#define rep(i,a,b) for(int i=(a);i<=(b);++i)

typedef unsigned long long Ull;
const int N=70;
const Ull one=1;
int n;
Ull k;
int a[N];

int main(){
	freopen("code.in","r",stdin),freopen("code.out","w",stdout);
	cin>>n>>k;
	rep(i,0,n-1)
		a[i]=(k&(one<<i))>>i;
	
	rep(i,0,n-2)
		if(a[i+1])
			a[i]=1-a[i];
	
	for(int i=n-1;i>=0;--i)
		cout<<a[i];
	return 0;
}
