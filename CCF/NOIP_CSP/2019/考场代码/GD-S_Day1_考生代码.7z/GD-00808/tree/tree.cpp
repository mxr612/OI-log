#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn = 2010;
int t, n;
int pos[maxn];  // num's pos
int num[maxn];  // pos's num
bool e[maxn][maxn];
int fa[maxn];









void build(int x)
{
	for(int i=1; i<=n; ++i)
	{
		if(e[x][i]) 
		{
			e[x][i] = e[i][x] = 0;
			fa[i] = x;
			build(i);
		}
	}
}




int main()
{
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	scanf("%d", &t);
	while(t--)
	{
		memset(e, 0, sizeof(e));
		memset(pos, 0, sizeof(pos));
		scanf("%d", &n);
		for(int i=1; i<=n; ++i)
		{
			scanf("%d", &pos[i]);
			num[pos[i]] = i;
		}
		for(int i=1, x, y; i<n; ++i)
		{
			scanf("%d %d", &x, &y);
			e[x][y] = e[y][x] = 1;
		}
		build(1);
		
		
		for(int i=1; i<=n; ++i)  //number
		{
			for(int j=1; j<pos[i]; ++j)  //jiedian
			{
				if(e[pos[i]][j] && num[j]>i)
				{
					int tmpposi = pos[i];
					int tmpnumj = num[j];
					pos[i] = j;
					num[j] = i;
					
					num[tmpposi] = tmpnumj;
					pos[tmpnumj] = tmpposi;
					
					e[pos[i]][j] = e[j][pos[i]] = 0;
				}
			}
			
		}
		
		
		for(int i=1; i<=n; ++i)
		{
			printf("%d ", pos[i]);
		}
		
		printf("\n");
		
		
		
		
		
	}
}
