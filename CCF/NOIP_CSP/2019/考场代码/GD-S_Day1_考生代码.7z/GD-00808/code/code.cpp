#include<cstdio>
#include<iostream>
using namespace std;

long long n, k;






void getcode(long long x, long long y, long long dir)  //1 shun   2 ni
{
	if(dir==2)
	{
		getcode(x, (1ll<<x)-1-y, 1);
		return ;
	}
	
	
	if(x==1)
	{
		if(y==0) printf("0");
		else printf("1");
		return;
	}
	
	
	if(y>(1ll<<(x-1))-1)
	{
		printf("1");
		y-=(1ll<<(x-1));
		getcode(x-1, y, 2);
	}
	
	else
	{
		printf("0");
		getcode(x-1, y, 1);
	}
	
	
}
int main()
{
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	scanf("%lld%lld", &n, &k);//	n = 64;
//	k = (1<<63)+362;
	getcode(n, k, 1);
	return 0;
}

