#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<vector>
#include<stack>
using namespace std;
const long long maxn = 5e5+10;
long long n;

bool tree[maxn];
vector <int> son[maxn];
long long fa[maxn];
stack <int> s;

bool num[maxn];
long long top;

void printnum(long long l, long long r)
{
	for(long long i=r; i>=l; --i)
	{
		printf("%lld", num[i]);
	}
}


void printtree()
{
	for(long long i=1; i<=n; ++i)
	{
		printf("%lld", tree[i]);
	}
}


long long getnum(long long x)
{
//	printf("firx  %lld\n", x);
	long long firx = x;
	top = 0;
	long long cnt = 0;
	while(!s.empty()) s.pop();
	memset(num, 0, sizeof(num));
	for(x; x>0; x = fa[x])
	{
		num[++top] = tree[x];
	}
	
//	printnum();
//	printf("\n");
//	printf("%lld\n", top);
	for(long long i=1; i<=top; ++i)
	{
		if(num[i]==0) continue;
		for(long long j=i+1; j<=top; ++j)
		{
			if(num[j]==1) continue;
//			printnum(i, j);
//			printf("\n");
			while(!s.empty()) s.pop();
			for(long long k=j; k>=i; --k)
			{
				if(num[k]==0)
				{
					s.push(0);
					continue;
				}
				else if(num[k]==1)
				{
					if(!s.empty() && s.top()==0)
					{
						s.pop();
						continue;
					}
					else 
					{
						s.push(1);
						break;
					}
				}
				
			}
//			printf("cnt  %lld\n", cnt);
			if(s.empty()) ++cnt;
		}
	}
	return cnt;
}




int main()
{
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	scanf("%lld", &n);
//	n = 2000;
	char a;
	for(long long i=1; i<=n; ++i)
	{
		scanf(" %c", &a);
//		if(i==0) a='(';
//		else a = ')';
		
		
		if(a=='(') tree[i] = 0;
		else tree[i] = 1;
	}
	for(long long i=2; i<=n; ++i)
	{
		scanf("%lld", &fa[i]);
//		fa[i] = i-1;
		son[fa[i]].push_back(i);
	}
//	printtree();
	
	
	
	long long ans = 0;
	for(long long i=1; i<=n; ++i)
	{
		ans ^= getnum(i)*i;
	}
	printf("%lld", ans);
	return 0;
	
	
}
