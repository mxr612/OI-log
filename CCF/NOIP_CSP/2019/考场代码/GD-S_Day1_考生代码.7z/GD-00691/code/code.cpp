#include<cstdio>
#define ull unsigned long long
using namespace std;
void gr(int n,ull k)
{
  if (!n)return ;
  if (k>=(1ull<<(n-1))){
    putchar('1');
    gr(n-1,(1ull<<(n-1))-(k&((1ull<<(n-1))-1))-1);
  }else {
    putchar('0');
    gr(n-1,k);
  }
}
int n; ull k;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%llu",&n,&k);
	gr(n,k);
  return 0;
}
