#include<cstdio>
#include<vector>
#define ll long long
#define MaxN 500500
using namespace std;
inline int read()
{
  int X=0;
  char ch=getchar();
  while(ch<'0'||'9'<ch)ch=getchar();
  while('0'<=ch&&ch<='9')
    X=X*10+(ch^48),ch=getchar();
  return X;
}
vector<int> g[MaxN];
char p[MaxN];
int c[MaxN];
struct Data
{int op,c;}sav[MaxN];
int n,top,tot;
ll ans;
void dfs(int u,ll s)
{
  int st=tot;
  if (p[u]==')'){
    if (top){
      sav[++tot]=(Data){1,c[top]};
      c[top]=0;
      s+=(++c[--top]);
    }else {
      sav[++tot]=(Data){2,c[0]};
      c[0]=0;
    }
  }else {
    ++top;
    sav[++tot]=(Data){0};
  }
  ans^=s*u;
  for (int i=0;i<g[u].size();i++)
    dfs(g[u][i],s);
  while(tot>st){
    if (sav[tot].op==0)top--;
    if (sav[tot].op==1){
      c[++top]=sav[tot].c;
      --c[top-1];
    }if (sav[tot].op==2)
      c[0]=sav[tot].c;
    tot--;
  }
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d%s",&n,p+1);
	for (int i=2;i<=n;i++)
	  g[read()].push_back(i);
	dfs(1,0);
	printf("%lld",ans);
  return 0;
}
