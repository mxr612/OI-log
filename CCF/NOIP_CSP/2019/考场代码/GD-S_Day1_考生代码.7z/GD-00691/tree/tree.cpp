#include<cstdio>
#include<vector>
#define MaxN 2050
using namespace std;
int n,f[MaxN],t[MaxN],p[MaxN],ans[MaxN],tp[MaxN];
bool vis[MaxN];
void dfs(int pos)
{
  if (pos==n){
    bool flag=0;
    for (int i=1;i<=n;i++)tp[p[i]]=i;
    for (int i=1;i<=n;i++)
      if (tp[i]<ans[i]){flag=1;break;}
      else if (tp[i]>ans[i])break;
    if (flag)
      for (int i=1;i<=n;i++)ans[i]=tp[i];
    return ;
  }
  for (int i=1;i<n;i++)
    if (!vis[i]){
      vis[i]=1;
      swap(p[f[i]],p[t[i]]);
      dfs(pos+1);
      swap(p[f[i]],p[t[i]]);
      vis[i]=0;
    }
}
void solve()
{
  scanf("%d",&n);
  for (int i=1,num;i<=n;i++){
    scanf("%d",&num);p[num]=i;
  }
  for (int i=1;i<n;i++)
    scanf("%d%d",&f[i],&t[i]);
  ans[1]=n+1;
  dfs(1);
  for (int i=1;i<=n;i++)
    printf("%d ",ans[i]);puts("");
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T;scanf("%d",&T);
	while(T--)solve();
  return 0;
}
