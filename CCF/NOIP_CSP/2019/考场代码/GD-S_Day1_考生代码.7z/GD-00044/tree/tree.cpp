#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#include<queue>
#include<stack>
using namespace std;
const int mxn=2010;
int I,i,j,k,x,y,z;
int T,m,n,p;
vector<int> a[mxn];
int b[mxn],rb[mxn];
queue<int> q;
bool used[mxn][mxn],vst[mxn];
bool stored[mxn];
int pth[mxn];
int ans[mxn];
stack<int> st;
int MIN(int x,int y){
	return x<y?x:y;
}
int MAX(int x,int y){
	return x<y?y:x;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	for(I=0;I<T;I++){
		memset(pth,0x00,sizeof(pth));
		memset(used,0x00,sizeof(used));
		memset(stored,0x00,sizeof(stored));
		scanf("%d",&n);
		for(i=1;i<=n;i++){
			scanf("%d",&b[i]);
			rb[b[i]]=i;
			a[i].clear();
		}
		for(i=1;i<n;i++){
			scanf("%d%d",&x,&y);
			a[x].push_back(y);
			a[y].push_back(x);
		}
		for(i=1;i<=n;i++){
			memset(vst,0x00,sizeof(vst));
			q.push(rb[i]);
			vst[rb[i]]=true;
			z=n+1;
			while(!q.empty()){
				x=q.front();
				z=MIN(z,x);
				q.pop();
				for(j=0;j<a[x].size();j++){
					y=a[x][j];
					if(!used[x][y]&&!vst[y]/*&&!stored[y]*/){
						vst[y]=true;
						q.push(y);
						pth[y]=x;
					}
				}
			}
			x=z;
			while(x!=rb[i]){
				st.push(x);
				used[pth[x]][x]=true;
				used[x][pth[x]]=true;
				x=pth[x];
			}
			while(!st.empty()){
				x=st.top();
				st.pop();
				rb[b[pth[x]]]=rb[b[x]];
				b[pth[x]]=b[x];
			}
			b[z]=i;
			rb[i]=z;
			//ans[i]=z;
			//stored[z]=true;
		}
		for(i=1;i<=n;i++){
			printf("%d ",rb[i]);
		}
		printf("\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
