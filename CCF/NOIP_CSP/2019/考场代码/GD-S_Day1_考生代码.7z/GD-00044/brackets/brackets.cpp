#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
using namespace std;
typedef long long ll;
const ll mxn=500010,mxlbn=21;
ll i,j,k,x,y,z;
ll m,n,p;
vector<int> a[mxn];
int lb[mxn];
int prnt[mxn][mxlbn];
char b[mxn];
ll f[mxn],s[mxn];
int lvl[mxn];
int g[mxn][mxlbn];
int nxt[mxn];
ll MIN(ll x,ll y){
	return x<y?x:y;
}
ll MAX(ll x,ll y){
	return x<y?y:x;
}
void dfsa(int o,int lvl){
	int i,ox,oy;
	::lvl[o]=lvl;
	g[o][0]=lvl;
	ox=o;
	for(i=1;i<=lb[n];i++){
		ox=prnt[o][i-1];
		prnt[o][i]=prnt[ox][i-1];
		g[o][i]=MIN(g[o][i-1],g[ox][i-1]);
		//printf("<>%d %d\n",g[o][i],::lvl[prnt[o][i]]);
	}
	if(b[o]=='('){
		f[o]=f[prnt[o][0]];
		ox=o;
		for(i=lb[n];i>=0;i--){
			if(g[ox][i]>lvl){
				ox=prnt[ox][i];
			}
		}
		s[o]=s[ox]+1;
		for(i=0;i<a[o].size();i++){
			ox=a[o][i];
			nxt[o]=ox;
			dfsa(ox,lvl+1);
		}
		return;
	}
	ox=o;
	oy=o;
	for(i=lb[n];i>=0;i--){
		if(g[ox][i]>=lvl-1){
			ox=prnt[ox][i];
		}
		if(g[oy][i]>=lvl){
			oy=prnt[oy][i];
		}
	}
	ox=nxt[ox];
	//printf("<>%d [%d %d] %lld %lld\n",lvl,::lvl[ox],::lvl[oy],s[ox],s[oy]);
	f[o]=f[prnt[o][0]]+((::lvl[oy]==lvl-1)?((::lvl[ox]==lvl-1)?s[oy]-s[ox]+1:s[oy]):0);
	for(i=0;i<a[o].size();i++){
		ox=a[o][i];
		nxt[o]=ox;
		dfsa(ox,lvl-1);
	}
	return;
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%lld",&n);
	scanf("%s",b+1);
	lb[0]=-1;
	lb[1]=0;
	for(i=2;i<=n;i++){
		scanf("%lld",&x);
		a[x].push_back(i);
		prnt[i][0]=x;
		lb[i]=lb[i>>1]+1;
	}
	lvl[0]=-2*n;
	f[0]=0;
	nxt[0]=1;
	dfsa(1,1);
	x=0;
	for(i=1;i<=n;i++){
		x^=i*f[i];
		//printf("<>%lld %lld\n",i,f[i]);
	}
	printf("%lld\n",x);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
