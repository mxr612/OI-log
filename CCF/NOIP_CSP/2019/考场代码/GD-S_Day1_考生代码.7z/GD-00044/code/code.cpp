#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef unsigned long long llu;
typedef long long ll;
ll i,j,k,x,y,z;
llu m,n,p;
llu work(llu x,llu y){
	if(!y){
		return 0;
	}
	if(x<(1llu<<y-1)){
		return work(x,y-1);
	}
	return 1llu<<y-1|work((1llu<<y)-1-x,y-1);
}
int main(){
	scanf("%llu%llu",&m,&n);
	x=work(n,m);
	for(i=m-1;i>=0;i--){
		printf("%d",(x&1llu<<(llu)i)?1:0);
	}
	printf("\n");
	return 0;
}
