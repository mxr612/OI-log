#include<iostream>
#include<cstdio>
using namespace std;
long long sum[500010],ans;
int a[2010],b[2010],c[2010],minn[2010],n;
int e[2000010],nxt[2000010],head[500010],cnt;
void add(int x,int y){
	cnt++;
	e[cnt]=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
void dfs(int x,int t,int fa){
	//cout<<x<<" "<<t<<" "<<fa<<endl;
	c[t]=x;
	b[x]=b[fa]+a[x];
	minn[t]=2e9;
	for(int i=t-1;i>=0;i--){
		if(b[c[i]]==b[x]) sum[x]++;//,cout<<c[i]<<" "<<i<<endl;
		minn[i]=min(minn[i+1],b[c[i]]);
		if(minn[i]-b[x]<0) break;
	}
	for(int i=head[x];i;i=nxt[i])
	if(e[i]!=fa){
		int y=e[i];
		sum[y]+=sum[x];
		dfs(y,t+1,x);
	}
}
int main(){
	int x;
	char ch;
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		cin>>ch;
		if(ch=='(') a[i]=1;
		else a[i]=-1;
	}
	for(int i=2;i<=n;i++){
		scanf("%d",&x);
		add(x,i),add(i,x);
	}
	b[0]=0;//cout<<"sdsa"<<endl;
	dfs(1,1,0);//cout<<"ssk"<<endl;
	for(int i=1;i<=n;i++)
	ans^=(i*sum[i]);//,cout<<sum[i]<<" ";cout<<endl;
	printf("%lld",ans);
}
/*
10
()()((()))
1 2 1 3 3 2 5 4 7
*/
