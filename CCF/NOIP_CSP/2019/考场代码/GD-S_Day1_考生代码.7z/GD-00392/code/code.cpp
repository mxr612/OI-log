#include<iostream>
#include<cstdio>
using namespace std;
unsigned long long k;
int n,ans[110];
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	int sta=1;
	scanf("%d%llu",&n,&k); 
	for(int i=n-1;i>=0;i--){
		if(k>=(1ll<<i)){
			ans[i]=sta;
			k-=(1ll<<i);
		}
		else ans[i]=sta^1;
		if(ans[i]) sta^=1;
	}
	for(int i=n-1;i>=0;i--)
	printf("%d",ans[i]);
}
