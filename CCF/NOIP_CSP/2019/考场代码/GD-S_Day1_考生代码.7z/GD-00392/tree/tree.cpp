#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
bool vis[2010],no=1;
int n,a[2010],b[2010],c[2010],eg[2010][2],ans[2010];
int d[2010],rt,nt[2010],dep[2010],pre[2010];
int e[4010],nxt[4010],head[2010],cnt;
bool check(){
	for(int i=1;i<=n;i++){
		if(b[i]>ans[i]) return false;
		if(b[i]<ans[i]) return true;
	}
	return false;
}
void dfs(int t){
	if(t>=n){
		for(int i=1;i<=n;i++)
		b[i]=a[i];
		for(int i=1;i<n;i++)
		swap(b[eg[c[i]][0]],b[eg[c[i]][1]]);
		if(no==1||check()){
			no=0;
			for(int i=1;i<=n;i++)
			ans[i]=b[i];
		}
		return;
	}
	for(int i=1;i<n;i++)
	if(vis[i]==0){
		vis[i]=1;
		c[t]=i;
		dfs(t+1);
		vis[i]=0;
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int t,x,y;
	scanf("%d",&t);
	while(t--){
		no=1;
		scanf("%d",&n);
		memset(ans,0,sizeof(ans));
		memset(vis,0,sizeof(vis));
		memset(d,0,sizeof(d));
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
		}
		for(int i=1;i<n;i++){
			scanf("%d%d",&x,&y);
			eg[i][0]=x;
			eg[i][1]=y;
		}
		dfs(1);
		for(int i=1;i<=n;i++)
		printf("%d ",ans[i]);
		printf("\n");
	}
}
/*
1 
5
4 3 5 2 1
2 3
3 4
4 5
5 1
*/
/*
1 
4
4 1 2 3
2 4
2 1
3 2
*/
