#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define maxn 2000
using namespace std;
int T,n;
int xx[maxn+5],yy[maxn+5];

struct edge {
	int from;
	int to;
	int next;
} E[maxn*2+5];
int head[maxn+5];
int sz=0;
void add_edge(int u,int v) {
	sz++;
	E[sz].from=u;
	E[sz].to=v;
	E[sz].next=head[u];
	head[u]=sz;
}

int a[maxn+5];

int is_flower(){
	static int deg[maxn+5];
	for(int i=1;i<n;i++){
		deg[xx[i]]++;
		deg[yy[i]]++;
	}
	for(int i=1;i<=n;i++) if(deg[i]==n-1) return i;
	return 0;
}

namespace flower{
	bool vis[maxn+5];
	int posv[maxn+5];
	void solve(int root){
		for(int i=1;i<=n;i++) posv[a[i]]=i;
		for(int i=1;i<=n;i++) vis[i]=0;
		for(int i=1;i<=n;i++){
			int to=0;
			for(int j=1;j<=posv[i];j++){
				if(!vis[j]||j==root){
					to=j;
					break;
				}
			}
			if(to==root){
				swap(posv[i],posv[a[to]]);
				vis[to]=1;
			}else{
				swap(posv[i],posv[a[root]]);
				swap(posv[a[root]],posv[a[to]]);
				vis[posv[i]]=vis[to]=1;
			}
		}
		for(int i=1;i<=n;i++){
			printf("%d ",posv[i]);
		}
		printf("\n");
	}
}
int deep[maxn+5];
void dfs(int x,int fa){
	deep[x]=deep[fa]+1;
	for(int i=head[x];i;i=E[i].next){
		int y=E[i].to;
		if(y!=fa){
			dfs(y,x);
		}
	}
}
int is_chain(){
	static int deg[maxn+5];
	for(int i=1;i<n;i++){
		deg[xx[i]]++;
		deg[yy[i]]++;
	}
	for(int i=1;i<=n;i++){
		if(deg[i]==1){
			dfs(i,0);
			for(int j=1;j<=n;j++){
				if(deep[j]==n) return i;
			}
			break;
		}
	}
	return 0;
}

namespace chain{
	int posv[maxn+5];
	void solve(int root){
		root++;
		root--;
		for(int i=1;i<=n;i++) posv[a[i]]=i;
		for(int i=1;i<=n;i++){
			printf("%d ",posv[i]);
		}
		printf("\n");
	}
}
namespace brute_force {
	int tmp[maxn+5];
	int id[maxn+5];
	int ans[maxn+5],now[maxn+5];
	void calc() {
		for(int i=1; i<=n; i++) {
			tmp[i]=a[i];
			now[i]=0;
		}
		for(int i=1; i<n; i++) {
			int x=xx[id[i]],y=yy[id[i]];
			swap(tmp[x],tmp[y]);
		}
		for(int i=1; i<=n; i++) now[tmp[i]]=i;
	}
	bool is_small(int *a,int *b,int n) {
		for(int i=1; i<=n; i++) {
			if(a[i]<b[i]) return 1;
			else if(a[i]>b[i]) return 0;
		}
		return 0;
	}
	void solve(){
		for(int i=1; i<=n; i++) ans[i]=n-i+1;
		for(int i=1; i<n; i++) id[i]=i;
		do {
			calc();
			if(is_small(now,ans,n)) {
				for(int i=1; i<=n; i++) ans[i]=now[i];
			}
		} while(next_permutation(id+1,id+1+n-1));
		for(int i=1; i<=n; i++) printf("%d ",ans[i]);
		printf("\n");
	}
}


void ini() {
	for(int i=1; i<=n; i++) head[i]=0;
	sz=0;
}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int x;
	scanf("%d",&T);
	while(T--) {
		scanf("%d",&n);
		ini();
		for(int i=1; i<=n; i++) {
			scanf("%d",&x);
			a[x]=i;
		}
		for(int i=1; i<n; i++) {
			scanf("%d %d",&xx[i],&yy[i]);
			add_edge(xx[i],yy[i]);
			add_edge(yy[i],xx[i]);
		}
//		flower::solve(1);
		if(n<=10) brute_force::solve();
		else{
			int tmp1=is_flower(),tmp2=is_chain();
			if(tmp1) flower::solve(tmp1);
			else if(tmp2) chain::solve(tmp2);
			else brute_force::solve();
//			if(is_flower()) flower::solve();
//			else if(is_chain()) chain::solve();
//			else brute_force::solve();
		}
	}
}
/*
1
5
1 2 5 3 4
1 2
1 3
1 4
1 5
*/
