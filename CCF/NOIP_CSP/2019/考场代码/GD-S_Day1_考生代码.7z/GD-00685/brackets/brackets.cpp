#include<iostream>
#include<cstdio>
#include<cstring>
#define maxn 500000
using namespace std;
typedef long long ll;
struct edge {
	int from;
	int to;
	int next;
} E[maxn*2+5];
int esz=1;
int head[maxn+5];
void add_edge(int u,int v) {
	esz++;
	E[esz].from=u;
	E[esz].to=v;
	E[esz].next=head[u];
	head[u]=esz;
}


char a[maxn+5];
int deep[maxn+5];
int top=0;
int stk[maxn+5];
ll dp[maxn+5];


ll ans[maxn+5];
void dfs1(int x,int fa) {
	deep[x]=deep[fa]+1;
	bool flag=false;
	int l;
	if(a[x]=='(') stk[++top]=deep[x];
	else {
		if(top>0) {
			l=stk[top];
			top--;
			dp[deep[x]]=dp[l-1]+1;
			flag=true;
		}
	}
	ans[x]=dp[deep[x]];
	for(int i=head[x]; i; i=E[i].next) {
		int y=E[i].to;
		if(y!=fa) {
			dfs1(y,x);
		}
	}
	if(flag){
		stk[++top]=l;
		dp[deep[x]]=0;
	}else if(a[x]=='('){
		top--;
	}
}

ll res=0;
void dfs2(int x,int fa) {
	ans[x]+=ans[fa];
	res^=ans[x]*x;
	for(int i=head[x]; i; i=E[i].next) {
		int y=E[i].to;
		if(y!=fa) {
			dfs2(y,x);
		}
	}
}

int n;
int main() {
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int f;
	scanf("%d",&n);
	scanf("%s",a+1);
	for(int i=2; i<=n; i++) {
		scanf("%d",&f);
		add_edge(f,i);
		add_edge(i,f);
	}
	dfs1(1,0);
	dfs2(1,0);
	printf("%lld\n",res);
}
/*
5
(()()
1 1 2 2
*/
