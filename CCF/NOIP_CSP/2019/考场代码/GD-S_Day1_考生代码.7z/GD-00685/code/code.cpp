#include<iostream>
#include<cstdio>
#include<cstring>
#define maxn 64
using namespace std;
typedef unsigned long long ll;
int n;
ll k;
ll pow2[maxn+5];
string solve(int n,ll k){
	if(n==1){
		if(k==0) return "0";
		else return "1";
	}else{
		if(k>=pow2[n-1]){
			string x=solve(n-1,pow2[n-1]-1-(k%pow2[n-1]));
			x="1"+x;
			return x;
		}else{
			string x=solve(n-1,k);
			x="0"+x;
			return x;
		}
	}
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	pow2[0]=1;
	for(int i=1;i<=63;i++) pow2[i]=pow2[i-1]*2;
	cin>>n>>k;
	string ans=solve(n,k);
	cout<<ans;
}
