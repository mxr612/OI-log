#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cmath>
using namespace std;

int n;
unsigned long long m,k;

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	m=pow(2,n);
	while(m>1)
	{
		if(k>m/2-1)
		{
			printf("1");
			k=m-1-k;
		}
		else printf("0");
		m/=2;
	}
	return 0;
}
