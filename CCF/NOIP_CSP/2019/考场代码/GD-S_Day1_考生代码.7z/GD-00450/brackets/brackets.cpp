#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<queue>
using namespace std;

const int maxn=500005;

struct EDGE
{
	int tar,nex;
}edge[maxn];

bool kh[maxn];
int n,fa[maxn],head[maxn];
int vis[maxn],lef[maxn],cur=0;
int malef[maxn],lavis[maxn];
long long f[maxn],ans=0;
queue<int> q;
string st;

void addedge(int x,int y)
{
	cur++;
	edge[cur].tar=y;
	edge[cur].nex=head[x];
	head[x]=cur;
}

void bfs()
{
	if(kh[1]==0) lef[1]=1;
	q.push(1);
	int root;
	while(!q.empty())
	{
		root=q.front();
		q.pop();
		for(int i=head[root];i!=0;i=edge[i].nex)
		{
			int t=edge[i].tar;
			if(kh[t]==0)
			{
				lef[t]=lef[root]+1;
				vis[t]=vis[root];
				f[t]=f[root];
			}
			else
			{
				lef[t]=0;
				if(lef[root])
				{
					malef[t]=lef[root]-1;
					lavis[t]=vis[root];
					if(lef[root]==1) vis[t]=vis[root]+1;
					else vis[t]=1;
					f[t]=f[root]+vis[t];
				}
				else
				{
					if(malef[root])
					{
						malef[t]=malef[root]-1;
						if(malef[t]==0) vis[t]=lavis[root]+1;
						else vis[t]=1,lavis[t]=lavis[root];
						f[t]=f[root]+vis[t];
					}
					else
					{
						vis[t]=0;
						f[t]=f[root];
					}
				}
				
			}
			q.push(t);
		}
	}
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	memset(kh,0,sizeof kh);
	memset(head,0,sizeof head);
	memset(vis,0,sizeof vis);
	memset(lavis,0,sizeof lavis);
	memset(lef,0,sizeof lef);
	memset(malef,0,sizeof malef);
	memset(f,0,sizeof f);
	scanf("%d",&n);
	cin>>st;
	for(int i=0;i<st.size();i++)
	{
		if(st[i]=='(') kh[i+1]=0;
		else kh[i+1]=1;
	}
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&fa[i]);
		addedge(fa[i],i);
	}
	bfs();
	long long tmp;
	for(int i=1;i<=n;i++)
	{
		tmp=i*f[i];
		ans=ans^tmp;
	}
	printf("%lld",ans);
	return 0;
}
