#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const int N=2001;
int T,v[N],a[N][3],g[N],n,cut[N];
string ans;
bool use[N][N];
void dfs(int now)
{
	if(now>=n)
	{
		string ts;
		for(int i=1;i<=n;i++)
			ts+=v[i]+48,ts+=' ';
		if(ts<ans)	
			ans=ts;
		return;	
	}
	for(int i=1;i<n;i++)
	{
		if(!cut[i])
		{
			swap(v[a[i][0]],v[a[i][2]]);
			cut[i]=1;
			dfs(now+1);	
			swap(v[a[i][0]],v[a[i][2]]);
			cut[i]=0;
		}		
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>T;
	while(T--)
	{
		memset(v,0,sizeof(v));
		memset(a,0,sizeof(a));
		memset(g,0,sizeof(g));
		memset(cut,0,sizeof(cut));
		memset(use,0,sizeof(use));
		for(int i=1;i<=n;i++)
			ans+='z';
		v[0]=1e9;
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			int t;
			scanf("%d",&t);
			v[t]=i;
		}
		for(int i=1;i<n;i++)
		{
			int x,y;
			scanf("%d%d",&x,&y);
			a[i][0]=y;
			a[i][2]=x;
			a[i][1]=g[x];
			g[x]=i;
		}
		if(n<50)
		{
			dfs(1);
			cout<<ans<<endl;	
		}
		else
		{
			for(int i=1;i<=n;i++)
			{
				int mi=0;
				for(int j=g[i];j>0;j=a[j][1])
					if(!use[a[j][0]][i]&&v[a[j][0]]<v[mi])
						mi=a[j][0];
				if(mi==0)
					continue;		
				use[a[mi][0]][i]=use[i][a[mi][0]]=1;
				int t=v[mi];
				v[mi]=v[i];
				v[i]=t;		
			}
			for(int i=1;i<=n;i++)
				cout<<v[i]<<" ";	
			cout<<endl;	
		}
		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
