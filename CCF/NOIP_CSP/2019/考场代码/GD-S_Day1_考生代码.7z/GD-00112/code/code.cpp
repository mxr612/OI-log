#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
unsigned long long n,k;
string s; 
void dfs(unsigned long long now,unsigned long long c)
{
	if(now<=1&&c==1)
	{
		s+=now+48;
		return;
	}
	if(now>=c)
	{
		long long tc=now-c;
		dfs(c-tc-1,c/2);
		s="1"+s;
	}
	else
	{
		dfs(now,c/2);
		s="0"+s;
	}
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	unsigned long long t=1;
	cin>>n>>k;
	for(int i=1;i<n;i++)
		t*=2;		
	dfs(k,t);
	cout<<s;
	fclose(stdin);
	fclose(stdout);	
	return 0;
}
