#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const int N=1000000;
int fa[N],v[N],n,st[N],ans;
int fread()
{
	int x=0;
	char ch=getchar();
	while(ch<'0'||ch>'9')
		ch=getchar();
	while(ch>='0'&&ch<='9')
	{
		x=(x<<1)+(x<<3)+(ch^48);
		ch=getchar();
	}
	return x;	
}
char fch()
{
	char ch=getchar();
	while(ch!='('&&ch!=')')
		ch=getchar();
	return ch;	
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		char ch=fch();
		if(ch=='(')
			v[i]=-1;
		else
			v[i]=0;	
	} 
	for(int i=2;i<=n;i++)
		fa[i]=fread();
	for(int i=2;i<=n;i++)
	{
		int now=i,t=0,s=0;
		memset(st,0,sizeof(st));
		while(now>0)
		{
			t++;
			int j=t-1;
			st[t]=v[now];
			if(st[t]==-1&&t>1)
			{
				int ts=0;
				while(st[j]>-1&&j>0)
				{
					if(st[j]==0&&st[t]==-1)
					{
						t=j;
						st[t]=1;
						ts++;
					}
					else if(st[j]==1&&st[t]==1)	
						ts++;
					if(st[t]==1&&st[j]!=1)
						break;	
					j--;	
				}
				if(st[t]==1)
					s+=ts;	
			}
			now=fa[now];
		}
		ans=ans^(i*s);
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
