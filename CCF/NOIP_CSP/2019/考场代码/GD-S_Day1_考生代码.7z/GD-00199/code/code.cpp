#include<iostream>
#include<cstdio>
using namespace std;

#define ll long long


int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	int n;ll k;
	scanf("%d%lld",&n,&k);
	for(int i=n-1;i>=0;i--)
		if(k&(1ll<<i)){
			printf("1");
			k-=(1ll<<i);
			if(i>0)k=((1ll<<i)-1)-k;
		}
		else printf("0");
}	
