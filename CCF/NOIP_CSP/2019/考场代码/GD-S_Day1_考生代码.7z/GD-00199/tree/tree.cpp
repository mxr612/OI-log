#include<iostream>
#include<cstdio>
using namespace std;

#define ll long long

int read(){
	int x=0;char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9')x=x*10+(c-'0'),c=getchar();
	return x;
}
#define in(a) a=read()

#define maxn 2010
int l,nxt[maxn*2],head[maxn],to[maxn*2],id[maxn*2];
void add(int x,int y,int i){l++;nxt[l]=head[x];head[x]=l;to[l]=y;id[l]=i;}

int use[maxn],vis[maxn][maxn];
int f[maxn][maxn];
int fa[maxn][maxn];
int r;
void dfs(int x,int e){
	for(int i=head[x];i;i=nxt[i]){
		int c=to[i];
		if(c==fa[r][x])continue;
		if(f[e][id[i]])continue;
		fa[r][c]=x;vis[r][c]=1;
		dfs(c,id[i]);
	}
}
void update(int x,int e,int c){
	for(int i=head[x];i;i=nxt[i]){
		if(to[i]==fa[r][x]){
			f[e][id[i]]=c;
			update(fa[r][x],id[i],c);
		}
	}
}
int ans[maxn];

int a[maxn];
int n;
int get(int i){
	if(i==n+1)return 1;
	for(int j=1;j<=n;j++)fa[i][j]=vis[i][j]=0;
	r=i;
	fa[i][a[i]]=0;dfs(a[i],0);
	for(int j=1;j<=n;j++){
		if(vis[i][j]&&!use[j]){
			int F;
			for(int k=head[j];k;k=nxt[k])
				if(to[k]==fa[i][j])
					F=id[k];
//					cout<<i<<' '<<F<<endl;
			int flag=0;
			for(int k=head[j];k;k=nxt[k])
				if(to[k]!=fa[i][j]&&f[id[k]][F]){
					flag=1;
					break;
				}
			if(flag)continue;
			int son=j;
			while(fa[i][son]!=a[i])son=fa[i][son];
			int W;
			for(int k=head[a[i]];k;k=nxt[k])
				if(to[k]==son)
					W=id[k];
			for(int k=head[a[i]];k;k=nxt[k])
				if(to[k]!=son&&f[W][id[k]]){
					flag=1;
					break;
				}
//					cout<<i<<' '<<' '<<j<<flag<<endl;
			if(flag)continue;
			for(int k=head[j];k;k=nxt[k])
				if(to[k]!=fa[i][j]){
					f[F][id[k]]=1;
				}
			for(int k=head[a[i]];k;k=nxt[k])
				if(to[k]!=son){
					f[id[k]][W]=1;
				}
//					cout<<i<<' '<<F<<' '<<fa[j]<<endl;
			r=i;update(fa[i][j],F,1);
			use[j]=1;
			ans[i]=j;
			int c=get(i+1);
			use[j]=0;
			for(int k=head[j];k;k=nxt[k])
				if(to[k]!=fa[i][j]){
					f[F][id[k]]=0;
				}
			for(int k=head[a[i]];k;k=nxt[k])
				if(to[k]!=son){
					f[id[k]][W]=0;
				}
			r=i;update(fa[i][j],F,0);
			if(c)return 1;
		}
	}
}
int d[maxn];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int t;
	in(t);
	while(t--){
		in(n);
		
		l=0;
		for(int i=1;i<=n;i++)head[i]=use[i]=d[i]=0;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++)
				f[i][j]=vis[i][j]=0;
		for(int i=1;i<=n;i++)in(a[i]);
		for(int i=1;i<n;i++){
			int x,y;
			in(x);in(y);
			d[x]++;d[y]++;
			add(x,y,i);add(y,x,i);
		}
		int data=0;
		for(int i=1;i<=n;i++)
			if(d[i]==n-1)
				data=1;
//		if(data==1){solve();continue;}
		get(1);
		for(int i=1;i<n;i++)printf("%d ",ans[i]);
		printf("%d\n",ans[n]);
	}
}
