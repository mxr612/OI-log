#include<iostream>
#include<cstdio>
using namespace std;

#define ll long long

int read(){
	int x=0;char c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9')x=x*10+(c-'0'),c=getchar();
	return x;
}

#define maxn 500010
int l,nxt[maxn],head[maxn],to[maxn];
void add(int x,int y){l++;nxt[l]=head[x];head[x]=l;to[l]=y;}

int sl[maxn],sr[maxn];
char s[maxn];

int z[maxn],num,b[maxn],e[maxn];
int a[maxn];
ll sum[maxn];
int top;

void dfs(int x){
	if(s[x]=='(')sl[x]++;
	else sr[x]++;
	b[x]=sl[x]-sr[x];
	int NUM=num;
//	cout<<x<<endl;
//	for(int i=1;i<=top;i++)cout<<z[i]<<' ';cout<<endl;
	while(top&&b[z[top]]>b[x]){
		e[++num]=z[top];
		top--;
	}
	if(b[z[top]]==b[x])a[x]=a[z[top]]+1;
	z[++top]=x;
	sum[x]+=a[x];
//	cout<<x<<' '<<a[x]<<endl;
	
//	int C=w[sl[x]-sr[x]+maxn];
//	if(C!=-1)a[x]=a[C]+1;
//	w[sl[x]-sr[x]+maxn]=x;
	
	for(int i=head[x];i;i=nxt[i]){
		int c=to[i];
		sl[c]=sl[x];sr[c]=sr[x];
		sum[c]=sum[x];
		dfs(c);
	}
	top--;
	for(int i=num;i>NUM;i--)z[++top]=e[i];
	num=NUM;
	
//	w[sl[x]-sr[x]+maxn]=C;
}

int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n;
	n=read();
	scanf("%s",s+1);
	for(int i=2;i<=n;i++){
		int x;
		x=read();
		add(x,i);
	}
//	memset(w,-1,sizeof(w));
//	w[maxn]=0;
	dfs(1);
	ll ans=0;
	for(int i=1;i<=n;i++){
//		cout<<i<<' '<<sum[i]<<endl;
		ans^=1ll*i*sum[i];
	}
	printf("%lld\n",ans);
}
/*
sl[i]-sr[i]=sl[j-1]-sr[j-1]
*/
