#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstdio>
#include<string>
#include<cstring>
using namespace std;
int t,n,a[4000],g;
struct st{
	int x,y;
}Edge[4000];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>t;
	while (t--){
		cin>>n;
		for (int i=1;i<=n;i++){
			cin>>g;
            cout<<i<<" 	";	
			a[g]=i;
		}
		for (int i=1;i<=n;i++){
			cin>>Edge[i].x>>Edge[i].y;
		}
		cout<<endl;
	}
	return 0;
}
