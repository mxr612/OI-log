#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstdio>
#include<string>
#include<cstring>
using namespace std;
long long n,k,num[110];
string ansh;
void ans(long long lever,long long u){
	if (lever==1){
		if (u==0)ansh+='0';
		else ansh+='1';
		return ;
	}
	if (u>num[lever-1]){
		ansh+='1';
		ans(lever-1,num[lever-1]-(u-num[lever-1])+1);
	}
	else{
		ansh+='0';
		ans(lever-1,u);
	}
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	for (long long i=1;i<n;i++){
		num[i]=(num[i-1]+1)*2-1;
	}
	ans(n,k);
	cout<<ansh<<endl;
	return 0;
}
