#include<iostream>
#include<fstream>
#include<algorithm>
#include<cstdio>
#include<string>
#include<cstring>
using namespace std;
char a[500010];
long long n,cnt,hd[500010],ans=-1,g,u,c[1000010];
struct st{
	long long nex,to;
}edge[500010];
void add(long long from,long long to){
	cnt++;
	edge[cnt].nex=hd[from];
	edge[cnt].to=to;
	hd[from]=cnt;
}
void dfs(long long now,long long l,long long r,long long ok,long long ansnow)
{
	if (a[now]==')'&&l>r){
			ok++; 
			ansnow=ansnow+ok;
	}
	if (a[now]=='(')l++;
	else r++;
	if (ans==-1)ans=now*ansnow;
	else ans=ans^(now*ansnow);
	for (long long i=hd[now];i;i=edge[i].nex){
		dfs(edge[i].to,l,r,ok,ansnow);
	}
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	u=1;
	for (long long i=1;i<=n;i++)cin>>a[i];
	for (long long i=2;i<=n;i++){
		cin>>g;
		add(g,i);
		if (g!=i-1)u=0;
	}
	if (u){
		long long l=0,r=0,ok=0,ans=0,ansnow=0;
		if (a[1]=='(')l++;
		else r++;
		for (long long i=2;i<=n;i++)
		{
			if (a[i]==')'&&l>r){
				ok++; 
				ansnow=ansnow+ok;
			}
			if (a[i]=='(')l++;
		    else r++;
		   ans^=i*ansnow;
		}
		cout<<ans;
		return 0;
	}
	dfs(1,0,0,0,0);
	cout<<ans<<endl;
	return 0;
}
