#include<cstdio>
unsigned long long n,k,mi[105]={1};
int ans[105];
inline void search(int now,unsigned long long cnt){
	if(now==1){
		if(cnt==0) ans[1]=0;
		else ans[1]=1;
		return ;
	}
	if(cnt<mi[now-1]){
		ans[now]=0;
		search(now-1,cnt);
		return ;
	}
	ans[now]=1;
	search(now-1,mi[now-1]-cnt-1+mi[now-1]);
	return ;
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%llu%llu",&n,&k);
	if(n==0){
		fclose(stdin);fclose(stdout);
		return 0;
	}
	for(register int i=1;i<=n;i++) mi[i]=mi[i-1]*2;
	search(n,k);
	for(register int i=n;i>=1;i--) printf("%d",ans[i]);
	fclose(stdin);fclose(stdout);
	return 0;
}
