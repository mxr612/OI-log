#include<cstdio>
#include<cctype>
#include<cstring>
const int maxn=2005;
inline void swap(int &a,int &b){int t=a;a=b;b=t;}
inline int R(){
	int r=0;char c=getchar();
	while(!isdigit(c)) c=getchar();
	while(isdigit(c)) r=(r<<1)+(r<<3)+(c^48),c=getchar();
	return r;
}
int t,n,du[maxn],p[maxn],q[maxn];
int ans[maxn];
int edge[maxn][2],visit[maxn];
inline void dfs(int now){
	if(now==n){
		int flag=1;
		for(register int i=1;i<=n;i++){
			if(ans[i]>p[i]){
				flag=2;
				break;
			}
			if(ans[i]<p[i]){
				flag=0;
				break;
			}
		}
		if(flag==2) for(register int i=1;i<=n;i++) ans[i]=p[i];
	}
	for(register int i=1;i<=n;i++){
		if(visit[i]) continue;
		visit[i]=true;
		swap(p[q[edge[i][0]]],p[q[edge[i][1]]]);
		swap(q[edge[i][0]],q[edge[i][1]]);
		dfs(now+1);
		swap(q[edge[i][0]],q[edge[i][1]]);
		swap(p[q[edge[i][0]]],p[q[edge[i][1]]]);
		visit[i]=0;
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	for(register int qwq=1;qwq<=t;qwq++){
		n=R();
		memset(q,0,sizeof(q));
		memset(p,0,sizeof(p));
		memset(ans,127,sizeof(ans));
		memset(edge,0,sizeof(edge));
		for(register int i=1;i<=n;i++) p[i]=R(),q[p[i]]=i;
		for(register int i=1;i<n;i++){
			edge[i][0]=R();edge[i][1]=R();
		}
		dfs(1);
		for(register int i=1;i<=n;i++) printf("%d ",ans[i]);
		printf("\n");
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
