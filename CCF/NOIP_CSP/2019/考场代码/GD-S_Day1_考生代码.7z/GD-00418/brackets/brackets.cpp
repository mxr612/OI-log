#include<cstdio>
#include<cctype>
#define ull unsigned long long
const int maxn=500005;
struct node{
	int to,next;
}edge[maxn];
int n,fa[maxn],head[maxn],tot,pre[maxn],f[maxn];//��iΪ(��pre[i]Ϊ��һ��(,f[i]Ϊ֮������� 
ull ans[maxn],res;
bool typ[maxn];
inline void add(int from,int to){
	edge[++tot].next=head[from];
	edge[tot].to=to;
	head[from]=tot;
	return ;
}
inline void search(int now,int zz,int tuan){//��ǰ�ڵ� ��ǰ��ָ��(�ڵ� ��ǰ����
	for(register int i=head[now];i;i=edge[i].next){
		int u=edge[i].to;
		if(typ[now]==0 && typ[u]==0) ans[u]=ans[now],f[u]=tuan,pre[u]=now,search(u,u,0);
		else if(typ[now]==1 && typ[u]==0) ans[u]=ans[now],f[u]=tuan,pre[u]=zz,search(u,u,0);
		else if(typ[now]==0 && typ[u]==1){
			ans[u]=ans[now]+f[now]+1;
			search(u,pre[now],f[now]+1);
		}
		else{
			if(zz==0) ans[u]=ans[now],search(u,0,0);
			else{
				ans[u]=ans[now]+f[zz]+1;
				search(u,pre[zz],f[zz]+1);
			}
		}
	}
	return ;
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	for(register int i=1;i<=n;i++){
		char c=getchar();
		while(c!='(' && c!=')') c=getchar();
		if(c=='(') typ[i]=0;
		else typ[i]=1;
	}
	for(register int i=2;i<=n;i++){
		scanf("%d",&fa[i]);
		add(fa[i],i);
	}
	if(typ[1]==0) search(1,1,0);
	else search(1,0,0);
	for(register int i=1;i<=n;i++){
		res^=ans[i]*i;
	}
	printf("%llu\n",res);
	fclose(stdin);fclose(stdout);
	return 0;
}
