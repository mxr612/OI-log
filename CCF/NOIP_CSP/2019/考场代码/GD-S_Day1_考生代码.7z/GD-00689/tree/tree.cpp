#include<bits/stdc++.h>
#define rep(i,x,y) for(int i(x),l__(y);i<=l__;i++)
#define drep(i,x,y) for(int i(x),l__(y);i>=l__;i--)
using namespace std;
typedef long long ll;

int T,n;
int a[2001];

int main()
{
#ifndef HAZE
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
#endif
	scanf("%d",&T);
	rep(_,1,T)
	{
		scanf("%d",&n);
		rep(i,1,n)
			scanf("%d",&a[i]);
		sort(a+1,a+n+1);
		rep(i,1,n)
			printf("%d%c",a[i]," \n"[i==n]);
	}
	return 0;
}
