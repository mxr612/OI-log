#include<bits/stdc++.h>
#define rep(i,x,y) for(int i(x),l__(y);i<=l__;i++)
#define drep(i,x,y) for(int i(x),l__(y);i>=l__;i--)
using namespace std;
typedef long long ll;
const int siz=5e5+10;

struct edge
{
	int v,nxt;
}e[siz];

int n;
int head[siz],a[siz],f[siz];
ll s[siz];
ll avl[siz];

void adde(int u,int v);
void dfs(int u,int cnt1);

int main()
{
#ifdef HAZE
	freopen("brackets.in","r",stdin);
#else
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
#endif
	scanf("%d",&n);
	char c;
	do{c=getchar();}while(c!='\n');
	rep(i,1,n)
	{
		c=getchar();
		a[i]=(c=='('?1:-1);
	}
	rep(i,2,n)
	{
		int u;
		scanf("%d",&u);
		adde(u,i);
	}
	f[1]=-1;
	s[1]=0;
	int cnt1(-1);
	if(a[1]==1)
		cnt1=1;
	for(int i=head[1];i!=0;i=e[i].nxt)
		dfs(e[i].v,cnt1);
//#ifdef HAZE
//	rep(i,1,n)
//		cout<<s[i]<<' ';
//	cout<<endl;
//#endif
	ll ans=s[1];
	rep(i,2,n)
		ans^=(ll)i*s[i];
	cout<<ans<<endl;
	return 0;
}

void dfs(int u,int cnt1)
{
//	if(a[u]==1&&f[u]==cnt2)
//		s[u]++;
	if(a[u]==1)
		cnt1=u;
	if(a[u]==-1)
	{
		if(cnt1!=-1)
		{
			s[u]+=avl[f[u]]+avl[f[cnt1]]+1;
			avl[u]+=avl[f[u]]+avl[f[cnt1]]+1;
			do
			{
				cnt1=f[cnt1];
			}
			while(a[cnt1]!=1&&cnt1!=-1);
		}
	}
	s[u]+=s[f[u]];
	for(int i=head[u];i!=0;i=e[i].nxt)
		dfs(e[i].v,cnt1);
}

void adde(int u,int v)
{
	static int cnt;
	e[++cnt]=(edge){v,head[u]};
	head[u]=cnt;
	f[v]=u;
}
