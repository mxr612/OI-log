#include<bits/stdc++.h>
#define rep(i,x,y) for(int i(x),l__(y);i<=l__;i++)
#define drep(i,x,y) for(int i(x),l__(y);i>=l__;i--)
using namespace std;
typedef long long ll;

int n;
int a[101];
ll k;

void dfs(ll l,ll r,ll las,ll dep);

int main()
{
#ifndef HAZE
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
#endif
	cin>>n>>k;
	k++;
	dfs(1,1ll<<n,1ll<<n,1);
	rep(i,1,n)
		printf("%d",a[i]);
	putchar('\n');
	return 0;
}

void dfs(ll l,ll r,ll las,ll dep)
{
//	cout<<dep<<endl;
	ll mid=(l+r)>>1;
	if((k>mid&&k<=las)||(k<=mid&&k>las))
		a[dep]=1;
	else
		a[dep]=0;
	if(dep<n)
	{
		if(k<=mid)
			dfs(l,mid,mid,dep+1);
		else
			dfs(mid+1,r,mid,dep+1);
	}
}
