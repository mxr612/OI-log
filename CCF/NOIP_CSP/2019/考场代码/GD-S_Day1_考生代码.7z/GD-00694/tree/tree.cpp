#include<iostream>
#include<cstdio>
#include<cstring>
#define maxn 2010
using namespace std;
bool wgh[maxn][maxn],vis[maxn];
int ans[maxn],num[maxn],n,deg[maxn],p[maxn];
void add(int x,int y){wgh[x][y]=1;}
void dfs(int dep){
	if(dep==n){
		bool flag=0,ff=0;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(num[j]==i){
					if(ans[i]>j) flag=1;
					if(flag) ans[i]=j;
					else if(ans[i]<j){
						ff=1;
						break;
					}
				}
			}
			if(ff) break;
		}
		return ;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(!wgh[i][j]) continue;
			wgh[i][j]=wgh[j][i]=0;
			swap(num[i],num[j]);
			dfs(dep+1);
			wgh[i][j]=wgh[j][i]=1;
			swap(num[i],num[j]);
		}
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T;
	cin>>T;
	while(T--){
		memset(wgh,0,sizeof(wgh));
		memset(ans,0x7f,sizeof(ans));
		memset(deg,0,sizeof(deg));
		int x,y;
		cin>>n;
		for(int i=1;i<=n;i++){
			scanf("%d",&p[i]);
			num[p[i]]=i;
		}
		for(int i=1;i<n;i++){
			scanf("%d%d",&x,&y);
			add(x,y);
			add(y,x);
			deg[x]++;
			deg[y]++;
		}
		bool flagl=1,flag=0;
		for(int i=1;i<=n;i++){
			if(deg[i]>3) flagl=0;
			if(deg[i]==n-1){
				flag=1;
				break;
			}
		}
		if(n<=10){
			dfs(1);
			for(int i=1;i<=n;i++) printf("%d ",ans[i]);
			printf("\n");
			continue;
		}
		if(flagl){
			int minx=1;
			while(minx!=n){
				int k=1,t=minx;
				for(;k<=n;k++){
					if(num[k]==minx){
						p[t]=k;
						break;
					}
					else{
						p[t]=k;
						t=num[k];
						vis[num[k]]=1;
					}
				}
				for(int i=minx+1;i<=n;i++){
					if(!vis[i]){
						minx=i;
						break;
					}
				}
			}
			for(int i=1;i<=n;i++) printf("%d ",p[i]);
			printf("\n");
			continue;
		}
		dfs(1);
	}
	return 0;
}
