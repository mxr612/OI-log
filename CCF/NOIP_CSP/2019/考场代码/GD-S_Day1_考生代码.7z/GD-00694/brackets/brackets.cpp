#include<iostream>
#include<cstring>
#include<cstdio>
#include<string>
#define maxn 500010
#define ll long long
using namespace std;
int head[maxn],link[maxn],to[maxn],fa[maxn],stk[maxn];
int tot,size,Size;
ll ans,f[maxn];
char s[maxn];
string S;
void Pops(){Size--;}
void Pushs(char x){s[Size++]=x;}
void PoP(){size--;}
void PuSh(int x){stk[size++]=x;}
void add(int x,int y){
	link[++tot]=head[x];
	to[tot]=y;
	head[x]=tot;
}
ll work(){
	memset(f,0,sizeof(f));
	for(int i=0;i<Size;i++){
		if(s[i]=='(') PuSh(i);
		else{
			if(size&&s[stk[size-1]]=='('){
				if(stk[size-1]==0) f[i]=1;
				else f[i]=f[stk[size-1]-1]+1;
				PoP();
			}
		}
	}
	ll ANS=0;
	for(int i=0;i<Size;i++) ANS+=f[i];
	size=0;
	return ANS;
}
void dfs(int x){
	ans^=1ll*work()*x;
	for(int i=head[x];i;i=link[i]){
		int u=to[i];
		Pushs(S[u-1]);
		dfs(u);
		Pops();
	}
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n;
	cin>>n;
	cin>>S;
	bool flag=1;
	for(int i=2;i<=n;i++){
		scanf("%d",&fa[i]);
		if(fa[i]!=i-1) flag=0;
		add(fa[i],i);
	}
	if(flag){
		for(int i=0;i<n;i++) s[i]=S[i];
		Size=n;
		work();
		int t=0;
		for(int i=0;i<Size;i++){
			t+=f[i];
			ans^=1LL*(i+1)*t;
		}
		cout<<ans;
		return 0;
	}
	Pushs(S[0]);
	dfs(1);
	cout<<ans;
	return 0;
}
