#include<iostream>
#include<cstdio>
#define ll long long
using namespace std;
unsigned ll PoW[50];
void work(int n,unsigned ll k,bool t){
	if(n==0) return ;
	if(k>PoW[n-1]) cout<<!t;
	else cout<<t;
	work(n-1,k>PoW[n-1]?k-PoW[n-1]:k,k>PoW[n-1]?1:0);
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	PoW[0]=1;
	for(int i=1;i<=64;i++) PoW[i]=PoW[i-1]*2;
	int n;
	unsigned ll k;
	cin>>n>>k;
	work(n,k+1,0);
	return 0;
}
