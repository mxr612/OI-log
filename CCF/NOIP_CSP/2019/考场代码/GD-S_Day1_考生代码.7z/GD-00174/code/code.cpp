#include<iostream>
#include<cstdio>
using namespace std;
long long t[100],k;
int n;
int dfs(int n,long long k){
	if(n==0)return 0;
//	printf("%d %lld\n",n,k);
	if(n==1){
		if(k==0)printf("0");
		if(k==1)printf("1");
		return 0;
	}
	if(k>t[n-1]-1){
		printf("1");
		dfs(n-1,t[n]-k-1);
	}
	else {
		printf("0");
		dfs(n-1,k);
	}
	return 0;
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%lld",&n,&k);
	t[0]=1;
	for(int i=1;i<=n+1;i++)t[i]=t[i-1]*2;
	dfs(n,k);
return 0;
}
