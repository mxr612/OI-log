#include<iostream>
#include<cstdio>
#include<vector>
using namespace std;
const int maxn=500005;
int n,m,f[maxn],s[maxn],add[maxn],sum[maxn],t1[maxn],t2[maxn];
long long tot[maxn];
vector<int> tree[maxn];
char c;
void dfs(int u,int fa){
	t1[u]=t1[fa];t2[u]=t2[fa];sum[u]=sum[fa];add[u]=add[fa];tot[u]=tot[fa];
	if(s[u]==1){
	if(s[fa]==2){
	if(s[f[fa]]==1&&t1[u]!=0){
	tot[u]+=sum[u]*(sum[u]+1)/2;
	sum[u]=1;	
	}	
	t1[u]=0;	
	}
	t1[u]++;	
	}
	if(s[u]==2){
	if(sum[u]!=0){
	if(t1[u]==0){
		tot[u]+=(long long)(sum[u]*(sum[u]+1)/2);
		sum[u]=0;
	}
	else{
		t1[u]--;
		if(t1[u]==0){
			sum[u]++;
		}
		else add[u]++;
	}	
	}
	else {
	if(t1[u]!=0){
	t1[u]--;
	if(t1[u]==0){
		sum[u]++;
	}
	else add[u]++;	
	}	
	}
	}
	for(int i=0;i<tree[u].size();i++){
		int v=tree[u][i];
		if(fa==v)continue;
		dfs(v,u);
	}
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
	cin>>c;if(c=='(')s[i]=1;
	else s[i]=2;
	}
	for(int i=2;i<=n;i++){
	scanf("%d",&f[i]);
	tree[f[i]].push_back(i);	
	}
	dfs(1,0);
	long long ans=0;
	for(int i=2;i<=n;i++)ans^=i*(tot[i]+add[i]+(sum[i]*(sum[i]+1)/2));
	cout<<ans;
}
