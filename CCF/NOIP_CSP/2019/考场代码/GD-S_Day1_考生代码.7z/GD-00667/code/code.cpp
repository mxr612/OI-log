#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#define int unsigned long long
using namespace std;

inline void read(int &x) {
	x=0;
	int f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=f;
}

int n,k;
//v位格雷码,当前rk为x,是否翻转rev
void dfs(int v,int x,bool rev) {
	int opx=(1ull<<v-1);
	if (rev) {
		x=(1ull<<v)-x+1;
	}
//	cout<<v<<" "<<x<<" "<<rev<<endl;
	if (v==1) {
		char o=(x==2?'1':'0');
		putchar(o);
		return;
	}
	if (x<=opx) {
		putchar('0');
		dfs(v-1,x,0);
	} else {
		putchar('1');
		dfs(v-1,x-opx,1);
	}
}

signed main() {
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	int spe=(1ull<<63)-1+(1ull<<63);
	if (k==spe) {
		printf("1000000000000000000000000000000000000000000000000000000000000000");
		return 0;
	}
//	cout<<spe<<endl;
	dfs(n,k+1,0);
	return 0;
}
