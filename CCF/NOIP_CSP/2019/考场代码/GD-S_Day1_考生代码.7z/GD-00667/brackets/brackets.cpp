#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int N=500010;

inline void read(int &x) {
	x=0;
	int f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=f;
}

struct note {
	int t;
	int next;
};

int head[N];
int cnt;
note e[N<<1];

inline void add(int x,int y) {
	e[++cnt].t=y;
	e[cnt].next=head[x];
	head[x]=cnt;
}

int fa[N];
int n;
char s[N];

namespace sub1 {
	int sta1[N];
	int sta[N];
	int cant[N];
	int con,tot;
	inline int check(int l,int r) {
		for(int i=1;i<=tot;i++) {
			if (l<=cant[i]) {
				return 0;
			}
		}
		return 1;
	}
	inline int solve(int x) {
		int ans=0;
		con=tot=0;
//		printf("%d\n",x);
		while(fa[x]) {
			sta1[++con]=(s[x]=='('?1:-1);
			x=fa[x];
		}
		sta1[++con]=(s[x]=='('?1:-1);
		for(int i=1;i<=con;i++) {
			sta[i]=sta1[con-i+1];
			sta[i]+=sta[i-1];
			if (sta[i]<0) {
				cant[i]=1;
			}
		}
		for(int i=1;i<=con;i++) {
			cant[i]+=cant[i-1];
		}
//		for(int i=1;i<=con;i++) {
//			printf("%d ",sta[i]);
//		}
//		putchar('\n');
//		putchar('\n');
		for(int i=1;i<con;i++) {
			for(int j=i+1;j<=con;j++) {
				int opx=sta[j]-sta[i-1];
				if (!opx&&!cant[j]-cant[i-1]) {
					ans++;
				}
			}
		}
		return ans;
	}
	inline void work() {
		int ans=0;
		for(int i=2;i<=n;i++) {
			ans^=solve(i)*i;
		}
		printf("%d\n",ans);
	}
}

int main() {
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	memset(head,-1,sizeof(head));
	read(n);
	scanf("%s",s+1);
	for(int i=2;i<=n;i++) {
		read(fa[i]);
		add(i,fa[i]);
		add(fa[i],i);
	}
	sub1::work();
	return 0;
}
