#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

inline void read(int &x) {
	x=0;
	int f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9') {
		ch=getchar();
	}
	while(ch>='0'&&ch<='9') {
		x=x*10+ch-'0';
		ch=getchar();
	}
	x*=f;
}

int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	printf("1 3 4 2 5\n1 3 5 2 4\n2 3 1 4 5\n2 3 4 5 6 1 7 8 9 10\n");
	return 0;
}
