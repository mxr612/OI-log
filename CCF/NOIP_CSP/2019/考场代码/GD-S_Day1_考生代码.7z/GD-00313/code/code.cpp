#include<iostream>
#include<cmath>
#include<cstdio>
using namespace std;
int N;
long long K;
void search(int n,long long k) {
	long long tmp = (long long)pow(2,n-1);
	if(k>=tmp) {
		cout<<"1";
	} else {
		cout<<"0";
	}
	if(n==1) {
		return;
	}
	if(k>=tmp) {
		search(n-1,(tmp-1)-(k-tmp));
	} else {
		search(n-1,k);
	}
}
int main() {
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>N>>K;
	search(N,K);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
