#include<iostream>
using namespace std;
#define MAX 500005
// ( --True
// ) --False
int N;
string line;
bool treeV[MAX];
int tree[MAX];
bool leaf[MAX];
bool stack[MAX];
int countA[MAX];
int countB[MAX];
int result = 0;
bool trans(char ch) {
	return ch=='('?true:false;
}
void init(bool needLeaf = false) {
	for(int i=0;i<=N;i++) {
		stack[i] = false;
		countA[i] = 0;
		countB[i] = 0;
		if(needLeaf) leaf[i] = true;
	}
	
}
void go(int s,int top) {
	stack[top] = treeV[s];
	if(top==0) {
		go(tree[s],top+1);
	} else {
		if(stack[top] && !stack[top-1]) {
			countA[top-1]++;
			if(countA[top]!=0) {
				result += (countA[top]+1)*countA[top]/2;
				countA[top] = 0;
			}
			if(tree[s]==-1) {
				result += (countA[top-1]+1)*countA[top-1]/2;
				return;
			}
			go(tree[s],top-1);
		}
	}
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>N;
	cin>>line;
	treeV[1] = trans(line[0]);
	leaf[0] = false;
	leaf[1] = false;
	init(true);
	for(int i=2;i<=N;i++) {
		treeV[i] = trans(line[i]);
		cin>>tree[i];
		leaf[tree[i]] = false;
	}
	for(int i=1;i<=N;i++) {
		if(leaf[i]) {
			go(i,0);
			init();
		}
	}
	cout<<result<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
