#include<bits/stdc++.h>
#define N 500001
using namespace std;
long long ans;
char sta[N];
vector<int> g[N];
stack<char> stk,stk1,stk2;
int fa[N];
void dfs(int u)
{
	stk.push(sta[u]);
	if(u==1)return;
	else dfs(fa[u]);
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n;
	scanf("%d\n",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%c ",&sta[i]);
	}
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&fa[i]);
	}
	long long ans=0;
	for(int i=1;i<=n;i++)
	{
		map<string,int> mp;
		string str="";
		while(!stk2.empty())stk2.pop();
		long long k=0;
		dfs(i);
		while(!stk.empty())
		{
			stk1.push(stk.top());
			stk.pop();
		}
		while(!stk1.empty())
		{
			char tp=stk1.top();
			stk1.pop();
			if(tp=='('&&stk2.empty()==false&&stk2.top()==')')
			{
				stk2.pop();
				str+=tp;
				if(!mp[str])
				{
					mp[str]=true;
					k++;
				}
			}
			else
			{
				stk2.push(tp);
				str+=tp;
			}
		}
		ans^=(long long)(i*k);
		printf("%lld\n",ans);
		
	}
	//printf("%lld",ans);
}
/*
6
(())()
1 1 2 2 4
*/
