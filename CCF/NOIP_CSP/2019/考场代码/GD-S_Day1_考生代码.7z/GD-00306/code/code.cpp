#include<bits/stdc++.h>
using namespace std;
unsigned long long n,k;
int ans[66];
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%llu %llu",&n,&k);
	k%=(4*(n-1));
	k++;
	if(k==1)
	{
		for(int i=1;i<=n;i++)
		{
			printf("0");
		}
		return 0;
	}
	if(k<=n)
	{
		k--;
		for(int i=1;i<=k;i++)
		{
			ans[i]=1;
		}
		for(int i=n;i>=1;i--)
		{
			printf("%d",ans[i]);
		}
		return 0;
	}
	if(k<=2*(n-1))
	{
		k-=n;
		for(int i=1;i<=n-1;i++)
		{
			ans[i]=1;
		}
		for(int i=1;i<=k;i++)
		{
			ans[i]=0;
		}
		for(int i=n;i>=1;i--)
		{
			printf("%d",ans[i]);
		}
		return 0;
	}
	if(k<=3*(n-1))
	{
		ans[n]=1;
		k-=(2*n-1);
		for(int i=n-1;i>=n-k-1;i--)
		{
			ans[i]=1;
		}
		for(int i=n;i>=1;i--)
		{
			printf("%d",ans[i]);
		}
		return 0;
	}
	else
	{
		k-=(3*(n-1));
		for(int i=1;i<=n;i++)
		{
			ans[i]=1;
		}
		for(int i=n-1;i>=n-k;i--)
		{
			ans[i]=0;
		}
		for(int i=n;i>=1;i--)
		{
			printf("%d",ans[i]);
		}
		return 0;
	}
}
/*
44 4444444444444
*/
