#include<bits/stdc++.h>
using namespace std;
#define ull unsigned long long
ull n,k,f[65],t[65];
string s;
ull read()
{
	ull x=0,f=1; char ch=getchar();
	while (ch<'0' || ch>'9') {if (ch=='-') f=-1; ch=getchar();}
	while (ch>='0' && ch<='9') {x=x*10+ch-'0';   ch=getchar();}
	return x*f;
}
void turn(ull x)
{
	while (x!=0)
	{
		char ch=x%2+'0';
		s+=ch;
		x/=2;
	}
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	n=read();cin>>k;
	ull p=k;
	ull a=1;
	int i=0;
	while (1)
	{
		if (k==2) {a=3;break;}
		if (k==3) {a=2;break;}
		i++;
		if (k%2==0) {t[i++]=0;k/=2;}
		else {t[i]=1;k=(k-1)/2;}
	}
	while (1)
	{
		if (k==p) break;
		a=a*2+1;
		if (t[i--]==0) k*=2;
		else k=k*2+1;
	}
	turn(a);
	for (int i=s.size()-1;i>=0;i--) cout<<s[i];
	fclose(stdin); fclose(stdout);
	return 0;
}
