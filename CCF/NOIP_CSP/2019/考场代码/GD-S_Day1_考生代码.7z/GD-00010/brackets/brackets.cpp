#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=500005;
int vis[N],ver[N],Next[N],head[N];
ll cnt,ans,top,n,k[N];
char sta[N],tree[N];
ll read()
{
	ll x=0,f=1; char ch=getchar();
	while (ch<'0' || ch>'9') {if (ch=='-') f=-1; ch=getchar();}
	while (ch>='0' && ch<='9') {x=x*10+ch-'0';   ch=getchar();}
	return x*f;
}
void add(int x,int y)
{
	ver[++cnt]=y; Next[cnt]=head[x]; head[x]=cnt;
}
void data(int x)
{
	int tot=0,sum=0;
	for (int i=1;i<=top;i++)
	{
		if (sta[i]=='(')
		 tot++;
		if (sta[i]==')')
		{
			if (tot==0) continue;
			if (tot>0)
			{
				tot--;
				sum++;
			}
		}
	}
	k[x]=sum;
}
void dfs(int x)
{
	sta[++top]=tree[x];
	data(x);
	vis[x]=1;
	for (int i=head[x];i;i=Next[i])
	{
		int v=ver[i];
		if (!vis[v])
		 dfs(v);
		sta[top--]='0';
	}
}
int main()
{
    freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	n=read();
	for (ll i=1;i<=n;i++)
	 cin>>tree[i];
	for (ll i=2;i<=n;i++)
	{
		ll f=read(); 
		add(f,i);
	}
	dfs(1);
	for (int i=1;i<=n;i++)
	 ans^=k[i]*i;
	cout<<ans;
	fclose(stdin); fclose(stdout);
	return 0;
}
