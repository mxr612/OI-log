#include<iostream>
#include<fstream>
#include<cstring>
using namespace std;
int jiedian[2010],out[2010],x[2010],y[2010],temp[2010];
bool bian[2010][2010];
bool found=false;
bool canbe(int a,int b){
	int temp=0;
	for(int i=1;i<=n;i++)
		if(jiedian[i]==a)
			temp=i;
	while(temp!=1){
		
	}
}
void findmin(int num,int n){
	int x,y,temp=0;
	if(num>n&&!found){
		for(int i=1;i<n;i++){
			if(!canbe(out[i],i)){
				return;
			}
		}
		found=true;
		return;
	}else{
		for(x=n;n>=1;x--){
			for(y=x;y<=n;y++){
				temp=out[x];out[x]=out[y];out[y]=temp;
				findmin(num++,n);
				temp=out[x];out[x]=out[y];out[y]=temp;
			}
		}
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int t,n;
	cin>>t;
	for(int j=0;j<t;j++){
		memset(bian,false,sizeof(bian));
		for(int i=1;i<=n;i++)
			out[i]=i;
		found=false;
		memset(jiedian,0,sizeof(jiedian));
		cin>>n;
		for(int i=1;i<=n;i++){
			cin>>temp[i];
			jiedian[temp[i]]=i;
		}
		for(int i=1;i<n;i++){
			cin>>x[i]>>y[i];
			bian[x[i]][y[i]]=true;
			bian[y[i]][x[i]]=true;
		}
		findmin(1,n);
		for(int i=1;i<=n;i++){
			cout<<out[i]<<" ";
		}
		cout<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
