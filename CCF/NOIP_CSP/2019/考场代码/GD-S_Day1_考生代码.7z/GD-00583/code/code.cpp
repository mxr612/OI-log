#include<fstream>
#include<iostream>
using namespace std;
int out[70]={0};
unsigned long long multi(int n){
	unsigned long long k=1;
	for(int i=0;i<n;i++)
		k*=2;
	return k;
}
void Gray(int n,long long k){
	int i;
	long long j;
	for(i=1;i<=n;i++){
		j=(k+1)%multi(i+1);
		if(j<multi(i-1)+1||j>3*multi(i-1)){
			out[i]=0;
		}else{
			out[i]=1;
		}
	}
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	long long k;
	int n;
	cin>>n>>k;
	Gray(n,k);
	for(int i=n;i>=1;i--){
		cout<<out[i];
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
