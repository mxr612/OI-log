#include<iostream>
#include<string>
using namespace std;
char tree[500010]={0},temp[100010]={0};
int father[500010]={0},k[100010]={0};
void finds(int num){
	int i=0,len=1,num;
	temp[0]=tree[num];
	while(num!=1){
		temp[i]=tree[father[num]];
		num=father[num];
		len++;i++;
	}
	for(i=0;i<len;i++){
		
	}
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n,allnum;
	string s;
	cin>>n;
	cin>>s;
	for(int i=1;i<=n;i++){
		tree[i]=s[i-1];
	}
	for(int i=2;i<=n;i++){
		cin>>father[i];
	}
	for(int i=2;i<n;i++){
		finds(i);
	}
//	for(int i=0;i<n-1;i++){
//		allnum=allnum+k[i]^k[i+1];
//	}
//	cout<<allnum;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
