#include<bits/stdc++.h>
using namespace std;
int n;
long long k,mid=2;
int a[65];
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<n-1;i++)
	mid=mid*2;
	k++;
	int cnt=1;
	for(int i=0;i<n;i++){
		if(cnt==1){
		if(k<=mid) a[n-i]=0;
		else{
		a[n-i]=1;
		k=k-mid;
		cnt=0;	
		} 
		mid=mid/2;
		}
		else if(cnt==0){
		if(k<=mid) a[n-i]=1,cnt=1;
		else{
		a[n-i]=0;
		k=k-mid;	
		} 
		mid=mid/2;
		}
	}
	for(int i=n;i>=1;i--)
	cout<<a[i];
	cout<<endl;
	return 0;
}
