#include<bits/stdc++.h>
using namespace std;
int n,cnt,s1[100005],s2[100005],l[100005],f[100005],ans[100005];
char s[100005];
void find(int x){
	if(f[x]!=0){
	ans[x]=ans[f[x]];
	l[x]=l[f[x]];
	}
	if(s[x-1]=='(') l[x]++;
    else{
    	if(l[x]>0) ans[x]++; l[x]--;
	}
	if(s1[x]!=0) find(s1[x]);
	if(s2[x]!=0) find(s2[x]);
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n>>s;
	for(int i=2,x;i<=n;i++){cin>>x; f[i]=x; if(s1[x]==0) s1[x]=i;else s2[x]=i;}
	find(1);
	for(int i=1;i<=n;i++)
	cnt=cnt^(i*ans[i]);
	cout<<cnt<<endl;
	return 0;
}
