#include<bits/stdc++.h>
using namespace std;
int t,n;
int a[10000];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>t;
	while(t--){
		cin>>n;
		for(int i=1;i<=n;i++) a[i];
		for(int i=1,x,y;i<=n-1;i++) 
		cin>>x>>y;
		
	} 
	
	return 0;
}
