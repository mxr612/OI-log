#include<bits\stdc++.h>
using namespace std;

long long m = 0;
long long _2(int n)
{
	long long m = 1;
	for (int i = 0;i < n; i++)
	{
		m *= 2;
	}
	return m;
}

int main()
{
	//freopen("code.in","r",stdin);
	//freopen("code.out","w",stdout);
	int n;
	long long k;
	cin >> n >> k;
	while (n >= 0)
	{
		if (k > _2(n))
		{
			m += _2(n);
			k = _2(n + 1) - k;
		}
		n--;
	}
	cout << m;
	return 0;
}
