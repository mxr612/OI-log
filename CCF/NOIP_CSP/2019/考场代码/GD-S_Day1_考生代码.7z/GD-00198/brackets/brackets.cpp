#include<bits/stdc++.h>
using namespace std;

int main()
{
	int n;
	string str;
	cin >> n >> str;
	int ch[n + 1];
	ch[1] = 0;
	for (int i = 1; i < n + 1; i++)
		cin >> ch[i];
	string st[n + 1];
	for (int i = 1, m; i < n + 1; i++)
	{
		m = i;
		for (int x = 0; ch[m] != 0; x++)
		{
			st[i][x] = str[m];
			m = ch[m];
		}
	}
	return 0;
}
