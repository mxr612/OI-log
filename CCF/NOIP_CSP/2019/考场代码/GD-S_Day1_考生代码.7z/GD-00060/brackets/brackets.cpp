#include<cstdio>
#define maxn 500050
#define ll long long
using namespace std;
struct enode{
	int nxt,y;
}e[maxn];
int tot=0;
char s[maxn];
int first[maxn];
ll ans[maxn],a[maxn];
int head=0;
void adde(int x,int y){
	e[tot].nxt=first[x];
	e[tot].y=y;
	first[x]=tot++;
}
void dfs(int x,int fa,int now){
	int head=now,f=0,t=0;
	if (s[x]=='(') {
		head++;
		ans[x]=ans[fa];
	}else{
		if (head){
			f=1;
			t=a[head];
			a[head]=0;
			head--;
			a[head]++;
			ans[x]=ans[fa]+a[head]; 
		}else ans[x]=ans[fa];
	}
	for (int i=first[x];i>=0;i=e[i].nxt){
		int y=e[i].y;
		dfs(y,x,head);
	}
	if (f) a[head+1]=t,a[head]--;
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n;
	scanf("%d",&n);
	scanf("%s",s+1);
	for (int i=1;i<=n;i++)
	first[i]=-1;
	for (int i=2;i<=n;i++){
		int x;
		scanf("%d",&x);
		adde(x,i);
	}
	dfs(1,0,0);
	ll S=0;
	for (int i=1;i<=n;i++)
	S^=ans[i]*i;
	printf("%lld\n",S);
	return 0;
}
/*
7
)))(())
1 1 3 4 5 6
*/
