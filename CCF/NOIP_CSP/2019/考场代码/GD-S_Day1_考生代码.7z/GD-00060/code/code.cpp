#include<cstdio>
#define ull unsigned long long
using namespace std;
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	ull n,k;
	scanf("%llu%llu",&n,&k);
	while (n){
		n--;
		if (k<1ull<<n) printf("0");else{
			if (n+1==64) k=(1ull<<n)-1+(1ull<<n)-k;else
				k=((1ull<<(n+1))-1)-k;
			printf("1");
		}
	}
	printf("\n");
	return 0;
}

