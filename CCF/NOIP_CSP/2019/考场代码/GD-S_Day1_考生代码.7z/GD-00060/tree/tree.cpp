#include<cstdio>
#include<algorithm>
#define maxn 2005
using namespace std;
int n;
int a[maxn],b[maxn],c[maxn],d[maxn],ans[maxn];
int x[maxn],y[maxn],v[maxn];
void dfs(int dep){
	if (dep==n-1){
		for (int i=1;i<=n;i++)
		b[i]=a[i];
		for (int i=1;i<n;i++)
		swap(b[x[c[i]]],b[y[c[i]]]);
		for (int i=1;i<=n;i++)
		d[b[i]]=i;
		int f=0;
		for (int i=1;i<=n;i++)
		if (d[i]<ans[i]) {
			f=1;
			break;
		}else if (d[i]>ans[i]) break;
		if (f){
			for (int i=1;i<=n;i++)
			ans[i]=d[i];
		}
		return;
	}
	for (int i=1;i<n;i++)
	if (!v[i]) v[i]=1,c[dep+1]=i,dfs(dep+1),v[i]=0;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	srand((unsigned)(new unsigned char*));
	int T;
	scanf("%d",&T);
	while (T--){
		scanf("%d",&n);
		for (int i=1,x;i<=n;i++)
		scanf("%d",&x),a[x]=i,ans[i]=n;
		for (int i=1;i<n;i++)
		scanf("%d%d",&x[i],&y[i]);
		if (n<=10){
			dfs(0);
			for (int i=1;i<=n;i++)
			printf("%d ",ans[i]);
			printf("\n");
		}else{
			for (int i=1;i<=n;i++)
			c[i]=i;
			for (int i=1;i<=10000;i++){
				for (int i=1;i<=1000;i++){
					int x=rand()%(n-1)+1,y=rand()%(n-1)+1;
					swap(c[x],c[y]);
				}
				for (int i=1;i<=n;i++)
				b[i]=a[i];
				for (int i=1;i<n;i++)
					swap(b[x[c[i]]],b[y[c[i]]]);
				for (int i=1;i<=n;i++)
				d[b[i]]=i;
				int f=0;
				for (int i=1;i<=n;i++)
				if (d[i]<ans[i]) {
					f=1;
					break;
				}else if (d[i]>ans[i]) break;
				if (f){
					for (int i=1;i<=n;i++)
					ans[i]=d[i];
				}
			}
			for (int i=1;i<=n;i++)
			printf("%d ",ans[i]);
			printf("\n");
		}
	}
	return 0;
}
