#include<bits/stdc++.h>
using namespace std;
struct tree{
	char c;
	int num,two[1025];
}t[100001];
int n,x,last=0;
long long int k;
char a,b;
char q[100001];
char get(){
	return q[last];
}
void push(char wa){
	last++;
	q[last]=wa;
}
void pop(){
	last--;
}
void tentotwo(long long int m,int i){
	int num=1;
	while(m==0){
		m/=2;
	    t[i].two[num]=m%2;
	    num++;
	}
	t[i].two[0]=num;
}
void yihuo(int a[],int b[]){
	for(int i=1;i<=b[0];i++){
		if(a[i]!=b[i]) b[i]=1;
		else b[i]=0;
	}
}
int main(){
    freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a;
		t[i].c=a;
		t[i].num=0;
	}
	for(int i=2;i<=n;i++){
		cin>>x;
	}
	push(t[1].c);
	for(int i=2;i<=n;i++){
		t[i].num=t[i-1].num;
		b=t[i].c;
		if(get()=='('&&b==')'){
			t[i].num++;
			pop();
		}else{
		    push(b);
		}
		k=i*t[i].num;
		tentotwo(k,i);
	}
	k=0;
	for(int i=1;i<=t[n].two[0];i++){
		k+=t[n].two[i]*(i-1)*2;
	}
	cout<<k;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
