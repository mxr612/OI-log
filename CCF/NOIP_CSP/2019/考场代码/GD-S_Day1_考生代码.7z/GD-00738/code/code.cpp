#include<bits/stdc++.h>
using namespace std;
int n,t=1;
bool end=true;
long long int a=1,k;
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<n;i++){
		a*=2;
	}
	while(end){
		if(k<a&&t==1){
			cout<<0;
		}
		if(k>=a&&t==1){
			cout<<1;
			k-=a;
		}
		if(k<a&&t==-1){
			cout<<1;
		}
		if(k>=a&&t==-1){
			cout<<0;
			k-=a;
		}
		if(a==1) end=false;
		t*=-1;
		a/=2;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
