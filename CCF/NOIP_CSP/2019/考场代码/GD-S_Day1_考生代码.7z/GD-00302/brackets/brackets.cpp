#include <bits/stdc++.h>
using namespace std;
const int MAXN=5e5+10;
int n,a[MAXN],tot,fa[MAXN],dis[MAXN],k[MAXN],tot_0,tot_1,flg,ans;
char s;
void get_fa(int x){
	//cout<<dis[tot]<<" ";
	//cout<<dis[tot]<<" ";
	dis[++tot]=a[x];
	if(x==1)return;
	get_fa(fa[x]);
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	fa[1]=1;
	for(int i=1;i<=n;i++){
		cin>>s;
		if(s=='(')a[i]=0;
		if(s==')')a[i]=1;
	}
	for(int i=1;i<n;i++)cin>>fa[i+1];
	k[1]=0;
	for(int j=2;j<=n;j++){//cout<<endl;
		tot=0,tot_0=0,tot_1=0;
		get_fa(j);//for(int i=1;i<=tot;i++)cout<<dis[i]<<" ";
		for(int i=tot;i>=1;i--){
			if(dis[i]==0)tot_0++;
			if(dis[i]==1)tot_1++;
			if(dis[i+1]==0&&dis[i]==1){
				k[j]++,tot_0--,tot_1--;
				if(flg-i==2)k[j]++;//cout<<j<<":"<<i<<endl;
			}
			if(tot_0==0&&dis[i]==1)tot_1--;
			if(tot_1==0&&dis[i]==0)tot_0=1;
			else if(tot_0>0&&dis[i]==1)k[j]++;//cout<<j<<":"<<i<<endl;
		}
		ans=0;
		//cout<<k[j]<<" ";
		ans=ans^(j*k[j]);
	}//cout<<endl;
	cout<<ans<<endl;
	return 0;
}
