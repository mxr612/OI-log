#include <bits/stdc++.h>
using namespace std;
#define ll long long
ll n,k,a[70],tot=0,cnt=1;
bool flg;
int ksm(ll a,ll n){
	ll res=1,x=a;
	while(n){
		if(n&1)res*=x;
		x*=x;
		n>>=1;
	}
	return res;
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	flg=true;
	scanf("%lld%lld",&n,&k);
	flg=true;
	k+=1;
	ll nn=ksm(2,n);
	while(nn>=2){
		tot++;
		if(k>nn)k-=nn;
		if(flg){
			if(k<=(nn/2))a[tot]=0;
			else{
				a[tot]=1;
				flg=false;
			}
		}
		else{
			if(k<=(nn/2)){
				a[tot]=1;
				flg=true;
			}
			else a[tot]=0;
		}
		nn>>=1;
		//cnt++;
		//cout<<nn<<endl;
	}
	for(ll i=1;i<=tot;i++)cout<<a[i];
	cout<<endl;
	return 0;
}
