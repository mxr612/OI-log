#include <iostream>
#include <cstdio>
#include <cstring>
#include <cctype>
#include <map>
#define maxn 2004
using namespace std;
int read(){
	char ch = getchar();
	int sum = 0;
	while(!isdigit(ch)){
		ch = getchar();
	}
	while(isdigit(ch)){
		sum = sum * 10 + (ch - '0');
		ch = getchar();
	}
	return sum;
}
map<int,int> check;
int t , n;
int ans[maxn], now[maxn];
struct edge{
	int u, v;
}e[maxn];
bool vis[maxn];
void dfs(int d){
	if(d == n){
		bool chkz = true, chkb = false;
		for(int i = 1;i<=n;i++){
			if(ans[i]){
				chkz = false;
				break;
			}
		}
		if(chkz){
			for(int i = 1;i<=n;i++){
				ans[now[i]] = i;
			}
			return;
		}
		for(int i = 1;i<=n;i++){
			check[now[i]] = i;
		}
		for(int i = 1;i<=n;i++){
			if(check[i] > ans[i]){
				return;
			}
		}
		for(int i = 1;i<=n;i++){
			ans[i] = check[i];
		}
	}
	for(int i = 1;i<n;i++){
		if(vis[i]){
			vis[i] = false;
			swap(now[e[i].u],now[e[i].v]);
			dfs(d + 1);
			vis[i] = true;
			swap(now[e[i].u],now[e[i].v]);
		}
	}
}
int main (){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	t = read();
	while(t > 0){
		n = read();
		memset(e,0,sizeof(e));
		memset(vis,true,sizeof(vis));
		for(int i = 1;i<=n;i++)
			now[i] = read();
		for(int i = 1;i<n;i++){
			e[i].u = read();
			e[i].v = read();
		}
		dfs(1);
		for(int i = 1;i<=n;i++){
			printf("%d ",ans[i]);
		}
		printf("\n");
		t--;
	}
	return 0;
}
