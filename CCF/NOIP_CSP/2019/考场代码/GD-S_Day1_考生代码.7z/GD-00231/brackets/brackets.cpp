#include <iostream>
#include <cstdio>
#include <cstring>
#include <cctype>
#define maxn 1000004
using namespace std;
int fa[maxn];
bool lf[maxn], rt[maxn];
int k[maxn];
int n, now = 1;
unsigned long long ans;
inline int read(){
	char ch = getchar();
	int sum = 0;
	while(!isdigit(ch)){
		ch = getchar();
	}
	while(isdigit(ch)){
		sum = sum * 10 + (ch - '0');
		ch = getchar();
	}
	return sum;
}
inline bool check(int len,int left){
	int ls = 0, rs = 0;
	for(int i = left;i<left + len;i++){
		if(lf[i]){
			ls++;
		}
		if(rt[i]){
			rs++;
		}
		if(rs > ls)
			return false;
	}
	return rs == ls;
}
void subtask1(){
	for(int i = 2;i<=n;i+=2){
		for(int l = 1;l<=n;l ++){
			if(check(i,l)){
				for(int j = l + i - 1;j<=n;j++){
					k[j]++;
				}
			}
		}
	}
	for(int i = 2;i<=n;i++){
		ans ^= ((unsigned long long)i * (unsigned long long)k[i]); 
	}
}
int main (){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	char ch = getchar();
	while(ch != '(' && ch != ')'){
		ch = getchar();
	}
	while(ch == '(' || ch == ')'){
		if(ch == '('){
			lf[now] = true;
			rt[now] = false;
			now++;
		}
		if(ch == ')'){
			lf[now] = false;
			rt[now] = true;
			now++;
		}
		ch = getchar();
	}
	bool sub1 = true;
	for(int i = 2;i<=n;i++){
		fa[i] = read();
		if(fa[i] != i - 1){
			sub1 = false;
		}
	}
	if(sub1){
		subtask1();
		printf("%d",ans);
	}
	else{
		printf("GG");
	}
	return 0;
}
