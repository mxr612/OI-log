#include <iostream>
#include <cstdio>
#include <cstring>
#include <cctype>
using namespace std;
unsigned long long n , k;
unsigned long long getnow(int p){
	if(p == 0)
		return 1;
	unsigned long long sum = 2;
	for(int i = 1;i<p;i++){
		sum *= 2;
	}
	return sum;
}
int main (){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	for(int i = n;i>0;i--){
		unsigned long long now = getnow(i), next = getnow(i - 1);
		if(next > k){
			printf("0");
		}
		else{
			if(k >= next && now > k){
				printf("1");
				k = now - k - 1;
			}
		}
	}
	return 0;
}
