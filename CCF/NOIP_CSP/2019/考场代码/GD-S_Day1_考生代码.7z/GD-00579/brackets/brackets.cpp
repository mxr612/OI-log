#include <iostream>
using namespace std;

int sum;
char f[500005];
int cnt=2;
int visit[500005];
int n,b;
string k;

struct TREE
{
	int bh;
	char kuo;
	int kk;//���ٸ��Ϸ��� 
}tree[500005];

inline int le(int x)
{
	return x<<1;
}

inline int ri(int x)
{
	return x<<1|1;
}
inline void add(int son,int fath)
{
	//���ӷ���û��?
	if(tree[le(fath)].bh!=0) 
	{
		tree[ri(fath)].bh=son;
		tree[ri(fath)].kuo=k[son-1];
	}
	else 
	{
		tree[le(fath)].bh=son;
		tree[le(fath)].kuo=k[son-1];
	}
}

inline void cheak(int k) //��� 
{
	int l=0,r=0,sum=0;
	while(f[++sum]=='(' || f[sum]==')')
	{
		if(f[sum]=='(') l++;
		if(f[sum]==')')
		{
			if(l>0) 
			{
				l--;
				tree[k].kk++;
			}
		}
	}
}

inline void dfs(int now) //now����������ı�� 
{
	if(now!=1 && visit[now]==0) 
	{
		cheak(now);
		visit[now]=1;
	}	
	if(tree[le(now)].bh!=0)
	{
		f[cnt]=tree[le(now)].kuo;
		cnt++;
		
		dfs(le(now));
		
		cnt--;
		f[cnt]='0';
	}		
	
	if(tree[ri(now)].bh!=0)
	{
		f[cnt]=tree[ri(now)].kuo;
		cnt++;
		visit[now]=1;
		
		dfs(ri(now));
		
		visit[now]=0;
		cnt--;
		f[cnt]='0';
	}
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n>>k;
	tree[1].bh=1;
	tree[1].kuo=k[0];
	for(int i=2;i<=n;i++) 
	{
		cin>>b;
		add(i,b);
	}//���� 
	
	f[1]=tree[1].kuo;
	dfs(1);
	
	int nmsl=0;
	for(int i=1;i<=n;i++) nmsl=nmsl^(i*tree[i].kk);
	cout<<nmsl;
//	cout<<endl;
//	for(int i=1;i<=n;i++) cout<<tree[i].bh<<" "<<tree[i].kk<<" "<<tree[i].kuo<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
