#include <iostream>
#include <algorithm>
using namespace std;
int a[2005];
int n;
int map[2005][2005];
int cnt=0;
int b[2005];
int visit[2005];
int c[2005];
int flag;

struct F
{
	int x,y;
}f[2005];

inline void sb()
{
	for(int i=1;i<=n-1;i++)
	{
		swap(a[f[b[i]].x],a[f[b[i]].y]);
	}
	for(int i=1;i<=n;i++) 
	{
		if(c[i]<a[i])
		{
			flag=1;
			return ;
		}	
	}
}

inline void dfs(int k)
{
	if(flag==1)return ;
	if(k==n-1)
	{
		sb();
	}
	else
	{
		for(int i=1;i<=n-1;i++)
		{
			if(visit[i]==1) continue; 
			b[k]=i;
			visit[i]=1;
			dfs(k+1);
			visit[i]=0;
			b[k]=0;
		}
	}
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int t;
	cin>>t;
	while(t--)
	{
		flag=0;
		memset(f,sizeof(f),0);
		memset(a,sizeof(a),0);
		memset(map,sizeof(map),0);
		memset(b,sizeof(b),0);
		memset(visit,sizeof(visit),0);
		memset(c,sizeof(c),0);
		cnt=0;
		cin>>n;
		for(int i=1;i<=n;i++) cin>>a[i];
		for(int i=1;i<=n-1;i++) 
		{
			cin>>x>>y;
			map[x][y]=1,map[y][x]=1;
			f[1].x=x,f[1].y=y;
		}
		dfs(1);
	}
	for(int i=1;i=n-1;i++) cout<<a[i];
	fclose(stdin);
	fclose(stdout);
	return 0;
}
