#include <iostream>
using namespace std;
int a[70];
long long f[65]={1,2};
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	
	int n;
	long long k;
	cin>>n>>k;
	
	for(int i=2;i<=n;i++)
	{
		if(i==63)
		{
			f[i]=(f[i-1]-1)*2+1;//���⴦�� 
		}
		else f[i]=f[i-1]*2;
	}
/*
	long long l=k-1;
	for(int i=n;i>=1;i--)
	{
		if(l>(f[i-1]-1))
		{
			l=f[i]-1-l;
			a[n-i+1]=1;
		}
		else a[n-i+1]=0;
	}
*/

	long long l=k;
	int b=n;
	while(b!=0)
	{
		if(b==63 && l==f[b]) a[b]=0; 
		if(l%4==0 || l%4==1) a[b]=0;//1 4 5 8 
		else a[b]=1;//2 3 6 7
		
	//	cout<<"b,l:  "<<b<<" "<<l<<" "<<f[b]<<" "<<a[b]<<endl;
		b--;
		l=(l-1)/2+1;	
	}
	for(int i=1;i<=n;i++) cout<<a[i];
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
