#include<bits/stdc++.h>
using std::cin;
using std::cout;
using std::endl;
int t,n,a[2010],ok=1,ind[2010],tt,l,r,min=0x3f3f3f,now;
int f[2010][2010];
void read(int &x)
{
	int f=1;
	x=0;
	char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9') {x=x*10+c-'0';c=getchar();}
	x*=f;
}
void dfsmin(int x,int fa)
{
	min=std::min(min,a[x]);
	for(int i=1;i<=n;i++)
	{
		if(i==fa||i==x) continue;
		if(!f[x][i]) continue;
		dfsmin(i,x);
	}
}
void dfs1(int x,int fa)
{
	
	for(int i=1;i<=n;i++)
	{
		if(i==fa||i==x) continue;
		if(!f[x][i]) continue;
		if(a[i]==min)
		{
			min=0x3f3f3f;
			r=i;
			f[x][i]=0;
			f[i][x]=0;
			std::swap(a[x],a[i]);
			tt++;
			now=0;
			return;
		}
		dfs1(i,x);
		if(now==0)
		{
			f[x][i]=0;
			f[i][x]=0;
			std::swap(a[x],a[i]);
			tt++;
			return;
		}
	}
}
int main()
{
	freopen("tree.in","w",stdin);
	freopen("tree.out","r",stdout);
	read(t);
	for(int i=1;i<=t;i++)
	{
		read(n);
		for(int i=1;i<=n;i++) read(a[i]);
		for(int i=1;i<n;i++)
		{
			int x,y;
			read(x);read(y);
			f[x][y]=1;
			f[y][x]=1;
			ind[x]++;
			ind[y]++;
			if(ind[x]>2||ind[y]>2) ok=0;
			if(ind[x]==n-1||ind[y]==n-1) ok=2;
		}
		l=1;
		if(ok==1)
		{
			while(tt<n-1) 
			{
				now=1;
				min=0x3f3f3f;
				dfsmin(l,0);
				dfs1(l,0);
				now=1;
				min=0x3f3f3f;
				dfsmin(r,0);
				dfs1(r,0);
				if(a[r]==min) break;
			}
			for(int i=1;i<=n;i++) cout<<a[i]<<" ";
		}
	}
	return 0;
}
