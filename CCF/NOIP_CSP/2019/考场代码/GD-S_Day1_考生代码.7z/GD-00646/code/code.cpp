#include<bits/stdc++.h>
using std::cin;
using std::cout;
using std::endl;
long long n,k,ans;
long long a[100000001];
long long st1[15][1<<15]={{0},{0,1},{0,1,3,2},{0,1,3,2,6,7,5,4},{0,1,3,2,6,7,5,4,12,13,15,14,10,11,9,8},{0,1,3,2,6,7,5,4,12,13,15,14,10,11,9,8,24,25,27,26,30,31,29,28,20,21,23,22,18,19,17,16}};
long long kkk(long long x,long long y)
{
	if(y==2) return x*x;
	if(y==1) return x;
	if(y%2==0)
	{
		long long z=kkk(x,y/2);
		return z*z;
	}
	else
	{
		long long z=kkk(x,y/2);
		return z*z*x;
	}
}
long long work(long long x,long long k)
{
	if(x<=5)
	{
		return st1[x][k];
	}
	if(k<=(kkk(2,x-1)-1)) return work(x-1,k);
	else
	{
		return work(x-1,kkk(2,x)-1-k)+(kkk(2,x-1));
	}
	if(k==kkk(2,x)-1)
	{
		return kkk(2,x-1);
	}
}
int main()
{
	freopen("code.in","w",stdin);
	freopen("code.out","r",stdout);
	cin>>n>>k;
	ans=work(n,k);
	std::stack<int> p;
	for(int i=0;i<n;i++) p.push((ans>>i)&1);
	while(!p.empty())
	{
		cout<<p.top();
		p.pop();
	}
	return 0;
}
