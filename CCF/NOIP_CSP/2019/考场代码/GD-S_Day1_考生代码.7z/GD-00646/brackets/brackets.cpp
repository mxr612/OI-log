#include<bits/stdc++.h>
using std::cin;
using std::cout;
using std::endl;
int n,ans,fa[500401],ok=1,sum[500401];
std::string p,ola;
std::vector<int> v[500401];
std::stack<std::pair<char,int> > q;
char a[500401];
char now[500401],cnt;
void read(int &x)
{
	int f=1;
	x=0;
	char c=getchar();
	while(c<'0'||c>'9') {if(c=='-') f=-1;c=getchar();}
	while(c>='0'&&c<='9') {x=x*10+c-'0';c=getchar();}
	x*=f;
}

void work()
{
	int s=0,ans1;
	while(!q.empty())q.pop();
		memset(sum,0,sizeof(sum));
		for(int i=1;i<=n;i++)
		{
			sum[i]+=sum[i-1];
			if(q.empty())
			{
				q.push(std::make_pair(a[i],i));
				continue;
			}
			if(q.top().first=='('&&a[i]==')')
			{
				sum[i]++;
				sum[i]-=(sum[i-1]-sum[q.top().second]);
				ans1++;
				q.pop();
				ans1+=((sum[i]-1-sum[q.top().second]));
			}
			else q.push(std::make_pair(a[i],i));
		}
	ans+=ans1;
}
void dfs(int x)
{
	now[++cnt]=a[x];
	if(cnt==n)
	{
		work();
	}
	for(int i=0;i<v[x].size();i++)
	{
		int to=v[x][i];
		if(to==fa[x]) continue;
		dfs(to);
		ola.erase();
		now[cnt]=0;
		cnt--;
	}
}
int main()
{
	freopen("brackets.in","w",stdin);
	freopen("brackets.out","r",stdout);
	read(n);
	cin>>p;
	for(int i=1;i<=n;i++) a[i]=p[i-1];
	for(int i=2;i<n;i++)
	{
		int x;
		read(x);
		v[x].push_back(i);
		v[i].push_back(x);
		fa[i]=x;
		if(fa[i]!=i-1) ok=0;
	}
	if(ok==1)
	{
		int s=0;
		memset(sum,0,sizeof(sum));
		for(int i=1;i<=n;i++)
		{
			sum[i]+=sum[i-1];
			if(q.empty())
			{
				q.push(std::make_pair(a[i],i));
				continue;
			}
			if(q.top().first=='('&&a[i]==')')
			{
				sum[i]++;
				sum[i]-=(sum[i-1]-sum[q.top().second]);
				ans++;
				q.pop();
				ans+=((sum[i]-1-sum[q.top().second]));
			}
			else q.push(std::make_pair(a[i],i));
		}
		cout<<ans;
		return 0;
	}
	dfs(1);
	cout<<ans;
	return 0;
}
