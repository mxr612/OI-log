#include<cstdio>
#include<iostream>
using namespace std;
#define ll long long
ll n,k;
int cbit;
void cnt(ll x){
	if(x<2){
		cbit++;return;
	}
	cnt(x/2),cbit++;
}
void print(ll x){
	if(x<2){
		putchar(x|48);return;
	}
	print(x/2),putchar((x%2)|48);
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	ll ans=(k/2)^k;
	cnt(ans);int tot=n-cbit;
	while(tot--){
		putchar(0|48);
	}
	print(ans);
	return 0;
}
