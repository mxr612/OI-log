#include<bits/stdc++.h>
using namespace std;
const int N=2e3+10;
int T,n,val[N];
map<pair<int,int>,int> avai;
inline bool cmp(int x,int y){
	if(avai[make_pair(x,y)]){
		avai[make_pair(x,y)]=0;avai[make_pair(y,x)]=0;
		return x<y;
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	srand(unsigned(time(0)));
	scanf("%d",&T);
	while(T--){
		memset(val,0,sizeof val);
		avai.clear();
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",&val[i]);
		for(int i=1;i<n;i++){
			int x,y;scanf("%d %d",&x,&y);
			avai[make_pair(x,y)]=1;avai[make_pair(y,x)]=1;
		}
		int t=5*n;
		while(t--){
			random_shuffle(val+1,val+n+1);
			sort(val+1,val+n+1,cmp);
		}
		for(int i=1;i<=n;i++)
			printf("%d ",val[i]);
		putchar(10);
	}
	return 0;
}