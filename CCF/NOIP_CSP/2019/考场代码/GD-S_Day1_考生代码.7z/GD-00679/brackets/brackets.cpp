#include<cstdio>
#include<iostream>
#include<vector>
#include<algorithm>
#include<cstring>
#include<string>
using namespace std;
inline int read(){
	int data=0,w=1;char ch=0;
	while(ch!='-' && (ch<'0'||ch>'9'))ch=getchar();
	if(ch=='-')w=-1,ch=getchar();
	while(ch>='0' && ch<='9')data=data*10+ch-'0',ch=getchar();
	return data*w;
}
const int N=5e5+10;
char kh[N];
vector<char> v;
int n;
int fa[N];
int match(string str){
	while(v.size())v.pop_back();
	if(str=="")return 0;
	int len=str.length();
	if(len%2)return 0;
	v.push_back(str[0]);
	for(int i=1;i<len;i++){
		char s=v.back();
		if(str[i]==')'&&s=='(')v.pop_back();
		else v.push_back(str[i]);
	}
	return v.empty()?1:0;
}
char seq[N];int cnt;
string sseq;
void solve(int x){
	if(fa[x])solve(fa[x]);
	seq[cnt++]=kh[x];
}
string subseq;
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	n=read();
	scanf("%s",kh+1);
	for(int i=1;i<n;i++){
		int x=read();fa[i+1]=x;
	}
	int num,ans=0;
	for(int i=2;i<=n;i++){
		num=0;
		memset(seq,0,sizeof seq);cnt=0;
		solve(i);sseq=seq;
		for(int j=0;j<sseq.length();j++)
			for(int k=j;k<sseq.length();k++){
					subseq=sseq.substr(j,k-j+1);
					num+=match(subseq);
			}
		ans^=(i*num);
	}
	printf("%d",ans);
	return 0;
}