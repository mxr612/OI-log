#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define ll long long

using namespace std;

const int N = 0;
const int a[4] = {0, 1, 1, 0};

int n;
ll m;

void poutt(ll num, int n)
{
	if(!n) return;
	poutt(num / 2, n-1);
	printf("%lld", num %2);
}


void dfs(bool isLeft, ll x, ll num, int depth)
{
	if(depth == n + 1)
	{
		poutt(x, n);
		return ;
	}
	if(num + (1ll << (n - depth)) <= m) 
		dfs(0, x + ((isLeft ^ 0ll) << (n - depth)) , num + (1ll << (n - depth)), depth+1);
	else 
		dfs(1, x + ((isLeft ^ 1ll) << (n - depth)) , num, depth+1);
}

int main()
{
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	scanf("%d%lld", &n, &m);
	dfs(1, 0, 0, 1);
	return 0;
}
