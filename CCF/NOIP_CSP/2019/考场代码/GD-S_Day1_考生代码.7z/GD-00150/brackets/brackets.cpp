#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define ll long long

using namespace std;

const int N = 500010;

int n;
int fa[N];
int val[N];
ll ans[N][2];
bool vis[N];
ll answer;

void dfs(int x)
{
	vis[x] = 1;
	if(vis[fa[x]])
	{
		if(ans[fa[x]][0] > 0 && val[x] == -1)
		{
			ans[x][1] = ans[fa[x]][1] + 1;
		}
		ans[x][0] = ans[fa[x]][0] + val[x];
		if(ans[x][0] < 0) ans[x][0] = 0;
		return;
	}
	dfs(fa[x]);
	if(ans[fa[x]][0] > 0 && val[x] == -1)
	{
		ans[x][1] = ans[fa[x]][1] + 1;
	}
	ans[x][0] = ans[fa[x]][0] + val[x];
	if(ans[x][0] < 0) ans[x][0] = 0;
}

int main()
{
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
	{
		char c = getchar();
		while(c != '(' && c != ')') c = getchar();
		if(c == '(') val[i] = 1;
		else val[i] = -1;
	}
	vis[1] = 1;
	ans[1][0] = val[1];
	for (int i = 2; i <= n; i++)
		scanf("%d", &fa[i]);
	for (int i = 2; i <= n; i++)
	{
		if(vis[i]) continue;
		dfs(i);
		answer ^= 1ll * ans[i][1] * i;
	}
	printf("%lld", answer);
	return 0;
}

