#include <cmath>
#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
#define ll long long

using namespace std;

const int N = 2010;

int t, n, a[N];
bool b[N][N];

int main()
{
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	for (scanf("%d", &t); t--;)
	{
		memset(b, 0, sizeof(b));
		scanf("%d", &n);
		for (int i = 1; i <= n; i++)
			scanf("%d", &a[i]);
		for (int i = 1; i < n; i++)
		{
			int x, y;scanf("%d%d", &x, &y);
			b[x][y] = 1;b[y][x] = 1;
		}
		for (int i = 1; i < n; i++)
			for (int j = i + 1; j <= n; j++)
				if(a[i] > a[j] && b[i][j])
				{
					b[i][j] = 0;
					int t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
		for (int i = 1; i < n; i++)
			for (int j = i + 1; j <= n; j++)
				if(a[i] > a[j] && b[i][j])
				{
					b[i][j] = 0;
					int t = a[i];
					a[i] = a[j];
					a[j] = t;
				}
		for (int i = 1; i <= n; i++)
			printf("%d ", a[i]);
		puts("");
	}
	return 0;
}

