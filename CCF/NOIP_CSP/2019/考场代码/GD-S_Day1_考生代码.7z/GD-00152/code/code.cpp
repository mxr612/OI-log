#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long LL;
LL n,k;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	int cur = 0;
	for(LL i=1;i<=n;i++)
	{
		LL s = 1LL<<(n-i);
		if(cur == 0)
		{
			if(k&s)
			{
				cur = 1;
				printf("1");
			}
			else 
			{
				printf("0");
			}
		}
		else
		{
			if(k&s)
			{
				printf("0");
			}
			else
			{
				printf("1");
				cur = 0;
			}
		}
	}
	return 0;
}
/*
44 4444444444444
*/
