#include<bits/stdc++.h>
using namespace std;
const int N = 2300;
int dl[N][N];
int nex[N<<1],head[N<<1],to[N<<1],hard[N];
int cnt ;
int val[N],pos[N];
int p;
int dep[N];
int fa[N];
int rd[N];
/*
void add(int x,int y)
{
	nex[++cnt] = head[x];
	head[x] = cnt;
	to[cnt] = y;
}
void find(int x,int pre)
{
	if(val[x] < val[p])
		p=x;
	for(int i=head[x];i;i=nex[i])if(dl[x][to[i]] !=-1 && hard[to[i]]!=1)
	{
		int v = to[i];
		if(v!=pre) 
		{
			find(v,x);
		}
	}
}
void lca(int x,int y)
{
	if(dep[x]<dep[y]) swap(x,y);
	while(dep[x]>dep[y])
	{
		dl[x][fa[x]] = dl[fa[x]][x] = -1;
		swap(val[x],val[fa[x]]);
		swap(pos[val[x]],pos[val[fa[x]]]);
		x=fa[x];
	}
	if(x==y) return;
	while(fa[x]!=fa[y])
	{
		dl[x][fa[x]] = dl[fa[x]][x] = -1;
		x=fa[x];
		swap(val[x],val[fa[x]]);
		swap(pos[val[x]],pos[val[fa[x]]]);
		dl[y][fa[y]] = dl[fa[y]][y] = -1;
		y=fa[y]; 
		swap(val[y],val[fa[y]]);
		swap(pos[val[y]],pos[val[fa[y]]]);
	}
	dl[x][fa[x]] = dl[fa[x]][x] = -1;
}
void dfs(int u,int pre)
{
	fa[u] = pre;
	dep[u] = dep[pre] + 1;
	for(int i=head[u];i;i=nex[i]) if(dl[u][to[i]]!=-1)
	{
		int v=to[i];
		if(v!=pre) dfs(v,u);
	}
}*/
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--)
	{
		memset(dl,0,sizeof(dl));
		cnt = 0;
		int n,x,y;
		memset(head,0,sizeof(head));
		memset(dep,0,sizeof(dep));
		memset(hard,0,sizeof(hard));
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		  {
		  	scanf("%d",&x);
		  	val[x] = i;
		  	pos[i] = x;
		  }
		for(int i=1;i<n;i++)
		  scanf("%d%d",&x,&y),rd[x]++,rd[y]++;
		int rt = 0;
		for(int i=1;i<=n;i++) if(rd[i]==n-1) rt = i;
		int least = 1;
		for(int i=1;i<=n;i++)
		{
			if(pos[i] == rt)
			{
				if(least == rt) 
				{
					printf("%d ",least+1);
					swap(val[pos[i]],val[least+1]);
					swap(pos[i],pos[val[least+1]]);
					dep[least+1] = 1;
					continue;
				}
				swap(val[least],val[pos[i]]);
				swap(pos[i],pos[val[least]]);
				dep[least] = 1;
				while(dep[least]==1)least ++;
			}
			else 
			{
				printf("%d ",least);
				swap(val[least],val[pos[i]]);
				swap(pos[i],pos[val[least]]);
				dep[least] = 1;
				while(dep[least] == 1)least ++;
			}
		}
	}
	return 0;
}
