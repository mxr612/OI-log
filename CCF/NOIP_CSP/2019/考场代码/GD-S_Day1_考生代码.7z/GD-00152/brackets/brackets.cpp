#include<bits/stdc++.h>
using namespace std;
const int N = 500020;
int nex[N],to[N],head[N],siz[N],dfn[N],fa[N];
int tong[N];
typedef long long LL;
struct node{
	int l,r,ls,rs;
	LL lag;
	node()
	{
		l=r=ls=rs=0;
		lag  = 0;
	}	
};
node f[N<<2];
int a[N];
int cnt=0,ti=0;
int fp=0;
char s[N];
void add(int x,int y)
{
	nex[++cnt] = head[x];
	to[cnt] = y;
	head[x] = cnt;
}
void dfs(int u,int pre)
{
	siz[u] = 1;
	dfn[u] = ++ti;
	for(int i=head[u];i;i=nex[i])
	{
		int v=to[i];
		if(v!=pre)
		{
			dfs(v,u);
			siz[u] += siz[v];
		}
	}
}
void build(int &u,int l,int r)
{
	u=++fp;
	f[u].l=l;
	f[u].r=r;
	if(l==r)
	{
		f[u].lag = 0;
		return ;
	}
	int mid = (l+r)>>1;
	build(f[u].ls,l,mid);
	build(f[u].rs,mid+1,r);
}
void pushdown(int u)
{
	if(!f[u].lag) return ;
	int ls = f[u].ls,rs=f[u].rs;
	f[ls].lag += f[u].lag;
	f[rs].lag += f[u].lag;
	f[u].lag = 0;  
}
void update(int u,int l,int r,LL z)
{
	if(f[u].l >r || f[u].r < l) return;
	if(l<=f[u].l && f[u].r<=r)
	{
		f[u].lag += z;
		return ;
	}
	pushdown(u);
	update(f[u].ls,l,r,z);
	update(f[u].rs,l,r,z);
}
LL query(int u,int x)
{
	if(x<f[u].l || x>f[u].r) return 0;
	if(f[u].l == f[u].r && x==f[u].l)
	  return f[u].lag;
	LL ans = 0;
	pushdown(u);
	ans = query(f[u].ls,x) + query(f[u].rs,x);
	return ans;
}
queue<int> q;
int md=0;
void sol(int u,int tot)
{
	if(a[u] ==1) tot--;
	else tot++;
	if(tot < 0) return ;
	if(tot == 0) md ++;
	if(u==1) return ;
	sol(fa[u],tot);
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n;
	scanf("%d",&n);
	scanf("%s",&s);
	int len =strlen(s);
	for(int i=0;i<len;i++)
	  if(s[i] == '(') a[i+1] = 1;
	  else a[i+1] = 0;
	for(int i=2;i<=n;i++)
	  {
	  	scanf("%d",&fa[i]);
	  	add(fa[i],i);
	  }
	dfs(1,0);
	int rt;
	build(rt,1,n);
	LL ans = 0;
	for(int i=1;i<=n;i++)
	{
		md = 0;
		 sol(i,0);
		 update(1,dfn[i],dfn[i]+siz[i]-1,md);
	}
	for(int i=1;i<=n;i++)
	{
		LL tmp = query(1,dfn[i]);
		ans = ans ^ (1LL*i*tmp);
	}
	printf("%lld\n",ans);
	return 0;
}
/*
*/
