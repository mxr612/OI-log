#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	long long n,m,a[100],b[100];
	scanf("%lld%lld",&n,&m);
	m+=1;
	a[1]=1;
	for(int i=2;i<=65;++i)
	{
		a[i]=a[i-1]*2;
	}
	for(int i=1;i<=64;++i)
	{
		printf("%d\n",a[i]);
	}
	int s=0;
	while(n>0)
	{
		int zhong=a[n+1]/2;
		if(m>zhong)
		{
			b[++s]=1;
			m=zhong-(m-zhong)+1;
		}
		else
		{
			b[++s]=0;
		}
		n-=1;
	}
	for(int i=1;i<=s;++i) printf("%lld",b[i]);
	return 0;
}
