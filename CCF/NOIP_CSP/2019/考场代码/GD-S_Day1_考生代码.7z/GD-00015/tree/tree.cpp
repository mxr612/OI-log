#include<bits/stdc++.h>
using namespace std;
struct data {
	int num,fa,id;
	friend bool operator <(const data a,const data b) {
		if(a.fa!=b.fa) return a.fa>b.fa;
		return a.num>b.num;
	}
} e[2005];
vector <int> tree[2005];
bool cmp(data a,data b) {
	if(a.fa!=b.fa) return a.fa<b.fa;
	else return a.num<b.num;
}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int t;
	cin>>t;
	while(t--) {
		for(int i=0; i<2005; i++) e[i].fa=0;
		for(int i=0; i<2005; i++) tree[i].clear();
		int n;
		cin>>n;
		for(int i=1; i<=n; i++) cin>>e[i].num,e[i].id=i;
		for(int i=1; i<n; i++) {
			int a,b;
			cin>>a>>b;
			tree[a].push_back(b);
			e[b].fa++;
		}
		sort(e+1,e+n+1,cmp);
		priority_queue <int> q;
		q.push(e[1].id);
		while(!q.empty()) {
			int t=q.top();
			q.pop();
			if(!e[t].fa) cout<<e[t].num<<' ';
			else {
				e[t].fa--;
				if(!e[t].fa) cout<<e[t].num<<' ';
			}
			for(int i=0; i<tree[t].size(); i++) {
				if(e[tree[t][i]].fa) q.push(tree[t][i]);
			}
		}
		cout<<'\n';
	}
}
