#include<bits/stdc++.h>
using namespace std;
long long n,k;
string dg(long long n,long long k){
	if(k==0) return "";
	if(n<pow(2,k-1)) return "0"+dg(n,k-1);
	else return "1"+dg(pow(2,k)-n-1,k-1);
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	cout<<dg(k,n);
}
