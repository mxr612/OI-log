#include<bits/stdc++.h>
using namespace std;
int n,ans;
char op[500005];
vector <int> tree[500005];
char sstr[5005][5005],str[500005];
bool vis[10000005];
int sti(string str) {
	int sum=0;
	for(int i=str.size()-1; i>=0; i--) {
		sum*=2;
		if(str[i]==')') sum+=1;
	}
	return sum;
}
void dfs(int k,int step) {
	str[step]=op[k];
	int strl=strlen(str)-1;
	for(int i=0;i<=strl;i++) sstr[k][i]=str[i];
//	cout<<str<<" "<<k<<'\n';
	for(int i=0; i<tree[k].size(); i++) {
		dfs(tree[k][i],step+1);
	}
	str[step]=0;
}
int dg(string str) {
	memset(vis,0,sizeof(vis));
	int cnt,ret=0;
	for(int i=0; i<str.size(); i++) {
		cnt=0;
		for(int j=i; j<str.size(); j++) {
			if(str[j]==')') cnt--;
			else cnt++;
			if(cnt<0) break;
			if(cnt==0) {
				int p=sti(str.substr(i,j-i+1));
				if(!vis[p]) {
					vis[p]=true;
					ret++;
				}
			}
		}
	}
	return ret;
}
int main() {
//	freopen("brackets.in","r",stdin);
//	freopen("brackets.out","w",stdout);
	cin>>n;
	for(int i=1; i<=n; i++) {
		cin>>op[i];
	}
	for(int i=2; i<=n; i++) {
		int a;
		cin>>a;
		tree[a].push_back(i);
	}
	dfs(1,0);
	cout<<"dfs";
	ans=dg(sstr[1]);
	for(int i=2; i<=n; i++) {
		ans=ans xor (i*dg(sstr[i]));
	}
	cout<<ans;
}
