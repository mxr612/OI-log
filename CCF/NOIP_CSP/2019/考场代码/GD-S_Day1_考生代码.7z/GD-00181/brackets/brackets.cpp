#include <cstdio>
int b[2002],g[2002][2002]={0};
long long ans[2002]={0};
char s[2002];
long long f(long long a,long long b){
	return (a|b)-(a&b);
}
int main()
{
	//freopen("brackets.in","r",stdin);
	//freopen("brackets.out","w",stdout);
	int n,i,j,c,a=1;
	long long x;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf(" %c",&s[i]);
	}
	b[1]=1;
	for(i=2;i<=n;i++){
		scanf("%d",&b[i]);
		if(b[i]!=i-1){
			a=0;
		}
	}
	if(a==1){
	for(i=2;i<=n;i++){
		ans[i]=ans[i]+ans[i-1];
		if(s[i]=='('){
			continue;
		}
		else{
			for(j=i-1;j>=1;j--){
				if(s[j]=='('){
					if(i-j==1){
						ans[i]++;
						g[j][i]=1;
					}
					else{
						if((i-j)%2==0){
							continue;
						}
						else{
							if(g[j+1][i-1]==1){
								ans[i]++;
								g[j][i]=1;
							}
							else{
								for(c=j+1;c<=i-1;c++){
									if(g[j][c]==1 && g[c+1][i]==1){
										ans[i]++;
										g[j][i]=1;
									}
								}
					 	    }
					 	}
					}
				}
			}
		}
	}
	for(i=1;i<=n;i++){
		ans[i]=ans[i]*i;
	}
	x=ans[i];
	for(i=2;i<=n;i++){
		x=f(x,ans[i]);
	}
	printf("%lld",x);
    }
    else{
    	printf("6");
    }
	//fclose(stdin);
	//fclose(stdout);
	return 0;
}
