#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int g[2001][2001];
bool pd[2001];
struct aaa{
	int wz,shu;
}a[2002];
bool comp(aaa w,aaa v){
	return w.wz<v.wz;
}
int main()
{
	int T,n,i,x,y,b=0,k,tmp,m=1;
	scanf("%d",&T);
	while(T--){
		memset(g,0,sizeof(g));
		scanf("%d",&n);
		for(i=1;i<=n;i++){
			a[i].shu=0;
			pd[i]=0;
		}
		for(i=1;i<=n;i++){
			scanf("%d",&a[i].shu);
			a[i].wz=i;
		}
		for(i=1;i<=n-1;i++){
			scanf("%d %d",&x,&y);
		}
		int b=n-1;
	    while(b){
			int minn=20000;
			for(i=1;i<=n;i++){
				if(pd[i]==0 && a[i].shu<minn && i!=m){
					k=i;
					minn=a[i].shu;
				}
			}
			a[k].wz=a[k].wz-k+m;
			for(i=m;i<=k-1;i++){
				a[i].wz++;
				pd[i]=1;
			}
			b=b-k+m;
			m=k;
		}
		sort(a+1,a+n+1,comp);
		for(i=1;i<=n;i++){
			printf("%d ",a[i].shu);
		}
		printf("\n");
	}
	return 0;
}
