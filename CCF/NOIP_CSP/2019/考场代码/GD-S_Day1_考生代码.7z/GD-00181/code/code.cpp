#include <cstdio>
int a[100],b[100];
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	int n,m=0,i,j,pd=1;
	long long k,x,ans=0;
	scanf("%d %lld",&n,&k);
	for(i=n;i>=1;i--){
		x=1;
		m++;
		for(j=1;j<=i-1;j++){
			x=2*x;
		}
		if(k>=x){
			a[m]=1;
			k=k-x;
		}
		else{
			a[m]=0;
		}
	}
    for(i=1;i<=n;i++){
    	x=1;
    	if(a[i]==pd){
    		for(j=1;j<=n-i;j++){
    			x=x*2;
    		}
    		ans=ans+x;
    		if(pd==0){
    			pd=1;
    		}
    		else{
    			pd=0;
    		}
    	}
    }
    m=0;
    for(i=n;i>=1;i--){
		x=1;
		m++;
		for(j=1;j<=i-1;j++){
			x=2*x;
		}
		if(ans>=x){
			b[m]=1;
			ans=ans-x;
		}
		else{
			b[m]=0;
		}
	}
	for(i=1;i<=n;i++){
		printf("%d",b[i]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
