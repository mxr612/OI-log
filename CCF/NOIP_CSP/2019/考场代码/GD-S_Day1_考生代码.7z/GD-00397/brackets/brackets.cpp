#include <iostream>
#include <cstdio>
#include <string> 
using namespace std;
const int maxn = 500050;
int n,t,a[maxn],last[maxn],fa[maxn];
long long ans,f[maxn];
string s;
struct edge{
	int u,v,nxt;
}e[maxn];
int read(){
	int x = 0;
	char c = getchar();
	while(c < '0' || c > '9') c = getchar();
	while(c >= '0' && c <= '9') x = x * 10 + (c ^ 48),c = getchar();
	return x;
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	n = read();
	cin >> s;
	for(int i = 0; i < n; i ++) if(s[i] == '(') a[i + 1] = 1;
	for(int i = 2; i <= n; i ++){
		fa[i] = read();
		e[i].u = fa[i],e[i].v = i,e[i].nxt = last[fa[i]],last[fa[i]] = i;
	}
	for(int i = 1; i <= n; i ++){
		f[i] = f[fa[i]],t = 0;
		for(int j = i; j; j = fa[j]){
			if(a[j]) t --;
			else t ++;
			if(t == 0) f[i] ++;
			else if(t < 0) break;
		}
	}
	ans = f[1];
	for(int i = 2; i <= n; i ++) ans = ans ^ (i * f[i]);
	cout << ans << endl;
	return 0;
}
