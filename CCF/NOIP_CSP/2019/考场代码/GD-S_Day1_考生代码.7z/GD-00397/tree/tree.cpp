#include <iostream>
#include <cstdio>
#include <algorithm>
using namespace std;
const int maxn = 2050,inf = 1e9;
int T,n,x,y,t,a[maxn],last[maxn],d[maxn],v[maxn],ans[maxn];
struct edge{
	int u,v,nxt;
}e[2 * maxn];
struct node{
	int num,pos;
}b[maxn];
int read(){
	int x = 0;
	char c = getchar();
	while(c < '0' || c > '9') c = getchar();
	while(c >= '0' && c <= '9') x = x * 10 + (c ^ 48),c = getchar();
	return x;
}
void insert(int x,int y,int k){
	e[k].u = x,e[k].v = y,e[k].nxt = last[x],last[x] = k;
}
bool cmp(node x,node y){
	return x.num < y.num;
}
void dfs(int x){
	if(x == n){
		for(int i = 1; i <= n; i ++) b[i].num = a[i],b[i].pos = i;
		sort(b + 1,b + 1 + n,cmp);
		for(int i = 1; i <= n; i ++){
			if(ans[i] < b[i].pos) break;
			else if(ans[i] > b[i].pos){
				for(int j = 1; j <= n; j ++) ans[j] = b[j].pos;
				break;
			} 
		}
		return;
	}
	for(int i = 1; i < n; i ++){
		if(!v[i]){
			v[i] = 1;
			swap(a[e[i].u],a[e[i].v]);
			dfs(x + 1);
			v[i] = 0;
			swap(a[e[i].u],a[e[i].v]);
		}
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	T = read();
	while(T --){
		n = read();
		for(int i = 1; i <= n; i ++) ans[i] = inf;
		for(int i = 1; i <= n; i ++) t = read(),a[t] = i,last[i] = 0;
		for(int i = 1; i <= 2 * n; i ++) e[i].nxt = 0;
		for(int i = 1; i < n; i ++){
			x = read(),y = read(),d[x] ++,d[y] ++;
			insert(x,y,i);
		}
		dfs(1);
		for(int i = 1; i <= n; i ++) printf("%d ",ans[i]);
		printf("\n");
	}
	return 0;
}
