#include <iostream>
#include <cstdio>
#include <string>
using namespace std;
int n,p;
unsigned long long k,l,r,mid;
string ans;
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin >> n >> k;
	r = (1ll << (n - 1)) - 1 + (1ll << (n - 1));
	while(n){
		mid = (l + r) / 2;
		if(k <= mid){
			if(p) ans += "1";
			else ans += "0";
			r = mid,p = 0;
		}else{
			if(p) ans += "0";
			else ans += "1";
			l = mid + 1,p = 1;
		}
		n --;
	}
	cout << ans << endl;
	return 0;
}
