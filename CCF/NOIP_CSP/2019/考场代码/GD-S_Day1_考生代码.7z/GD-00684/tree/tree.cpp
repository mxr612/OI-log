#include<cstdio>
#include<iostream>
#include<algorithm>
#include<queue>
#include<cmath>
#include<cstring>
#include<math.h>
#define inc(i,a,b) for(register int (i)=(a);(i)<=(b);i++)
#define dec(i,a,b) for(register int (i)=(a);(i)>=(b);i--)
using namespace std;
void read(int &x)
{
	x=0;bool f=false;char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=true;c=getchar();}
	while(c<='9'&&c>='0')x=(x<<3)+(x<<1)+c-'0',c=getchar();
	if(f)x=-x;return;
}
int T;
typedef long long LL;
const int mx=5e5+7;
struct node
{
	int n,t;
}nx[mx<<1];
int h[mx],cnt;
void add(int u,int v)
{
	nx[++cnt].n=h[u];
	nx[cnt].t=v;
	h[u]=cnt;
}
int n,a[mx],x,y,b[mx];
bool vis[mx];
int main()
{
	freopen("tree","r",stdin);
	freopen("tree","w",stdout);
	read(T);
	while(T--)
	{
		read(n);
		inc(i,1,n)read(a[i]),b[a[i]]=i;
		inc(i,1,n-1)read(x),read(y);
		sort(a+1,a+n+1);
		inc(i,1,n)printf("%d ",a[i]);
	}
}
