#include<cstdio>
#include<iostream>
#include<algorithm>
#include<queue>
#include<cmath>
#include<cstring>
#include<math.h>
#define inc(i,a,b) for(register int (i)=(a);(i)<=(b);i++)
#define dec(i,a,b) for(register int (i)=(a);(i)>=(b);i--)
using namespace std;
void read(int &x)
{
	x=0;bool f=false;char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=true;c=getchar();}
	while(c<='9'&&c>='0')x=(x<<3)+(x<<1)+c-'0',c=getchar();
	if(f)x=-x;return;
}
typedef long long LL;
const int mx=5e5+7;
struct node
{
	int n,t;
}nx[mx<<1];
int h[mx],cnt;
void add(int u,int v)
{
	nx[++cnt].n=h[u];
	nx[cnt].t=v;
	h[u]=cnt;
}
int n,fa[mx];
LL con[mx],dp[mx],ret;
bool sp[mx];
std::queue <int> q;
void dfs(int x,int f)
{
	dp[x]=dp[f];
	if(sp[x])
	{
		con[x]=con[f];
		if(sp[f])con[x]=0;
	}
	if((!sp[x])&&(q.empty()))con[x]=0;
	if((!sp[x])&&(!q.empty()))
	{
		con[x]=con[q.front()]+1;
		q.pop();
		dp[x]=dp[f]+con[x];
	}
	ret=ret^(x*dp[x]);
	for(int i=h[x];i;i=nx[i].n)
	{
		if(sp[x]&&(q.front()!=x))q.push(x);
		dfs(nx[i].t,x);
	}
	if(sp[x]&&q.front()==x)q.pop();
	return;
}
void sread(bool &x)
{
	char c=getchar();
	while(c!='('&&c!=')')c=getchar();
	if(c=='(')x=true;
	else x=false;
	return;	
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	read(n);
	inc(i,1,n)sread(sp[i]);
	inc(i,2,n)
	{
		read(fa[i]);
		add(fa[i],i);
	}
	dfs(1,0);
	printf("%lld",ret);
}
