#include<cstdio>
#include<iostream>
#include<algorithm>
#include<queue>
#include<cmath>
#include<cstring>
#include<math.h>
#define inc(i,a,b) for(register int (i)=(a);(i)<=(b);i++)
#define dec(i,a,b) for(register int (i)=(a);(i)>=(b);i--)
using namespace std;
void read(int &x)
{
	x=0;bool f=false;char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=true;c=getchar();}
	while(c<='9'&&c>='0')x=(x<<3)+(x<<1)+c-'0',c=getchar();
	if(f)x=-x;return;
}
int n,a[30],len,cimi[80][30],len2[80];
bool cmp(int x)
{
	if(len<len2[x])return false;
	if(len>len2[x])return true;
	dec(i,len,1)
	{
		if(a[i]>cimi[x][i])return true;
		if(a[i]<cimi[x][i])return false;
	}
	return false;
}
void putans()
{
	char c=getchar();
	while(c>'9'||c<'0')c=getchar();
	while(c<='9'&&c>='0')a[++len]=c-'0',c=getchar();
	a[1]++;
	inc(j,1,len)if(a[j]>9)
	{
		a[j+1]+=a[j]/10;
		a[j]=(a[j]+10)%10;
	}
	if(a[len+1])len++;
	while(n>=0)
	{
		if(cmp(n))
		{
			a[1]--;len=len2[n+1];
			inc(j,1,len2[n+1])a[j]=cimi[n+1][j]-a[j];
			inc(j,1,len2[n+1])if(a[j]<0)
			{
				a[j+1]--;
				a[j]=a[j]+10;
			}
			while(a[len]==0)len--;
			printf("1");
		}
		else printf("0");
		n--;
	}
}
void prep(int x)
{
	cimi[0][1]=1;len2[0]=1;
	cimi[1][1]=2;len2[1]=1;
	inc(i,2,x)
	{
		len2[i]=len2[i-1];
		inc(j,1,len2[i-1])
			cimi[i][j]=cimi[i-1][j]<<1;
		inc(j,1,len2[i-1])if(cimi[i][j]>9)
		{
			cimi[i][j+1]+=cimi[i][j]/10;
			cimi[i][j]=(cimi[i][j]+10)%10;
		}
		if(cimi[i][len2[i-1]+1])len2[i]++;
	}
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	read(n);
	prep(n);
	n--;
	putans();
	puts("");
	return 0;
}
