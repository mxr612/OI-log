#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=500010;
int n,sum[maxn],head[maxn],b[maxn],cnt,x,kkk,ans,st[maxn],top,d[maxn],f[maxn];
bool pd[maxn];
char s[maxn];
struct edge{
	int v,nxt;
}a[maxn];
void add(int u,int v)
{
	a[++cnt].v=v; a[cnt].nxt=head[u]; head[u]=cnt;
}
void dfs(int u,int fa)
{
	d[u]=d[fa];
	if(b[u]==0){
		st[++top]=u;
		pd[u]=1;
	}
	else if(top>0){
		int x=st[top]; top--;
		pd[x]=0;
		sum[u]++;
		sum[u]+=sum[f[x]];
		d[u]+=sum[u];
	}
	if(u!=1){
		int kkk;
		kkk=d[u]*u;
		ans^=kkk;
	}
	for(int i=head[u];i!=0;i=a[i].nxt)
	{
		if(pd[u]==0&&b[u]==0) st[++top]=u,pd[u]=1;
		int v=a[i].v;
		dfs(v,u);
	}
	if(pd[u]==1) top--;
	return ;
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",s+1);
	for(int i=1;i<=n;i++)
	{
		if(s[i]=='(') b[i]=0;
		else b[i]=1;
	}
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&f[i]);
		add(f[i],i);
	}
	dfs(1,0);
	printf("%d\n",ans);
	fclose(stdin); fclose(stdout);
	return 0;
}
