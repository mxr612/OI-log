#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
int n,de[101010],x,y,a[0101010],t,k,pd;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
		}
		for(int i=1;i<n;i++)
		{
			scanf("%d%d",&x,&y);
			de[x]++; de[y]++;
		}
		for(int i=1;i<=n;i++) if(de[i]==n-1){
			k=i; pd=1;
		}
		if(pd==1){
			for(int i=1;i<=n;i++) printf("%d ",i);
			printf("\n");
			continue;
		}
		for(int i=1;i<=n;i++)
		{
			printf("%d ",i);
		}
		printf("\n");
	}
	fclose(stdin); fclose(stdout);
	return 0;
}
