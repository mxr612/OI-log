#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
typedef unsigned long long ull;
ull n,k,sum=1,ans[101];
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%llu%llu",&n,&k);
	for(int i=1;i<=n;i++)
	{
		sum*=2;
	}
	sum--;
	int cnt=0;
	while(sum!=1)
	{
		ull mid=sum/2;
		if(k>mid){
			ans[++cnt]=1;
			k-=mid+1;
			k=mid-k;
		}
		else{
			ans[++cnt]=0;
		}
		sum=mid;
	}
	if(k==0) ans[++cnt]=0;
	else ans[++cnt]=1;
	for(int i=1;i<=n;i++) printf("%llu",ans[i]);
	printf("\n");
	fclose(stdin); fclose(stdout);
	return 0;
}
