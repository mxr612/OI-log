#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>

#define int long long

#define Fur(i,x,y) for(int i=x;i<=y;++i)
#define Fdr(i,x,y) for(int i=x;i>=y;--i)
using namespace std;
inline int min(int x,int y){return x<y?x:y;}
inline int max(int x,int y){return x>y?x:y;}

#define N 500011
int n,cnt=0,head[N],f[N],ans[N];
char val[N];
struct edge{
	int to,nxt;
}e[N];
void add(int x,int y){
	e[++cnt].to=y;e[cnt].nxt=head[x];head[x]=cnt;
}
const int m1=1000007,m2=19260817,base=1331;
struct node{
	int s[m1+10],ss[m1+10];
	int h1(int x){
		return x*base%m1;
	}
	int h2(int x){
		return x*base%m2*base%m1;
	}
	int get(int x){
		return min(s[h1(x)],ss[h2(x)]);
	}
	void push(int x){
		s[h1(x)]++;
		ss[h2(x)]++;
	}
	void del(int x){
		s[h1(x)]--;
		ss[h2(x)]--;
	}
}T;
int d[N],tt=0;
void dfs(int x){
	if(val[x]=='(')++d[x];
	else --d[x];
	if(d[x]<0)d[x]=(tt+=n);
	if(val[x]==')')ans[x]+=T.get(d[x]);
	T.push(d[x]);
	for(int i=head[x],to;to=e[i].to,i;i=e[i].nxt){
		ans[to]=ans[x];d[to]=d[x];
		dfs(to);
	}
	T.del(d[x]);
}
char a[N];
void DFS(int x,int d){
	a[d]=val[x];
	int tp=0;
	Fdr(i,d,0){
		if(a[i]==')')tp++;
		else tp--;
		if(!tp)++ans[x];
		if(tp<0)break;
	}
	for(int i=head[x],to;to=e[i].to,i;i=e[i].nxt){
		ans[to]=ans[x];
		DFS(to,d+1);
	}
}
signed main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",val+1);
	bool ff=1;
	Fur(i,2,n){
		scanf("%d",&f[i]);
		if(f[i]!=i-1)ff=0;
		add(f[i],i);
	}
	if(n<=7000)DFS(1,0);
	else{
		if(ff){
			T.push(0);
			dfs(1);
		}
		else DFS(1,0);
	}
	int ANS=0;       
	Fur(i,1,n)ANS^=i*ans[i];
	cout<<ANS<<endl;
}    
