#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
#define ll long long 
#define ull unsigned long long
#define int ull
#define Fur(i,x,y) for(int i=x;i<=y;++i)
using namespace std;

int n,k;
bool a[10000];
int dfs(int d,int res,int now){
	if(d==n){
		Fur(i,0,d-1)putchar((a[i]?1:0)+'0');
		exit(0);
	}
	if(res>(now>>1ull)){
		a[d]=1;
		dfs(d+1,now-res,(now>>1ull));
	}
	else{
		a[d]=0;
		dfs(d+1,res,(now>>1ull));
	}
}
signed main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	dfs(0,k,(1ull<<n)-1);
}
