#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int n,e[2010][2],val[2010],ans[2010],t,an[2010];
bool bz[2010];
void dg(int x)
{
	if(x == n)
	{
		for(int i = 1;i <= n;i++)
		{
			if(val[i] < ans[i])
			{
				for(int j = 1;j <= n;j++) ans[j] = val[j];
				return;
			}
			if(val[i] > ans[i]) return;
		}
		return;
	}
	for(int i = 1;i < n;i++)
	{
		if(bz[i]) continue;
		bz[i] = 1;
		swap(val[e[i][0]],val[e[i][1]]);
		dg(x + 1);
		swap(val[e[i][0]],val[e[i][1]]);
		bz[i] = 0;
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	int k;
	while(t--)
	{
		scanf("%d",&n);
		for(int i = 1;i <= n;i++)
		{
			scanf("%d",&k);
			val[k] = i;
			ans[i] = 2001;
		}
		for(int i = 1;i < n;i++) scanf("%d%d",&e[i][0],&e[i][1]);
		dg(1);
		for(int i = 1;i <= n;i++) printf("%d ",ans[i]);
		printf("\n");
	}
	return 0;
}
