#include<cstdio>
#include<cstring>
using namespace std;
typedef unsigned long long  ull;
ull n,k,t;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%llu%llu",&n,&k);
	t = 0;
	for(int i = 1;i < n;i++) t = (t << 1) + 1;
	bool bz = 0;
	for(int i = 0;i < n;i++)
	{
		if(k <= t)
		{
			printf("%d",bz);
			bz = 0;
		}
		else
		{
			printf("%d",1 - bz);
			k = k - t - 1;
			bz = 1;
		}
		t = t >> 1;
	}
	return 0;
}
