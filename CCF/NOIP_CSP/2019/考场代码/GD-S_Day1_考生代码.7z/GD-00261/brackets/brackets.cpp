#include<cstdio>
#include<cstring>
using namespace std;
const int N = 500010;
int last[N],e[N][2],dg[N][3],n,fa,tot,cnt[N];
long long f[N],ans;
char s[N],S[20];
void rd(int &x)
{
	scanf("%s",S);
	int len = strlen(S);
	x = 0;
	for(int i = 0;i < len;i++)
	{
		x = x * 10 + S[i] - 48;
		S[i] = '\000';
	}
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	rd(n);
	scanf("%s",s);
	for(int i = 1;i < n;i++)
	{
		rd(fa);
		e[i][0] = i + 1;
		e[i][1] = last[fa];
		last[fa] = i;
	}
	dg[1][0] = tot = 1;
	if(s[0] == '(') dg[1][1] = 1;
	while(tot > 0)
	{
		int x = dg[tot][0];
		if(last[x] == 0)
		{
			if(s[x - 1] == ')') cnt[dg[tot][1]] = 0;
			tot--;
			continue;
		}
		tot++;
		dg[tot][1] = dg[tot - 1][1];
		int v = e[last[x]][0];
		last[x] = e[last[x]][1];
		f[v] = f[x];
		dg[tot][2] = dg[tot - 1][2];
		if(s[v - 1] == ')')
		{
			if(dg[tot][1] > 0)
			{
				dg[tot][1]--;
				cnt[dg[tot][1]]++;
				f[v] = f[v] + cnt[dg[tot][1]];
			}
		}
		else
		{
			dg[tot][1]++;
			cnt[dg[tot][1]] = 0;
		}
		dg[tot][0] = v;
	}
	for(int i = 1;i <= n;i++) ans = ans ^ (i * f[i]);
	printf("%lld",ans);
	return 0;
}
