#include<map>
#include<set>
#include<stack>
#include<queue>
#include<cmath>
#include<string>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define int unsigned long long
inline int Read(){
	int ans=0,fl=1;
	char ch=getchar();
	for(;ch<'0' || ch>'9';ch=getchar())
		if(ch=='-')
			fl=-1;
	for(;ch>='0' && ch<='9';ch=getchar())
		ans=(ans<<3)+(ans<<1)+(ch^'0');
	return ans*fl;
}
int n,k,ans[64+5];
signed main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	n=Read();
	k=Read();
	for(int i=n;i>=1;i--)
		if(k>=(1ll<<(i-1))){
			k=(1ll<<i)-k-1;
			ans[i]=1;
		}
	for(int i=n;i>=1;i--)
		printf("%llu",ans[i]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
