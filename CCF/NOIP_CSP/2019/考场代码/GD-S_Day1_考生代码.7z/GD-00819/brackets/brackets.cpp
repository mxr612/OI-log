#include<map>
#include<set>
#include<stack>
#include<queue>
#include<cmath>
#include<string>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
#define int long long
inline int Read(){
	int ans=0,fl=1;
	char ch=getchar();
	for(;ch<'0' || ch>'9';ch=getchar())
		if(ch=='-')
			fl=-1;
	for(;ch>='0' && ch<='9';ch=getchar())
		ans=(ans<<3)+(ans<<1)+(ch^'0');
	return ans*fl;
}
const int maxn=5e5+5;
struct node{
	int x;
	char s;
}sta[maxn],ctp[maxn];
char s[maxn];
int n,cnt,apl,Max,top,ans[maxn],dp[maxn],head[maxn],nxt[maxn],to[maxn],f[maxn];
inline void add_edge(int x,int y){
	nxt[++cnt]=head[x];
	to[head[x]=cnt]=y;
}
inline void Find_ans(int u,int opt){
	for(int i=head[u];i!=0;i=nxt[i]){
		int v=to[i];
		ans[v]=ans[u];
		bool pd=false,fl=true;
		if(top!=0 && sta[top].s=='(' && s[v]==')'){
			pd=true;
			ctp[v].x=sta[top].x;
			ctp[v].s=sta[top].s;
			ans[v]+=(dp[v]=dp[f[sta[top].x-1]]+1);
			top--;		
		}
		else {
			sta[++top].x=opt+1;
			sta[top].s=s[v];
		}
		f[opt+1]=v;
		Find_ans(v,opt+1);
		if(pd==true){
			sta[++top].x=ctp[v].x;
			sta[top].s=ctp[v].s;
		}
		else top--;
	}
}
signed main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	n=Read();
	scanf(" %s",s+1);
	for(int i=2;i<=n;i++)
		add_edge(Read(),i);
	sta[++top].s=s[1];
	sta[top].x=f[1]=1;
	Find_ans(1,1);
	for(int i=1;i<=n;i++)
		apl^=(i*ans[i]);
	printf("%lld\n",apl);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
