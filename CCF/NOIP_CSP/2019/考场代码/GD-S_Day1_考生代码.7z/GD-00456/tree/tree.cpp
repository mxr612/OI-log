#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
typedef long long LL;
using namespace std; 
const int MAXN=2002;
bool G[MAXN][MAXN];
int pos[MAXN];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	int T,x,y,n;
	scanf("%d",&T);
	
	while(T--)
	{
		scanf("%d",&n);
		for(int i=1; i<=n; i++)
		{
			scanf("%d",&x);
			pos[i]=x; //��¼i��λ�� 
		} 
		for(int i=1; i<=n-1; i++)
		{
			scanf("%d%d",&x,&y);
			if(x>y) swap(x,y); //��֤x<=y 
			G[x][y]=1; 
		}
		
		for(int i=1; i<=n; i++)
		{
			for(int j=i+1; j<=n; j++) //j����>=i 
			{
				if(G[i][j] && pos[i]>pos[j])
				{
					swap(pos[i],pos[j]);
					G[i][j]=0;
				} 
			} 
		} 
		
		for(int i=1; i<=n; i++)
		{
			printf("%d ",pos[i]);
		}
	}
	
	return 0;
} 
