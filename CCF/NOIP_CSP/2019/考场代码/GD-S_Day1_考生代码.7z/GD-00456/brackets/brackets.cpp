#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
typedef long long LL;
using namespace std; 
const int MAXN=500000;
int fa[MAXN];
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	
	int n;
	scanf("%d",&n);
	
	for(int i=2; i<=n; i++)
	{
		scanf("%d",&fa[i]);
	}
	
	return 0;
} 
