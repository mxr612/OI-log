#include<bits/stdc++.h>
using namespace std;
long long typedef LL;
const int MAXN = 5e5 + 5;
int n,cur = -1;
int Head[MAXN];
LL Ans[MAXN];
char S[MAXN];
struct wyy
{
	int to,next;
}Edge[MAXN];
int read()
{
	char ch = getchar();int w = 0;
	while(ch < '0' || ch > '9')	ch = getchar();
	while(ch >= '0' && ch <= '9')
	{
		w = w * 10 + ch - '0';
		ch = getchar();
	}
	return w;
}
void Add(int from,int to)
{
	Edge[++ cur].to = to;
	Edge[cur].next = Head[from];
	Head[from] = cur;
}
void Read()
{
	n = read();
	scanf("%s",S + 1);
	memset(Head,-1,sizeof(Head));
	for(int i = 2 ; i <= n ; i ++)
	{
		int fa = read();
		Add(fa,i);
	}
}
void DFS(int x,int fa,int len,string fas)
{
	string tmp = fas + S[x];
	
	int lef = 0 , rig = 0 , nans = 0;
	if(S[x] == ')')	rig ++;	else	lef ++;
	for(int i = len - 2 ; i >= 0 ; i --)
	{
		if(lef > rig)	break;
		if(tmp[i] == '(')	lef ++;		else	rig ++;
		if(lef == rig)	nans ++;
	}
	Ans[x] = Ans[fa] + nans;
	
	for(int h = Head[x] ; h != -1 ; h = Edge[h].next)
	{
		int y = Edge[h].to;
		DFS(y,x,len + 1,tmp);
	}
}
void Calc()
{
	LL ans = 0;
	for(int i = 1 ; i <= n ; i ++)
		ans = ans ^ (i * Ans[i]);
	cout << ans << endl;
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	Read();
	DFS(1,0,1,"");
	Calc();
	return 0;
}
