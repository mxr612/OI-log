#include<bits/stdc++.h>
using namespace std;
unsigned long long typedef ull;
ull n,k;
string s;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin >> n >> k;
	ull w = (ull)(1) << (n - 1);
	while(w)
	{
		if(k < w)	s = s + '0';
		else
		{
			s = s + '1';
			k -= w;
			k = w - 1 - k;
		}
		w >>= 1;
	}
	cout << s << endl;
	return 0;
}
