#include<bits/stdc++.h>
using namespace std;
const int MAXN = 2005;
int n,T,cur;
int Head[MAXN],Num[MAXN],Vis[MAXN],Id[MAXN],A[MAXN],Tmp[MAXN];
int X[MAXN],Y[MAXN],Ans[MAXN];
struct wyy
{
	int to,next,id;
}Edge[MAXN * 2];
void Init()
{
	cur = -1;
	for(int i = 1 ; i <= n ; i ++)	Ans[i] = n - i + 1;
	memset(Vis,0,sizeof(Vis));
}
void Add(int from,int to,int id)
{
	Edge[++ cur].to = to;
	Edge[cur].next = Head[from];
	Edge[cur].id = id;
	Head[from] = cur;
	
	Edge[++ cur].to = from;
	Edge[cur].next = Head[to];
	Edge[cur].id = id;
	Head[to] = cur;
}
void Read()
{
	for(int i = 1 ; i <= n ; i ++)	
	{
		int x;
		cin >> x;
		Num[x] = i;
	}
	//for(int i = 1 ; i <= n ; i ++)	printf("%d ",Num[i]);
	//printf("\n");
	memset(Head,-1,sizeof(Head));
	for(int i = 1 ; i < n ; i ++)
	{
		int x,y;
		cin >> x >> y;
		Add(x,y,i);//iΪ�ߵı�� 
		X[i] = x , Y[i] = y;
	} 
}
void DFS(int c)
{
	if(c == n)
	{
		for(int i = 1 ; i <= n ; i ++)	Tmp[i] = Num[i];
		for(int i = 1 ; i < n ; i ++)
		{
			int x = X[A[i]] , y = Y[A[i]];
			swap(Tmp[x],Tmp[y]);
		}
		for(int i = 1 ; i <= n ; i ++)	Id[Tmp[i]] = i;
		int ok = 0;//1��С��  0�����ڵ��� 
		for(int i = 1 ; i <= n ; i ++)	
		{
			if(Id[i] < Ans[i])
			{
				ok = 1;
				break;
			}
			else
			{
				if(Id[i] > Ans[i])	
					break;
			}
		}
		if(ok == 1)	for(int i = 1 ; i <= n ; i ++)	Ans[i] = Id[i];
		return;
	}
	for(int i = 1 ; i < n ; i ++)
	{
		if(!Vis[i])	
		{
			Vis[i] = 1;
			A[c] = i;
			DFS(c + 1);
			Vis[i] = 0;
		}
	}
}
void Force()
{
	DFS(1);
}
void Print()
{
	for(int i = 1 ; i <= n ; i ++)	printf("%d ",Ans[i]);
	printf("\n");
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin >> T;
	while(T --)
	{
		cin >> n;
		Init();
		Read();
		Force();
		Print();
	}
	return 0;
}
