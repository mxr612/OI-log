#include<bits/stdc++.h>
#define LL unsigned long long
using namespace std;
int n,k;
int a[2048],b[21];
void SUB1() {
	a[0]=0; a[1]=1; 
	int len=2;
	int poww=2;
	for(int i=2;i<=n;i++) {
		int k=0;
		for(int j=len*2-1;j>=len;j--) {
			a[j]=a[k]+poww;
			k++;
		}
		len*=2;
		poww*=2;
	}
	/*
	for(int i=0;i<len;i++)
			cout<<a[i]<<" ";
		cout<<endl;
	/*/
}
LL K;
void SUB2() {
	LL poww=1;
	int Reverse=0;
	for(int i=1;i<n;i++)
		poww=poww*2;
	for(int i=1;i<=n;i++) {
		int tmp=K/poww;
		if(Reverse) tmp=1-tmp;
		printf("%d",tmp);
		if(tmp)Reverse=1-Reverse;
		K=K%poww;
		poww/=2;
	}
	printf("\n");
}
void Print1() {
	int tmp=a[k];
	for(int i=1;i<=n;i++) {
		b[i]=tmp%2;
		tmp/=2;
	}
	for(int i=n;i>=1;i--)
		printf("%d",b[i]);
	printf("\n");
}
int main() {
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	
	scanf("%d",&n);
	if(n<=10) {
		scanf("%d",&k);
		SUB1();
		//
		
		//
		Print1();
	}else {
		scanf("%lld",&K);
		SUB2();
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}
//18446744073709551616
//9223372036854775807
