#include<bits/stdc++.h>
#define LL unsigned long long
#define N 500007
using namespace std;
int n,ans=0;
char s[N];
int a[N],fa[N];
bool f[3001][3001];
bool flag1;
void SUB1() { //n3
	int tmp=0;
	memset(f,0,sizeof(f));
	for(int i=1;i<=n;i++) {
		for(int j=i-1;j>=1;j--) {
			if(j+1==i && a[j]==1 && a[i]==0) {
				f[j][i]=1;
				tmp++;
			}
			if(f[j+1][i-1] && a[j]==1 && a[i]==0) {
				f[j][i]=1;
				tmp++;
			}
			for(int k=j-1;k>=1;k--) {
				if(f[k][j-1] && f[j][i] && !f[k][i]) {
					f[k][i]=1;
					tmp++;
				}
			}
		}
	//	cout<<tmp<<endl;
		ans=ans^(tmp*i);
	}
	printf("%d\n",ans);
}
int dp[N];
/*void SUB2() {
	ans=0;
	memset(f,0,sizeof(f));
	for(int i=1;i<=n;i++) {
		dp[i]=dp[i-1];
		for(int j=i-1;j>=1;j--) {
			if(j+1==i && a[j]==1 && a[i]==0) {
				f[j][i]=1;
				dp[i]++;
			}
			if(f[j+1][i-1] && a[j]==1 && a[i]==0) {
				f[j][i]=1;
				dp[i]++;
			}
			if(f[j][i])dp[i]+=dp[j-1];
		}
		cout<<dp[i]<<endl;
		ans=ans^(dp[i]*i);
	}
	printf("%d\n",ans);
}*/
int main() {
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",s);
	for(int i=1;i<=n;i++) {
		if(s[i-1]=='(') a[i]=1;
		else a[i]=0;
	//	cout<<a[i];
	}
	for(int i=2;i<=n;i++) {
		scanf("%d",&fa[i]);
		if(fa[i]!=i-1) flag1=1;
	}
	if(!flag1) {
		SUB1();
		return 0;
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}
/*
SUB1
5
()(()
1 2 3 4

9
()(()())(
1 2 3 4 5 6 7 8

9
(()()()))
1 2 3 4 5 6 7 8

9
(()(())))
1 2 3 4 5 6 7 8
*/
