#include<bits/stdc++.h>
#define N 4001
using namespace std;
int T,n,cnt=0;
bool flag1=0;
int a[N],head[N],du[N];
struct Edge{
	int nxt,to;
}e[N*10];
void init() {
	flag1=0;
	memset(e,0,sizeof(e));
	memset(head,0,sizeof(head));
	memset(du,0,sizeof(du));
	cnt=0;
}
void add(int u,int v) {
	e[++cnt].nxt=head[u];
	e[cnt].to=v;
	head[u]=cnt;
}
struct Line{
	int x,y;
}b[N];
int Map[N],Ans[N];
bool Used[N];
void dfs(int R) {
	if(R==n) {
		bool flag0=1;
		for(int i=1;i<=n;i++) {
			if(Map[i]<Ans[i]) {
				break;
			}else if(Map[i]>Ans[i]) {
				flag0=0;
				break;
			}
		}
		if(flag0) {
			for(int i=1;i<=n;i++)
				Ans[i]=Map[i];
		}
		return ;
	}
	for(int i=1;i<n;i++) {
		int x=b[i].x,y=b[i].y;
		if(!Used[i]) {
			swap(Map[a[x]],Map[a[y]]);
			Used[i]=1;
			dfs(R+1);
			swap(Map[a[x]],Map[a[y]]);
			Used[i]=0;
		}
	}
}
int juhua;
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while(T--) {
		init();
		scanf("%d",&n);
		for(int i=1;i<=n;i++) {
			scanf("%d",&Map[i]);
			a[Map[i]]=i;
		}
		for(int i=1;i<n;i++) {
			int x,y;
			scanf("%d%d",&x,&y);
			add(x,y); add(y,x);
			b[i].x=x; b[i].y=y;
			du[x]++; du[y]++;
		}
		for(int i=1;i<=n;i++) {
			if(du[i]==n-1) {
				flag1=1;
				juhua=i;
			}
		}
		if(n<=160) {
			for(int i=1;i<=n;i++)
				Ans[i]=100;
			dfs(1);
			for(int i=1;i<=n;i++)
				printf("%d ",Ans[i]);
			printf("\n");
			continue;
		}else if(flag1) {
		/*	if(Map[juhua]==juhua) {
				int Wei=juhua;
				for(int i=juhua;i<=n;i++) {
					if(Map[i]==i)
						Wei++;					
				}
			//	cout<<Wei<<endl;
				for(int i=1;i<=n;i++) {
					if(i!=juhua) {
						printf("%d ",i);
					}
					if(Wei==i) {
						printf("%d ",juhua);
					}
				}
				printf("\n");
			}
			else {*/
				for(int i=1;i<=n;i++) 
					printf("%d ",i);
				printf("\n");
			//}
			continue;
		}
	}
	return 0;
	fclose(stdin);
	fclose(stdout);
}
/*
SUB1
2
6
3 5 2 4 1 6
1 2
1 3
1 4
5 1
6 1
6
3 5 2 4 1 6
1 2
1 3
1 4
5 1
6 1

2
5
3 4 2 1 5
1 2
2 3
3 4
4 5
5
1 2 5 3 4
1 2
1 3
1 4
1 5

4
5
4 2 3 1 2
2 1
2 3
2 4
2 5
5
1 2 5 4 3
2 1
2 3
2 4
2 5
5
3 2 1 4 5
2 1
2 3
2 4
2 5
5
1 2 3 4 5
2 1
2 3
2 4
2 5
*/
