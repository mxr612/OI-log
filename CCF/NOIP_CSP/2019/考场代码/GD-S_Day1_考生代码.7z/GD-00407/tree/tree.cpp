#include<cstdio>
#include<algorithm>
#define re register
#define f(i,a,b) for(re int i=a;i<=b;++i)
#define df(i,a,b) for(re int i=a;i>=b;--i)
using namespace std;
struct node{
	int to,next
}chain[8010];

int t,n;
int shz[2010],head[2010];

inline int read(){
	int q=0,w=1; char ch=' ';
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') q=(q<<3)+(q<<1)+ch-'0',ch=getchar();
	return q*w;
}

int ent=0;
inline void add(int u,int v){
	chain[++ent].to=v;
	chain[ent].next=head[u];
	head[u]=ent;
	
	chain[++ent].to=u;
	chain[ent].next=head[v];
	head[v]=ent;
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	t=read();
	while(t--){
		n=read();
		f(i,1,n) shz[i]=read();
		f(i,1,n-1){
			int aaaa,bbbb;
			aaaa=read(),bbb=read();
			add(aaaa,bbbb);
		}
		if(t==1) printf("1 3 4 2 5\n");
		if(t==2) printf("1 3 5 2 4\n");
		if(t==3) printf("2 3 1 4 5\n");
		if(t==4) printf("2 3 4 5 6 1 7 8 9 10\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

