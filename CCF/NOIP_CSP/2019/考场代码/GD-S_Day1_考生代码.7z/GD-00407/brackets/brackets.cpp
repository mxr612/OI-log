#include<iostream>
#include<cstdio>
#include<queue>
#include<algorithm>
#define re register
#define f(i,a,b) for(re ll i=a;i<=b;++i)
#define df(i,a,b) for(re ll i=a;i>=b;--i)
using namespace std;
typedef long long ll;
ll n;
ll ans=0;
ll sli[500010];
ll fq[500010],ch[500010];
queue<ll> q;
string sss;

bool falg;

inline ll read(){
	ll q=0,w=1; char ch=' ';
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') q=(q<<3)+(q<<1)+ch-'0',ch=getchar();
	return q*w;
}

inline ll sosu(ll v){
	ll u=fq[v];
	ll lish=0,zhgo=0,qili=0;
	if(ch[v]==1) q.push(1);
	while(u!=v){
		if(ch[u]==1){
			q.push(1);
			if(lish!=0){
				zhgo=zhgo+lish+qili;
				qili+=1;	lish=0;
			}
		}
		else{
			if(!q.empty()){
				q.pop();
				lish+=1;
			}
		}
		v=u;
		u=fq[v];
	}
	if(ch[1]==0){
		zhgo=zhgo+lish+qili;
		qili+=1;	lish=0;
	}
	return zhgo;
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	n=read();
	cin>>sss;
	f(i,1,n){
		ch[i]=sss[i-1]-'(';
		fq[i]=i;
	}
	f(i,2,n){
		int k; k=read(); fq[i]=k;
	}
	ans=0;
	f(i,2,n){
		ll zhji;
		while(!q.empty()) q.pop();
		sosu(i);
		zhji=i*sosu(i);
		ans=ans^zhji;
	}
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
