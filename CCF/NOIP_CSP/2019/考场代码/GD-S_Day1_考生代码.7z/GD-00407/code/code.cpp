#include<cstdio>
#include<algorithm>
#define re register
#define f(i,a,b) for(re int i=a;i<=b;++i)
#define df(i,a,b) for(re int i=a;i>=b;--i)
using namespace std;
typedef long long ll;
int n;
int ans[70];
ll k,zhji;

inline int readi(){
	int q=0,w=1; char ch=' ';
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') q=(q<<3)+(q<<1)+ch-'0',ch=getchar();
	return q*w;
}

inline ll readl(){
	ll q=0,w=1; char ch=' ';
	while(ch<'0'||ch>'9'){if(ch=='-')w=-1;ch=getchar();}
	while(ch>='0'&&ch<='9') q=(q<<3)+(q<<1)+ch-'0',ch=getchar();
	return q*w;
}

inline ll ksm(int p){
	ll kkk=2,x=1;
	while(p){
		if(p%2) x*=kkk;
		kkk*=kkk;
		p=(p>>1);
	}
	return x;
}

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	n=readi(); k=readl();
	k+=1;
	df(i,n-1,1){
		ll zhji1,zhji2,zhs;
		zhji1=ksm(i);
		zhji2=zhji1+1;
		if(k<=zhji1) continue;
		else{
			zhs=k-zhji2;
			k=zhji1-zhs;
			ans[i+1]=1;
		}
	}
	k-=1;
	if(k==1) ans[1]=1;
	df(i,n,1){
		printf("%lld",ans[i]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

