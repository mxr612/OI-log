#include<bits/stdc++.h>
#define N 2005

using namespace std;
int n,f[N],s[N],d[N],p=1;
vector <int> a[N];

int main()
{
	
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);//*/
	int T;
	cin>>T;
	while(T--)
	{
		cin>>n;
		for(int i=1;i<=n;i++)scanf("%d",&s[i]);
		for(int i=1;i<n;i++)
		{
			int x,y;
			scanf("%d%d",&x,&y);
			cout<<i<<" ";
			a[x].push_back(y);
			a[y].push_back(x);
			d[x]++;d[y]++;
			if(d[x]>2 || d[y]>2)p=0;
		}
		cout<<endl;
	}
	
	
	
	return 0;
}










