#include<bits/stdc++.h>
#define N 1005

using namespace std;
int n,ans[N],cnt;
long long k,f[N];

void ch(long long x)
{
	while (x)
	{
		cnt++;
		ans[cnt]=x%2;
		x/=2;
	}
}


long long dfs(int a,long long b)
{
	//cout<<a<<" "<<b<<endl;
	if(a==1)
	{
		if(b%2)return 0;
		else return 1;
	}
	long long x,y;
	if(b>f[a]/2)x=dfs(a-1,f[a]-b+1);
	else x=dfs(a-1,b);
	//cout<<x<<endl;
	if(b>f[a]/2)return x+f[a-1];
	else return x;
}


int main()
{
	
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);//*/
	cin>>n>>k;
	long long int x=1;k++;
	for(int i=0;i<=63;i++)
	{
		f[i]=x;
		x*=2;
	}
	//cout<<f[44]<<endl;
	long long y;
	y=dfs(n,k); ch(y);
//	cout<<y<<endl;
	for(int i=1;i<=n-cnt;i++)
	{
		cout<<"0";
	}
	for(int i=cnt;i>=1;i--)
	{
		printf("%d",ans[i]);
	}
	
	
	return 0;
}










