#include<bits/stdc++.h>
#define N 500005

using namespace std;

int f[N],temp[N],n,c[N],s[N],top,p=1,cnt;
long long lj[N],ans;
stack <int> st,num;
struct node{
	int x,y;
}a[N];
bool comp(node x,node y)
{
	if(x.x<=y.x)return true;
	else return false;
}

void fan()
{
	int k=top;
	for(int i=1;i<=top;i++)temp[i]=s[i];
	for(int i=1;i<=top;i++)
	{
		s[i]=temp[k];k--;
	}
}



int dfs(int l,int r,int d)
{
	//cout<<l<<" ; "<<r<<endl;
	if(l+1==r)
	{
		return 1;
	}
	int ll=1,lr=1,k=0,tt=0;
	for(int i=d;i>=n;i--)
	{
		if(a[i].y>lr && a[i].x>l && a[i].y<r)
		{
			lr=a[i].y;tt++;
			k+=dfs(a[i].x,a[i].y,i-1);
		}
		
	}
	return k+1+lj[tt];
}

int work()
{
	
	long long k=0;
	int t;
	while(!st.empty())st.pop();
	while(!num.empty())num.pop();
	for(int i=1;i<=top;i++)
	{
		if(s[i]==-1)
		{
			st.push(s[i]);
			num.push(i);
		}
		else if(s[i]==1 && !st.empty())
		{
			st.pop();
			t=num.top();
			cnt++;
			a[cnt].x=t;a[cnt].y=i;
			num.pop();
		}
	}
	//cout<<"begin"<<endl;
	int l=1,r=1;
	for(int i=cnt;i>=1;i--)
	{
		if(a[i].y>r)
		{
			r=a[i].y;
			k+=dfs(a[i].x,a[i].y,i-1);
		}
	}
	
	return k;
}
 
 int work0()
{
	ans=0;
	for(int i=2;i<=n;i++)
	{
		long long k=i;top=0;cnt=0;
		while(k!=1)
		{
			top++;s[top]=c[k];
			k=f[k];
		}
		top++;s[top]=c[k];
		fan();
		//cout<<top<<endl;
		//k=0;
		k=work();
		ans=ans^(k*i);
		//cout<<ans<<" "<<k<<endl;
	}
	
}

int main()
{
	
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);//*/
	cin>>n;
	string s;
	cin>>s;lj[1]=1;
	for(int i=0;i<s.length();i++)
	{
		if(s[i]==')')c[i+1]=1;
		else c[i+1]=-1;
	}
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&f[i]);
		if(f[i]!=i-1)p=0;
		lj[i]=lj[i-1]+i;
	}
	
	work0();
	
	cout<<ans<<endl;
	
	
	return 0;
}


/*
8
(()()(()
1 2 3 4 5 6 7

5
(()()
1 1 2 2

6
(())()
1 5 2 1 5

0


10
())(()()()
1 1 7 2 2 3 3 5 9

15
()()()()()((())
*/







