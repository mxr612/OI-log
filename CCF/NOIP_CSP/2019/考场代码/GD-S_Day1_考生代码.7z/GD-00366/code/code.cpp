#include<bits/stdc++.h>
#define fo(i,a,b)for(int i=a,_e=b;i<=_e;++i)
#define fd(i,a,b)for(int i=b,_e=a;i>=_e;--i)
#define ul unsigned long long
using namespace std;
int n;
ul k;
void go(int n,ul k){
	if(n==1){
		putchar('0'+k);
		return;
	}
	ul a=(ul)1<<n-1;
	if(k<a)putchar('0'),go(n-1,k);
	else putchar('1'),go(n-1,a*2-1-k);
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	go(n,k);
	fclose(stdin);fclose(stdout);return 0;
}
