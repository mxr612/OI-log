#include<bits/stdc++.h>
#define fo(i,a,b)for(int i=a,_e=b;i<=_e;++i)
#define fd(i,a,b)for(int i=b,_e=a;i>=_e;--i)
#define min(a,b)(a<b?a:b)
#define ll long long
using namespace std;
const int N=5e5+5;
int n,x,y;
int la[N],ne[N],fa[N],v[N],ct[N],d[N];
int f[N][20],va[N][20];
int las[N*2];
ll an[N],ans;
void R(int &n){
	char c;for(n=0;(c=getchar())<'0'||c>'9';);
	for(;c<='9'&&c>='0';c=getchar())n=n*10+c-48;
}
void go(int x){
	v[x]+=v[fa[x]];
	an[x]=an[fa[x]];
	d[x]=d[fa[x]]+1;
	va[x][0]=v[x];
	f[x][0]=fa[x];
	fo(i,1,18){
		if(!f[x][i-1])break;
		f[x][i]=f[f[x][i-1]][i-1];
		va[x][i]=min(va[x][i-1],va[f[x][i-1]][i-1]);
	}
	int y=las[v[x]+N];
	if(y>-1){
		int dt=d[x]-d[y],w=x,z=1e9;
		fd(i,0,18)if(dt>=1<<i)dt-=1<<i,z=min(z,va[w][i]),w=f[w][i];
		ct[x]=z>=v[x]?ct[y]+1:0;
		an[x]+=ct[x];
	}
	las[v[x]+N]=x;
	ans^=an[x]*x;
	for(int i=la[x];i;i=ne[i])go(i);
	las[v[x]+N]=y;
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d\n",&n);
	fo(i,1,n)v[i]=getchar()=='('?1:-1;
	fo(i,2,n)R(fa[i]),ne[i]=la[fa[i]],la[fa[i]]=i;
	fo(i,-n,n)las[i+N]=-1;
	las[N]=0;
	go(1);
	printf("%lld\n",ans);
	fclose(stdin);fclose(stdout);return 0;
}
