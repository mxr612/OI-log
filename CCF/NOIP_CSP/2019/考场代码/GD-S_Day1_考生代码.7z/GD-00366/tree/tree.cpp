#include<bits/stdc++.h>
#define fo(i,a,b)for(int i=a,_e=b;i<=_e;++i)
#define fd(i,a,b)for(int i=b,_e=a;i>=_e;--i)
#define link(x,y)(ne[++js]=la[x],la[x]=js,to[js]=y,b[js]=i)
#define ff(i,x)for(int i=la[x];i;i=ne[i])
using namespace std;
const int N=2005;
int t,n;
int v[N];
namespace bl{
	int x[N],y[N],vv[N];
	int ans[N],dy[N];
	int jc,p[N];
	void go(){
		fo(i,1,n)scanf("%d",&v[i]);
		fo(i,1,n-1)scanf("%d%d",&x[i],&y[i]);
		jc=1;
		fo(i,1,n-1)jc*=i;
		fo(i,1,n-1)p[i]=i;
		fo(i,1,n)ans[i]=n+1;
		fo(i,1,jc){
			fo(i,1,n)vv[i]=v[i];
			fo(i,1,n-1)swap(vv[x[p[i]]],vv[y[p[i]]]);
			fo(i,1,n)dy[vv[i]]=i;
			fo(i,1,n){
				if(dy[i]<ans[i]){
					fo(j,1,n)ans[j]=dy[j];
					break;
				}
				if(dy[i]>ans[i])break;
			}
			next_permutation(p+1,p+n);
		}
		fo(i,1,n)printf("%d ",ans[i]);printf("\n");
	}
}
int la[N],ne[N*2],to[N*2],b[N*2],js,du[N];
namespace line{
	int x,y;
	int dy[N],d[N];
	int fa[N],bfa[N];
	int ans[N];
	bool is[N][N],can[N],can2,us[N];
	void dfs(int x){
		can2=1;
		ff(i,x)if(b[i]!=bfa[x]&&is[bfa[x]][b[i]])can2=0;
		if(can2)can[x]=1;
		ff(i,x)if(b[i]!=bfa[x]){
			fa[to[i]]=x;
			bfa[to[i]]=b[i];
			if(!is[b[i]][bfa[x]])dfs(to[i]);
		}
	}
	bool go(){
		js=0;
		fo(i,1,n)scanf("%d",&v[i]),la[i]=0,dy[v[i]]=i;
		fo(i,1,n-1)scanf("%d%d",&x,&y),link(x,y),link(y,x),du[x]++,du[y]++;
		bool yes=1;
		fo(i,1,n)if(du[i]>2){
			yes=0;
			break;
		}
		if(yes==0)return 1;
		fo(i,1,n-1)fo(j,1,n-1)is[i][j]=0;
		fo(i,1,n)us[i]=0;
		fo(i,1,n){
			int z=dy[i];
			fo(j,1,n)can[j]=0;
			ff(j,z){
				can2=1;
				ff(k,z)
					if(k!=j&&is[b[k]][b[j]])can2=0;
				if(can2)fa[to[j]]=z,bfa[to[j]]=b[j],dfs(to[j]);
			}
			fo(j,1,n)if(can[j]&&!us[j]){
				printf("%d ",j);us[j]=1;
				int x=j;
				ff(k,x)if(bfa[x]!=b[k])
					is[b[k]][bfa[x]]=1;
				int y;
				for(;y=x,x=fa[x],x!=z;)
					is[bfa[x]][bfa[y]]=1;
				ff(k,z)if(b[k]!=bfa[y])
					is[bfa[y]][b[k]]=1;
				break;
			}
		}
		printf("\n");
		return 0;
	}
}
namespace jh{
	#define P pair<int,int>
	#define fi first
	#define se second
	set<pair<int,int> >A,A1;
	int ans[N];
	bool go(){
		bool yes=0;
		fo(i,1,n)if(du[i]==n-1){
			yes=1;
			break;
		}
		if(yes==0)return 1;
		fo(i,1,n)A.insert(P(i,v[i])),A1.insert(P(v[i],i));
		fo(i,1,n-1){
			P a=*A1.begin();
			P b=*A.begin();
			if(b.fi==a.se)b=*++A.begin();
			ans[a.fi]=b.fi;
			A1.erase(a);A1.erase(P(b.se,b.fi));
			A.erase(b);A.erase(P(a.se,a.fi));
			a=P(b.se,a.se);
			A1.insert(a);
			A.insert(P(a.se,a.fi));
		}
		P a=*A.begin();
		ans[a.se]=a.fi;
		fo(i,1,n)printf("%d ",ans[i]);
		printf("\n");
		return 0;
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	for(;t--;){
		scanf("%d",&n);
		fo(i,1,n)du[i]=0;
		if(n<=10){
			bl::go();
		}else{
			if(line::go()){
				if(jh::go()){
					
					printf("\n");
				}
			}
		}
		
	}
	fclose(stdin);fclose(stdout);return 0;
}
