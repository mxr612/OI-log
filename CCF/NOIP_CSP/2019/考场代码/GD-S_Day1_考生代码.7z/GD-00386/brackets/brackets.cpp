#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#include <vector>
#define ll long long
#define re read()
using namespace std;
int n,ans;
bool a[500100];
int fa[500100];
int p[500100];
inline ll read()
{
	ll x=0,t=1;
	char c=getchar();
	while (c<'0'||c>'9')
	{
		if (c=='-') t=-1;
		c=getchar();
	}
	while (c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+(c^48);
	    c=getchar();
	}
	return x;
} 
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	n=re;
	for (int i=1;i<=n;i++) a[i]=(getchar()==')');
	for (int i=1,x;i<n;i++) 
	{
	    fa[i]=(x=re);
	}
	long long tot=0;
	int lian=0,ans1=0,l=0;
	for (int i=2;i<=n;i++)
	{
		if ((a[i]+a[i-1])==1&&!a[i-1]) lian++,ans+=lian,p[i]=p[i-1]=1,i++;
		else if (a[i]+a[l]==1) lian=1,ans++,p[i]=p[l]=1;
		else lian=0;
		l=0;
		for (int j=i;j>=1;j--) 
		if (!p[i]) 
		    if (a[i]) l=i;
		    else break;
		tot+=ans^i;
	}
	printf("%lld",tot);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
