#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>
#define ll long long
#define re read()
using namespace std;
ll n,m,k=1;
inline ll read()
{
	ll x=0,t=1;
	char c=getchar();
	while (c<'0'||c>'9')
	{
		if (c=='-') t=-1;
		c=getchar();
	}
	while (c>='0'&&c<='9')
	{
		x=(x<<1)+(x<<3)+(c^48);
	    c=getchar();
	}
	return x;
} 
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	n=re;m=re+1;
	for (int i=1;i<n;i++) k*=2;
	bool t=0,tt=0;
	for (int i=1;i<=n;i++)
	{
		if (t!=(m>k)) 
		{
			t=(m>k);
		    printf("1");
		}
		else printf("0");
		if (m>k) m-=k;
		k/=2;
		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
