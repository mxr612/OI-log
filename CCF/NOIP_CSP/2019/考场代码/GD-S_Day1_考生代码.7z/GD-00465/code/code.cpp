#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

const unsigned long long INF=18446744073709551615ull;

char ans[70];int ans_sz;

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	
	int n;unsigned long long k;cin>>n>>k;
	
	while(n)
	{
		if( k<( 1ull<<(n-1) ) ) ans[ans_sz++]='0';
		else
		{
			if( n<64 ) k=( 1ull<<n )-( k-(1ull<<(n-1))+1 );
			else k=INF-( k-(1ull<<(n-1)) );
			
			ans[ans_sz++]='1';
			k-=1ull<<(n-1);
		}
		
		n--;
	}
	
	for(int i=0;i<ans_sz;i++) cout<<ans[i];
	return 0;
}

