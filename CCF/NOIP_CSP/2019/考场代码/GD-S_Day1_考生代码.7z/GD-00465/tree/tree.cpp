#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	int T;scanf("%d",&T);
	
	while(T--)
	{
		int n;scanf("%d",&n);
		
		int tmp;
		for(int i=1;i<=n;i++) scanf("%d",&tmp);
		
		for(int i=1;i<n;i++) scanf("%d%d",&tmp,&tmp);
		
		for(int i=1;i<=n;i++) printf("%d ",i);puts("");
	}
	
	return 0;
}

