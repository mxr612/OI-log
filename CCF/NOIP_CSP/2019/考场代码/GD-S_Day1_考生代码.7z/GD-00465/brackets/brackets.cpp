#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

const int maxn=500005;

char c[maxn];
int fa[maxn];

struct Graph
{
	int val[256];
	Graph()
	{
		val['(']=-1,val[')']=1;
		fa[1]=0,ans[fa[1]]=0;
	}
	
	struct Edge{int from,to;}edges[maxn];
	int edge_cnt,Head[maxn],Next[maxn<<1];
	
	void add_edge(int from,int to)
	{
		edges[++edge_cnt]=(Edge){from,to};
		Next[edge_cnt]=Head[from],Head[from]=edge_cnt;return;
	}
	
	int ans[maxn];
	
	int stack[maxn];int top;
	
	void dfs(int root,int del,int ecnt,bool flag)
	{
		ans[root]=ans[fa[root]];
//		stack[top++]=c[root];
//		
//		printf("%d\n",root);for(int i=0;i<top;i++) printf("%c",stack[i]);puts("");
		
		if( c[root]=='(' ) del++,stack[top++]=root,flag=1;
		else if( c[root]==')' and del )
		{
			if( del )
			{
				del--;
				if(!del and flag) ecnt++;
				
				ans[root]+=1+ecnt;
				
//				if( top and c[ fa[stack[top-1]] ]==')' and ans[fa[stack[top-1]]] ) ans[root]++;
			}
			else flag=0,ecnt=0;
		}
//		printf("%d!!%d\n",root,del);
		
		for(int i=Head[root];i;i=Next[i])
		{
			Edge e=edges[i];
			dfs(e.to,del,ecnt,flag);
		}
//		printf("%d\n",ans[root]);
		top--;
		
		return;
	}
}G;
char stack[maxn];int top;

int ans[maxn];

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	
	int n;scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf(" %c",&c[i]);
	
	bool flag=1;
	
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&fa[i]),G.add_edge(fa[i],i);
		if( fa[i]!=i-1 ) flag=0;
	}
	
	if( flag==1 )
	{
		for(int i=1;i<=n;i++)
		{
			ans[i]=ans[i-1];
			
			for(int j=1;j<=i;j++)
			{
				top=0;
				
				for(int k=j;k<=i;k++)
				{
					if( top and stack[top-1]=='(' and c[k]==')' ) top--;
					else stack[top++]=c[k];
				}
				
				if( !top ) ans[i]++;
			}
		}
		
		long long Ans=ans[1];
		for(int i=2;i<=n;i++) Ans=( Ans^( (long long)i*ans[i] ) );//,printf("%d\n",ans[i]);
		
		printf("%lld",Ans);return 0;
	}
	
	G.dfs(1,0,0,0);
	
	long long ans=G.ans[1];
	for(int i=2;i<=n;i++) ans=( ans^( (long long)i*G.ans[i] ) );//,printf("ans[%d]=%d\n",i,G.ans[i]);
	
	printf("%lld",ans);
	return 0;
}

