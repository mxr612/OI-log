#include<cstdio>
#include<algorithm>
//used(i,i+1)

int readint()
{
	int ret = 0; char ch = getchar();
	while (ch > '9' || ch < '0') ch = getchar();
	while (ch <= '9' && ch >= '0') ret = (ret << 3) + (ret << 1) + ch - 48, ch = getchar();
	return ret;
}

const int MAXN = 2e3 + 10;
int x[MAXN], y[MAXN], s[MAXN] = {0}, ok[MAXN] = {0}, num[MAXN], pos[MAXN];
int T, N;

int lowbit(int x){return x & -x;}

int sum(int k)
{
	int ret = 0;
	while (k > 0)
	{
		ret += s[k];
		//printf("%d %d %d\n", s[k], ret, k);
		k -= lowbit(k);
	}
}

int add(int k)
{
	while (k <= N)
	{
		s[k]++;
		k += lowbit(k);
	}
}

int main()
{
	freopen("tree.in", "r", stdin);
	//freopen("tree.out", "w", stdout);
	T = readint();
	while (T--)
	{
		scanf("%d", &N);
		for (int i = 1;i <= N; i++) {int p = readint(); num[p] = i, pos[i] = p;}
		int ind = 0;
		for (int i = 1; i < N; i++)
		{
			x[i] = readint(), y[i] = readint();
			if (x[i] == 1 || y[i] == 1) ind++;
		}
		if (ind != N - 1)
		{
			add(N);
			for (int i = 1; i <= N; i++)
			{
				int flag = 0, qwq = i, now = 0, fd = 0;
				while (!flag)
				{
					fd = 0;
					for (int j = now + 1; j <= N; j++) if (!ok[j]) {now = j; fd = 1; break;}
					if (!fd) break; 
					if (sum(qwq) - sum(pos[now]) == 0) 
					{
						flag = 1; ok[now] = 1;
						if (qwq > pos[now])
							for (int i = pos[now]; i < qwq; i++) std::swap(num[i], num[i + 1]), add(i), pos[num[i]]++, pos[num[i + 1]]--;
						else
							for (int i = pos[now]; i > qwq; i--) std::swap(num[i], num[i - 1]), add(i - 1), pos[num[i]]--, pos[num[i - 1]]++;
					}
				}
				//for (int i = 1; i <= N; i++) printf("%d ", num[i]); printf("\n");
			}
		}
		for (int i = 1; i <= N; i++) printf("%d ", num[i]);
	}
	return 0;
}
