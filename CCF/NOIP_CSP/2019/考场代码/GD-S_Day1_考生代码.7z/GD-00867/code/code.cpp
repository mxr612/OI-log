#include<cstdio>

int N;
long long K;

int main()
{
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	scanf("%d%lld", &N, &K); K++; 
	for (int i = N; i >= 1; i--)
	{
		if (K > (1 << (i - 1))) 
		{
			printf("1"); 
			K = (1 << i) + 1 - K;
		}
		else 
		{
			printf("0");
		}
	}
	return 0;
}
