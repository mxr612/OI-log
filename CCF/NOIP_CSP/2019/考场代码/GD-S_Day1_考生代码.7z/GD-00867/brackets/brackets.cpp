#include<cstdio>
#include<cstring>

const int MAXN = 5e5 + 10;
int N;
long long Ans = 0;
char str[MAXN];
int fa[MAXN], tot[MAXN], sum[MAXN], bac[MAXN] = {0};

int readint()
{
	int ret = 0; char ch = getchar();
	while (ch > '9' || ch < '0') ch = getchar();
	while (ch <= '9' && ch >= '0') ret = (ret << 3) + (ret << 1) + ch - 48, ch = getchar();
	return ret;
}

int main()
{
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	N = readint();
	scanf("%s", str + 1);
	for (int i = 1; i < N; i++) fa[i] = readint();
	for (int i = 1; i <= N; i++)
	{
		int cnt = 0;
		for (int j = i; j <= N; j++)
		{
			if (str[j] == '(') cnt++;
			else cnt--;
			if (!cnt) tot[j]++;
			if (cnt < 0) break;
			//printf("%d %d %d\n", i, j, cnt);
		}
	}
/*	sum[0] = 0;
	for (int i = 1; i <= N; i++) 
	{
		sum[i] = sum[i - 1] + (str[i] == '(' ? 1 : -1);
		if (!sum[i]) tot[i]++;
		if (sum[i] < 0) memset(bac, 0, sizeof(bac));
		else tot[i] += bac[sum[i]];
		if (sum[i] < sum[i - 1]) bac[sum[i]]++;
	}*/
	int now = 0;
	for (int i = 1; i <= N; i++) now += tot[i], Ans = Ans ^ (long long)(i * now);//, printf("%d %d\n", i, now);
	printf("%lld", Ans);
	return 0;
}
