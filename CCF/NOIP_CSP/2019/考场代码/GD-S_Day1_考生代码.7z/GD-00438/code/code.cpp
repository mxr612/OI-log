#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
#define ll long long
#define re register
using namespace std;
string s1[10000005],s2[10000005],t;
//ll a[99999999],b[99999999];
int n,k;
void d(string s[],char a)
{
	for (re int i=1;i<=n;i++)
	{
		for (re int j=s[i].size();j>=1;j--)
			s[i][j+1]=s[i][j];
		s[i][1]=a;
	}
	
}
bool cmp(string a,string b)
{
	return a>b;
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	ll no=0;
	cin>>n>>k;
	s2[2]='0';s2[1]='1';
	for (re int i=1;i<=n;i++)
	{
		for (re int j=1;j<=pow(2,i);++j)
		{
			s1[no+j]=s2[j];
			no++;
		}
		for (re int j=1;j<=no+1;j++)
			s2[j]=s1[j];
		sort(s1+1,s1+n+1);
		d(s1,0);
		sort(s2+1,s2+n+1,cmp);
		d(s2,1);
	}
	int tn=pow(2,n-1);
	if(k<=tn)
		cout<<s1[k];
	else
		cout<<s2[k-tn];
	return 0;
}
