#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <stack>
#include <algorithm>
#define ll long long
#define re register
using namespace std;
int n,ans,cnt;
struct TR{
	char da;
	int fa;
}tr[500005];

inline bool ju(string s1)
{
	if(s1[0]==')' || s1.size()==1)
	return 0;
	char a[1005];
	int v=s1.size();
	for (re int i=0,cn=0;i<=s1.size()-1;i++)
	{
		if(a[cn]=='(' && s1[i]==')')
		{
			a[cn]='0';
		}
		else
		{
			a[cn]=s1[i];
			cn++;
		}
	}
	if(a[0]=='0')
		return 1;
	else return 0;
}
inline void bu(int t)
{
	string s1,s;
	while(1)
		{
			if(t==0)
			{
				s+=tr[0].da;
				break;
			}
				
			s+=tr[t].da;
			t=tr[t].fa;
		}
	for (re int i=s.size()-1;i>=0;i--)
	{
		for (re int j=i-1;j>=0;j--)
		{
			for (re int k=0;k<=i-j;k++)
				s1+=s[s.size()-k];
			if(ju(s1)==1)
				cnt++;
		}
	}
}
int main()
{
	freopen ("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	for (re int i=1;i<=n;++i)
		scanf("%c",&tr[i].da);
	for (re int i=1;i<=n;++i)
		scanf("%d",&tr[i].fa);
	int t;
	for (re int i=2;i<=n;++i)
	{
		cnt=0;
		t=i;
		bu(t);
		int ans=ans^(cnt*i);
	}
	cout<<ans;
	return 0;
}
