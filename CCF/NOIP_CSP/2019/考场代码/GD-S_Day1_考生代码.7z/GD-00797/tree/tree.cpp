#include<cstdio>
#include<iostream>
#include<cmath>
#include<cctype>
#include<queue>
using namespace std;
const int N=2*1e5+10;
typedef long long ll;
struct edges
{
	int u,v;
}p[N];
int head[N],nxt[N],cnt=-1;
bool use[N];
inline void add(int x,int y)
{
	p[++cnt].u=x;
	p[cnt].v=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
int ans[N],c[N],t[N],n;
void dfs(int num)
{
	if(!num)
	{
		bool fg=0;
		for(int i=1;i<=n;i++)
		{
			if(t[i]<ans[i])
			{
				fg=1;break;
			}
			if(t[i]>ans[i])
				break;
		}
		if(fg)
			for(int i=1;i<=n;i++)
				ans[i]=t[i];
	}
	for(int i=1;i<=cnt;i+=2)
	{
		if(!use[i])
		{
			use[i]=1;
			swap(c[p[i].u],c[p[i].v]);
			t[p[i].u]=c[p[i].u];
			t[p[i].v]=c[p[i].v];
			dfs(num-1);
			use[i]=0;
			swap(c[p[i].u],c[p[i].v]);			
		}
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int tmp,t1,t2;
	scanf("%d",&tmp);
	while(tmp--)
	{
		memset(use,0,sizeof(use));
		memset(head,0,sizeof(head));
		memset(nxt,0,sizeof(nxt));
		memset(ans,0x3f,sizeof(ans));
		memset(c,0,sizeof(c));
		memset(t,0,sizeof(t));
		cnt=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&t1);
			c[t1]=i;
		}
		for(int i=1;i<n;i++)
		{
			scanf("%d%d",&t1,&t2);
			add(t1,t2);
			add(t2,t1);
		}
		dfs(n-1);
		for(int i=1;i<=n;i++)
			printf("%d ",ans[i]);
		printf("\n");
	}
}
