#include<cstdio>
#include<iostream>
#include<cmath>
#include<cctype>
#include<queue>
using namespace std;
const int N=12*1e5+10;
typedef long long ll;
struct edges
{
	int u,v;
}p[N];
int head[N],nxt[N],cnt=0;
inline void add(int x,int y)
{
	p[++cnt].u=x;
	p[cnt].v=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
int fa[N],pre[N],c[N],n;
int q[N],rear,tail;
ll f[N],g[N];
void bfs(int v0)
{
	rear=1;tail=0;
	q[++tail]=v0;
	int x;
	while(rear<=tail)
	{
		x=q[rear];rear++;
		for(int i=head[x];i;i=nxt[i])
		{
			int dd=p[i].v;
			if(fa[x]!=dd)
			{
				if(c[dd])
				{
					f[dd]=f[x];
					g[dd]=0;
					pre[dd]=dd;
				}
				else
				{
					if(pre[x]>0)
					{
						g[dd]=1;
						g[dd]+=g[fa[pre[x]]];
						f[dd]=f[x]+g[dd];
						pre[dd]=pre[fa[pre[x]]];
					}
					else
					{
						if(pre[x]==0)pre[dd]=-1;
						f[dd]=f[x];
						g[dd]=0;
					}
				}
				q[++tail]=dd;
			}
		}
	}
}
inline int read()
{
	int x=0,f=1;
	char tmp=getchar();
	while(tmp<'0'||tmp>'9')
	{
		if(tmp=='-')f=-1;
		tmp=getchar();
	}
	while(tmp>='0'&&tmp<='9')
	{
		x=(x<<1)+(x<<3)+(tmp^48);
		tmp=getchar();
	}
	return x*f;
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	memset(fa,0,sizeof(fa));
	memset(pre,0,sizeof(pre));
	memset(f,0,sizeof(f));
	memset(head,0,sizeof(head));
	memset(nxt,0,sizeof(nxt));
	char ch;
	ll ans=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf(" %c",&ch);
		if(ch=='(')
			c[i]=1;
		else
			c[i]=0;
	}
	for(int i=2;i<=n;i++)
	{
		fa[i]=read();
		add(i,fa[i]);
		add(fa[i],i);
	}	
	f[1]=0;
	g[1]=0;
	if(c[1])pre[1]=1;
	bfs(1);
	for(int i=1;i<=n;i++)
		ans=ans^(1ll*i*f[i]);
	printf("%lld\n",ans);
	return 0;
}
/*
6
())(()
1 1 2 2 5
*/
