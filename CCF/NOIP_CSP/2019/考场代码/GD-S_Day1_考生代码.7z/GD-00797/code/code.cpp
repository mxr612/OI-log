#include<cstdio>
#include<iostream>
#include<cmath>
#include<cctype>
using namespace std;
typedef unsigned long long ull;
int n;
ull k;
int ans[1000];
ull qmod(ull x,int w)
{
	ull res=1;
	for(int i=1;i<=w;i++)
		res*=x;
	return res;	
} 
void solve(int num,ull pos)
{
	ull tmp=qmod(2,num-1);
	if(num==0)return;
	if(pos<tmp)
	{
		ans[num]=0;
		solve(num-1,pos);
	}
	else
	{
		ull t=pos+1-tmp;
		ans[num]=1;
		solve(num-1,tmp-t);
	}
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	memset(ans,0,sizeof(ans));
	cin>>n>>k;
	solve(n,k);
	for(int i=n;i;i--)
		printf("%d",ans[i]);
	printf("\n");
	return 0;
}
