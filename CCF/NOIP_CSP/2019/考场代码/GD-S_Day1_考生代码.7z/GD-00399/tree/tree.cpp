#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
int a[2010],minn[2010];
int s[2010],used[2010],ans[2010];
int q[2010];
int x[2010],y[2010];
int m,n;
bool p(){

	for(int i=1;i<=n;i++)if(s[i]!=ans[i])return s[i]<ans[i];
	return 0;
}
void dfs(int k){
	if(k>=n){
		for(int i=1;i<=n;i++)s[a[i]]=i;
		if(p())for(int i=1;i<=n;i++)ans[i]=s[i];
		return;
	}
	for(int i=1;i<n;i++)if(!used[i]){
		q[k]=i;
		used[i]=1;
		swap(a[x[i]],a[y[i]]);
		dfs(k+1);
		used[i]=0;
		swap(a[x[i]],a[y[i]]);
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--){
		memset(ans,0x3f,sizeof(ans));
		scanf("%d",&n);
		int ss;
		for(int i=1;i<=n;i++)scanf("%d",&ss),a[ss]=i;
		for(int i=1;i<n;i++)scanf("%d%d",&x[i],&y[i]);
		dfs(1);
		for(int i=1;i<=n;i++)printf("%d ",ans[i]);
		printf("\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
