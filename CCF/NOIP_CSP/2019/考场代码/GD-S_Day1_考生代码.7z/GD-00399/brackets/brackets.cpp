#include<iostream>
#include<cstdio>
using namespace std;
int head[500010],nxt[500010],mark[500010],cnt;
void add(int u,int v){
	nxt[++cnt]=head[u],mark[cnt]=v,head[u]=cnt;
}
char a[500010],tot;
long long num[500010];
long long que[500010],q[500010];
int m,n;
long long ans;
void dfs(long long k,long long sum,int l,int r){
	tot++;
	if(a[k]==')'){
		if(l==r)l=r=num[tot]=0;
		else{
			num[tot]=num[que[l-r]]+1;
			r++;
			sum+=num[tot];
		}
		printf("%d %d\n",k,sum);
		ans^=(sum*k);
		for(int i=head[k];i;i=nxt[i])dfs(mark[i],sum,l,r);
		r--;
		tot--;
	}
	else{
		int mem1=que[l-r+1];
		l++;
		que[l-r]=tot;
		if(l==r+1)num[tot]=num[tot-1];
		else num[tot]=0;
		printf("%d %d\n",k,sum);
		ans^=(sum*k);
		for(int i=head[k];i;i=nxt[i])dfs(mark[i],sum,l,r);
		que[l-r]=mem1;
		l--;
		tot--;
	}
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",a+1);
	for(int i=2;i<=n;i++)scanf("%d",&m),add(m,i);
	dfs(1,0,0,0);
	printf("%lld",ans);
	fclose(stdout);
	return 0;
}
