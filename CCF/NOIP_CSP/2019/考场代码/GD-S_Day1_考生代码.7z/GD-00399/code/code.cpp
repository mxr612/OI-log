#include<iostream>
#include<cstdio>
using namespace std;
long long n;
char k[50];
int rp[50];
int qp[64][50];
int len;
bool p(int a[],int b[]){
	for(int i=0;i<=40;i++)
	if(a[i]==b[i])continue;
	else return a[i]>b[i];
	return 1;
}
void m(int a[],int b[]){
	for(int i=0;i<=40;i++)a[i]-=b[i];
	a[40]--;
	for(int i=40;i;i--)if(a[i]<0)a[i]+=10,a[i-1]--;
	for(int i=0;i<=40;i++)rp[i]=a[i];
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%lld%s",&n,k);
	qp[0][40]=1;
	for(int i=1;i<64;i++){
		for(int j=40;j>=0;j--)qp[i][j]=qp[i-1][j]*2;
		for(int j=40;j>0;j--)if(qp[i][j]>9)qp[i][j]-=10,qp[i][j-1]++;
	}
	for(len=0;k[len];len++);
	len--;
	for(int i=0;i<=len;i++)rp[40-i]=k[len-i]-'0';
	for(int i=n;i;i--){
		if(p(rp,qp[i-1])){
			printf("1");
			m(qp[i],rp);
		}
		else printf("0");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
