#include<cstdio>
int n,tot;
long long mo=1,a[70],k;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%lld",&n,&k);
	for(int i=1;i<n;i++)mo*=2;
	while(mo)
	{
		a[++tot]=k/mo;
		if(k/mo==1)
		{
			k%=mo;
			k=mo-1-k;
		}
		else k%=mo;
		mo>>=1;
	}
	for(int i=1;i<=tot;i++)
	printf("%d",a[i]);
	return 0;
}
