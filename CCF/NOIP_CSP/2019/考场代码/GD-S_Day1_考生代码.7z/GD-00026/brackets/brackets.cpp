#include<cstdio>
#include<vector>
using namespace std;
vector<int>son[500005];
int n,fa[500005],dp[500005],lf[500005],cnt,q[500005];
char c[500005];
long long f[500005],ans;
void dfs(int x,int tot)
{
	if(c[x]=='(')
	{
		if(tot<0)tot=0;
		tot++;lf[tot]++;
	}	
	else tot--;
	dp[x]=tot;
	if(c[x]==')')
	f[x]+=lf[tot+1];
	f[x]+=f[fa[x]];
	for(int i=0;i<son[x].size();i++)
	dfs(son[x][i],tot);
	if(c[x]=='(')lf[tot]--;
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",c+1);
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&fa[i]);
		son[fa[i]].push_back(i);
	}
	dfs(1,0);
	ans=f[1];
	for(long long i=2;i<=n;i++)
	ans=ans^(f[i]*i);
	printf("%lld",ans);
	return 0;
}
