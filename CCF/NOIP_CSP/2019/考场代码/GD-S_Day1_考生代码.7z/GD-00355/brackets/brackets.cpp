#include <bits/stdc++.h>
#define file(s) freopen(s".in", "r", stdin), freopen(s".out", "w", stdout)
#define LL long long
using namespace std;
const int N = 5e5 + 77777;

bool chkmax(int &x, int y) { return x < y ? x = y , 1 : 0; }
bool chkmin(int &x, int y) { return x > y ? x = y , 1 : 0; }

#define Rint register int
#define inc(i, x, y) for (Rint i = x; i <= y; ++i)
#define dec(i, x, y) for (Rint i = x; i >= y; --i)
#define gc getchar

int rd() {
	int ret = 0; bool fl = 0; char ch = 0;
	while (!isdigit(ch)) fl |= (ch == '-'), ch = gc();
	while (isdigit(ch)) ret = (ret << 1) + (ret << 3) + (ch ^ 48), ch = gc();
	return fl ? -ret : ret;
}

char s[N];

int ecnt = 0, head[N];
struct edge { int nxt, to; } e[N << 1];
void adde(int u, int v) {
	e[++ecnt] = (edge) {head[u], v}, head[u] = ecnt;
	e[++ecnt] = (edge) {head[v], u}, head[v] = ecnt;
}
#define go(i, v, u) for (Rint i = head[u], v = e[i].to; i; i = e[i].nxt, v = e[i].to)

int lst = 0;

int pp = 0;
int P[N], dp[N];
LL ans[N];

void dfs(int u, int fa, int dep) {
	ans[u] = ans[fa]; int st = -1, fl = 0;
	if (s[u] == '(') P[++pp] = dep, dp[dep] = 0, fl = 1;
	else if (pp) {
		st = P[pp]; P[pp] = 0;
		--pp; dp[dep] = dp[st - 1] + 1;
		ans[u] += dp[dep];
	}
	go(i, v, u) if (v != fa) dfs(v, u, dep + 1);
	if (~st) P[++pp] = st;
	else if (fl) P[pp] = 0, --pp;
	dp[dep] = 0;
}

int main() {
	file("brackets");
	int n = rd();
	scanf("%s", s + 1);
	inc(i, 2, n) adde(i, rd());
	dfs(1, 0, 1);
	LL out = 0;
	inc(i, 1, n) (out ^= (1ll * ans[i] * i));
	printf("%lld\n", out);
}
