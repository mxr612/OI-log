#include <bits/stdc++.h>
#define file(s) freopen(s".in", "r", stdin), freopen(s".out", "w", stdout)
#define LL long long
using namespace std;
const int N = 80;

bool chkmax(int &x, int y) { return x < y ? x = y , 1 : 0; }
bool chkmin(int &x, int y) { return x > y ? x = y , 1 : 0; }

#define Rint register int
#define inc(i, x, y) for (Rint i = x; i <= y; ++i)
#define dec(i, x, y) for (Rint i = x; i >= y; --i)
#define gc getchar

int rd() {
	int ret = 0; bool fl = 0; char ch = 0;
	while (!isdigit(ch)) fl |= (ch == '-'), ch = gc();
	while (isdigit(ch)) ret = (ret << 1) + (ret << 3) + (ch ^ 48), ch = gc();
	return fl ? -ret : ret;
}

char s[N];
int a[N], g[N], cnt;
stack<int> S;

int main() {
	file("code");
	int n = rd(), st = 0;
	scanf("%s", s);
	int len = strlen(s);
	inc(i, 0, len - 1) a[i] = s[i] - '0';
	while (st < len) {
		S.push((a[len - 1] & 1));
		int rst = 0;
		inc(i, st, len - 1) {
			a[i] = a[i] + rst;
			if (a[i] & 1) rst = 10;
			else rst = 0;
			a[i] /= 2;
		}
		if (!a[st]) st++;
	}
	inc(i, 1, n - S.size()) g[++cnt] = 0;
	while (S.size()) { g[++cnt] = S.top(); S.pop();	}
	int lft = 0, rgt = 1;
	inc(i, 1, n) {
		if (g[i] == 0) printf("%d", lft), lft = 0, rgt = 1;
		else printf("%d", rgt), lft = 1, rgt = 0;
	}
}
