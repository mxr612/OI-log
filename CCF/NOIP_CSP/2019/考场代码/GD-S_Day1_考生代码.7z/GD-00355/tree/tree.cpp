#include <bits/stdc++.h>
#define file(s) freopen(s".in", "r", stdin), freopen(s".out", "w", stdout)
#define LL long long
using namespace std;
const int N = 2e3 + 777;

bool chkmax(int &x, int y) { return x < y ? x = y , 1 : 0; }
bool chkmin(int &x, int y) { return x > y ? x = y , 1 : 0; }

#define Rint register int
#define inc(i, x, y) for (Rint i = x; i <= y; ++i)
#define dec(i, x, y) for (Rint i = x; i >= y; --i)
#define gc getchar

int rd() {
	int ret = 0; bool fl = 0; char ch = 0;
	while (!isdigit(ch)) fl |= (ch == '-'), ch = gc();
	while (isdigit(ch)) ret = (ret << 1) + (ret << 3) + (ch ^ 48), ch = gc();
	return fl ? -ret : ret;
}

struct edge{ int f, t;};
edge Q[N];
bool vis[N];
int ans[N], deg[N];
int g[N], n, vl[N], ed[N], re[N];

void dfs(int dep){
	if (!dep) {
		inc(i, 1, n) vl[i] = re[i]; 
		inc(i, 1, n - 1) 
			swap(vl[Q[g[i]].f], vl[Q[g[i]].t]);
		inc(i, 1, n) ed[vl[i]] = i;
		bool fl = 0;
		inc(i, 1, n) {
			if (ans[i] > ed[i]) 
				{fl = 1; break;}
			else if (ans[i] < ed[i]) break;
		}
		if (fl == 1) inc(i, 1, n) ans[i] = ed[i];
		return;
	}
	inc(i, 1, n - 1) if (!vis[i]) vis[i] = 1, g[dep] = i, dfs(dep - 1), vis[i] = 0;
}

int main() {
	file("tree");
	int T = rd();
	while (T--) {
		n = rd(); int u, v, fl = 0, lnk = 1;
		inc(i, 1, n) vl[i] = rd(), re[i] = vl[i], ans[i] = n + 1;
		inc(i, 1, n - 1) {
			u = rd(), v = rd();
			Q[i] = (edge){u, v}, deg[u]++, deg[v]++;
			if (deg[u] == n - 1 || deg[v] == n - 1) fl = 1;
			if (abs(u - v) != 1) lnk = 0;
		}
		if (lnk) {
			inc(i, 1, n) printf("%d ", i);
			puts("");
		}
		else if (fl) {
			inc(i, 1, n) ans[i] = i;
			if (vl[1] == 1) swap(ans[1], ans[2]);
			inc(i, 1, n) printf("%d ", ans[i]);
			puts("");
		}
		else {
			dfs(n - 1);
			inc(i, 1, n) printf("%d ", ans[i]);
			puts("");
		}
	}
}
