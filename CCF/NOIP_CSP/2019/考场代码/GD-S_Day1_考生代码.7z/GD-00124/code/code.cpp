#include<bits/stdc++.h>
using namespace std;
long long n,m;
int ans[128];
bool p;
long long a[128];
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	a[1]=1;
	for (int i=2;i<=66;i++){
		a[i]=a[i-1]*2;
	}
	cin>>n>>m;
	m++; p=true;
	for (int i=n;i>=1;i--){
		if (p){
			if (a[i]>=m) {
				ans[n-i]=0;
			}else{
				ans[n-i]=1;
				m-=a[i];
				if (p) p=false;
				else p=true;
			}
		}else{
			if (a[i]>=m) {
				ans[n-i]=1;
				if (p) p=false;
				else p=true;
			}else{
				ans[n-i]=0;
				m-=a[i];
				
			}
		}
	}
	for (int i=0;i<=n-1;i++) cout<<ans[i];
	return 0;
}
