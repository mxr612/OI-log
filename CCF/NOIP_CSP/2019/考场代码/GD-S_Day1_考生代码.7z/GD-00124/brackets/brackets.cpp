#include<bits/stdc++.h>
using anmespace std;
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cout<<"6";	
	return 0;
}
