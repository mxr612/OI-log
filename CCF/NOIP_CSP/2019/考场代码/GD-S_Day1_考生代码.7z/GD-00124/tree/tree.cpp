#include<bits/stdc++.h>
using namespace std;
int a[2010][2010];
bool p[2010][2010];
int ai[2010],cnt[2010],ans[2010],zhan1[2010],zhan2[2010];
int T,n,ji,jix,jiy;
void srch(int bnm,int wei){
	int shu=ai[bnm];
	if (cnt[bnm]<=0) return;
	else{
		for (int i=1;i<=cnt[bnm];i++){
			if (p[bnm][a[bnm][i]]){
				p[a[bnm][i]][bnm]=false;
				srch(a[bnm][i],wei+1);
			}
		}
		int w=0;
		for (int i=1;i<=cnt[bnm];i++){
			if (p[bnm][a[bnm][i]]){//a[bnm][i]Ϊ��� 
				w++;
				zhan1[w]=a[bnm][i];
				zhan2[w]=ai[a[bnm][i]];
			}	
		}
		zhan1[0]=bnm;
		zhan2[0]=ai[bnm];
		sort(zhan1,zhan1+w+1);
		sort(zhan2,zhan2+w);
		for (int i=0;i<=w;i++){
			if (ai[zhan1[i]]!=zhan2[i]){
				ai[zhan1[i]]=zhan2[i];
				p[bnm][zhan1[i]]=false;
			}else{
				if (wei==1){
					if (i!=w){
						ai[zhan1[i]]=zhan2[i];
						ai[zhan1[i+1]]=zhan2[i+1];
						swap(ai[zhan1[i]],ai[zhan1[i+1]]);
						p[bnm][zhan1[i]]=false;
						p[bnm][zhan1[i+1]]=false;
					}else{
						ai[zhan1[i]]=zhan2[i];
						swap(ai[zhan1[i]],ai[zhan1[i-1]]);
						p[bnm][zhan1[i]]=false;
					}
				}
			}
		}
	}
	return;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>T;
	for (int k=1;k<=T;k++){
		cin>>n;
		for (int i=1;i<=n;i++){
			cin>>ji;
			ai[ji]=i;//ji Ϊ���,ai[i]Ϊ���� 
		}
		for (int i=1;i<=n-1;i++){
			cin>>jix>>jiy;
			p[jix][jiy]=true; p[jiy][jix]=true;
			cnt[jix]++; cnt[jiy]++;
			a[jix][cnt[jix]]=jiy;
			a[jiy][cnt[jiy]]=jix;
		}
		for (int i=1;i<=n;i++) srch(i,1);
		for (int i=1;i<=n;i++) ans[ai[i]]=i;
		for (int i=1;i<=n;i++) cout<<ans[i]<<" ";
	}
	return 0;
}
