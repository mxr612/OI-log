#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
long long m,cl;
int n,sc;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cl=1;
	scanf("%d%lld",&n,&m);
	for (int i=1;i<=n-1;i++)
	cl=cl<<1;
	int bl=0;
	for (int i=1;i<=n;i++)
	{
		if ((m>=cl&&bl==0)||(m<cl&&bl==1))
		sc=1;
		else
		sc=0;
		printf("%d",sc);
		if(m>=cl) m-=cl;
		if (sc==1)
		{if(bl==1) bl=0;
		else bl=1;}
		cl=(cl>>1);
	}
	return 0;
}
