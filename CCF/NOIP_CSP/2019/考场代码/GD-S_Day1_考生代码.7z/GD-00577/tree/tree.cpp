#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int T,n,zh;
int r[2001],o[2001],vl[2001],mi[2001],og[2001],cd[2001],scc[2001],su=0;
int oo[2001];
struct op{
	int zx,nx,o;
}eg[4001];
int jd[2001];
void ad(int x,int y)
{
	su++;
	eg[su].zx=y;
	eg[su].nx=r[x];
	eg[su].o=0;
	r[x]=su;
}
void bl(int x)
{
	int mb=x,sl=0;
	cd[x]=x,og[x]=x;
	o[x]=1;
	mi[x]=vl[x];
	for (int i=r[x];i;i=eg[i].nx)
	{
		int z=eg[i].zx;
		if (o[z]==1||eg[i].o==1||oo[z]==1) {continue;}
		bl(z);
		if (mi[z]<mi[x])
		mi[x]=mi[z],mb=z,sl=i,cd[x]=cd[z];
	}
	og[mb]=x;
	if (mb!=x)
	jd[mb]=(((sl+1)>>1)<<1);
	else jd[x]=0;
}
void bl2(int x)
{
	int zz=og[x];
	swap(vl[zz],vl[x]);
	if (jd[x]!=0||og[x]!=x)
	eg[jd[x]].o=1,eg[jd[x]-1].o=1;
	if (og[x]!=x)
	bl2(zz);
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	for (int i=1;i<=T;i++)
	{
		memset(oo,0,sizeof(oo));
		su=0;
		int y,u;
		scanf("%d",&n);
		for (int j=1;j<=n;j++)
		scanf("%d",&vl[j]);
		for (int j=1;j<=n-1;j++)
		scanf("%d%d",&y,&u),
		ad(y,u),ad(u,y);
		for (int j=1;j<=n;j++)
		{
			memset(o,0,sizeof(o));
			bl(j);
			scc[j]=mi[j];
			printf("%d ",scc[j]);
			oo[j]=1;
			bl2(cd[j]);
		}
		printf("\n");
	}
}
