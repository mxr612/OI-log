#include<cstdio>
#include<iostream>
const int N=5e5+10;
int n,m,i,j;
int f[N],sum[N],le[N],ri[N],h[N];
char s[N];
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d%d",&n,&m);
	scanf("%s",s+1);
	bool bz=true;
	for (i=2;i<=n;i++)
	{
		scanf("%d",&f[i]);
		if (f[i]!=i-1) bz=false;
	}
	if (bz)
	{
		int num=0;
		long long ans=0;
		for (i=1;i<=n-1;i++)
		{
			if (s[i]=='(' && s[i+1]==')')
			{
				num++;
				int l=i,r=i+1;
				while (l>=1 && r<=n)
				{
					if (s[l]=='(' && s[r]==')')
					{
						le[num]=l;
						ri[num]=r;
						sum[num]++;
					}
					else
						break;
					l--;
					r++;
				}
				h[num]=1;
			}
		}
		long long js=0,jl=0;
		j=1;
		for (i=2;i<=n;i++)
		{
			while (ri[j]<i && j<num) j++;
			if (le[j]<=i && ri[j]>=i)
			{
				if (i==ri[j])
				{
					if (ri[j-1]+1==le[j])
					{
						jl+=h[j]*h[j-1];
						h[j]+=h[j-1];
					}
				}
				if (s[i]==')') js++;
			}
			ans^=(i*(js+jl));
		}
		printf("%lld",ans);
	}
	
}
