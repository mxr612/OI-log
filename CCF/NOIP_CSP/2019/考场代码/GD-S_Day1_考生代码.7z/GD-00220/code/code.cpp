#include<cstdio>
#include<iostream>
long long i,n,m,sum;
int ans[110];
long long ksm(long long xx,long long yy)
{
	long long jl=1;
	while (yy)
	{
		if (yy&1) jl=jl*xx;
		yy>>=1;
		xx=xx*xx;
	}
	return jl;
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	m++;
	int num=0;
	for (i=1;i<=n;i++)
	{
		long long k=ksm((long long)2,(n-i+1));
		long long js=m/k;
		if (m%k) js++;
		long long p=m-k*(js-1);
		if (js%2)
		{
			if (p<=k/2) ans[i]=0;
			else
				ans[i]=1;
		}
		else
		{
			if (p<=k/2) ans[i]=1;
			else
				ans[i]=0;
		}
	}
	for (i=1;i<=n;i++)
	{
		printf("%d",ans[i]);
	}
	return 0;
}
