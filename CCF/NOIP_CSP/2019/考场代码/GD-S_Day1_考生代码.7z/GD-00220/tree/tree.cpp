#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;
const int N=2010;
int n,m,i,j,T,bian,mi;
int a[N],f[N][3],num[N],ans[N],d[N],p[N],nxt[N],la[N],tov[N],fr[N];
bool bz[N],vis[N],tr;
int bzbz[N];
void insert(int xx,int yy)
{
	bian++;
	tov[bian]=yy;
	fr[bian]=xx;
	nxt[bian]=la[xx];
	la[xx]=bian;
}
void search(int t)
{
	if (t==n)
	{
		bool bz1=false;
		for (int k=1;k<=n;k++)
		{
			if (ans[k]>num[k])
			{
				bz1=true;
				break;
			}
			if (ans[k]<num[k]) break;
		}
		if (bz1)
		{
			for (int k=1;k<=n;k++)
			{
				ans[k]=num[k];
			}
		}
		return;
	}
	for (int k=1;k<=n-1;k++)
	{
		if (!bz[k])
		{
			bz[k]=true;
			int xx=f[k][1],yy=f[k][2];
			int jh=a[xx];
			a[xx]=a[yy];
			a[yy]=jh;
			num[a[xx]]=xx;
			num[a[yy]]=yy;
			search(t+1);
			jh=a[xx];
			a[xx]=a[yy];
			a[yy]=jh;
			num[a[xx]]=xx;
			num[a[yy]]=yy;
			bz[k]=false;
		}
	}
}
void fi(int xx)
{
	mi=min(mi,xx);
	int k=la[xx];
	while (k)
	{
		int p1=tov[k];
		if (bzbz[p1]<2 && !bz[k])
		{
			bz[k]=true;
			fi(p1);
			bz[k]=false;
		}
		k=nxt[k];
	}
}
void suan(int xx)
{
	int k=la[xx];
	while (k)
	{
		int p1=tov[k];
		if (bzbz[p1]<2 && !bz[k])
		{
			bzbz[p1]++;
			bz[k]=true;
			
			int x1=fr[k],y1=tov[k];
			int jh=a[x1];
			a[x1]=a[y1];
			a[y1]=jh;
			num[a[x1]]=x1;
			num[a[y1]]=y1;
			if (p1==mi)
			{
				tr=true;
				return;
			}
			suan(p1);
			if (tr) return;
			jh=a[x1];
			a[x1]=a[y1];
			a[y1]=jh;
			num[a[x1]]=x1;
			num[a[y1]]=y1;
			
			bz[k]=false;
			bzbz[p1]--;
		}
		k=nxt[k];
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while (T)
	{
		scanf("%d",&n);
		bool bz2=true;
		memset(d,0,sizeof(d));
		for (i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
			num[a[i]]=i;
		}
		for (i=1;i<=n-1;i++)
		{
			scanf("%d%d",&f[i][1],&f[i][2]);
			insert(f[i][1],f[i][2]);
			insert(f[i][2],f[i][1]);
			d[f[i][1]]++;
			d[f[i][2]]++;
			if (d[f[i][1]]>2 || d[f[i][2]]>2) bz2=false;
		}
		if (!bz2 || n<=10)
		{
			memset(bz,false,sizeof(bz));
			for (i=1;i<=n;i++)
			{
				ans[i]=n;	
			}
			search(1);
		}
		else
		{
			memset(bzbz,false,sizeof(bzbz));
			for (i=1;i<=n;i++)
			{
				int num1=num[i];
				mi=1e9;
				for (j=1;j<=n;j++)
				{
					vis[i]=false;
				}
				vis[num1]=false;
				fi(num1);
				for (j=1;j<=n;j++)
				{
					vis[i]=false;
				}
				tr=false;
				if (mi!=num[i]) suan(num1);
			}
			for (i=1;i<=n;i++)
			{
				ans[i]=num[i];
			}
		}
		for (i=1;i<=n;i++)
		{
			printf("%d ",ans[i]);
		}
		printf("\n");
		T--;
	}
}
