#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#define ll long long
using namespace std;

ll n,k,ans;
ll l,r;
bool check,shunxu;
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	shunxu=1;
	cin>>n>>k;
	l=0;r=1;
	for(int i=1;i<=n;i++){
		r*=2;
	}r--;
	while(l<r){
		check=0;
		ll mid=l+r>>1;
		if(k>mid){
			l=mid+1;
			k=r-(k-l);
			check=1;
			
		}
		if(k<=mid){
			r=mid;
		}
		
		cout<<check;
	}
	return 0;
}
