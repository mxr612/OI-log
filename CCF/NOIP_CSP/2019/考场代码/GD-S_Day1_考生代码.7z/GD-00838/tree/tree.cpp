#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#define ll long long
using namespace std;

int T;
ll n,k,ans;
ll l,r;
int x,y;
int dat[2001];
bool check,shunxu;
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>T;
	while(T--){
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&dat[i]);
		}
		for(int i=1;i<n;i++)cin>>x>>y;
		sort(dat+1,dat+1+n);
		for(int i=1;i<=n;i++)
		{
			cout<<dat[i]<<' ';
		}cout<<endl;
		
	}
}
/* 6
(()())
1 2 3 4 5
*/
