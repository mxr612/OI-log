#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
#include<algorithm>
#define ll long long
#define maxn 500001
#define RI register int
using namespace std;

int n;
int from[maxn];
char map[maxn],lianxu;
ll k[maxn],ans;
ll comp[maxn];//iceng������ɵ�������� 
bool genl;
int r,l;
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	getchar();
	for(RI i=1;i<=n;i++)
	map[i]=getchar();
	for(RI i=2;i<=n;i++)
	scanf("%d",&from[i]);
	genl=(map[1]=='(')?1:0;
	
	for(int i=1;i<=n;i++)//gen to i
	{
		l=r=0;
		int fa=from[i];
		if(map[i]=='(')l++;
		else r++;
		memset(comp,0,sizeof(comp));
		
		if(genl){
			
			while(fa){
				if(r){
					if(map[fa]=='('){
						if(lianxu=='('){
							comp[r]=0;
						}
						k[i]+=++comp[r];
						r--;
						
					}
					else{
						r++;
					}
				}else{
					if(map[fa]==')')r++;
					else{
						if(lianxu=='('){
							comp[1]=0;
						}
					}
				}
				lianxu=map[fa];
				fa=from[fa];
			}
		}else{
			while(fa){
				if(l){
					if(map[fa]==')'){
						if(lianxu==')'){
							comp[l]=0;
						}
						k[i]+=++comp[l];
						l--;
						
					}
					else{
						l++;
					}
				}else{
					if(map[fa]=='(')l++;
					else{
						if(lianxu==')'){
							comp[1]=0;
						}
					}
				}
				lianxu=map[fa];
				fa=from[fa];
			}
		}
	}
	ans=k[1];
	for(RI i=2;i<=n;i++)
	{
		ans=ans^(i*k[i]);
	}
//for(RI i=1;i<=n;i++)
//cout<<k[i]<<' ';
	cout<<ans;
	return 0;
}
