#include<iostream>
#include<cstdio>
#include<stack>
using namespace std;
struct data{
	long long x,y;
}t[1000001];
long long n,id,ans,h[1000001],s,p[1000001];
char ch[1000001];
stack<long long> q;
void add(long long a,long long b){
	t[b].x=b;
	t[b].y=h[a];
	h[a]=b;
	return;
}
void dfs(long long a){
	long long u,v;
	if(ch[a]==')'){
		u=q.top();
		q.pop();
		v=q.top();
		p[a]=p[a]+v;
		for(long long i=h[a];i;i=t[i].y){
			p[t[i].x]=p[a];
			dfs(t[i].x);
		}
		q.push(u);
	}else{
		u=q.top();
		q.pop();
		q.push(u+1);
		q.push(0);
		for(long long i=h[a];i;i=t[i].y){
			p[t[i].x]=p[a];
			dfs(t[i].x);
		}
		q.pop();
		q.pop();
		q.push(u);
	}
	s=p[a]*a;
	ans=ans^s;
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%lld",&n);
	scanf("%s",ch+1);
	for(long long i=2;i<=n;i++){
		scanf("%lld",&id);
		add(id,i);
	}
	for(long long i=1;i<=n+3;i++)q.push(0);
	dfs(1);
	printf("%lld\n",ans);
}
