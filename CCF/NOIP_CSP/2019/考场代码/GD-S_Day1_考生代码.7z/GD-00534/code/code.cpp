#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int n,s[101],l,f[101],fl,p[101][101],k[101],t[101];
char ch[101];
bool check(int a){
	bool b=1;
	for(int i=1;i<=100;i++){
		if(f[i]!=p[a][i]){
			if(f[i]>p[a][i])b=1;
			else b=0;
			break;
		}
	}
	if(b){
		for(int i=1;i<=100;i++)f[i]=f[i]-p[a][i];
		for(int i=100;i>=1;i--){
			if(f[i]<0){
				f[i]=f[i]+10;
				f[i-1]--;
			}
		}
	}
	return b;
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",ch+1);
	l=strlen(ch+1);
	for(int i=1;i<=l;i++)f[100-l+i]=ch[i]-'0';
	p[n][100]=1;
	for(int i=n-1;i>=1;i--){
		for(int j=1;j<=100;j++)p[i][j]=p[i+1][j]*2;
		for(int j=100;j>=1;j--){
			p[i][j-1]=p[i][j-1]+p[i][j]/10;
			p[i][j]=p[i][j]%10;
		}
	}
	for(int i=1;i<=n;i++){
		if(check(i))t[i]=1;
		else t[i]=0;
	}
	for(int i=1;i<=n;i++){
		if(t[i]){
			s[i]=1;
			for(int j=i+1;j<=n;j++){
				if(t[j]==0)t[j]=1;
				else t[j]=0;
			}
		}else s[i]=0;
	}
	for(int i=1;i<=n;i++)printf("%d",s[i]);
	return 0;
}
