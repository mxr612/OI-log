#include<iostream>
#include<cstdio>
using namespace std;
int w,n,x[10001],y[10001],f[10001],h[10001],cnt,s[40001],p[40001],tot,fl,k[10001];
void check(){
	bool kkk=0;
	for(int i=1;i<=n;i++){
		if(f[i]<k[i]){
			kkk=1;
			break;
		}
		if(k[i]<f[i])break;
	}
	if(kkk){
		for(int i=1;i<=n;i++)k[i]=f[i];
	}
}
void bfs(int a){
	if(a==n){
		check();
		return;
	}
	for(int i=1;i<n;i++){
		if(!p[i]){
			p[i]=1;
			swap(f[s[x[i]]],f[s[y[i]]]);
			swap(s[x[i]],s[y[i]]);
			bfs(a+1);
			swap(s[x[i]],s[y[i]]);
			swap(f[s[x[i]]],f[s[y[i]]]);
			p[i]=0;
		}
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&w);
	while(w){
		w--;
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			k[i]=n;
			p[i]=0;
		}
		for(int i=1;i<=n;i++){
			scanf("%d",&f[i]);
			s[f[i]]=i;
		}
		for(int i=1;i<n;i++)scanf("%d%d",&x[i],&y[i]);
		bfs(1);
		for(int i=1;i<=n;i++)printf("%d ",k[i]);
		printf("\n");
	}
}
