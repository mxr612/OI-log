#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>
using namespace std;

string f[5000050],tmp[5000050];
int n,k;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%d",&n,&k);
	f[1]="0"; f[2]="1"; int num=2;
	for (int i=2; i<=n; i++)
	{
		for (int i=1; i<=num; i++)
		{
			tmp[i]="0"+f[i];
		}
		int sum=0;
		for (int i=num; i>0; i--)
		{
			sum++;
			tmp[num+sum]="1"+f[i];
		}
		num*=2;
		for (int i=1; i<=num; i++)
		  f[i]=tmp[i];
	}
	cout<<f[k+1];
	return 0;
}
