#include <iostream>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <algorithm>
using namespace std;

const int maxn=2050;
int Ans=0,sum[maxn],f[maxn],n;
bool boo[maxn][maxn];
char ch[maxn];
int Count(string s)
{
	int lon=s.size(),ans=0;
	for (int i=0; i+1<lon; i++)
	{
		if (s[i]=='('&&s[i]!=s[i+1]) boo[i][i+1]=true;
	}
	for (int i=4; i<=lon; i+=2)
	{
		for (int j=0; j+i-1<lon; j++)
		{
			if (s[j]=='('&&s[j+i-1]!=s[j]&&boo[j+1][j+i-2]) boo[j][j+i-1]=true;
			for (int k=j+1; k<=j+i-2; k++)
			  if (boo[j][k]&&boo[k+1][j+i-1]) 
			  {
			  	boo[j][j+i-1]=true; break;
			  }
		}
	}
	for (int i=2; i<=lon; i+=2)
	  for (int j=0; j+i-1<lon; j++)
	    if (boo[j][j+i-1]) ans++;
	return ans;
}
int main()
{
	freopen("brackets.int","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	for (int i=1; i<=n; i++)
	  cin>>ch[i];
	f[1]=1;
	for (int i=2; i<=n; i++)
	  scanf("%d",&f[i]);
	for (int i=1; i<=n; i++)
	{
		int tmp=i; string s="";
		while (tmp!=1)
		{
			s+=ch[tmp];
			tmp=f[tmp];
		}
		s+=ch[1];
		for (int j=0; j<s.size()/2; j++) swap(s[j],s[s.size()-j-1]);
		memset(boo,false,sizeof(boo));
		sum[i]=i*Count(s);
	}
	for (int i=1; i<=n; i++)
	{
	  Ans=(Ans xor sum[i]);
	}
	printf("%d",Ans);
	return 0;
}
