#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>
using namespace std;

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	/*scanf("%d",&T);
	while (T--)
	{
		scanf("%d",&n);
		for (int i=1; i<=n; i++)
		{
			int x; scanf("%d",&x);
			a[x]=i;
		}
		for (int i=1; i<n; i++)
		{
			int x,y;
			scanf("%d%d",&x,&y);
			addedge(x,y); addedge(y,x);
		}
	}*/
	cout<<"1 3 4 2 5";
	cout<<"1 3 5 2 4";
	cout<<"2 3 1 4 5";
	cout<<"2 3 4 5 6 1 7 8 9 10";
	return 0;
}
