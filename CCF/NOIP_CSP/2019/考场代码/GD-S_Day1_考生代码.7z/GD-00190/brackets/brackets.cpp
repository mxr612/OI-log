#include<iostream>
#include<cstdio>
#define rg register
#define il inline
using namespace std;
typedef long long LL;
int n,cnt_edge;
LL ans;
struct edge{
	int to,next;
}a[500005];
char ch[500005];
int fir[500005];
LL dp[500005];
il void set_edge(int from,int to)
{
	a[++cnt_edge].to=to;
	a[cnt_edge].next=fir[from];
	fir[from]=cnt_edge;
}
void DP(LL cur,LL cnt,LL tot)
{
//	cout<<cur<<endl;
//	cout<<dp[cur]<<"dp"<<endl;
	if(ch[cur]=='(') ++cnt;
	else if(cnt>0)
	{
		--cnt;
		++tot;
	}
	dp[cur]=tot;ans^=dp[cur]*cur;
//	cout<<dp[cur]<<"dp"<<endl;
//	if(dp[cur]) cout<<cur<<"cur"<<endl;
	for(rg int i=fir[cur];i;i=a[i].next)
	{
		DP(a[i].to,cnt,tot);
	}
}
int main(void)
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	ios::sync_with_stdio(false);cin.tie(0);
	cin>>n;
	for(rg int i=1;i<=n;++i) cin>>ch[i];
	for(rg int i=1,x;i< n;++i)
	{
		cin>>x;
		set_edge(x,i+1);
	}
	DP(1LL,0,0);
	cout<<ans;
}
