#include<iostream>
#include<cstdio>
#define rg register
#define il inline
using namespace std;
int n,T;
struct edge{
	int u,v;
}e[2005];
int a[2005];
int v[2005];
int temp[2005];
int ans[2005];
bool vis[2005];
il void print()
{
	for(rg int i=1;i<=n;++i) printf("%d ",ans[i]);
	putchar('\n');
}
void update()
{
	for(rg int i=1;i<=n;++i) temp[a[i]]=i;
	for(rg int i=1;i<=n;++i) 
	if(temp[i]<ans[i])
	{
		for(rg int j=1;j<=n;++j)
		ans[j]=temp[j];
		return;
	}
	else if(temp[i]>ans[i]) return;
	
}
void dfs(int k)
{
	if(k==n)
	{
		update();
		return;
	}
	for(rg int i=1;i<n;++i)
	{
		if(vis[i]) continue;
		vis[i]=1;
		rg int tmp=a[e[i].v];
		a[e[i].v]=a[e[i].u];
		a[e[i].u]=tmp;
		dfs(k+1);
		tmp=a[e[i].v];
		a[e[i].v]=a[e[i].u];
		a[e[i].u]=tmp;
	}
}
int main(void)
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		for(rg int i=1,x;i<=n;++i)
		{
			scanf("%d",&x);
			v[i]=x;
			a[x]=i;
			ans[i]=x;
		}
		for(rg int i=1;i<n;++i)
		scanf("%d%d",&e[i].u,&e[i].v);
		dfs(1);
		print();
	}
}
