#include<iostream>
#include<cstdio>
#define rg register
#define il inline
using namespace std;
typedef long long LL;
int n;
LL k;
void print(int n,LL k,bool pre)
{
	if(n==0) return;
	rg LL mid=1LL<<n-1;
	if(k>=mid)
	{
		if(pre){
			putchar('0');
			return print(n-1,k%mid,pre);
		}
		else 
		{
			putchar('1');
			return print(n-1,k%mid,pre^1);
		}
		
	}else{
		if(pre)
		{
			putchar('1');
			return print(n-1,k%mid,pre^1);
		}
		else {
			putchar('0');
			return print(n-1,k%mid,pre);
		}
	}
}
int main(void)
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%lld",&n,&k);
	print(n,k,0);
}
