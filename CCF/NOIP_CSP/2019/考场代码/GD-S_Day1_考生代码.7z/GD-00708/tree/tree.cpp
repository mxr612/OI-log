#include<cstdio>
#define N 2005
#define swap(x,y) (x^=y,y^=x,x^=y)
using namespace std;
struct Node{
	int y;
	int x;
}tab[N];
bool vis[N];
int a[N],ans[N],tep[N];
int n;
bool check(){
	for(int i=1;i<=n;i++){
		if(tep[i]<ans[i])return 1;
		if(tep[i]>ans[i])return 0;
	}
	return 0;
}
void dfs(int k){
	if(k==0){
		for(int i=1;i<=n;i++){
			tep[a[i]]=i;
		}
		if(ans[1]==0||check()){
			for(int i=1;i<=n;i++)
				ans[i]=tep[i];
		}
	}
	for(int i=1;i<n;i++){
		if(!vis[i]){
			vis[i]=1;
			swap(a[tab[i].x],a[tab[i].y]);
			dfs(k-1);
			vis[i]=0;
			swap(a[tab[i].x],a[tab[i].y]);
		}
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T,t;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&t);
			a[t]=i;
		}
		for(int i=1;i<n;i++){
			scanf("%d%d",&tab[i].x,&tab[i].y);
		}
		dfs(n-1);
		for(int i=1;i<=n;i++)
			printf("%d ",ans[i]);
		printf("\n");
		ans[1]=0;
	}
	return 0;
}
