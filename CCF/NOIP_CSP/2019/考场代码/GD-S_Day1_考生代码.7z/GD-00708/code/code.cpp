#include<cstdio>
#define ll long long
using namespace std;
void dfs(int n,ll k){
	if(n==1){
		printf("%lld",k);
		return ;
	}
	ll num=1;
	num<<=(n-1);
	num-=1;
	if(k<=num){
		printf("0");
		dfs(n-1,k);
	}
	else{
		num=1;
		num<<=n;
		num-=1;
		printf("1");
		dfs(n-1,num-k);
	}
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	int n;
	ll k;
	scanf("%d%lld",&n,&k);
	dfs(n,k);
	return 0;
}
