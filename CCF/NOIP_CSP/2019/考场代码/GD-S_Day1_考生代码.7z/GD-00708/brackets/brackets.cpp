#include<cstdio>
#include<iostream>
#define N 500005
#define ll long long
using namespace std;
bool ord[N];
int cnt,head[N];
struct Node{
	ll to;
	int nxt;
}tab[N];
void add(ll x,ll y){
	tab[++cnt].to=y;
	tab[cnt].nxt=head[x];
	head[x]=cnt;
}
ll ans,val[N];
ll top;
void dfs(ll x,ll t){
	ll v;
	int k=-2;
	if(ord[x]==1){
		++top;
		k=-1;
	}
	else{
		if(top!=0){
			k=val[top];
			val[top]=0;
			--top;
			t+=val[top]+1;
			val[top]++;
		}
	}
	ans^=x*t;
	for(int i=head[x];i;i=tab[i].nxt){
		v=tab[i].to;
		dfs(v,t);
	}
	if(k==-1)--top;
	else if(k!=-2){
		--val[top];
		++top;
		val[top]=k;
	}
	
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n;
	scanf("%d",&n);
	char c;
	bool pan=1;
	for(int i=1;i<=n;i++){
		cin>>c;
		if(c=='(')ord[i]=1;
		else ord[i]=0;
	}
	ll fa;
	for(ll i=2;i<=n;i++){
		scanf("%lld",&fa);
		if(fa!=i-1)pan=0;
		add(fa,i);
	}
	if(pan==1){
		ll t=0;
		for(int i=1;i<=n;i++){
			if(ord[i]==1){
				++top;
			}
			else{
				if(top!=0){
					val[top]=0;
					--top;
					t+=val[top]+1;
					val[top]++;
				}
			}
			ans^=i*t;
		}
		printf("%lld",ans);
		return 0;
	}
	dfs(1,0);
	printf("%lld",ans);
	return 0;
}
