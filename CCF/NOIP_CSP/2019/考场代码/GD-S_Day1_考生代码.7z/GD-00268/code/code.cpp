#include<bits/stdc++.h>
#define ll unsigned long long
using namespace std;
ll read() {
	ll x = 0;
	char ch = getchar();
	for(;ch < '0' || ch > '9';) ch  = getchar();
	for(;ch >= '0' && ch <= '9';) x = x * 10 + (ch - '0'), ch = getchar();
	return x;
}
int n;
ll k, ha[105];
void get(int x, ll y) {
	if(x == 0) return;
	if(y <= ha[x - 1]) {
		printf("0");
		get(x - 1, y);
	} else {
		printf("1");
		get(x - 1, ha[x] - y);
	}
}
int main() {
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d", &n); 
	k = read();
	ha[0] = 0;
	for(int i = 1; i <= n; i ++) ha[i] = ha[i - 1] | (1ll << (i - 1));
//	for(int i = 0; i <= n; i ++) printf("%lld ", ha[i]);
	get(n, k);
	return 0;
}
