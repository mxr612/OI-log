#include<bits/stdc++.h>
#define N 2005
using namespace std;
int n, a[N], b[N], c[N], ha[N], U[N], V[N], ans[N], vis[N], aa[N], t, L[N], R[N];
void dfs(int x) {
	if(x >= n) {
		for(int i = 1; i <= n; i ++) c[i] = a[i];
		for(int i = 1; i < n; i ++) {
			int u = U[b[i]], v = V[b[i]];
			swap(c[u], c[v]);
		}
		for(int i = 1; i <= n; i ++) ha[c[i]] = i;
		int F = 0;
		for(int i = 1; i <= n; i ++) {
			if(ha[i] == ans[i])  continue;
			if(ha[i] > ans[i]) F = 1;
			break;		
		}
		if(!F) {
			for(int i = 1; i <= n; i ++) ans[i] = ha[i];
	//		for(int i = 1; i < n; i ++) printf("*%d*", b[i]); printf("\n"); 
		} 
	}
	for(int i = 1; i < n; i ++) {
		if(!vis[i]) {
			vis[i] = 1;
			b[x] = i;
			dfs(x + 1);
			vis[i] = 0;
		}
	}
}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d", &t);
	while(t --) {
		scanf("%d", &n);
		for(int i = 1; i <= n; i ++) scanf("%d", &aa[i]), ans[i] = n, a[aa[i]] = i, L[i] = R[i] = 0;
	//	for(int i = 1; i <= n; i ++) printf("%d ", a[i]); printf("\n");
		for(int i = 1; i < n; i ++) scanf("%d%d", &U[i], &V[i]);
	if(n <= 10)	dfs(1);
	else {
		for(int i = 1; i <= n; i ++) {
			int pos = 0;
			for(int j = 1; j <= n; j ++) if(a[j] == i) pos = j;
			for(int j = pos - 1; j >= 1; j --) {
				if(R[j]) break;
				pos = j;
				L[j + 1] = R[j] = i;
				swap(a[j], a[j + 1]);
			}
		}
		for(int i = 1; i <= n; i ++) ans[a[i]] = i; 
	}
		
		for(int i = 1; i <= n; i ++) printf("%d ", ans[i]);	 printf("\n");
	}
	
	return 0;
}
