#include<bits/stdc++.h>
#define N 2000005
#define ll long long
using namespace std;
struct edge {
	int v, nxt;
} e[N];
int p[N], eid;
void init() {
	eid = 0;
	memset(p, -1, sizeof p);
}
void insert(int u, int v) {
	e[eid].v = v;
	e[eid].nxt = p[u];
	p[u] = eid ++;
}
int size[N * 7], root[N], ch[N * 7][2], tot, pos = 0;
void update(int rt) {
	size[rt] = size[ch[rt][0]] + size[ch[rt][1]];
}
void add(int &rt, int l, int r, int x, int o, int rtt) { 
	if(!rt) rt = ++ tot;//printf("%d %d %d *%d* %d %d  %d\n", rt, l, r, x, o, rtt, size[rtt]);
	if(l == r) {
		size[rt] = size[rtt] + 1;
		return;
	}
	int mid = (l + r) >> 1;
	if(x <= mid) add(ch[rt][0], l, mid, x, o, ch[rtt][0]), ch[rt][1] = ch[rtt][1];
	else add(ch[rt][1], mid + 1, r, x, o, ch[rtt][1]), ch[rt][0] = ch[rtt][0];
	update(rt);
}
void clear(int &rt, int l, int r, int x, int rtt) {//printf(" %d %d %d *%d* %d  %d\n", rt, l, r, x, rtt, size[rtt]);
	if(!rt) rt = ++ tot;
	if(l == r) {
		size[rt] = 0;
		return;
	}
	int mid = (l + r) >> 1;
	if(x <= mid) clear(ch[rt][0], l, mid, x, ch[rtt][0]), ch[rt][1] = ch[rtt][1];
	else clear(ch[rt][1], mid + 1, r, x, ch[rtt][1]), ch[rt][0] = ch[rtt][0];
	update(rt);
}
int query(int rt, int l, int r, int x) {//printf("   %d %d %d %d  %d\n", rt, l, r, x, size[rt]);
	if(!rt) return 0;
	if(l == r) return size[rt];
	int mid = (l + r) >> 1;
	if(x <= mid) return query(ch[rt][0], l, mid, x);
	else return query(ch[rt][1], mid + 1, r, x);
}
int n, fa[N], ha[N];
ll ans[N];

char st[N];

void dfs(int u) { 
	ans[u] = ans[fa[u]];
	if(ha[u] == 1) {
		add(root[u], -n, n, pos, 1, root[fa[u]]);
		pos --;
	} else {
		clear(root[u], -n, n, pos, root[fa[u]]);
		pos ++;
		ans[u] += query(root[u], -n, n, pos);
	}
	for(int i = p[u]; i + 1; i = e[i].nxt) {
		int v = e[i].v;
		if(v == fa[u]) continue;
		dfs(v);
	}
	if(ha[u] == 1) {
		pos ++;
	} else {
		pos --;
	}
//	printf("%d %lld    %d\n", u, ans[u], root[u]);
}
int main() {
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	init();
	scanf("%d", &n);
	scanf("%s", st + 1);
	for(int i = 1; i <= n; i ++) 
		if(st[i] == '(') ha[i] = 1;
		else ha[i] = -1;
	for(int i = 2; i <= n; i ++) {
		scanf("%d", &fa[i]);
		insert(fa[i], i);
	}
	dfs(1);
/*	int pos = 0;
	for(int i = 1; i <= n; i ++) { ans[i] = ans[i - 1];
		if(ha[i] == 1) {
			add(root, -n, n, pos, 1);
			pos --;
		} else {
			clear(root, -n, n, pos);
			pos ++;
			ans[i] += query(root, -n, n, pos);
		}
	} */
//	for(int i = 1; i <= n; i ++) printf("%lld ", ans[i]);
	ll anss = 0;
	for(int i = 1; i <= n; i ++) anss = anss ^ (i * ans[i]);
	printf("%lld", anss);	
	return 0;
}
