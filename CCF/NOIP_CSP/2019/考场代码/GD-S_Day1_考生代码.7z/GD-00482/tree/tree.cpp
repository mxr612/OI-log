#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
const int MAXN=2222;
#define FOR(i,a,b) for(int i=(a);i<=(b);i++)
#define ROF(i,a,b) for(int i=(a);i>=(b);i--)
#define MEM(x,v) memset(x,v,sizeof(x))
template<typename T>
inline void read(T &x){
	x=0;
	char ch=getchar();
	bool f=0;
	while(ch<'0' || ch>'9') f|=ch=='-',ch=getchar();
	while(ch>='0' && ch<='9') x=x*10+ch-'0',ch=getchar();
	if(f) x=-x;
}
int T,n,el,head[MAXN],to[MAXN*2],nxt[MAXN*2],w[MAXN],deg[MAXN],rt;
bool vis[MAXN];
inline void add(int u,int v){
	to[++el]=v;nxt[el]=head[u];head[u]=el;
}
namespace brute{
	int u[MAXN],v[MAXN],hhh[MAXN],ans[MAXN];
	void chkmin(){
		FOR(i,1,n) hhh[w[i]]=i;
		FOR(i,1,n){
			if(hhh[i]>ans[i]) return;
			if(hhh[i]<ans[i]) break;
		}
		FOR(i,1,n) ans[i]=hhh[i];
	}
	void dfs(int dep){
		if(dep==n) return chkmin();
		FOR(i,1,n-1) if(!vis[i]){
		vis[i]=true;
				swap(w[u[i]],w[v[i]]);
			dfs(dep+1);
			swap(w[u[i]],w[v[i]]);
			vis[i]=false;
		}
	}
	void solve(){
		FOR(i,1,n-1) read(u[i]),read(v[i]);
		FOR(i,1,n) ans[i]=n-i+1;
		dfs(1);
		FOR(i,1,n) printf("%d ",ans[i]);
		puts("");
	}
}
namespace chain{
	int seq[MAXN],sl,ans[MAXN];
	bool used[MAXN];
	void dfs(int u,int f){
		seq[++sl]=u;
		for(int i=head[u];i;i=nxt[i]){
			int v=to[i];
			if(v==f) continue;
			dfs(v,u);
		}
	}
	void solve(){
		FOR(i,1,n-1){
			int u,v;
			read(u);read(v);
			add(u,v);add(v,u);
		}
		MEM(used,0);sl=0;
		FOR(i,1,n) if(deg[i]==1){dfs(i,0);break;}
		FOR(i,1,n-1){
			int at=0,lft,rig,mn=0;
			FOR(j,1,n) if(w[j]==i) at=j;
			lft=rig=at;
			while(lft>1 && !used[lft-1]) lft--;
			while(rig<n && !used[rig]) rig++;
			FOR(j,lft,rig) if(mn!=at && (!mn || seq[j]<seq[mn])) mn=j;
			if(!mn){ans[i]=at;continue;}
			if(mn>at){
				int mn2=0;
				FOR(j,mn+1,rig) if(!mn2 || w[seq[j]]<w[seq[mn2]]) mn2=j;
				if(mn2){
					if(at+1==mn){
						int mn3=1e9;
						FOR(i,lft,at) mn3=min(mn3,seq[i]);
						if(mn3<seq[mn2]){
							ROF(j,mn2,mn+1) used[j-1]=true,swap(w[seq[j]],w[seq[j-1]]);
						}
					}
					else{
						if(seq[mn-1]<seq[mn2]){
							ROF(j,mn2,mn+1) used[j-1]=true,swap(w[seq[j]],w[seq[j-1]]);
						}
					}
				}
				FOR(j,at,mn-1) used[j]=true,swap(w[seq[j]],w[seq[j+1]]);
				ans[i]=mn;
			}
			else{
				int mn2=0;
				FOR(j,lft,mn-1) if(!mn2 || w[seq[j]]<w[seq[mn2]]) mn2=j;
				if(mn2){
					if(at-1==mn){
						int mn3=1e9;
						FOR(i,at,rig) mn3=min(mn3,seq[i]);
						if(mn3<seq[mn2]){
							FOR(j,mn2,mn-1) used[j]=true,swap(w[seq[j]],w[seq[j+1]]);
						}
					}
					else{
						if(seq[mn-1]<seq[mn2]){
							FOR(j,mn2,mn-1) used[j]=true,swap(w[seq[j]],w[seq[j+1]]);
						}
					}
				}
				ROF(j,at,mn+1) used[j-1]=true,swap(w[seq[j]],w[seq[j-1]]);
				ans[i]=mn;
			}
		}
		FOR(i,1,n) printf("%d ",ans[i]);
		puts("");
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	read(T);
	while(T--){
		MEM(head,0);MEM(to,0);MEM(nxt,0);MEM(deg,0);el=0;
		read(n);
		FOR(i,1,n){
			int id;
			read(id);
			w[id]=i;
		}
		if(n<=10) brute::solve();
		else chain::solve();
	}
}
