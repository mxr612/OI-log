#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
const int MAXN=555555;
#define FOR(i,a,b) for(int i=(a);i<=(b);i++)
#define ROF(i,a,b) for(int i=(a);i>=(b);i--)
#define MEM(x,v) memset(x,v,sizeof(x))
template<typename T>
inline void read(T &x){
	x=0;
	char ch=getchar();
	bool f=0;
	while(ch<'0' || ch>'9') f|=ch=='-',ch=getchar();
	while(ch>='0' && ch<='9') x=x*10+ch-'0',ch=getchar();
	if(f) x=-x;
}
int n,el,head[MAXN],to[MAXN],nxt[MAXN],cnt[MAXN*2],tp;
char s[MAXN];
ll ans,sum;
inline void add(int u,int v){
	to[++el]=v;nxt[el]=head[u];head[u]=el;
}
void dfs(int u){
	int tmp=-1;
	if(s[u]=='('){
		tp++;
		cnt[tp]=1;
	}
	else{
		tmp=cnt[tp];
		cnt[tp]=0;
		tp--;
		sum+=cnt[tp];
		cnt[tp]++;
	}
	ans^=sum*u;
	for(int i=head[u];i;i=nxt[i]){
		int v=to[i];
		dfs(v);
	}
	if(s[u]=='('){
		cnt[tp]=0;
		tp--;
	}
	else{
		cnt[tp]--;
		sum-=cnt[tp];
		tp++;
		cnt[tp]=tmp;
	}
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	read(n);
	scanf("%s",s+1);
	FOR(i,2,n){
		int f;
		read(f);
		add(f,i);
	}
	cnt[n]=1;tp=n;
	dfs(1);
	cout<<ans<<endl;
}
/*
20
())))()((()(()))))()
1 2 2 3 4 4 7 4 8 9 5 11 2 13 15 9 13 7 4 
*/
