#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
const int MAXN=111;
#define FOR(i,a,b) for(int i=(a);i<=(b);i++)
#define ROF(i,a,b) for(int i=(a);i>=(b);i--)
#define MEM(x,v) memset(x,v,sizeof(x))
template<typename T>
inline void read(T &x){
	x=0;
	char ch=getchar();
	bool f=0;
	while(ch<'0' || ch>'9') f|=ch=='-',ch=getchar();
	while(ch>='0' && ch<='9') x=x*10+(ch-'0'),ch=getchar();
	if(f) x=-x;
}
int n;
ll k;
void outputhhh(int n,ull k){
	if(n==-1) return;
	if(k&(1ull<<n)) printf("1"),outputhhh(n-1,(1ull<<n)-1-(k-(1ull<<n)));
	else printf("0"),outputhhh(n-1,k);
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	read(n);read(k);
	outputhhh(n-1,k);
}
