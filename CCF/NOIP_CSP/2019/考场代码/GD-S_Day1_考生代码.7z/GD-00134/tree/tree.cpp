#include<bits/stdc++.h>
using namespace std;
int cc,to[6000],net[6000],fr[6000],ans[6000],op[6000],nm[6000];
int n,t,x,u,v;
void addedge(int u,int v)
{
	cc++;
	to[cc]=v;net[cc]=fr[u];fr[u]=cc;
}
void com()
{
	for (int i=1;i<=n;i++)
	{
		if (ans[i]>op[i]) 
		{
			for (int j=1;j<=n;j++)
				ans[j]=op[j];
			break;
		}
		if (ans[i]<op[i]) break;
	}
}
void dfs(int x)
{
	if (x==((1<<(n-1))-1))
	{
		com();return ;
	}
	for (int i=1;i<n;i++)
	{
		if ((x&(1<<(i-1)))) continue;
		swap(op[to[i*2]],op[to[i*2-1]]);
		dfs(x|(1<<(i-1)));
		swap(op[to[i*2]],op[to[i*2-1]]);
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>t;
	for (int tt=1;tt<=t;tt++)
	{
		cin>>n;	
		for (int i=1;i<=n;i++)
		{
			ans[i]=99999;fr[i]=0;
		}
		cc=0;
		for (int i=1;i<=n;i++)
		{
			cin>>x;
			op[i]=x;
			nm[x]=i;
		}
		for (int i=1;i<n;i++)
		{
			cin>>u>>v;
			addedge(nm[u],nm[v]);
			addedge(nm[v],nm[u]);
		}
		dfs(0);
		for (int i=1;i<=n;i++)
		  cout<<ans[i]<<" ";
		cout<<endl;
	}
	return 0;
}
