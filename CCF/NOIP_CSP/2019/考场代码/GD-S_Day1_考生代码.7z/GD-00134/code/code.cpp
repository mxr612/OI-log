#include<bits/stdc++.h>
using namespace std;
long long n;unsigned long long k;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	unsigned long long mi=1;
	for (int i=1;i<=n;i++)
	{
		if (i==64)
		{
			if (k>=mi) 
			{
				cout<<"1";
				k=((mi-1)*2+1)-k;
			}
			else
			{
				cout<<"0";
			}
			n--;
			break;
		}
		mi*=2;
	}
	for (int i=n;i>=1;i--)
	{
		if (k>=mi/2)
		{
			cout<<"1";
			k=(mi-1)-k;
		}else
		{ 
			cout<<"0";
		}
		mi/=2;
	}
	return 0;
}
