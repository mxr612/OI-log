#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<iomanip>
#include<algorithm>
#define ll int
using namespace std;
ll read()
{
	ll s=0,t=1;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')t*=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		s=s*10+c-'0';
		c=getchar();
	}
	return s*t;
}
ll t,n,tot=0,head[2019],du[2019],mid=0,bj[2019],num[2019],lo[2019];
struct kkk
{
	ll from,to;
}e[2019];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	t=read();
	for(ll texas=1;texas<=t;texas++)
	{
		memset(head,0,sizeof(head));
		memset(bj,0,sizeof(bj));
		memset(lo,0,sizeof(lo));
		memset(num,0,sizeof(num));
		n=read();
		for(ll i=1;i<=n;i++)
		{
			ll x;
			x=read();
			num[x]=i;
			lo[i]=x;
			if(i==x)bj[i]=1;
		}
		for(ll i=1;i<n;i++)
		{
			ll x,y;
			x=read();
			y=read();
			du[x]++;
			du[y]++;
			if(du[x]>1)mid=x;
			if(du[y]>1)mid=y;
		}
		for(ll i=1;i<n;i++)
		{
			if(mid==num[mid]||bj[num[mid]]==1)
			{
				ll minn=99999;
				for(ll j=1;j<=n;j++)
				if(j!=mid)
				{
					if(bj[j]==0)minn=min(minn,num[j]);
				}
				swap(lo[num[mid]],lo[num[minn]]);
				swap(num[mid],num[minn]);
//				cout<<"SWAP specialy"<<mid<<' '<<minn<<endl;
				bj[minn]=1;
			}
			else
			{
				if(bj[num[mid]]==0)
				{
					swap(lo[num[mid]],lo[num[num[mid]]]);
					swap(num[mid],num[num[mid]]);
//					cout<<"SWAP "<<mid<<' '<<num[mid]<<endl;
					bj[num[mid]]=1;
				}
			}
		}
		for(ll i=1;i<=n;i++)cout<<lo[i]<<' ';
		putchar('\n');
	}
}
