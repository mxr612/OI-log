#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<iomanip>
#include<algorithm>
#define ll long long
using namespace std;
ll read()
{
	ll s=0,t=1;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')t*=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		s=s*10+c-'0';
		c=getchar();
	}
	return s*t;
}
ll n,k,zhan[114],top=0;
void f(ll deep,ll x)
{
	if(deep==0)return;
	f(deep-1,x/2);
	top++;
	if(deep==1)
	{
		if(x==0)
		zhan[top]=0;
		else zhan[top]=1;
	}
	else
	{
		if(((x+1)/2)%2==0)zhan[top]=0;
		else zhan[top]=1;
	}
//	cout<<deep<<' '<<x<<' '<<top<<' '<<zhan[top]<<endl;
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	n=read();
	k=read();
	f(n,k);
	for(ll i=1;i<=top;i++)
	{
		printf("%lld",zhan[i]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
