#include<iostream>
#include<cstring>
#include<cstdio>
#include<cmath>
#include<iomanip>
#include<algorithm>
#define ll int
using namespace std;
ll read()
{
	ll s=0,t=1;
	char c=getchar();
	while(c<'0'||c>'9')
	{
		if(c=='-')t*=-1;
		c=getchar();
	}
	while(c>='0'&&c<='9')
	{
		s=s*10+c-'0';
		c=getchar();
	}
	return s*t;
}
char ass[500010];
string s;
ll n,head[500010],tot=0,root,done[500010],ready[500010],hfx[500010],qian[500010];
long long answer=0;
struct kkk
{
	ll to,next;
}e[500010];
void add(ll x,ll y)
{
	tot++;
	e[tot].to=y;
	e[tot].next=head[x];
	head[x]=tot;
}
void f(ll fa,ll x,ll last)
{
	char asshole=ass[x];
	ready[x]=ready[fa];
	done[x]=done[fa];
//	hfx[x]=hfx[fa];
	if(asshole=='(')
	{
		qian[x]=last;
		last=x;
		ready[x]++;
		hfx[x]=hfx[fa];
		if(ass[fa]=='(')hfx[x]=0;
	}
	if(asshole==')')
	{
		if(ready[x]>0)
		{
			ready[x]--;
			
/*			hfx[x]+=1;
			if(last!=fa)hfx[x]+=hfx[last];*/
			
			hfx[x]=hfx[last]+1;
//			if(last!=fa)hfx[x]+=hfx[fa];
			
//			cout<<x<<"'s last is "<<last<<endl;
//			cout<<zhan[top]<<' '<<hfx[zhan[top]]<<' ';
			last=qian[last];
			done[x]+=hfx[x];
//			cout<<done[x]<<endl;
		}
		if(ready[x]<0)
		{
			ready[x]=0;
			hfx[x]=0;
		}
	}
//	cout<<done[x]*x<<endl;
	if(done[x]!=0)answer=(answer^(long long)(done[x]*x));
//	cout<<fa<<' '<<x<<' '<<done[x]<<' '<<ready[x]<<' '<<answer<<endl;
	for(ll i=head[x];i;i=e[i].next)
	{
		f(x,e[i].to,last);
	}
	return;
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	n=read();
	cin>>s;
	for(ll i=0;i<s.size();i++)
	{
		ass[i+1]=s[i];
	}
	for(ll i=1;i<n;i++)
	{
		ll x;
		x=read();
		add(x,i+1);
//		cout<<"CONTECT "<<x<<' '<<i+1<<endl;
	}
	root=1;
	f(0,1,0);
/*	for(ll i=1;i<=n;i++)cout<<hfx[i]<<' ';cout<<endl;
	for(ll i=1;i<=n;i++)cout<<done[i]<<' ';cout<<endl;*/
	printf("%lld",answer);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
