#include <iostream>
using namespace std;
int main()
{
	int T;
	cin>>T;
	while(T)
	{
		int n;
		cin>>n;
		int arr[n];
		int I=1;
		for(int i=0;i<n;i++)
		{
			int point;
			cin>>point;
			arr[point-1]=I;
			I++;
		}
		for(int i=1;i<n;i++)
		{
			int x,y;
			cin>>x>>y;
		}
		T--;
	}
	return 0;
}
