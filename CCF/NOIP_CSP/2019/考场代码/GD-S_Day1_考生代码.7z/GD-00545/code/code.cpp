#include <iostream>
#include <string>
using namespace std;
int main()
{
	/*freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);*/
	int n,k;
	cin>>n>>k;
	int sum=100000;
	string s1[sum],s2[sum];
	for(unsigned long long i=0;i<sum;i++)
	{
		s1[i]="aa";
		s2[i]="aa";
	}
	s1[0]="0";
	s2[0]="1";
	unsigned long long I=1;
	for(int i=1;i<n;i++)
	{
		unsigned long long J=0;
		while(J<sum&&I<sum)
		{
			if(s2[J]!="aa")
			{
				s1[I]=s2[J];
				I++;
				J++;
			}
			else
			{
				J=0;
				break;
			}
		}
		for(int j=I-1;j>=0;j--)
		{
			s2[J]=s1[j];
			s2[J]="1"+s2[J];
			J++;
		}
		for(int j=0;j<I;j++)
		{
			s1[j]="0"+s1[j];
		}
	}
	if(k>=I)
	{
		cout<<s2[k-I];
	}
	else
	{
		cout<<s1[k];
	}
	return 0;
}
