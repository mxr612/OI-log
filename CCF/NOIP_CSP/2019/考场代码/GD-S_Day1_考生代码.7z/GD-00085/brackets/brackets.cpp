#include<iostream>
#include<cstdio>
using namespace std;
int n,a1[500001],v[500001];
long long ans;
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int a,b;
	long long c;
	char d;
	cin >> n;
	for(int r=1;r<=n;r++)
	{
		cin >> d;
		a1[r]+=a1[r-1];
		if(d == '(') a1[r]++;
		else if(a1[r] > 0) 
		{	
			v[r]++;
			a1[r]--;
		}
		v[r]+=v[r-1];
	}
	for(int r=1;r<=n-1;r++)
		cin >> b;
	for(int r=1;r<=n;r++)
	{
		c=v[r];
		ans=ans xor (r*c);
	}
	cout << ans;
	return 0;
}
