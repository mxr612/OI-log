#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
void dfs(long long int n,long long int k)
{
	if(n == 1)
	{
		if(k == 2) cout << 1;
		else cout << 0;
		return;
	}
	long long int a,b,c;
	if(n == 64)
	{
		if(k>pow(2,63))
		{
			cout << 1;
			dfs(n-1,pow(2,64)+k+1);
			return;
		}
		cout << 0;
		dfs(n-1,k);
		return;
	}
	a=pow(2,n-1);
	if(k > a)
	{
		b=k-a;
		cout << 1 ;
		dfs(n-1,a-b+1);
		return;
	}
	cout << 0 ;
	dfs(n-1,k);
	return;
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	long long int n,k;
	cin >> n >> k;
	k++;
	dfs(n,k);
	return 0;
}
