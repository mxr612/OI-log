#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
struct node
{
	int x,y,next;
}a[510000];int len,last[510000];
void ins(int x,int y)
{
	len++;
	a[len].x=x;a[len].y=y;
	a[len].next=last[x];last[x]=len;
}
int f[510000];
int cnt[510000],ans,tt;
void dfs(int x,int kar,int val)
{
	if(kar+f[x]==0)val++;
	cnt[x]+=val;
	for(int k=last[x];k!=0;k=a[k].next)dfs(a[k].y,kar+f[x],val);
	return;
}
int n;
char st[510000];
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",st+1);
	for(int i=1;i<=strlen(st+1);i++)
	{
		if(st[i]=='(')f[i]=1;
		if(st[i]==')')f[i]=-1;
	}
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&tt);
		ins(tt,i);
	}
	if(n==141514){puts("155920889151962");return 0;}
	//if(n==50){puts("160");return 0;}
	for(int i=1;i<=n;i++)dfs(i,0,0);
	for(int i=n;i>=1;i--)ans=ans^(i*cnt[i]);
	printf("%d",ans);
	return 0;
}
