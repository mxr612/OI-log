#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef long long ll;
ll d[65];
void dfs(ll kar,ll base)
{
	if(base==0)return;
	if(kar>d[base-1])putchar('1'),dfs(2*d[base-1]-kar+1,base-1);
	else putchar('0'),dfs(kar,base-1);
}
ll n,k;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	d[0]=1;for(int i=1;i<=63;i++)d[i]=d[i-1]*2;
	scanf("%lld %lld",&n,&k);k++;
	dfs(k,n);
	return 0;
}
