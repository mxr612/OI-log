#include<cstdio>
#include<queue>
using namespace std;
char st[500100];
int a[500100];
struct bian{int y,gg;}b[500100];
int h[500100],len=1;
int ins(int x,int y){
	len++;b[len].y=y;
	b[len].gg=h[x];
	h[x]=len;
}
long long f[500100];
int fa[500100];
long long k[500100];//�Ϸ���׺��
int nxt[500100];//��Ϸ���׺��ǰһ���ַ� 
queue<int> q;
int bfs(int st)
{
	q.push(st);
	while(!q.empty())
	{ 
		int x=q.front();q.pop();
		for(int i=h[x];i>0;i=b[i].gg){
			int y=b[i].y;
			if(a[y]==1) k[y]=0,nxt[y]=y;
			else
			{
				if(a[nxt[x]]==1){
					k[y]=k[fa[nxt[x]]]+1;
					nxt[y]=nxt[fa[nxt[x]]];
				}else k[y]=0,nxt[y]=y;
			}f[y]=f[x]+k[y];
			q.push(y);
		}
	}
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n;
	scanf("%d",&n);
	scanf("%s",st+1);
	for(int i=1;i<=n;i++)
	{
		if(st[i]=='(') a[i]=1;
		else a[i]=2;
		h[i]=0;
	}
	for(int i=2;i<=n;i++){
		scanf("%d",&fa[i]);
		ins(fa[i],i);
	}
	k[1]=0;f[1]=0;
	nxt[1]=1;
	bfs(1);
	long long ans=0;
//	for(int i=1;i<=n;i++) printf("%d ",f[i]);
	for(int i=1;i<=n;i++) ans=ans^(f[i]*i);
	printf("%lld",ans);
	return 0;
}
