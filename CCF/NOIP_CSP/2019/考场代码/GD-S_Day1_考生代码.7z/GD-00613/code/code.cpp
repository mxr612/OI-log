#include<cstdio>
#include<iostream>
using namespace std;
int f[110];
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	unsigned long long n,k,len,nn;
	cin >> n >> k;
	nn=n-1;
	while(n>=1)
	{
		n--;
		len=(1ll<<n);len--;
		if(k>len)//����
		{
			k-=len+1;
			k=len-k;
			f[n]=1;
		}else f[n]=0;
	}
	for(int i=nn;i>=0;i--) printf("%d",f[i]);
	return 0;
}// 64 18446744073709551615
