#include<cstdio>
int read()
{
	int x=0;char c=getchar();
	while(c>'9' || c<'0') c=getchar();
	while(c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	return x;
}
struct bian{int y,gg;}b[500100];
int h[500100],len=1;
int ins(int x,int y){
	len++;b[len].y=y;
	b[len].gg=h[x];
	h[x]=len;
}
int p[2010],a[1010];//a��ȨֵΪi�ĵ㣬p�����Ȩֵ 
int d[2010];
int l[2010],n;
bool v[2010];
int now[2010],pp[2010],ans[2010];
void check()
{
	int t,x,y;
	for(int i=1;i<=n;i++) now[i]=a[i],pp[i]=p[i];
	for(int i=1;i<n;i++)
	{
		x=b[l[i]^1].y,y=b[l[i]].y; 
		t=pp[x],pp[x]=pp[y];pp[y]=t;
		now[pp[x]]=x;now[pp[y]]=y;
	}
	for(int i=1;i<=n;i++) 
	if(now[i]>ans[i]) return ;
	else if(now[i]<ans[i]){
		for(int j=1;j<=n;j++) ans[j]=now[j];
		return ;
	}
}
void dfs(int num)
{
	if(num==n){
		check();
		return ;
	}
	for(int i=2;i<=len;i+=2){
		if(!v[i])
		{
			v[i]=v[i^1]=true;
			l[num]=i;
			dfs(num+1);
			v[i]=v[i^1]=false;
		}
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T;
	T=read();
	while(T--)
	{
		int x,y;len=1;
		n=read();
		for(int i=1;i<=n;i++) a[i]=read(),p[a[i]]=i,ans[i]=1e6,d[i]=0;
		for(int i=1;i<n;i++){
			x=read();y=read();
			d[x]++;d[y]++;
			ins(x,y);ins(y,x);
		}
		dfs(1);
		for(int i=1;i<=n;i++) printf("%d ",ans[i]);
		printf("\n");
	}
	return 0;
}
