#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
typedef unsigned long long LL;
#define int LL
void rd(int &x)
{
	x=0;char c=getchar();int fl=1;
	while (!isdigit(c)){if (c=='-') fl=-1;c=getchar();}
	while (isdigit(c)){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=fl;
}
void print(int x)
{
	if (x>9) print(x/10);
	putchar(x%10^48);
}
int n,k,
	bit[70];
signed main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	rd(n);rd(k);
	if (k==18446744073709551615ull)
	{
		print(1);
		for (int i=1;i<=63;i++)
			print(0);
		return 0;
	}
	++k;
	bit[0]=1ull;
	for (int i=1;i<n;i++)
	{
		bit[i]=bit[i-1]*2ull;
	}
	for (int i=n-1;i>=1;i--)
	{
		while (k<=bit[i]&&i>=1)
		{
			print(0);--i;
		}
		if (i<1) break;
		print(1);
		k=bit[i]-(k-bit[i])+1;
	}
	print(k==2?1:0);
	return 0;
}
