#include<iostream>
#include<cstdio>
#include<cstring>
#include<vector>
using namespace std;
typedef long long LL;
#define I inline
#define R register
I void rd(int &x)
{
	x=0;R char c=getchar();R int fl=1;
	while (!isdigit(c)){if (c=='-') fl=-1;c=getchar();}
	while (isdigit(c)){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=fl;
}
I void print(R int x)
{
	if (x>9) print(x/10);
	putchar(x%10^48);
}
inline int ch(R char x)
{
	return x==')';
}
int cur,n,
	head[500005];
char st[500005];
LL sum,nans;
struct EDGE{
	int t,next;
}e[1000005];
I void add(int a,int b)
{
	cur++;
	e[cur].t=b;
	e[cur].next=head[a];
	head[a]=cur;
}
struct NOD{
	int dep,lst;
	vector < int > cnt;
}g,nnow;
I void DFS(R int u,R int fa,R NOD now,R LL ans)
{
//	printf("%d\n",u);
	sum^=(u*ans);
	R NOD nnow;
	R bool son=1;
	for (R int h=head[u];h!=-1;h=e[h].next)
	{
		R int v=e[h].t;
		if (v==fa) continue;
		son=0;
		nnow=now;
		R LL nans=ans;
		int c=ch(st[v]);
		if (!now.lst&&c)
		{
			nans-=nnow.cnt[nnow.dep]*(nnow.cnt[nnow.dep]+1)/2;
			++nnow.cnt[nnow.dep];
			nans+=nnow.cnt[nnow.dep]*(nnow.cnt[nnow.dep]+1)/2;
		}else
		if (!now.lst&&!c)
		{
			nnow.dep++;
			nnow.cnt.push_back(0);
		}else
		if (now.lst&&c)
		{
			nnow.cnt[nnow.dep]=0;
			if (nnow.dep>1) 
			{
				nnow.dep--;
				nans-=nnow.cnt[nnow.dep]*(nnow.cnt[nnow.dep]+1)/2;
				++nnow.cnt[nnow.dep];
				nans+=nnow.cnt[nnow.dep]*(nnow.cnt[nnow.dep]+1)/2;
			}
		}
		nnow.lst=c;
		DFS(v,u,nnow,nans);
	}
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	rd(n);
	scanf("%s",st+1);
	memset(head,-1,sizeof head);
	R bool OK=1;
	for (R int i=2;i<=n;i++)
	{
		R int x;
		rd(x);
		if (x!=i-1) OK=0;
		add(x,i);add(i,x);
	}
	if (!OK||n<=5005)
//	if (1)
	{
		g.dep=1;
		g.lst=ch(st[1]);
		g.cnt.push_back(0);g.cnt.push_back(0);
		DFS(1,0,g,0);
		print(sum);
	}
	else
	{
		nnow.dep=1;
		nnow.lst=ch(st[1]);
		nnow.cnt.push_back(0);nnow.cnt.push_back(0);
		for (R int i=2;i<=n;i++)
		{
			R int c=ch(st[i]),
			lst=ch(st[i-1]);
			if (!lst&&c)
			{
				nans-=nnow.cnt[nnow.dep]*(nnow.cnt[nnow.dep]+1)/2;
				++nnow.cnt[nnow.dep];
				nans+=nnow.cnt[nnow.dep]*(nnow.cnt[nnow.dep]+1)/2;
			}else
			if (!lst&&!c)
			{
				nnow.dep++;
				nnow.cnt.push_back(0);
			}else
			if (lst&&c)
			{
				nnow.cnt[nnow.dep]=0;
				if (nnow.dep>1) 
				{
					nnow.dep--;
					nans-=nnow.cnt[nnow.dep]*(nnow.cnt[nnow.dep]+1)/2;
					++nnow.cnt[nnow.dep];
					nans+=nnow.cnt[nnow.dep]*(nnow.cnt[nnow.dep]+1)/2;
				}
			}
			sum^=i*nans;
//			printf("%d:%I64d\n",i,nans);
		}
		print(sum);
	}
	return 0;
}
