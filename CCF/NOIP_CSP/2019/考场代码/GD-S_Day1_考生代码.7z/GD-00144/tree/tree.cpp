#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
void rd(int &x)
{
	x=0;char c=getchar();int fl=1;
	while (!isdigit(c)){if (c=='-') fl=-1;c=getchar();}
	while (isdigit(c)){x=(x<<1)+(x<<3)+(c^48);c=getchar();}
	x*=fl;
}
void print(int x)
{
	if (x>9) print(x/10);
	putchar(x%10^48);
}
int cur,n,T,
	d[4005],dep[4005],head[4005],num[4005],
	f[4005][24],cut[4005][4005];
struct EDGE{
	int t,next;
}e[4005];
void add(int a,int b)
{
	cur++;
	e[cur].t=b;
	e[cur].next=head[a];
	head[a]=cur;
}
bool DFS(int u,int fa,int to)
{
	if (u==to) return 1;
	bool res=0;
	for (int h=head[u];h!=-1;h=e[h].next)
	{
		int v=e[h].t;
		if (v==fa||cut[u][v]) continue;
		res|=DFS(v,u,to);
	}
	return res;
}
void Pre(int u,int fa)
{
	f[u][0]=fa;
	for (int i=1;i<=20;i++)
		f[u][i]=f[f[u][i-1]][i-1];
	for (int h=head[u];h!=-1;h=e[h].next)
	{
		int v=e[h].t;
		if (v==fa) continue;
		Pre(v,u);
	}
}
int LCA(int a,int b)
{
	if (dep[a]<dep[b]) swap(a,b);
	int cha=dep[a]-dep[b];
	for (int i=0;i<=20;i++)
		if (cha&(1<<i))
			a=f[a][i];
	if (a==b) return a;
	for (int i=20;i>=0;i--)
		if (f[a][i]!=f[b][i])
			a=f[a][i],b=f[b][i];
	return f[a][0];
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	rd(T);
	while (T--)
	{
		rd(n);
		memset(head,-1,sizeof head);
		memset(e,0,sizeof e);
		for (int i=1;i<=n;i++)
		{
			rd(d[i]);
			num[d[i]]=i;
		}
		for (int i=1;i<n;i++)
		{
			int a,b;
			rd(a);rd(b);
			add(a,b);add(b,a);
		}
		Pre(1,0);
//		DFS(1,0);
		for (int i=1;i<=n;i++)
		{
			if (!DFS(d[i],0,i)) continue;
			int lca=LCA(d[i],i);
			int t=d[i];
			while (t!=lca)
			{
				swap(num[t],num[f[t][0]]);
				d[f[t][0]]=t;d[t]=f[t][0];
				cut[t][f[t][0]]=1;
				t=f[t][0];
			}
			t=i;
			while (t!=lca)
			{
				swap(num[t],num[f[t][0]]);
				d[f[t][0]]=t;d[t]=f[t][0];
				cut[t][f[t][0]]=1;
				t=f[t][0];
			}
		}
		for (int i=1;i<=n;i++)
			printf("%d ",d[i]);
		printf("\n");
	}
	return 0;
}
