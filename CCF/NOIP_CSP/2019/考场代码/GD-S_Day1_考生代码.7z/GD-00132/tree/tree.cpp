#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#include<stack>
#include<deque>
#include<vector>
#include<set>
#include<map>
#include<iostream>
using namespace std;
typedef long long int ll;
typedef double db;
typedef vector<int> vec;
typedef string str;
typedef pair<int,int> pa;

const int n_size=2005;
int T,n,num[n_size],poi[n_size],top;

int cnt,head[n_size],to[2*n_size],nex[2*n_size],in_c[n_size];
void add(int a,int b){
	to[++cnt]=b;
	nex[cnt]=head[a];
	head[a]=cnt;
}

void deal1(){
	if(top!=num[top]){
		for(int i=1;i<=n;i++) printf("%d ",i);printf("\n");
		return;
	}else{
		if(top==1){
			for(int i=1;i<=n;i++) printf("%d ",poi[i]); printf("\n");
			return;
		}else{
			for(int i=1;i<=n;i++){
				if(i==top) printf("%d ",num[1]);
				else if(i==num[1]) printf("%d ",top);
				else printf("%d ",i);
			}
			printf("\n");
			return;
		}
	}
}

int ans[100],now[100],vis[100];
pa road[100];
void dfs(int t){
	if(t==n-1){
		for(int i=1;i<=n;i++) if(num[i]<ans[i]){
			for(int j=1;j<=n;j++) ans[j]=num[j];
			break;
		}
	}
	for(int i=1;i<n;i++){
		if(!vis[i]){
			vis[i]=1;
			swap(num[road[i].first],num[road[i].second]);
			dfs(t+1);
			vis[i]=0;
			swap(num[road[i].first],num[road[i].second]);
		}
	}
}
void deal2(){
	for(int i=1;i<=n;i++) ans[i]=11;
	for(int i=1;i<n;i++){
		scanf("%d%d",&road[i].first,&road[i].second);
	}
	dfs(0);
	for(int i=1;i<=n;i++) printf("%d ",ans[i]);printf("\n");
}


int main(){
  freopen("tree.in","r",stdin);
  freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&num[i]);
			poi[num[i]]=i;
		}
		
		if(n<=10){
			deal2();
			continue;
		}
		cnt=0;
		memset(in_c,0,sizeof(in_c));
		for(int i=1,a,b;i<n;i++){
			scanf("%d%d",&a,&b);
			add(a,b);
			add(b,a);
			in_c[a]++;in_c[b]++;
		}
		
		top=0;int cnt1,cnt2=0;
		for(int i=1;i<=n;i++){
			if(in_c[i]==n-1){
				top=i;
//				break;
			}
			if(in_c[i]==2) cnt2++;
			else if(in_c[i]==1) cnt1++;
		}
		
		if(top){
			deal1();
			continue;
		}
		
	}
	return 0;
}

