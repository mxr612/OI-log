#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#include<stack>
#include<deque>
#include<vector>
#include<set>
#include<map>
#include<iostream>
using namespace std;
typedef long long int ll;
typedef double db;
typedef vector<int> vec;
typedef string str;
typedef pair<int,int> pa;

const int n_size=5e5+5;

int n,f[n_size],son[n_size];
ll s[n_size],ss[n_size],ans;
char ch[n_size];

int cnt,head[n_size],nex[n_size],to[n_size],fat[n_size],pi[n_size];
void lian(int a,int b){
	to[++cnt]=b;
	nex[cnt]=head[a];
	head[a]=cnt;
}

void dfs(int u){
	if(ch[u]==')'){
		int cnt=0;
		for(int i=u;i!=0;i=fat[i]){
			if(cnt<0) break;
			if(ch[i]==')'){
				if(pi[i]) i=pi[i];
				else cnt++;
			}else if(ch[i]=='('){
				cnt--;
				if(cnt==0){
					s[u]=s[fat[i]]+1;
					pi[u]=i;
					break;
				}
			}
		}
	}
	
	ss[u]=ss[fat[u]]+s[u];
	for(int i=head[u],v;i;i=nex[i]){
		v=to[i];
		dfs(v);
	}
}

int main(){
  freopen("brackets.in","r",stdin);
  freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf(" %c",&ch[i]);
	for(int i=2,x;i<=n;i++){
		scanf("%d",&x);
		lian(x,i);
		fat[i]=x;
	}
	dfs(1);
	ans=1*ss[1];
	for(ll i=2;i<=n;i++){
		ans^=(i*ss[i]);
	}
	printf("%lld",ans);
	return 0;
}

