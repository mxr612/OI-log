#include<cstdio>
#include<cmath>
#include<cstring>
#include<algorithm>
#include<queue>
#include<stack>
#include<deque>
#include<vector>
#include<set>
#include<map>
#include<iostream>
using namespace std;
typedef unsigned long long int ll;
typedef double db;
typedef vector<int> vec;
typedef string str;
typedef pair<int,int> pa;

ll n,k,p[100];
vec ans;

void dfs(ll a,ll b){
	if(a==0) return;
	if(b>p[a-1]){
		ans.push_back(1); 
		dfs(a-1,p[a]-b+1);
	}else{
		ans.push_back(0);
		dfs(a-1,b);
	}
}

int main(){
  freopen("code.in","r",stdin);
  freopen("code.out","w",stdout);
	p[0]=1;
	for(int i=1;i<=64;i++) p[i]=p[i-1]*2;
	scanf("%lld%lld",&n,&k);
	dfs(n,k+1);
	for(int i=0;i<(int)ans.size();i++) printf("%d",ans[i]);
	return 0;
}

