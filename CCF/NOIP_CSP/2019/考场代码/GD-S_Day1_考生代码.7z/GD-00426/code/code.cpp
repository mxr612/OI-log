#include <iostream>
#include <cstdio>
#include <vector>
#include <string>

using namespace std;

string c;
int n,b[105];
long long g[105];
long long k;
void search(int x,long long y){
	if(x==n&&y==k){
		printf("%s",c.c_str());
		fclose(stdin);
		fclose(stdout);
		exit(0);
	}
	if(!b[x]){
		c='0'+c;
		search(x+1,y);
	}else{
		c[0]='1';
		b[x]=0;
		search(x,g[x]-y);
	}
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%lld",&n,&k);
	g[1] = 1;
	for(int i = 2; i <= n; ++i) g[i] = g[i-1]*2+1;
	int j = n;
	long long p = k;
	while(j>1){
		if(p>(g[j]-1)/2){
			b[j] = 1;
			p = g[j] - p;
		}
		j--;
	}
	if(p==0) {
		c = '0';
		search(1,0);
	}
	else {
		c = '1';
		search(1,1);
	}
	return 0;
}
