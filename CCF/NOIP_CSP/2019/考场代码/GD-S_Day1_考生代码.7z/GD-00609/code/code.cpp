using namespace std;
#include <cstdio>
#include <cstring>
#include <algorithm>
#define ull unsigned long long
ull n,k;
void dfs(ull n,ull k){
	if (n==1){
		putchar(k+'0');
		return;
	}
	if (k<1ll<<n-1){
		putchar('0');
		dfs(n-1,k);
	}
	else{
		putchar('1');
		dfs(n-1,(1ll<<n)-k-1);
	}
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%llu%llu",&n,&k);
	dfs(n,k);
	return 0;
}
