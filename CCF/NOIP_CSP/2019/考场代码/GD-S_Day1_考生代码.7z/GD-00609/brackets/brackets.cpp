using namespace std;
#include <cstdio>
#include <cstring>
#include <algorithm>
#define N 500010
#define ll long long
int n;
char s[N];
int fa[N];
struct EDGE{
	int to;
	EDGE *las;
} e[N];
int ne;
EDGE *last[N];
int sum[N],_dep[N],*dep=_dep+1;
int _buc[N*2],*buc=_buc+N;
ll f[N];
struct Floor{
	int x,up;
	EDGE *ei;
} st[N];
int top;
void dfs(int x){
	st[++top]=(Floor){1,0,last[1]};
	while (top){
		int x=st[top].x;
		if (st[top].ei==last[x]){
			dep[x]=dep[fa[x]]+1;
			sum[x]=sum[fa[x]]+(s[x]=='('?1:-1);
			int up=buc[sum[x]];
			st[top].up=up;
			if (dep[buc[sum[x]-1]]<dep[up])
				f[x]=f[up]+1;
			buc[sum[x]]=x;
		}
		if (st[top].ei==NULL){
			buc[sum[x]]=st[top].up;
			--top;
			continue;
		}
		st[top+1]=(Floor){st[top].ei->to,0,last[st[top].ei->to]};
		st[top].ei=st[top].ei->las;
		++top;
	}
}
//void dfs(int x){
//	dep[x]=dep[fa[x]]+1;
//	sum[x]=sum[fa[x]]+(s[x]=='('?1:-1);
//	int up=buc[sum[x]];
//	if (dep[buc[sum[x]-1]]<dep[up])
//		f[x]=f[up]+1;
//	buc[sum[x]]=x;
//	for (EDGE *ei=last[x];ei;ei=ei->las)
//		dfs(ei->to);
//	buc[sum[x]]=up;
//}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d%s",&n,s+1);
	for (int i=2;i<=n;++i){
		scanf("%d",&fa[i]);
		e[ne]=(EDGE){i,last[fa[i]]};
		last[fa[i]]=e+ne++;
	}
	memset(_buc,255,sizeof _buc);
	dep[-1]=-1;
	buc[0]=0;
	dfs(1);
	ll ans=0;
//	for (int i=1;i<=n;++i)
//		printf("%d ",f[i]);
	for (int i=1;i<=n;++i){
		f[i]+=f[fa[i]];
		ans^=i*f[i];
	}
	printf("%lld\n",ans);
	return 0;
}
