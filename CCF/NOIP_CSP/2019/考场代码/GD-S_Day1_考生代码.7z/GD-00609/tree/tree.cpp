using namespace std;
#include <cstdio>
#include <cstring>
#include <algorithm>
#define N 2010
int n;
int a[N],b[N];
struct edge{
	int u,v;
} ed[N];
bool bz[N];
int ans[N];
void dfs(int x){
	if (x==n){
		for (int i=1;i<=n;++i)
			b[a[i]]=i;
		for (int i=1;i<=n;++i){
			if (ans[i]<b[i])
				return;
			if (ans[i]>b[i])
				break;
		}
		memcpy(ans,b,sizeof(int)*(n+1));
		return;
	}
	for (int i=1;i<n;++i)
		if (!bz[i]){
			bz[i]=1;
			swap(a[ed[i].u],a[ed[i].v]);
			dfs(x+1);
			swap(a[ed[i].u],a[ed[i].v]);
			bz[i]=0;
		}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T;
	scanf("%d",&T);
	while (T--){
		scanf("%d",&n);
		for (int i=1;i<=n;++i)
			scanf("%d",&b[i]);
		for (int i=1;i<=n;++i)
			a[b[i]]=i;
		for (int i=1;i<n;++i)
			scanf("%d%d",&ed[i].u,&ed[i].v);
		for (int i=1;i<=n;++i)
			ans[i]=n-i+1;
		dfs(1);
		for (int i=1;i<=n;++i)
			printf("%d ",ans[i]);
		printf("\n");
	}
	return 0;
}
