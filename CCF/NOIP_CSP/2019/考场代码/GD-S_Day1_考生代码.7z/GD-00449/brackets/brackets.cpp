#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
void read(int &x)
{
	x=0;
	char c;
	for(c=getchar();c<'0'||c>'9';c=getchar());
	for(;c>='0'&&c<='9';c=getchar())
		x=x*10+c-'0';
}

const int maxn=5e5+5;
char val[maxn];
int nxt[maxn],hed[maxn],cnt[maxn];
ll ans[maxn];
stack<int>lb;
void dfs(int u,int fa)
{
	int tmp=0;
	ans[u]=ans[fa];
	if(val[u]=='('){
		lb.push(u);
		if(val[fa]==')')
			cnt[u]=cnt[fa];
	}else{
		if(lb.empty())
			cnt[u]=0;
		else{
			tmp=lb.top();
			lb.pop();
			cnt[u]=cnt[tmp]+1;
		}
		ans[u]+=cnt[u];
	}
	for(int v=hed[u];v;v=nxt[v])
		dfs(v,u);
	if(val[u]=='(')
		lb.pop();
	else if(tmp)
		lb.push(tmp);
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n,x;
	ll opt=0;
	read(n);
	scanf("%s",val+1);
	for(int i=2;i<=n;i++){
		read(x);
		nxt[i]=hed[x];
		hed[x]=i;
	}
	dfs(1,0);
	for(int i=1;i<=n;i++)
		opt^=ans[i]*i;
	cout << opt;
}

