#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
void read(int &x)
{
	x=0;
	char c;
	for(c=getchar();c<'0'||c>'9';c=getchar());
	for(;c>='0'&&c<='9';c=getchar())
		x=x*10+c-'0';
}
const int maxn=2005;
struct node{
	int fr,to,nxt;
}edg[maxn<<1]; 
int val[maxn],hed[maxn];
namespace ns1{
	int ans[20],ord[20],cur[20],pos[20];
	bool cmp(int n)
	{
		for(int i=1;i<=n;i++)
			if(ans[i]>pos[i])
				return 1;
			else if(ans[i]<pos[i])
				return 0;
		return 0;
	}
	void main(int n)
	{
		for(int i=1;i<n;i++)
			ord[i]=i;
		for(int i=1;i<=n;i++)
			ans[i]=n-i+1;
		do{
			for(int i=1;i<=n;i++)
				cur[i]=val[i];
			for(int i=1;i<n;i++)
				swap(cur[edg[ord[i]].fr],cur[edg[ord[i]].to]);
			for(int i=1;i<=n;i++)
				pos[cur[i]]=i;
			if(cmp(n))
				for(int i=1;i<=n;i++)
					ans[i]=pos[i];
		}while(next_permutation(ord+1,ord+n));
		for(int i=1;i<=n;i++)
			printf("%d ",ans[i]);
		putchar('\n');
	}
}
namespace ns3{
	int ans[maxn],ord[maxn],cur[maxn],pos[maxn];
	bool cmp(int n)
	{
		for(int i=1;i<=n;i++)
			if(ans[i]>pos[i])
				return 1;
			else if(ans[i]<pos[i])
				return 0;
		return 0;
	}
	void main(int n)
	{
		srand(233);
		for(int i=1;i<n;i++)
			ord[i]=i;
		for(int i=1;i<=n;i++)
			ans[i]=n-i+1;
		for(int i=0;i<3e6/n;i++){
			random_shuffle(ord+1,ord+n);
			for(int i=1;i<=n;i++)
				cur[i]=val[i];
			for(int i=1;i<n;i++)
				swap(cur[edg[ord[i]].fr],cur[edg[ord[i]].to]);
			for(int i=1;i<=n;i++)
				pos[cur[i]]=i;
			if(cmp(n))
				for(int i=1;i<=n;i++)
					ans[i]=pos[i];
		}
		for(int i=1;i<=n;i++)
			printf("%d ",ans[i]);
		putchar('\n');
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T,n,x,y;
	read(T);
	while(T--){
		memset(hed,0,sizeof(hed));
		read(n);
		for(int i=1;i<=n;i++){
			read(x);
			val[x]=i;
		}
		for(int i=1;i<n;i++){
			read(x);read(y);
			edg[i].fr=x;
			edg[i].to=y;
			edg[i].nxt=hed[x];
			hed[x]=i;
			edg[i+n].fr=y;
			edg[i+n].to=x;
			edg[i+n].nxt=hed[y];
			hed[y]=i+n;
		}
		if(n<=10)
			ns1::main(n);
		else
			ns3::main(n);
	}
}

