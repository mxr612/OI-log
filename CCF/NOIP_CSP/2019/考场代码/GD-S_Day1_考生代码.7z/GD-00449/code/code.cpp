#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
void read(ull &x)
{
	x=0;
	char c;
	for(c=getchar();c<'0'||c>'9';c=getchar());
	for(;c>='0'&&c<='9';c=getchar())
		x=x*10+c-'0';
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	int n,lst=0;
	ull k;
	scanf("%d",&n);
	read(k);
	for(int i=n-1;i>=0;i--){
		printf("%d",lst^int(k>>i&1));
		lst=k>>i&1;
	}
}
