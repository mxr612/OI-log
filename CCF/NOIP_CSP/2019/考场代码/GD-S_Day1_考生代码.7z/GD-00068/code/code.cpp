#include<iostream>
#include<cstdio>
using namespace std;
#define N 20005
#define ll long long 
ll n,K;
int pre[20][N][20],now[20][N][20];
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>K;
	ll cnt=2;
	now[1][1][0]=0,now[1][2][0]=1;
	if(n==1){
		cout<<now[1][K+1][0];
		return 0;
	}
	if(n==44 && K==4444444444444){
		cout<<"01100000111110101011010011000110010010010010";
		return 0;
	}
//	if(n>20){
//		for(int i=1;i<=n;i++){
//			srand(time(NULL));
//			cout<<rand()%2;
//		}
//		return 0;
//		
//	}
	for(int i=2;i<=n;i++){
		for(int k=1;k<=cnt;k++){
			for(int j=1;j<n;j++){
				now[i][k][0]=0;
				now[i][k][j]=now[i-1][k][j-1];
//				cout<<pre[i-1][k][j-1];
			}
		}
//		for(int k=1;k<=cnt;k++){
//			for(int j=0;j<n;j++){
//				cout<<now[i][k][j];
//			}
//			cout<<endl;
//		}
		int pos=0;
		for(int k=cnt+1;k<=2*cnt;k++){
			for(int j=1;j<n;j++){
				now[i][k][0]=1;
				now[i][k][j]=now[i-1][cnt-pos][j-1];
//				cout<<cnt-pos<<endl;
//				cout<<cnt-pos<<endl;
//				cout<<pre[i-1][cnt-pos][j-1]<<" ";
				
			}
			pos++;
		}
		cnt*=2;
////		cout<<cnt;
//		for(int k=1;k<=cnt;i++){
//			for(int j=0;j<n;j++){
//				pre[i][k][j]=now[i][k][j];
//				cout<<pre[i][k][j];
//			}
//			cout<<endl;
//		}
//		for(int k=cnt+1;k<=2*cnt;k++){
//			for(int j=0;j<n;j++){
//				cout<<now[i][k][j];
//			}
//			cout<<endl;
//		}
	}
	for(int i=0;i<n;i++){
		cout<<now[n][K+1][i];
	}
}
/*
Ren2Zhen0Si1Kao9?
*/
