#include<iostream>
#include<cstdio>
using namespace std;
#define N 50005
int n;
int head[N],nxt[N*2],to[N*2],tot;
int sum[N];
int le[N];
char ch[N];
int dep[N];
int ans;
int f[N];
void add(int x,int y){
	to[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}

void dfs(int x,int fa){
//	cout<<x<<" "<<fa<<endl;
	f[x]=fa;
	dep[x]=dep[fa]+1;
	if(ch[x]=='('){
		le[x]=le[fa]+1;
		sum[x]=sum[fa]+1;
//		cout<<x<<" "<<le[x]<<" "<<sum[x]<<endl;
	}
	if(ch[x]==')'){
		if(le[fa]){
			le[x]=le[fa]-1;
			sum[x]=sum[fa]-1;
		}
		else{
			le[x]=le[fa];
			sum[x]=sum[fa]+1;
		}
	}
	for(int i=head[x];i;i=nxt[i]){
		int y=to[i];
		if(y==fa) continue;
		dfs(y,x);
	}
}

int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	scanf("%s",ch+1);
	for(int i=2;i<=n;i++){
		int fa;
		cin>>fa;
		add(fa,i);
		add(i,fa);
//		if(ch[i]=='('){
//			lef[i]=lef[fa]+1;
//			sum[i]=sum[fa]+1;
//		}
//		if(ch[i]==')'){
//			if(lef[fa]){
//				lef[i]=lef[fa]-1;
//				sum[i]=sum[fa]-1;
//			}
//			else{
//				sum[i]=sum[fa]+1;
//			}
//		}
	}
	dfs(1,0);
//	for(int i=1;i<=n;i++){
//		cout<<sum[i]<<" ";
//	}
	for(int i=1;i<=n;i++){
		int k=(dep[i]-sum[i])/2;
		k*=i;
		ans=(ans xor k);
	}
	cout<<endl;
	cout<<ans;
}
