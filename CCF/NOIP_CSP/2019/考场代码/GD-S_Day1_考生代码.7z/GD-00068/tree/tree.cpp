#include<iostream>
#include<cstdio>
using namespace std;
#define N 10005
int n,T;
int head[N],nxt[N*2],to[N*2],tot;
int a[N];
int ans[N];
bool used[N];
int du[N];
int ed;
struct node{
	int u,v;
}e[N];
int fa[N];
void add(int x,int y){
	to[++tot]=y;
	nxt[tot]=head[x];
	head[x]=tot;
}
int st;
//void dfs(int x,int fa,int num){
//	if(num==n){
//		pd();
//		return;
//	}
//	for(int i=head[x];i;i=nxt[i]){
//		int y=to[i];
//		if(y==fa) continue;
//		if(used[i]) dfs(y,x,num);
//		int tmp=a[x];
//		a[x]=a[y];
//		a[y]=tmp;
//		used[i]=1;
//		dfs(y,x,num+1);
//		used[i]=0;
//		num--;
//	}
//}

void change(int bin){
	for(int i=1;i<n;i++){
		if(a[1]==1) break;
		int tmp=a[fa[bin]];
		a[fa[bin]]=a[bin];
		a[bin]=tmp;
		bin=fa[bin];
//		cout<<fa[bin]<<" "<<a[fa[bin]]<<endl;
	}
} 

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>T;
	while(T--){
		cin>>n;
		for(int i=1;i<=n;i++){
			cin>>a[i];
		}
		for(int i=1;i<n;i++){
			int x,y;
			cin>>e[i].u>>e[i].v;
			fa[e[i].v]=e[i].u;
			if(a[e[i].u]==1){
				st=e[i].u;
			}
//			add(x,y);
//			add(y,x);
		}
		change(st);
		for(int i=1;i<=n;i++){
			cout<<a[i]<<" ";
		}
	}
}
