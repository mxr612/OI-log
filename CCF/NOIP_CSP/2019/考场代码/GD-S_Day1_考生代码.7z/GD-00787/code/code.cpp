#include <iostream>
#include <fstream>
using namespace std;
int n;
unsigned long long k;
void dfs(int m,unsigned long long i)
{
	if (m==0) return;
	unsigned long long r=(unsigned long long)1<<m;
	if (i>=r/2)
	{
		cout<<1;
		dfs(m-1,r-i-1);
	}
	if (i<r/2)
	{
		cout<<0;
		dfs(m-1,i);
	}
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	dfs(n,k);
	return 0;
}
