#include <iostream>
#include <fstream>
#include <cstring>
using namespace std;
int n;
char c[500005];
struct EDGE
{
	int target;
	int Next;
}edge[500005];
int head[500005];
void add_edge(int cur,int u,int v)
{
	edge[cur].target=v;
	edge[cur].Next=head[u];
	head[u]=cur;
}
long long dp[500005];
long long ans;
void dfs(int root,string s,long long sum)
{
	s+=c[root];
	int d=0;
	for (int i=s.size()-1;i>=0;i--)
	{
		if (s[i]==')') d++;
		if (s[i]=='(') d--;
		if (d<0) break;
		if (d==0) sum++;
	}
	ans^=(long long)((long long)root*sum);
	for (int i=head[root];i!=-1;i=edge[i].Next)
		dfs(edge[i].target,s,sum);
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	memset(head,-1,sizeof(head));
	for (int i=1;i<=n;i++) cin>>c[i];
	for (int i=1;i<n;i++)
	{
		int f;
		cin>>f;
		add_edge(i,f,i+1);
	}
	dfs(1,"",0);
	cout<<ans;
	return 0;
}
