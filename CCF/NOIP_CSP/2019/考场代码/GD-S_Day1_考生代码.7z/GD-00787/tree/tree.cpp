#include <iostream>
#include <fstream>
#include <cstring>
#define min(x,y) (x<y?x:y)
using namespace std;
int t;
int n;
int id[2005];
int m[2005][2005];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>t;
	while(t--)
	{
		cin>>n;
		memset(id,0,sizeof(id));
		memset(m,0,sizeof(m));
		for (int i=1;i<=n;i++) cin>>id[i];
		for (int i=1;i<n;i++)
		{
			int x,y;
			cin>>x>>y;
			m[x][y]=m[y][x]=1;
		}
		for (int i=1;i<=n;i++)
		{
			bool f=true;
			while(f)
			{
				f=false;
				int min1=0x7f7f7f7f;
				for (int j=1;j<=n;j++)
					if (m[id[i]][j]&&j<id[i])
					{
						min1=min(j,min1);
						f=true;
					}
				if (f)
				{
					int k;
					for (int j=1;j<=n;j++)
						if (id[j]==min1) 
						{
							k=j;
							break;
						}
					swap(id[i],id[k]);
					m[id[i]][id[k]]=m[id[k]][id[i]]=0;
				}
			}
		}
		for (int i=1;i<=n;i++) cout<<id[i]<<' ';
		cout<<endl;
	}
	return 0;
}
