#include <cstdio>
#include <algorithm>
#include <cstring>
#define ll long long

using namespace std;

const int N = 5e5 + 5;

struct Edge
{
	int to,next;
}edge[N];

int n,tot;
int a[N],fa[N],st[N],pre[N];
char s[N];
ll ans;
ll sum[N];

void link(int u,int v)
{
	edge[++tot].to = v;
	edge[tot].next = st[u];
	st[u] = tot;
}

void update(int x)
{
	sum[x] = sum[fa[x]];
	if (~a[x]) return;
	int mi = 0x3f3f3f3f;
	for (int k = x ; k ; k = fa[k]) 
	{
		mi = min(pre[k],mi);
		if (mi < pre[x]) break;
		if (!(pre[x] ^ pre[fa[k]]) && mi >= pre[x]) sum[x]++;
	}
}

void dfs(int x)
{
	for (int l = st[x] ; l ; l = edge[l].next)
	{
		int v = edge[l].to;
		if (v == fa[x]) continue;
		update(v);
		dfs(v);
	}
}

void prepa(int x)
{
	for (int l = st[x] ; l ; l = edge[l].next)
	{
		int v = edge[l].to;
		if (v == fa[x]) continue;
		pre[v] += pre[x];
		prepa(v);
	}
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",s + 1);
	for (int i = 2 ; i <= n ; i++)
		scanf("%d",&fa[i]),link(fa[i],i);
	for (int i = 1 ; i <= n ; i++) pre[i] = a[i] = (s[i] == '(' ? 1 : -1);
	prepa(1);
	dfs(1);
	for (int i = 1 ; i <= n ; i++) ans ^= (i * sum[i]);
	printf("%lld\n",ans);
	return 0;
}
