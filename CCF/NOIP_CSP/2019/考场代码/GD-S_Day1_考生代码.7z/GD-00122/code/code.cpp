#include <cstdio>
#include <algorithm>
#include <cstring>
#define ll long long

int n,ans;
ll k;

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%lld",&n,&k);
	for (ll i = n ; i ; i--)
	{
		ll w = (ll)1 << (i - 1);
		ll s = k / w;
		s %= (ll)4;
		if (s == 0 || s == 3) ans = 0;
		if (s == 1 || s == 2) ans = 1;
		printf("%d",ans);
	}
	return 0;
}
