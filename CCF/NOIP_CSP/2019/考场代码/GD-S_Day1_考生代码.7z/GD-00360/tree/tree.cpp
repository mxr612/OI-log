#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
#define fo(i,a,b) for(register int i = a;i <= b;++ i)
#define fd(i,a,b) for(register int i = a;i >= b;-- i)
#define wr(a,b) cout << "Debug :" << a << " = "  << b << endl;   
using namespace std;

const int N = 500010;
int n;
int a[N], x[N], y[N];
int pos[N], posb[N], msap[N], ans[N];
inline void sswap(int &a, int &b) {
	int p = a; 
	a = b; 
	b = p;
}
int main() {
	ios::sync_with_stdio(false); cin.tie(0);	
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);

    int tcase = 0;
    cin >> tcase ;
    //tcase = 1;
    while (tcase --) {
    	cin >> n; 
    	fo (i,1,n) {
    		cin >> pos[i];
    		posb[i] = pos[i];
    		msap[pos[i]] = i; 
		}
		fo (i,1,n - 1) {
			cin >> x[i] >> y[i];
		}
    	int lim = 1;
    	fo (i,1,n - 1) {
    	  lim *= i;
    	  a[i] = i;
        }
        bool init = 1;
    	while(lim--){
    		fo (i,1,n - 1) {
    		//   cout << a[i] ;
			   sswap(pos[msap[x[a[i]]]], pos[msap[y[a[i]]]]);
			}
			//cout << endl;
		//	fo (i,1,n) cout << ans[i] << ' ';
		//	cout << endl;
		//	fo (i,1,n) cout << pos[i] << ' ';
		//	cout << endl;	cout << endl;
			if (init) {
				fo (i,1,n) ans[i] = pos[i];
				init = 0;
			}
			else fo (i,1,n) {
				if (ans[i] != pos[i] && ans[i] > pos[i]) {
					fo (j,i,n) ans[j] = pos[j];
					break;
				}
			}
    		fd (i,n,1) {pos[i] = posb[i];}
    		if (lim == 0) break;
			next_permutation(a + 1, a + n);
		}
		fo (i,1,n) cout << ans[i] << ' ';
		cout << endl;
	}
	/*
	fo (i,1,10) a[i] = i;
	fo (i,1,3628800) {
	next_permutation(a + 1, a + 1 + 10);
	}*/
	return 0;
}
