#include<iostream>
#include<cmath>
#define fo(i,a,b) for(int i = a;i <= b;++ i)
#define fd(i,a,b) for(int i = a;i >= b;-- i)
#define wr(a,b) cout << "Debug :" << a << " = "  << b << endl;   
using namespace std;

const int N = 500010;

int n, tot = 0, top = 0;
int fa[N], last[N], netx[N << 1], tar[N << 1];
int f[N], g[N], st[N];
char str[N];
bool ins[N];
long long ans = 0;

inline void add(int x, int y) {
	netx[++ tot] = last[x]; last[x] = tot; tar[tot] = y;
}

void dfs(int x) {//	wr("x",x);
	int rev = 0, back = 0;
	ins[x] = 1;
	if (str[x] == '(') st[++ top] = x, rev = -1;
	 else {
	 	if (top)  {
		  f[x] = f[fa[st[top]]] + 1; // if (!ins[st[top]]) wr("1sds",st[top]);
	 	  rev = +1, back = st[top--]; 
	    }   
	 }
	g[x] = g[fa[x]] + f[x];
	ans ^= (1ll * x * g[x]);
	for (int i = last[x];i;i = netx[i]) {
		int t = tar[i]; 
		if (t != fa[x]) dfs(t);
 	}
 	if (rev == 1) st[++ top] = back; 
 	if (rev == -1) st[top--] = 0;
	ins[x] = 0;
}

int main() {
	ios::sync_with_stdio(false); cin.tie(0);	
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);

	cin >> n;    cin >> str + 1;
	fo (i,2,n) {
		cin >> fa[i];
		add(fa[i], i);add(i, fa[i]);
	} 
	dfs(1);
//	fo (i,1,n) {
//		cout << g[i] << ' '<< f[i] << endl;
//	}
//	cout << "ans : "<< ans << endl;
	cout << ans << endl;
	return 0;
}
