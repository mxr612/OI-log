#include<iostream>
#include<cmath>
#define fo(i,a,b) for(int i = a;i <= b;++ i)
#define fd(i,a,b) for(int i = a;i >= b;-- i)
#define wr(a,b) cout << "Debug :" << a << " = "  << b << endl;   
using namespace std;

long long n, k;

void dfs(int n, long long k) {
	if (n == 0) return;
	cout << (k > (1ll << (n - 1)));
	if (k <= (1ll << (n - 1))) {
      dfs(n - 1, k);
	}
	else {
	  dfs(n - 1, (1ll << n) - k + 1);
	}
}

int main() {
	ios::sync_with_stdio(false); cin.tie(0);
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);

    cin >> n >> k; ++ k;
	dfs(n,k);
	
	return 0;
}
