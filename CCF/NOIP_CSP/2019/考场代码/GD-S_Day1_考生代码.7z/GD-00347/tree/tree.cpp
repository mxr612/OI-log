#include<bits/stdc++.h>
using namespace std;
#define maxn 2010

struct node{
	int x,y;
}a[maxn<<1];
int p[maxn],pos[maxn],ans[maxn];
int t,n,len;
bool v[maxn],bj=false;

void dfs(int k){
	if(k>=n){
		if(bj){
			for(int i=1;i<=n;i++)
				if(p[i]>ans[i]) return;
				else if(p[i]<ans[i]) break;
		}
		bj=true;
		for(int i=1;i<=n;i++)
			ans[i]=p[i];
		return;
	}
	for(int i=1;i<n;i++)
		if(!v[i]){
			v[i]=true;
			int x=a[i].x,y=a[i].y;
			swap(p[x],p[y]);
			dfs(k+1);
			swap(p[x],p[y]);
			v[i]=false;
		}
}
bool cmp(int x,int y){
	return ans[x]<ans[y];
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1,x;i<=n;i++){
			scanf("%d",&x);
			p[x]=i;
			pos[i]=i;
		}
		for(int i=1;i<n;i++)
			scanf("%d %d",&a[i].x,&a[i].y);
		dfs(1);
		sort(pos+1,pos+1+n,cmp);
		for(int i=1;i<=n;i++)
			printf("%d ",pos[i]);
		printf("\n");
	}
	return 0;
}
