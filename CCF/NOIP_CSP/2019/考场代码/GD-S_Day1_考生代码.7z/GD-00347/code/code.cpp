#include<bits/stdc++.h>
using namespace std;

int n,cnt=0,a[110],b[110],ans[110];
char s[110];

int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",s);
	int l=strlen(s);
	for(int i=0;i<l;i++)
		a[i+1]=s[i]-48;
	int t=1;
	while(true){
		for(int i=t;i<l;i++){
			int x=(a[i]&1);
			a[i]/=2;
			a[i+1]+=x*10;
		}
		if(a[t]==0) t++;
		b[++cnt]=(a[l]&1);
		a[l]/=2;
		if(t==l && a[l]==0) break;
	}
	while(cnt<n) b[++cnt]=0;
	ans[n]=b[n];
	for(int i=n-1;i>=1;i--)
		if(b[i+1]) ans[i]=b[i]^1;
		else ans[i]=b[i];
	for(int i=n;i>=1;i--)
		printf("%d",ans[i]);
	return 0;
}
