#include<bits/stdc++.h>
using namespace std;
#define maxn 500010

struct node{
	int y,next;
}a[maxn<<1];
int first[maxn],fa[maxn],v[maxn],sta[maxn],pre[maxn];
long long w[maxn],c[maxn];
int n,len,tp,top;
long long ans=0;
char s[maxn];

void ins(int x,int y){
	a[++len]=(node){y,first[x]};
	first[x]=len;
}
void dfs(int x){
	int k=top;
	sta[++tp]=x;
	pre[tp]=top;
	w[x]=w[fa[x]];
	if(v[x]==1 && v[sta[top]]==0){
		c[x]=c[fa[sta[top]]]+1;
		w[x]+=c[x];
		top=pre[top];
	}else top=tp;
	ans^=(long long)x*w[x];
	for(int i=first[x];i;i=a[i].next){
		int y=a[i].y;
		if(y==fa[x]) continue;
		dfs(y);
	}
	top=k;
}

int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",s);
	for(int i=0;i<n;i++)
		if(s[i]=='(') v[i+1]=0;
		else v[i+1]=1;
	memset(first,top=len=0,sizeof first);
	for(int i=2;i<=n;i++){
		scanf("%d",&fa[i]);
		ins(fa[i],i);
	}
	fa[1]=0;v[0]=2;w[0]=0;dfs(1);
	printf("%lld",ans);
	return 0;
}
