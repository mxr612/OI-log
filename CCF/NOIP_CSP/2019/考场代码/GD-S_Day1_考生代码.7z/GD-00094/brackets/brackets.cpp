#include<iostream>
#include<cstring>
#include<string>
#include<fstream>
#include<stack>
using namespace std;
int n,chr[500500],ans,pd,tot;
				stack<char> zhan;
string s;
void dfs(int);
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	cin>>s;
	for(int i=2;i<=n;i++)cin>>chr[i];
	//dfs(5);cout<<ans;
	for(int i=1;i<=n;i++)
	{
		ans=0;
		dfs(i);
		cout<<ans<<endl;
		tot=tot^(ans*i);
	}
	cout<<tot;
	return 0;
}
void dfs(int note)
{
	for(int i=0;i<note;i++)
	{
		
		for(int j=i;j<note;j++)
		{
			pd=0;
			for(int k=0;k<j-i;k++)
			{
				if(s[i+k]=='(') zhan.push('(');
				else
				{
					char lsc=zhan.top();zhan.pop();
					if(lsc!=s[i+k])
					{
												//while(zhan.size()!=0) zhan.pop();
						pd=1;
						break;
					}
				}
			}
			if(pd==0&&zhan.empty()) ans++;
		}
	}
}
