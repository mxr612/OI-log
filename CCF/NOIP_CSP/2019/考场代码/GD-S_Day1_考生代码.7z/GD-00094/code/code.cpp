#include<iostream>
#include<cstring>
#include<fstream>
#include<cmath>
using namespace std;
long long n,k,f[2][5000500],d[2][5000500],x=0,y=1;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	f[1][1]=1;
	d[1][1]=0;
	d[1][0]=1;
	for(int i=2;i<=n;i++)
	{
		for(int j=0;j<pow(2,i);j++)
		{
			if(j<pow(2,i-1)) {f[x][j]=f[y][j];d[x][j]=d[y][j]+1;}
			if(j>=pow(2,i-1)) 
			{
				f[x][j]=f[y][2*(int(pow(2,i-1))-1)-j+1]|(1<<(i-1));
				d[x][j]=0;
			}
		}
		swap(x,y);
	}
	long long lsa=f[y][k];//cout<<lsa<<" "<<d[y][k];
	for(int i=0;i<d[y][k];i++)cout<<0;
	while(d[y][k]<n)
	{
		int lsx=int(bool(lsa&(1<<(n-d[y][k]-1))));
		cout<<int(lsx);
		d[y][k]++;
	}
	return 0;
}
