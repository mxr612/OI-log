#include<cstdio>
#include<algorithm>
#include<iostream>
using namespace std;
unsigned long long k,now;
int n;
int a[110],tot;
inline void dfs(unsigned long long sum,unsigned long long val){
	if(val==0) return;
	if(sum>val){
		long long now1=(val-sum+1+val);
		dfs(now1,val/2);
		a[++tot]=1;	
	}
	else {
		dfs(sum,val/2);
		a[++tot]=0;
	}
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d",&n);
	now=1;
	for(register int i=1;i<n;i++){
		now=now*2;
	}
	cin>>k;
	k++;
	if(n==64&&k==0){
		printf("1");
		for(register int i=2;i<=n;i++){
			printf("0");
		}
		return 0;
	}
	dfs(k,now);
	for(register int i=tot;i>=1;i--){
		printf("%d",a[i]);
	}
	return 0;
}
