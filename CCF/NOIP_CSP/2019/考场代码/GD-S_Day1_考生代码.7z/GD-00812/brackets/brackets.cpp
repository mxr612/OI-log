#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<map>
using namespace std;
#define ull unsigned long long
ull p=233;
map<ull,int>mp;
struct sb{
	int to;
	int next;
}s[1000010];
int n,head[500010],sta[500010],top,tot,pos[500010],f[500010],deep[500010];
inline void add(int x,int y){
	s[++tot].next=head[x];
	s[tot].to=y;
	head[x]=tot;
}
ull sum[500010];
long long ans[500010];
char val[500010];
inline ull power(ull a,int b){
	ull ans1=1;
	for(;b;b>>=1){
		if(b&1)ans1=ans1*a;
		a=a*a;
	}
	return ans1;
}
inline void dfs(int x){
	for(register int i=head[x];i;i=s[i].next){
		int y=s[i].to;
		if(y!=f[x]){
			bool flag=false;
			int pres;
			f[y]=x;
			deep[y]=deep[x]+1;
			sum[y]=sum[x]*deep[x]*p+val[y];
			if(val[y]=='('){
				sta[++top]=y;
			}
			else {
				if(top){
					flag=true;
					pres=sta[top];
					pos[y]=pres;
					top--;
					int now=pos[y];
					while(now){
						ull now_val=sum[y]-sum[f[now]]*power(p,deep[y]-deep[now]+1);
						if(mp[now_val]==0){
							ans[y]++;
						}
						mp[now_val]++;
						now=pos[f[now]];
					}
				}
			}
			dfs(y);
			if(val[y]=='('){
				top--;
			}
			else {
				if(flag){
					sta[++top]=pres;
					int now=pos[y];
					while(now){
						ull now_val=sum[y]-sum[f[now]]*power(p,deep[y]-deep[now]+1);
						mp[now_val]--;
						now=pos[f[now]];
					}
				}
			}
		}
	}
}
inline void calc(int x){
	for(register int i=head[x];i;i=s[i].next){
		int y=s[i].to;
		if(y!=f[x]){
			ans[y]+=ans[x];
			calc(y);
		}
	}
}
char ch[500010];
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",val+1);
	for(register int i=2;i<=n;i++){
		int x;
		scanf("%d",&x);
		add(x,i);
		add(i,x);
	}
	sum[1]=val[1];
	if(val[1]=='(')sta[++top]=1;
	deep[1]=1;
	dfs(1);
	calc(1);
	long long ans2=0;
	for(register int i=1;i<=n;i++){
		ans2=ans2^(1ll*i*ans[i]);
	}
	printf("%lld\n",ans2);
	return 0;
}

