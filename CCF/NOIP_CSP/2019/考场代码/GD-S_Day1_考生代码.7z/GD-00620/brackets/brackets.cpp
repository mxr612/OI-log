#include<cstdio>
#include<iostream>
#include<cmath>
#include<algorithm>
#include<cstring>
using namespace std;
const int maxn=5e5+5;
int n,a[maxn];
long long sum,ans;
char s[maxn];
inline int sp(int k)
{
	int ll=0,num=0,flag=1;
	for(int i=1;i<k;i++)
	for(int j=i+1;j<=k;j+=2)
	{
		ll=0;flag=1;
		for(int p=i;p<=j;p++)
		{
			if(s[p]=='(') ll++;
			else ll--;
			if(ll<0)
			{
				flag=0;
				break;
			}
		}
		if(ll>0) flag=0;
		if(flag) num++;
	}
	return num;
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>s[i];
	for(int i=1;i<n;i++)
	{
		cin>>a[i];
		if(a[i]=i) sum++;
	}
	if(sum==n-1)
	{
		for(int i=2;i<=n;i++)
		{
			long long kkk;
			kkk=sp(i);
			if(kkk==0) continue;
			else ans=ans^(kkk*i);
		}
	}
	cout<<ans;
}
