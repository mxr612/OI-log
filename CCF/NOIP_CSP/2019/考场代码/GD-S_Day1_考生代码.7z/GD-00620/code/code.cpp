#include<cstdio>
#include<iostream>
using namespace std;
int n,flag;
long long k,a[100],ans;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	a[0]=0;
	for(int i=1;i<=64;i++)
	a[i]=a[i-1]*2+1;
	cout<<a[63]<<endl;
	if(k<=a[63]&&k>=0)
	{
		for(int i=63;i>=1;i--)
		{
			if(k>a[i]/2)
			k=a[i]-k,ans+=a[i-1]+1;
		}
	}
	cout<<ans<<endl;
	for(int i=n-1;i>=0;i--)
	{
		if(ans>a[i]) cout<<1,ans-=a[i],ans-=1;
		else cout<<0;
	}
}
