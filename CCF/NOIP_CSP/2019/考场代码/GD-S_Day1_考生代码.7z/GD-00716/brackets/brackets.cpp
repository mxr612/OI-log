#include<queue>
#include<cstdio>
#include<string>
#include<algorithm>
#include<iostream>
using namespace std;

int n;
char st[500005];
struct OneEdge
{
	int to,nxt;
} e[1000005];
int depth[500005];
int cnt=0,front[500005];
void add(int x,int y)
{
	cnt++;
	e[cnt].to=y;
	e[cnt].nxt=front[x];
	front[x]=cnt;
}
string dist[500005];
void bfs()
{
	int u,v;
	queue<int> q;
	q.push(1);
	dist[1]=st[1];
	depth[1]=1;
	
	while(!q.empty())
		{
			u=q.front();
			q.pop();
			for(int i=front[u];i>0;i=e[i].nxt)
				{
					v=e[i].to;
					if(depth[v]==0)
						{
							depth[v]=depth[u]+1;
							dist[v]=dist[u]+st[v];
							q.push(v);
						}
				}
		}
}
bool pan(string x)
{
	int s=0,len=x.size();
	for(int i=0;i<len;i++)
		if(x[i]=='(')
			s++;
		else
			{
				s--;
				if(s<0)
					return false;
			}
	if(s==0)
		return true;
	return false;
}
long long pd(string x)
{
	//�����������Ӵ�
	long long ans=0;
	int len=x.size();
	for(int i=0;i<len;i++)
		for(int j=2;j<=len-i;j++)
			if(pan(x.substr(i,j)))
				ans++;
	return ans; 
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	
	scanf("%d",&n);
	scanf("%s",st+1);
	int x;
	for(int i=2;i<=n;i++)
		{
			scanf("%d",&x);
			add(i,x);
			add(x,i);
		}
	long long ans=0;
	bfs();
	
	for(int i=1;i<=n;i++)
		ans^=i*pd(dist[i]);
	printf("%lld",ans);
	return 0;
}
