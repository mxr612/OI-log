#include<iostream>
#include<cstdio>
using namespace std;
typedef unsigned long long ull;

ull adbcf(ull a,ull b)
{
	ull ans=1;
	while(b)
		{
			if(b&1)
				ans=ans*a;
			a=a*a;
			b>>=1;
		}
	return ans;
}
ull w,n,k;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);

	cin>>n>>k;
	w=adbcf(2,n);
	//last half=1,not=0
	while(w!=1)
		{
			//panduan front or rear
			if(k>=w/2)
				{
					//rear
					printf("1");
					//fold
					k=(w-1)-k;
				}
			else
				printf("0");
			w/=2;
		}
	return 0;
}
