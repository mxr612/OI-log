#include<iostream>
#include<cmath>
#include<cstdio>
#include<string>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<map>
#include<vector>
using namespace std;
int n,a[500005],dad[500005],smallson[500005],x;
long long f[500005],s;
vector <int>c[500005];
inline int cins()
{
	char ch=getchar();
	while(ch!='('&&ch!=')')ch=getchar();
	if(ch=='(')return 1;
	return -1;
}
inline void cleaner(int y)
{
	 while(c[y].size()>0)c[y].pop_back();
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
    cin>>n;
    for(int i=1;i<=n;i++)
    a[i]=cins();
    for(int i=2;i<=n;i++)
    scanf("%d",&dad[i]),
    smallson[dad[i]]=i;
    c[1].push_back(0);
    if(a[1]==1)c[1].push_back(0);
    for(int i=2;i<=n;i++)
    {
    	c[i]=c[dad[i]];
    	if(smallson[dad[i]]==i)cleaner(dad[i]);
    	x=0;
    	if(a[i]==-1)
    	if(c[i].size()>1)
        {
        	c[i].pop_back();
        	if(c[i].size()>0)
        	{
			    x=c[i][c[i].size()-1]+1;
            	c[i].pop_back();
            	c[i].push_back(x);
        	}
        }
        else
        {
        	c[i].pop_back();
            c[i].push_back(0);
        }
		else c[i].push_back(0);
    	f[i]=f[dad[i]]+x;
    	s=(s)xor(f[i]*i);
    }
    cout<<s;
	return 0;
}

