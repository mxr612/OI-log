#include<iostream>
#include<cmath>
#include<cstdio>
#include<string>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<map>
#include<vector>
using namespace std;
int n;
long long k,a[105];
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	a[0]=1;
	for(int i=1;i<n;i++)
	a[i]=a[i-1]<<1;
	for(int i=n;i>=1;i--)
	{
		if(k>=a[i-1])
		{
			printf("1");
			k=a[i-1]-(k-a[i-1])-1;
		}
		else printf("0");
	}
	return 0;
}
