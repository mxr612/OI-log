#include <iostream>
#include <cstdio>
using namespace std;
#define ll long long
ll n,k,ans;
bool f;

void dfs(ll dep,ll rk){
	if(dep==1){
		ans+=rk;
		return ;
	} else 
	if((1ll<<(dep-1))>rk){
		dfs(dep-1,rk);
	} else {
		dfs(dep-1,(1ll<<dep)-rk-1);
		ans+=(1ll<<(dep-1));
	}
}

void print(ll ans,ll dep){
	if(ans/2) print(ans/2,dep+1);
	else {
		if(dep!=n) printf("0");
	}
	printf("%lld",ans%2);
}

int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	dfs(n,k);
	print(ans,1);
	return 0;
}
