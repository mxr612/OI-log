#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
const int N=2010;
int v[N*2],nxt[N*2],first[N],cnt;
int fa[N],ans[N],a[N];
int aa[N],bb[N];
int val[N],n,cp[N],nw[N],cou[N];
bool vis[N];

void read(int &x){
	x=0;int f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-f;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
	x*=f;
}

void add(int a,int b){
	v[++cnt]=b;
	nxt[cnt]=first[a];
	first[a]=cnt;
	aa[cnt]=a;
	bb[cnt]=b;
}

void swap1(int &x,int &y){
	int t=x;
	x=y;
	y=t;
}

bool cmp(){
	for(int i=1;i<=n;i++)
		if(ans[i]>nw[i]) return 1;
		else if(ans[i]<nw[i]) return 0;
	return 0;
}

void check(){
//	for(int i=1;i<n;i++) cout<<a[i]<<' ';cout<<'\n';
	for(int i=1;i<=n;i++) cp[i]=val[i];
	for(int i=1;i<n;i++) swap1(cp[aa[a[i]]],cp[bb[a[i]]]);
	for(int i=1;i<=n;i++) nw[cp[i]]=i;
//	for(int i=1;i<=n;i++) cout<<nw[i]<<' ';cout<<'\n';
	if(cmp()) for(int i=1;i<=n;i++) ans[i]=nw[i];	
}

void dfs(int dep){
	if(dep==n){
		check();
		return ;
	}
	for(int i=1;i<cnt;i+=2)
		if(!vis[i]){
			vis[i]=1;
			a[dep]=i;
			dfs(dep+1);
			vis[i]=0;
		}
}

bool check1(){
	for(int i=1;i<cnt;i+=2){
		cou[aa[i]]++;
		cou[bb[i]]++;
	}
	int sum=0,sum2=0;
	for(int i=1;i<=n;i++)
		if(cou[i]==1) sum++;
		else if(cou[i]==2) sum2++;
	return sum==2&&sum2==(n-2);
}

void calc(int x,int ffa,int br){
	for(int i=first[x];i;i=nxt[i]){
		if(ffa==v[i]) continue;
		if(v[i]==br) return ;
		swap(cp[x],cp[v[i]]);
//		dfs(v[i],x);
	}
}

//void getans(){
//	int p1,p2;
//	for(int i=1;i<=n;i++)
//		if(val[i]==1) p2=i;
//	p1=1;
//	int p3=0,p4=0;
//	for(int i=1;i<=n;i++)
//		if(cou[i]==1&&p3) p4=i;
//		else p3=i;
//	for(int i=1;i<=n;i++) cp[i]=val[i];
//	calc(p3,0,1);
//	calc(p4,0,p2);
//	int x=1,ffa=0;
//	while(x!=p2){
//		int t=v[i];
//		if(t==ffa) t=v[nxt[i]];
//		swap1(cp[t],cp[x]);
//		ffa=x;
//		x=t;
//	}
////	for(int i=1;i<n;i++) cout<<a[i]<<' ';cout<<'\n';
//	for(int i=1;i<=n;i++) nw[cp[i]]=i;
////	for(int i=1;i<=n;i++) cout<<nw[i]<<' ';cout<<'\n';
//	if(cmp()) for(int i=1;i<=n;i++) ans[i]=nw[i];
//	for(int i=1;i<=n;i++) cp[i]=val[i];
//	calc(p3,0,1);
//	calc(p2,0,p4);
//	int x=1,ffa=0;
//	while(x!=p2){
//		int t=v[i];
//		if(t==ffa) t=v[nxt[i]];
//		swap1(cp[t],cp[x]);
//		ffa=x;
//		x=t;
//	}
////	for(int i=1;i<n;i++) cout<<a[i]<<' ';cout<<'\n';
//	for(int i=1;i<=n;i++) nw[cp[i]]=i;
////	for(int i=1;i<=n;i++) cout<<nw[i]<<' ';cout<<'\n';
//	if(cmp()) for(int i=1;i<=n;i++) ans[i]=nw[i];	
//}

int pre[N];
void getans2(){
	int pos=0;
	for(int i=1;i<=n;i++)
		if(cou[i]==n-1) pos=i;
	for(int i=1;i<=n;i++) pre[val[i]]=i;
//	if(pos==1){
//		for(int i=2;i<=n;i++);
//	} else {
		for(int i=1;i<=n;i++) if(vis[i]){
			int mn=(1<<29),pp=0;
			for(int j=1;j<=n;j++) if(i^j){
				if(!vis[j])
					if(mn>val[j]){
						mn=val[j];
						pp=j;
					}
			}
			swap1(val[i],val[pp]);
			vis[i]=vis[pp]=1;
		}
//	}
	int qw=0,qwq=0;
	for(int i=1;i<=n;i++)
		if((!vis[i])&&qw) qwq=i;
		else qw=i;
	swap1(val[qw],val[qwq]);
	for(int i=1;i<=n;i++) ans[val[i]]=i;
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T;
	read(T);
	while(T--){
		memset(first,0,sizeof(first));
		memset(vis,0,sizeof(vis));
		cnt=0;
		read(n);
		for(int i=1;i<=n;i++) read(val[i]);
		for(int i=1;i<=n;i++) ans[val[i]]=i;
		for(int i=1;i<n;i++){
			int a,b;
			read(a);read(b);
			add(a,b);
			add(b,a);
		}
		if(n<=10) dfs(1);
		else if(check1()); //getans();
		else getans2();
		for(int i=1;i<=n;i++) printf("%d ",ans[i]);
		printf("\n");
	}
}
