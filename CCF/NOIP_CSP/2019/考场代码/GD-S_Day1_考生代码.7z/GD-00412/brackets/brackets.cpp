#include <iostream>
#include <cstdio>
using namespace std;
const int N=500000+10;
#define ll long long
int v[N],nxt[N],first[N],cnt;
int n,top[N],pre[N],mch[N],fa[N];
ll dp[N];
char c[N];

void read(int &x){
	x=0;int f=1;char c=getchar();
	while(c<'0'||c>'9'){if(c=='-')f=-f;c=getchar();}
	while(c>='0'&&c<='9'){x=x*10+c-'0';c=getchar();}
	x*=f;
}

void add(int a,int b){
	v[++cnt]=b;
	nxt[cnt]=first[a];
	first[a]=cnt;
}

int q[N];
void getlas(){
	int head=1,tail=2;
	q[1]=1;
	while(head<tail){
		int x=q[head++];
		for(int i=first[x];i;i=nxt[i]){
			if(c[v[i]]==')'){
				mch[v[i]]=pre[x];
				pre[v[i]]=pre[fa[x]];
			} else pre[v[i]]=v[i];
			q[tail++]=v[i];
		}
	}
}

void bfs(){
	int head=1,tail=2;
	q[1]=1;
	while(head<tail){
		int x=q[head++];
		for(int i=first[x];i;i=nxt[i]){
			top[v[i]]=top[x];
			if(c[v[i]]=='('){
				dp[v[i]]=0;
				top[v[i]]++;
			} else 
			if(c[x]=='('){
				dp[v[i]]=dp[fa[x]]+1ll;
				--top[v[i]];
			} else {
				if(top[v[i]]){
					dp[v[i]]=1ll+dp[fa[mch[v[i]]]];
					--top[v[i]];
				} else dp[v[i]]=0;
			}
			q[tail++]=v[i];
		}
	}
}

ll ans,sum[N];
void calc(){
	int head=1,tail=2;
	q[1]=1;
	while(head<tail){
		int x=q[head++];
		for(int i=first[x];i;i=nxt[i]){
			sum[v[i]]=1ll*sum[x]+1ll*dp[v[i]];
			q[tail++]=v[i];
		}
	}
}

int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	read(n);
	scanf("%s",c+1);
	for(int i=2;i<=n;i++){
		int x;
		read(x);
		add(x,i);
		fa[i]=x;
	}
	if(c[1]=='(') pre[1]=1;
	getlas();
//	for(int i=1;i<=n;i++) printf("%d ",mch[i]);
	if(c[1]=='(') ++top[1];
	bfs();
	calc();
//	for(int i=1;i<=n;i++) printf("%d ",sum[i]);
	for(int i=1;i<=n;i++) ans^=(1ll*(1ll*i*1ll*sum[i]));
	printf("%lld",ans);
//	cout<<"qwq";
	return 0;
}
