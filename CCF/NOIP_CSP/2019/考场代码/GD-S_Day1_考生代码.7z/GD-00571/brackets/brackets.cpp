#include<bits/stdc++.h>
#define ll long long
using namespace std;
char ch[500001];
ll tree[500001],f[500001];
inline ll read() {
	char c=getchar();
	ll s=1,f=0;
	while(c<'0' or c>'9') {
		if(c=='-')
			s=-1;
		c=getchar();
	}
	while(c>='0' and c<='9') {
		f=f*10+c-'0';
		c=getchar();
	}
	return s*f;
}
int main() {
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	ll n,ls,ans=0;
	n=read();
	cin>>ch;
	for(register ll i=0; i<n; i++) {
		if(ch[i]==')')
			tree[i+1]=-1;
		else
			tree[i+1]=1;
		if(i!=0) {
			ls=read();
		}
	}
	for(register ll i=1; i<=n; i++) {
		ls=0;
		for(register ll j=i; j<=n; j++) {
			ls=ls+tree[j];
			if(ls<0)break;
			if(ls==0) {
				f[j]++;
			}
		}
	}
	for(register ll i=1; i<=n; i++) {
		f[i]=f[i-1]+f[i];
		ans=ans^(i*f[i]);
	}
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
