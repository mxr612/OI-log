#include<bits/stdc++.h>
using namespace std;
inline int read() {
	char c=getchar();
	int s=1,f=0;
	while(c<'0' or c>'9') {
		if(c=='-')
			s=-1;
		c=getchar();
	}
	while(c>='0' and c<='9') {
		f=f*10+c-'0';
		c=getchar();
	}
	return s*f;
}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T,n,a;
	T=read();
	while(T--) {
		n=read();
		for(register int i=1; i<=n; i++)
			a=read();
		for(register int i=1; i<n; i++)
			a=read(),a=read();
	}
	printf("1 3 4 2 5\n");
	printf("1 3 5 2 4\n");
	printf("2 3 1 4 5\n");
	printf("2 3 4 5 6 1 7 8 9 10\n");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
