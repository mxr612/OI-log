#include<bits/stdc++.h>
#define ull unsigned long long
using namespace std;
inline ull read() {
	char c=getchar();
	ull s=1,f=0;
	while(c<'0' or c>'9') {
		if(c=='-')
			s=-1;
		c=getchar();
	}
	while(c>='0' and c<='9') {
		f=f*10+c-'0';
		c=getchar();
	}
	return s*f;
}
int main() {
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	ull n,k;
	bool flag=0;
	n=read();
	k=read();
	/*if(n==64 and k==18446744073709551615){
	printf("1000000000000000000000000000000000000000000000000000000000000000\n");
	return 0;
	}*/
	k=k+1;
	ull l=1,r;
	if(n<64)
		r=pow(2,n);
	while(l<r) {
		ull mid=(l+r)/2;
		if(k>mid) {
			l=mid+1;
			if(flag)
				printf("0");
			else
				printf("1");
			flag=1;
		} else {
			r=mid;
			if(flag)
				printf("1");
			else
				printf("0");
			flag=0;
		}
	}
	printf("\n");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
