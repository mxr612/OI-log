#include<cstdio>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
#define ll long long
#define ull unsigned long long
#define N 100005
using namespace std;
int n,cnt;
ll k;
int ans[N];
void work(ll pos,int step){
	if(step==1){
		if(pos==1){
			ans[++cnt]=0;
		}
		else ans[++cnt]=1;
		return;
	}
	ll mid=1ll<<(step-1);
	if(pos>mid) work((1ll<<step)-pos+1,step-1);
	else work(pos,step-1);
	if(pos>mid) ans[++cnt]=1;
	else ans[++cnt]=0;
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d %lld",&n,&k);
	work(k+1,n);
	for(int i=cnt;i>=1;i--) printf("%d",ans[i]);
	return 0;
}
