#include<cstdio>
#include<algorithm>
#include<cstring>
#define ll long long
#define N 2005
using namespace std;
int T;
int n;
int num[N],x[N],y[N],tmp[N],ans[N];
bool vis[N];
bool cmp(int x,int y){
	return num[x]<num[y];
}
bool pd(){
	for(int i=1;i<=n;i++){
		if(ans[i]<tmp[i]) return 0;
		if(ans[i]>tmp[i]) return 1;
	}
	return 1;
}
void cov(){
	for(int i=1;i<=n;i++) ans[i]=tmp[i];
}
void dfs(int cur){
	if(cur>n-1){
		for(int i=1;i<=n;i++) tmp[i]=i;
		sort(tmp+1,tmp+n+1,cmp);
		if(!ans[1]) cov();
		else if(pd()) cov();
	}
	for(int i=1;i<=n-1;i++){
		if(!vis[i]){
			vis[i]=1;
			swap(num[x[i]],num[y[i]]);
			dfs(cur+1);
			swap(num[x[i]],num[y[i]]);
			vis[i]=0;
		}
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		memset(ans,0,sizeof(ans));
		memset(vis,0,sizeof(vis));
		int id;
		scanf("%d",&n);
		for(int i=1;i<=n;i++) scanf("%d",&id),num[id]=i;
		for(int i=1;i<=n-1;i++) scanf("%d %d",&x[i],&y[i]);
		dfs(1);
		for(int i=1;i<=n;i++) printf("%d ",ans[i]);
		printf("\n");
	}
	return 0;
}
