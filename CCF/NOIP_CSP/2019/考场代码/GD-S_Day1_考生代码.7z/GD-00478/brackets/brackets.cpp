#include<cstdio>
#include<algorithm>
#include<cstring>
#define ll long long
#define N 500005
using namespace std;
int n,len;
ll ans;
int fa[N];
char s[N],t[N];
bool pd(int l,int r){
	int top=0;
	for(int i=r;i>=l;i--){
		if(t[i]=='(') ++top;
		else{
			if(!top) return 0;
			top--;
		}
	}
	if(top) return 0;
	return 1;
}
int cal(){
	int res=0;
	for(int l=1;l<=len;l++){
		for(int r=l;r<=len;r++){
			if(pd(l,r)) res++;
		}
	}
	return res;
}
void work(int u){
	len=0;
	int p=u;
	t[++len]=s[p];
	while(fa[p]){
		t[++len]=s[fa[p]];
		p=fa[p];
	}
	int k=cal();
	ans=ans xor (1ll*u*k);
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf(" %s",s+1);
	for(int i=2;i<=n;i++) scanf("%d",&fa[i]);
	for(int i=1;i<=n;i++){
		work(i);
	}
	printf("%lld\n",ans);
	return 0;
}
