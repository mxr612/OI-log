#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<cstring>
#include<vector>
#include<queue>
#define LL long long
using namespace std;
const int maxn=5*1e5+100;
int n,sta;
int fa[maxn];
char ch[maxn],c;
int sum[maxn],path[maxn];
LL ans;
bool oK;
vector <int> g[maxn];

void printanswer()
{
//	for (int i=1;i<=n;i++)
//	  cout<<sum[i]<<endl;
	
	ans=sum[1];
	for (int i=2;i<=n;i++)
	  ans=ans xor (i*sum[i]);
	cout<<ans;
	exit(0);	
}


void water1()
{
	sta=0;
	int left=0,right=0;
	for (int i=sta;i<=n;i++)
	  for (int beg=1;beg<i;beg++)
	  {
	  	left=0;right=0;
	  	for (int ended=beg;ended<=i;ended++)
	    {
	    	if (ch[ended]=='(') left++;
	    	if (ch[ended]==')') right++;
	    	if (left==right&&left>0) sum[i]++;
	    	if (right>left) break;
	    }
	  }
	printanswer();
}


void judgeoK(int node,int num)
{
	int left=0,right=0;
	for (int beg=1;beg<num;beg++)
	{
		left=0;right=0;
		for (int ended=beg;ended<=num;ended++)
		{
			if (ch[path[ended]]=='(') left++;
			if (ch[path[ended]]==')') right++;
			if (right>left) break;
			if (left==right&&right!=0) sum[node]++;
		}
	}
}


void dfs(int node,int num,int left,int right)
{
//	if (right>left) return;
	int lleft=left,rright=right;
	path[num+1]=node;
	judgeoK(node,num+1);
	if (ch[node]=='(') lleft++;
	if (ch[node]==')') rright++;
//	if (right>left) return;
	for (int i=0;i<g[node].size();i++)
	  dfs(g[node][i],num+1,lleft,rright);
}


int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	
	scanf("%d",&n);
	c=getchar();
	for (int i=1;i<=n;i++)
	{
		scanf("%c",&ch[i]);
		if (ch[i]=='('&&sta==0) sta=i;
	}
	oK=true;
	for (int i=1;i<n;i++)
	{
		scanf("%d",&fa[i]);
		if (fa[i]!=i-1) oK=false;
		g[fa[i]].push_back(i+1);
	}
	if (n<=200&&oK==true) water1();
	else 
	{
	  dfs(1,0,0,0);
	  printanswer();	
	}
	return 0;
}
