#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<cstring>
#include<vector>
#include<queue>
#define LL long long
using namespace std;
const int maxn=2000+100;
int T;
int n;
struct dat
{
	int x,y;
}road[maxn];
int nodesnum[maxn],numsnode[maxn]/*,copynum[maxn]*/,copynode[maxn];
int order[maxn],ans[maxn];
bool chosen[maxn];

void printanswer()
{
	for (int i=1;i<=n;i++)
	  printf("%d ",ans[i]);
	printf("\n");
}

void makeanswer()
{
	for (int i=1;i<=n;i++)
	{
		nodesnum[i]=copynode[i];
	}
	  
	for (int i=1;i<n;i++)
	{
		int p=order[i];
		swap(nodesnum[road[p].x],nodesnum[road[p].y]);
	}
	
	for (int i=1;i<=n;i++)
	{
		numsnode[nodesnum[i]]=i;
	}
	bool oK=true;
	for (int i=1;i<=n;i++)
	  if (numsnode[i]>ans[i]) {oK=false;break;}
	if (oK==true)
	{
		for (int i=1;i<=n;i++)
		  ans[i]=numsnode[i];
	}
}

void dfs(int k)
{
	if (k>n-1) {makeanswer();return;}
	for (int i=1;i<=n-1;i++)
	  if (!chosen[i])
	  {
	  	chosen[i]=true;
	  	order[k]=i;
//	  	swap(nodesnum[road[i].x],nodesnum[road[i].y]);
//	  	swap(numsnode[road[i].x],numsnode[road[i].y]);
	  	
	  	dfs(k+1);
	  	
	  	chosen[i]=false;
	  	order[k]=i;
//	  	swap(nodesnum[road[i].x],nodesnum[road[i].y]);
//	  	swap(numsnode[road[i].x],numsnode[road[i].y]);
	  }
	  return;
}

void water1()
{
	memset(chosen,false,sizeof(chosen));
	dfs(1);
	printanswer();
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	scanf("%d",&T);
	while (T--)
	{
		scanf("%d",&n);
		for (int i=1;i<=n;i++)
		{
			ans[i]=n+1;
			scanf("%d",&numsnode[i]);
//			copynum[i]=numsnode[i];
			nodesnum[numsnode[i]]=i;
			copynode[numsnode[i]]=i;
		}
		for (int i=1;i<=n-1;i++)
		  scanf("%d%d",&road[i].x,&road[i].y);
		water1();
	}
	return 0;
}
