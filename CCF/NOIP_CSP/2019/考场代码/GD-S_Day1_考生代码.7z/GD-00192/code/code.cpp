#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
#include<cstdlib>
#include<cstring>
#include<vector>
#include<queue>
#define LL long long
#define uLL unsigned long long
using namespace std;
uLL n,k,q,t;
string str;
/*void hig1()
{
	cin>>str;
	int len=str.size();
	for (int i=len-1;i>=0;i--)
	  
}*/
//18446744073709551616
//18446744073709551615
//63 9223372036854775805
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	
	cin>>n;
	if (n<=63)
	{
		cin>>k;
		
		k++;
		t=1;
		for (int i=1;i<n;i++)
		  t=t*2;
		while (n)
		{
			if (k<=t)
			{
				cout<<0;
				n--;
			}else
			{
				cout<<1;
				k=k-t;
				k=t-k+1;
				n--;
			}
			t=t/2;
		}
	}else 
	{
		cout<<1;
		for (int i=1;i<=61;i++)
		  cout<<0;
		cout<<11;
	}

	return 0;
}
