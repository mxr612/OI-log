#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
typedef long long ll;
const double eps = 1e-8;

int n, lis[105]; 
double k, mi[105];

int main() {
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	mi[0] = 1; for(int i = 1;i <= 64;i ++) mi[i] = mi[i - 1] * 2.0;
//  scanf("%d%lld", &n, &k);
  cin >> n >> k;
  for(int i = n;i >= 2;i --) {
//  	ll res = (((1LL << (i - 2)) - 1) << 1) + 1;
    double res = mi[i - 1] - 1;
  	if(- eps <= res - k) lis[i] = 0;
  	else {
  		lis[i] = 1;
  		k = res - (k - res - 1);
		}
	}
	lis[1] = (k > 0.0001) ? (1) : (0);
	for(int i = n;i >= 1;i --) putchar(char('0' + lis[i]));
	puts("");
	return 0;
}

