#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
const int maxn = 2000 + 10;

int n, a[maxn], h[maxn], ecnt;
struct enode{
	int v, n;
	enode() {}
	enode(int _v, int _n):v(_v), n(_n) {}
}e[maxn << 1];

inline void addedge(int u, int v) { ecnt ++; e[ecnt] = enode(v,h[u]); h[u] = ecnt; }

int deg[maxn];

namespace work1{

int pos[maxn], Ans[maxn], val[maxn], lis[maxn];
inline void work() {
	for(int i = 1;i <= n;i ++) val[a[i]] = i;
	for(int i = 1;i < n;i ++) {
		int x = pos[i];
		int u = e[x * 2 - 1].v, v = e[x * 2 - 2].v;
		swap(val[u],val[v]);
	}
	for(int i = 1;i <= n;i ++) lis[val[i]] = i;
	for(int i = 1;i <= n;i ++) {
		if(lis[i] < Ans[i]) {
			for(int j = 1;j <= n;j ++) Ans[j] = lis[j];
			break;
		}
		if(lis[i] > Ans[i]) break;
	}
}

inline void solve() {
	Ans[1] = n + 1;
  for(int i = 1;i < n;i ++) pos[i] = i;
	do{
		work();
	}while(next_permutation(pos + 1,pos + n));
	for(int i = 1;i <= n;i ++) printf("%d ", Ans[i]);
	puts("");
}

}

namespace work2{

inline void solve() {
	int S = 0;
	for(int i = 1;i <= n;i ++) if(deg[i] == n - 1) {
		S = i;
		break;
	}
}

}

namespace work3{

int val[maxn], used[maxn], p[maxn], vis[maxn << 1], Mn;

void dfs(int u) {
	if(!used[u]) Mn = min(Mn,u);
	for(int i = h[u];~ i;i = e[i].n) {
		int v = e[i].v;
		if(vis[i]) continue;
		vis[i] = 1;
		dfs(v);
		vis[i] = 0;
	}
}

int lis1[maxn], lis2[maxn << 1], tot, Tmp1[maxn], Tmp2[maxn << 1], lcnt;

inline void calc() {
	for(int i = 1;i <= tot;i ++) lis1[i] = Tmp1[i], lis2[i] = Tmp2[i];
	lcnt = tot;
}

void dfs1(int u) {
	if(!used[u] && Mn == u) {
		calc();
		return;
	}
	for(int i = h[u];~ i;i = e[i].n) {
		int v = e[i].v;
		if(vis[i]) continue;
		tot ++;
		Tmp1[tot] = v;
		Tmp2[tot] = i;
		vis[i] = 1;
		dfs1(v);
		vis[i] = 0;
		tot --;
	}
}

inline void work(int S) {
	if(used[a[S]]) return;
	Mn = n + 1; tot = lcnt = 0;
	dfs(a[S]);
	dfs1(a[S]);
	int r = a[S];
	lis1[0] = a[S]; tot = lcnt;
	for(int i = 1;i < tot;i ++) {
		int u = lis1[i], v = lis1[i + 1];
		p[val[v]] = u;
	}
	p[S] = lis1[tot];
	if(tot) {
		val[r] = val[lis1[1]];
		a[val[r]] = r;
//		val[lis1[tot]] = vv;
//		a[vv] = lis1[tot];
	}
	else used[r] = 1;
	for(int i = 1;i <= tot;i ++) {
		int u = lis1[i];
		used[u] = 1;
		vis[lis2[i]] = vis[lis2[i] ^ 1] = 1;
	}
}

inline void solve() {
	memset(vis,0,sizeof(vis));
	memset(used,0,sizeof(used));
	for(int i = 1;i <= n;i ++) val[a[i]] = i;
	for(int i = 1;i <= n;i ++) {
		work(i);
	}
	for(int i = 1;i <= n;i ++) printf("%d ", p[i]);
	puts("");
}

}

inline void solve() {
	scanf("%d", &n); ecnt = -1;
	for(int i = 1;i <= n;i ++) scanf("%d", &a[i]);
	memset(h,-1,sizeof(h));
	for(int i = 1;i < n;i ++) {
		int u, v;
		scanf("%d%d", &u, &v);
		addedge(u,v);
		addedge(v,u);
		deg[u] ++; deg[v] ++;
	}
	int Mx = 0;
	for(int i = 1;i <= n;i ++) Mx = max(Mx,deg[i]);
	if(n <= 10) work1::solve();
	else work3::solve();
//	if(Mx == n - 1) work2::solve();
//	if(n <= 10) work1::solve();
//	else if(Mx == n - 1) work2::solve();
//	else work3::solve();
}

int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
  int cas; scanf("%d", &cas);
  while(cas --) {
  	solve();
	}
	return 0;
}

