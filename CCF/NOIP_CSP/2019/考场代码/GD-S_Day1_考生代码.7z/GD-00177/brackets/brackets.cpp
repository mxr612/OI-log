#include<algorithm>
#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
typedef long long ll;
const int maxn = 500000 + 10;

int n, pre[maxn], a[maxn];
char s[maxn];

ll f[maxn];
int g[maxn], nxt[maxn];

int main() {
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
  scanf("%d", &n);
  scanf("%s", s + 1);
  for(int i = 1;i <= n;i ++) a[i] = (s[i] == '(') ? (1) : (-1);
  for(int i = 2;i <= n;i ++) scanf("%d", &pre[i]);
  nxt[0] = -1; f[0] = g[0] = 0;
  for(int i = 1;i <= n;i ++) {
  	if(a[i] == 1) {
  		nxt[i] = i;
  		g[i] = 0;
		}
		else {
			int p = nxt[pre[i]];
			g[i] = 0;
			if(~ p) {
				g[i] = g[pre[p]] + 1;
				nxt[i] = nxt[pre[p]];
			}
			else nxt[i] = -1;
		}
  	f[i] = f[pre[i]] + g[i];
	}
	ll Ans = 0;
	for(int i = 1;i <= n;i ++) Ans = Ans ^ (1LL * i * f[i]);
	printf("%lld\n", Ans);
	return 0;
}

