#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;

long long n,k,t;

int c(int now)
{
	long long temp;
	for(int i=1;i<=now;i++)
	{
		temp=temp*2;
	}
	return temp;
}

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d",&n);
	scanf("%lld",&k);	
	t=1;
	if(n==1)
	{
		printf("%d",k);
	}

	else
	{
	    for(int j=1;j<=n-1;j++)
		{
			t=t*2;
		}
		while(n>0)
		{
			
			if(t<k+1)
			{
				printf("1");
				k=t*2-1-k;
			}
			else{
				printf("0");
				
			}
			n--;
			t=t/2;
		}
		
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
