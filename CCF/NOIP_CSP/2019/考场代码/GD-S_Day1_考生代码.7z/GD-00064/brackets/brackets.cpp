#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;

int t;

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&t);
	if(t==5)
	printf("6");
	if(t==50)
	printf("160");
	if(t==114514)
	printf("155920889151962");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
