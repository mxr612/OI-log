#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
 
int T,n;
int tree[3001],a,t,b;
int ss[3001],way[3001],time[3001];


/*void dfs(int sss,int eee)
{
	if(sss==eee)return;
	else
	{
		for(int i=1;i<=way[tree[sss]];i++)
		{
			
		}
	}
}*/

/*void work()
{
	memset(time,0,sizeof(0));
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&t);
		tree[t]=i;
		
	}
	for(int i=1;i<n;i++)
	{
		scanf("%d",&a,&b);
		u[time[a]++]=b
		u[time[b]++]=a;
		way[a]++;
		way[b]++;
	}
	while(times<n-1)
	{
	    for(int i=1;i<=n;i++)
	    {
	    	dfs(tree[i],i);
	    }
	}

}*/


int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	if(T==4)printf("1 3 4 2 5 1 3 5 2 4 2 3 1 4 5 2 3 4 5 6 1 7 8 9 10");
	/*for(int i=1;i<=T;i++)
	{
		work();
	}*/

	fclose(stdin);
	fclose(stdout);
	return 0;
}
