#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define N 999
int n,k;
int ans[N][15];
ll tot;
int l[N],cac;

void qiuzhi(int x){
	while(x != 0){
		if(x % 2 == 0){
			printf("0");
			x = x / 2;
			continue;
		}
		int ans = x % 2;
		x = x / 2;
		l[++cac] = ans;
	}
	for(int i = cac;i > 0;i--)printf("%d",l[i]);
	return ;
}

void work(){
	for(int i = 2;i <= n; i++){
		int mid = 1;
		for(int j = 1;j <= i; j++)mid *= 2;//������� 
		for(int j = 0;j < (mid / 2); j++){
			ans[j][i] = (ans[j][i - 1] << 1);
		}
		for(int j = (mid >> 1);j < mid;j++){
			ans[j][i] = ans[mid - 1 - j][i] + 1;
		}
		if(i == n)tot = mid;
	}
	// ceshi();
		
	qiuzhi(ans[k][n]);
	return;
}

int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin >> n >> k;
	ans[0][1] = 0;
	ans[1][1] = 1;
	if(k == 0){
		for(int i = 1;i <= n; i++)printf("0");
		return 0;
	}
	else if(k == 1){
		for(int i = 1;i < n; i++)printf("0");
		printf("1");
		return 0;
	}
	else if (k == 2){
		for(int i = 1;i <= n - 2; i++)printf("0");
		printf("11");
		return 0;
	}
	
	//else if(k == last){
	//	printf("1");
	//	for(int i = 1;i < n; i++)printf("0");
	//	return 0;
	// }//
	else {
		work();
	//	cout << ans[k][n];
		return 0;
	}
	return 0;
}
