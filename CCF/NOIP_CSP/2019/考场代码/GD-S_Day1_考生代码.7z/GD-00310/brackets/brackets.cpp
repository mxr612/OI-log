#include<bits/stdc++.h>
using namespace std;

char b[6666][6666];
int a[666666];

int main(){
	int n;
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	//for(int i = 1;i <= n; i++)cin >> b[i];
	srand(time(0));
	for(int i = 1;i < n; i++)cin >> a[i];
	int h = rand() % 20 + 1;
	printf("%d",h);
	return 0;
}

