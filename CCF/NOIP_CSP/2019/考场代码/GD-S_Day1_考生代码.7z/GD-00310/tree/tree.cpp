#include<iostream>
#include<bits/stdc++.h>
using namespace std;


int main(){
	srand(time(0));
	int n;
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&n);
	for(int i = 1;i <= 16; i++){
		int a = rand() % 20 + 1;
		printf("%d ",a);
	}
	return 0;
}
