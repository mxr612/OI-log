#include<cstdio>
#include<cstring>
#define  N  2100
#define  NN  4100
using  namespace  std;
int  n;
struct  node
{
	int  y,next;
}tr[NN];int  len,last[N];
inline  void  ins(int  x,int  y){tr[++len].y=y;tr[len].next=last[x];last[x]=len;}
int  a[N],b[N],c[N];
inline  int  mymin(int  x,int  y){return  x<y?x:y;}
inline  void  zwap(int  &x,int  &y){int  z=x;x=y;y=z;}
void  solve1(int  l,int  r) 
{
	if(l==r)return  ;
	int  mmid=999999999,mco=0;
	for(int  i=l;i<=r;i++)
	{
		mmid=mymin(mmid,b[i]);
		if(a[i]<a[mco])mco=i;
	}
	if(mmid==mco)
	{
		int  sco=0;
		for(int  i=l;i<=r;i++)
		{
			if(i!=mmid)
			{
				if(a[i]<a[sco])sco=i;
			}
		}
		mco=sco;
	}
	int  ll=0,rr=0;
	if(mmid>mco)
	{
		ll=mco,rr=mmid;
		for(int  i=mco;i<mmid;i++)zwap(a[i],a[i+1]);
	}
	else
	{
		ll=mmid,rr=mco;
		for(int  i=mco;i>mmid;i--)zwap(a[i],a[i-1]);
	}
	solve1(l,ll);solve1(rr,r);
}
int  size[N],top=0;
void  dfs(int  x,int  fa)
{
	bool  bk=0;
	for(int  k=last[x];k;k=tr[k].next)
	{
		int  y=tr[k].y;
		if(y!=fa)
		{
			dfs(y,x);
			if(!bk)a[++top]=c[x],b[top]=x,bk=1;
		}
	}
	if(bk==0)a[++top]=c[x],b[top]=x;
}
int  main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	a[0]=999999999;
	int  T;scanf("%d",&T);
	while(T--)
	{
		len=0;memset(last,0,sizeof(last));
		int  n;scanf("%d",&n);
		for(int  i=1;i<=n;i++)scanf("%d",&c[i]);
		for(int  i=2;i<=n;i++)
		{
			int  x,y;scanf("%d%d",&x,&y);
			ins(x,y);ins(y,x);
		}
		dfs(1,0);
		solve1(1,n);
		for(int  i=1;i<n;i++)printf("%d ",a[i]);
		printf("%d\n",a[n]);
	}
	return  0;
}
