#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cmath>
using  namespace  std;
unsigned  long  long  n,m,limit;
void  prin(unsigned  long  long  x)
{
	unsigned  long  long  y=1;for(int  i=1;i<n;i++)y<<=1;
	while(y)
	{
		printf("%d",(y&x)>0);
		y>>=1;
	}
	printf("\n");
}
inline  void  getz(unsigned  long  long  &x)
{
	char  c=getchar();
	while(c<'0'  ||  c>'9')c=getchar();
	while(c>='0'  &&  c<='9')x=(x<<3)+(x<<1)+(c^48),c=getchar();
}
int  main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	getz(n);getz(m);
	for(int  i=0;i<n;i++)limit=limit*2+1;
	unsigned  long  long  x=0,now=n-1,ans=0,l=0,r=limit;
	while(now<=64)
	{
		unsigned  long  long  mid=((r-l)>>1)+l;
		if(m<=mid)ans+=(0^x)<<now,x=0,r=mid-1;
		else  ans+=(1^x)<<now,x=1,l=mid+1;
		now--;
	}
	prin(ans);
	return  0;
}
