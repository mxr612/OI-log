#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#include<cstdlib>
#define fo(i,x,y) for(i=x;i<=y;i++)
#define dw(i,x,y) for(i=x;i>=y;i--)
#define ll long long
#define N 500055
using namespace std;
int n,m,i,j,k,tot,pos;
int a[N],f[N],b[N],nxt[N],lst[N];
ll x,y,sum,ans[N],g[N*2];
char ch;
int read()
{
	int x=0,f=1;
	char ch=getchar();
	while (ch<'0' || ch>'9'){if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0' && ch<='9') x=x*10+ch-'0',ch=getchar();
	return f*x;
}
void link(int x,int y)
{
	b[++tot]=y;
	nxt[tot]=lst[x];
	lst[x]=tot;
}
void dfs(int x)
{
	ll te=0;
	pos-=a[x];
	g[a[x]+pos]++;
	if (g[pos-1]) te=g[pos-1],g[pos-1]=0;
	ans[x]=ans[f[x]]+g[pos];
	
	int l=lst[x];
	while (l)
	{
		int to=b[l];
		dfs(to);
		l=nxt[l];
	}
	
	g[a[x]+pos]--;
	g[pos-1]+=te;
	pos+=a[x];
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	n=read();
	ch=getchar();
	while (ch!='(' && ch!=')') ch=getchar();
	while (ch=='(' || ch==')')
	{
		if (ch=='(') a[++i]=1;else a[++i]=-1;
		ch=getchar();
	}
	fo(i,2,n)
	{
		f[i]=read();
		link(f[i],i);
	}
	pos=500000;
	dfs(1);
	fo(i,1,n)
	{
		x=(ll)i*ans[i];
		sum^=x;
	}
	printf("%lld",sum);
	return 0;
}
