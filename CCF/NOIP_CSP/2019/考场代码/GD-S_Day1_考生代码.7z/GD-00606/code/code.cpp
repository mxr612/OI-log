#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#include<cstdlib>
#define fo(i,x,y) for(i=x;i<=y;i++)
#define dw(i,x,y) for(i=x;i>=y;i--)
#define ull unsigned long long
#define N 105
using namespace std;
ull n,i,k,x;
int a[N];
ull read()
{
	ull x=0,f=1;
	char ch=getchar();
	while (ch<'0' || ch>'9'){if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0' && ch<='9') x=x*10+ch-'0',ch=getchar();
	return f*x;
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	n=read();k=read();
	x=0;
	while (k)
	{
		a[++x]=k%2;
		k/=2;
	}
	while (x<n) a[++x]=0; 
	dw(i,x,1)
		if (a[i+1]==1) printf("%d",1-a[i]);else printf("%d",a[i]);
	return 0;
}
