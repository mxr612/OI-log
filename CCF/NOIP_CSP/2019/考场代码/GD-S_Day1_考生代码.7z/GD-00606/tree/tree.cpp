#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#include<cstdlib>
#define fo(i,x,y) for(i=x;i<=y;i++)
#define dw(i,x,y) for(i=x;i>=y;i--)
#define ll long long
#define N 2055
#define M 5055
using namespace std;
int n,m,i,j,k,x,y,t,T,ii,tot;
int a[N],pos[N],ans[N];
int in[N],lst[N],b[M],nxt[M];
bool bz[N];
struct edge
{
	int x,y;
}c[N];
int read()
{
	int x=0,f=1;
	char ch=getchar();
	while (ch<'0' || ch>'9'){if (ch=='-') f=-1;ch=getchar();}
	while (ch>='0' && ch<='9') x=x*10+ch-'0',ch=getchar();
	return f*x;
}
void link(int x,int y)
{
	b[++tot]=y;
	nxt[tot]=lst[x];
	lst[x]=tot;
	in[y]++;
}
bool cmp()
{
	int i;
	fo(i,1,n)
	{
		if (ans[i]>pos[i]) return true;
		if (ans[i]<pos[i]) return false;
	}
	return false;
}
void dfs(int x)
{
	if (x>n-1)
	{
		if (cmp()) memcpy(ans,pos,sizeof(ans));
	}else
	{
		int i;
		fo(i,1,n-1)
		{
			if (!bz[i])
			{
				bz[i]=1;
				swap(pos[a[c[i].x]],pos[a[c[i].y]]);
				swap(a[c[i].x],a[c[i].y]);
				dfs(x+1);
				swap(a[c[i].x],a[c[i].y]);
				swap(pos[a[c[i].x]],pos[a[c[i].y]]);
				bz[i]=0;
			}
		}
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	T=read();
	fo(ii,1,T)
	{
		n=read();
		fo(i,1,n)
		{
			x=read();
			a[x]=i;
			pos[i]=x;
		}
		tot=0;
		memset(nxt,0,sizeof(nxt));
		memset(in,0,sizeof(in));
		fo(i,1,n-1)
		{
			x=read();y=read();
			link(x,y);link(y,x);
			c[i].x=x;c[i].y=y;
		}
		memset(ans,0x3f,sizeof(ans));
		memset(bz,0,sizeof(bz));
		dfs(1);
		fo(i,1,n) printf("%d ",ans[i]);
		printf("\n");
	}
	return 0;
}
