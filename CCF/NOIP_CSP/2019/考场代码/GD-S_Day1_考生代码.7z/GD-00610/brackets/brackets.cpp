#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,data[500001],z,s[500001],a[500001],l,r,maxx=-1;
long long ans=0;
char c;
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		cin>>c;
		if(c=='(') data[i]=1;
		else data[i]=-1;
	}
	for(int i=2;i<=n;i++) scanf("%d",&l);
	for(int i=1;i<=n;i++) a[i]=a[i-1]+data[i],maxx=max(maxx,a[i]);
	
	for(int i=1;i<=n;i++)
	 for(int j=1;j<=i;j++)
	  for(int k=j;k<=i;k++)
		if(a[k]-a[j-1]==0&&data[k]==-1&&data[j]==1) s[i]++;
	ans=s[1];
	for(int i=1;i<=n;i++) 
	{
		ans^=(i*s[i]);
	}
	printf("%lld",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
