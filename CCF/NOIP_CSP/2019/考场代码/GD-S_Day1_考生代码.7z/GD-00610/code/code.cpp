#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;
long long n,k,z=1,mid;
bool b[65];
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	for(long long i=1;i<n;i++) z*=2;
	for(long long i=1;i<=n;i++)
	{
		if(!b[i-1])
		{
			if(k<z+mid) printf("0");
		    else printf("1"),b[i]=1,mid+=z;
		}
		else 
		{
			if(k<z+mid) printf("1");
		    else printf("0"),b[i]=1,mid+=z;
		}
		z/=2;
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
