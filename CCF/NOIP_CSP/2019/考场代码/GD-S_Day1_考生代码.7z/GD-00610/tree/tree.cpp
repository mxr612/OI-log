#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
int n,t,st[2001],h[2001],u,v,w[2001];
bool f[2001][2001];
long long ans=0;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		memset(f,0,sizeof(f));
		scanf("%d",&n);
		for(int i=1;i<=n;i++) scanf("%d",&st[i]),w[st[i]]=i;
		for(int i=1;i<n;i++)
		{
			scanf("%d%d",&u,&v);
			f[u][v]=f[v][u]=1;
			h[u]++;h[v]++;
		}
		for(int i=1;i<=n;i++) if(h[i]==n-1) u=i,v=w[i];
		for(int i=1;i<=n;i++)
		{
			if(st[i]==i)continue;
			if(f[u][w[i]]&&f[i][u]) swap(st[v],i),swap(u,w[i]),f[u][w[i]]=f[u][i]=0;
		}
		
		for(int i=1;i<=n;i++) printf("%d ",i);
		printf("\n");
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
