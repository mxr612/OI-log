#include<cstdio>
#include<cstring>
using namespace std;
unsigned long long K;
int A[70],N;
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%llu",&N,&K);
	for(int i=0;i<N;i++){
		if(K & 1)	A[i]=1;
		K >>= 1;
	}
	for(int i=N-1;i+1;i--)
		if(A[i])
			for(int j=i-1;j+1;j--)	A[j]=1-A[j];
	for(int i=N-1;i+1;i--)	printf("%d",A[i]);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
