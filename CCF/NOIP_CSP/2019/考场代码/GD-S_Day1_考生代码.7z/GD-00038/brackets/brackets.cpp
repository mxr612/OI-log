#include<cstdio>
#include<cstring>
#include<vector>
using namespace std;
int fa[500010];
char brk[500010];
int N;
int qxx[500010][2],tt[500010],nn;
void ad(int u,int v){
	qxx[++nn][0]=v;
	qxx[nn][1]=tt[u];
	tt[u]=nn;
}
int qzh[500010],ln;
int cnt[1000010];
long long ans,cal;
int pus(int u){
	int ret=0;
	++ln;qzh[ln]=qzh[ln-1];
	if(brk[u]=='(')	++qzh[ln];
	else{
		--qzh[ln];
		ret=cnt[qzh[ln-1]];
		cnt[qzh[ln-1]]=0;
	}
	cal+=cnt[qzh[ln]];++cnt[qzh[ln]];
	return ret;
}
void del(int u,int ret){
	--cnt[qzh[ln]];
	cal-=cnt[qzh[ln]];
	if(brk[u]==')')	cnt[qzh[ln-1]]=ret;
	--ln;
}
void dfs(int u){
	int p = pus(u);
	ans ^= (1ll * (u+1) * cal);
	for(int i=tt[u],v;i;i=qxx[i][1]){
		v = qxx[i][0];
		if(v==fa[u])	continue;
		dfs(v);
	}
	del(u,p);
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&N);
	for(int i=0;i<N;i++)	scanf(" %c",&brk[i]);
	for(int i=1;i<N;i++)	scanf(" %d",&fa[i]);
	for(int i=1;i<N;i++)	--fa[i];
	for(int i=1;i<N;i++)	ad(fa[i],i);
	cnt[500000]=1;qzh[0]=500000;dfs(0);
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
