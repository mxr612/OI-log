#include<cstdio>
#include<cstring>
#include<vector>
using namespace std;
int qxx[4010][4],tt[2010],nn;
int N,loc[2010],T;
int num[2010];
vector<int> hh[2010];
bool hav[2010][2010];
int qq[2010][2010];
int fa[2010];
bool used[2010];
void ad(int u,int v){
	qxx[++nn][0]=v;
	qxx[nn][1]=tt[u];
	qxx[tt[u]][2]=nn;
	qxx[nn][3]=u;
	tt[u]=nn;
	qq[u][v]=qq[v][u]=nn;
}
void cle(){
	for(int i=1;i<=N;i++)	tt[i]=0;
	nn=0;for(int i=1;i<=N;i++)	hh[i].clear();
	for(int i=1;i<=N;i++)
		for(int j=1;j<=N;j++)
			hav[i][j]=0;
	for(int i=1;i<=N;i++)	used[i]=false;
}
void del(int o){
	qxx[qxx[o][1]][2]=qxx[o][2];
	qxx[qxx[o][2]][1]=qxx[o][1];
	if(o==tt[qxx[o][3]])
		tt[qxx[o][3]]=qxx[o][1];
}
int mx1,mx2;
void dfs(int u,int f){
	if(used[u])	return;
	if(u < mx1)	mx1=u;
	else if(u < mx2)	mx2=u;
	for(int i=tt[u],v;i;i=qxx[i][1]){
		v=qxx[i][0];
		if(v==f)	continue;
		dfs(v,u);
	}
}
void dfs2(int u,int f){
	hh[u].push_back(u);
	fa[u]=f;
	int t;
	for(int i=tt[u],v;i;i=qxx[i][1]){
		v=qxx[i][0];
		if(v==f)	continue;
		dfs2(v,u);
		t = hh[v].size();
		for(int j=0;j<t;j++)	hh[u].push_back(hh[v][j]);
	}
	t = hh[u].size();
	for(int i=0;i<t;i++)	hav[u][hh[u][i]]=true;
}
void cut(int o){
	int u = qxx[o][0],v = qxx[o][3];
	del(o);if(o & 1)	return;
	loc[num[u]]=v;
	loc[num[v]]=u;
	swap(num[u],num[v]);
}
inline int dy(int u){return (u % 2 == 1 ? (u + 1) : (u - 1));}
int mmiinn(int u,int q,bool can){
	int ret=u;
	for(int i=tt[u];i;i=qxx[i][1]){
		int v = qxx[i][0];
		if(v==q)	continue;
		if(!can && v==fa[u])	continue;
		if(num[ret]>num[v])	ret=v;
	}
	return ret;
}
int mmaaxx(int u,int q,bool can){
	int ret=u;
	for(int i=tt[u];i;i=qxx[i][1]){
		int v = qxx[i][0];
		if(v==q)	continue;
		if(!can && v==fa[u])	continue;
		if(num[ret]<num[v])	ret=v;
	}
	return ret;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&N);
		for(int i=1;i<=N;i++)	scanf("%d",&loc[i]);
		for(int i=1;i<=N;i++)	num[loc[i]]=i;
		for(int i=1,a,b;i<N;i++){
			scanf("%d%d",&a,&b);
			ad(a,b);ad(b,a);
		}
		dfs2(1,-1);
		for(int i=1;i<N;i++){
			mx1=mx2=N+1;
			dfs(loc[i],-1);
			int tar=mx1;
			if(mx1 == loc[i])	tar=mx2;
			if(tar == N+1)	tar=loc[i];
			if(tar==loc[i])	continue;
			for(int j=tt[tar],v;j;j=qxx[j][1]){
				v = qxx[j][0];
				if(!hav[v][loc[i]]){cut(j);cut(dy(j));}
			}
			int u = loc[i];
			while(!hav[u][tar]){
				int l;
				if(fa[u]>u)	l = mmiinn(fa[u],u,false);
				else	l = mmaaxx(fa[u],u,false);
				if(l != fa[u]){
					cut(qq[l][fa[u]]);
					cut(dy(qq[l][fa[u]]));
				}
				cut(qq[u][fa[u]]);
				cut(dy(qq[u][fa[u]]));
				u = fa[u];
			}
			while(u != tar){
				bool havv=false;
				for(int j=tt[u],v;j;j=qxx[j][1]){
					v=qxx[j][0];
					if(hav[v][tar] && v!=fa[u]){
						int l;
						if(v>u)	l = mmiinn(v,u,false);
						else	l = mmaaxx(v,u,false);
						if(l != v){
							cut(qq[l][v]);
							cut(dy(qq[l][v]));
						}
						cut(j),cut(dy(j));
						u = v;havv=true;break;
					}
				}
				if(!havv)	break;
			}
			used[tar]=true;
		}
		for(int i=1;i<N;i++)
			printf("%d ",loc[i]);
		printf("%d\n",loc[N]);
		cle();
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
