#include<cstdio>
#include<cstring>
#include<iostream>
using namespace std;

const int maxn=2010;
int n,T,val[maxn],p[maxn],mp[maxn],a[maxn];
struct node
{
	int a,b;
}e[maxn];
bool vis[maxn];

int read()
{
	int x=0;
	char c=getchar();
	while (c<48||c>57)
		c=getchar();
	while (c>=48&&c<=57)
		x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x;
}

bool cmp()
{
	int i;
	if (mp[1]==0)
		return 1;
	for (i=1;i<=n;i++)
	{
		if (p[i]<mp[i])
			return 1;
		if (p[i]>mp[i])
			return 0;
	}
	return 0;
}

void dfs(int x)
{
	int i;
	if (x==n)
	{
		for (i=1;i<=n;i++)
			p[val[i]]=i;
		if (cmp())
		{
			for (i=1;i<=n;i++)
				mp[i]=p[i];
		}
		return;
	}
	for (i=1;i<=n-1;i++)
		if (!vis[i])
		{
			a[x]=i;
			vis[i]=1;
			swap(val[e[i].a],val[e[i].b]);
			dfs(x+1);
			vis[i]=0;
			swap(val[e[i].a],val[e[i].b]);
		}
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int i;
	T=read();
	while (T--)
	{
		n=read();
		for (i=1;i<=n;i++)
			val[read()]=i;
		for (i=1;i<=n-1;i++)
			e[i].a=read(),e[i].b=read();
		memset(vis,0,sizeof(vis));
		memset(mp,0,sizeof(mp));
		memset(p,0,sizeof(p));
		dfs(1);
		for (i=1;i<=n;i++)
			printf("%d ",mp[i]);
		puts("");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
