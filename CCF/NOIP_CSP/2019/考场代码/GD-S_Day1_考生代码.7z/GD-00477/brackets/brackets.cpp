#include<cstdio>
using namespace std;

const int maxn=500010;
typedef long long ll;
int n,m,head[maxn],tot,cnt[maxn],fa[maxn],b[maxn],dep[maxn],st;
ll f[maxn],ans;
char ch[maxn];
struct node
{
	int nxt,to;
}edge[maxn];

void add(int u,int v)
{
	edge[++tot]=(node){head[u],v};
	head[u]=tot;
}

int read()
{
	int x=0;
	char c=getchar();
	while (c<48||c>57)
		c=getchar();
	while (c>=48&&c<=57)
		x=(x<<1)+(x<<3)+(c^48),c=getchar();
	return x;
}

void dfs(int u)
{
	int i,v;
	st+=b[u];
	if (st<0)
	{
		st-=b[u];
		return;
	}
	if (st==0)
		f[u]++;
	for (i=head[u];i;i=edge[i].nxt)
	{
		v=edge[i].to;
		dfs(v);
	}
	st-=b[u];
}

void dfs2(int u)
{
	int i,v;
	for (i=head[u];i;i=edge[i].nxt)
	{
		v=edge[i].to;
		f[v]+=f[u];
		dfs2(v);
	}
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int i;
	scanf("%d%s",&n,ch+1);
	for (i=1;i<=n;i++)
	{
		if (ch[i]=='(')
			b[i]=1;
		else
			b[i]=-1;
	}
	for (i=2;i<=n;i++)
	{
		fa[i]=read();
		add(fa[i],i);
	}
	for (i=1;i<=n;i++)
		st=0,dfs(i);
	dfs2(1);
	for (i=1;i<=n;i++)
		ans^=(1ll*i*f[i]);
//		printf("%lld\n",f[i]);
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
