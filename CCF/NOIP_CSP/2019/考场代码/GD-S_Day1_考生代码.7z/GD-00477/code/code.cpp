#include<cstdio>
#include<cstring>
using namespace std;

const int maxn=110;
typedef unsigned long long ull;
int n,a[maxn];
ull k;

void fnd(int x)
{
	if (x==0)
		return;
	int i;
	if (a[x])
	{
		printf("1");
		for (i=x-1;i>=1;i--)
			a[i]^=1;
	}
	else
		printf("0");
	fnd(x-1);
}

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	int i;
	scanf("%d%llu",&n,&k);
	for (i=1;i<=n;i++)
	{
		a[i]=(k&1);
		k>>=1;
	}
	fnd(n);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
