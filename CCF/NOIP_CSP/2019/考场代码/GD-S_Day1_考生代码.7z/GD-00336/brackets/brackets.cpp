#include<iostream>
#include<cstdio>
#define maxn 500005
using namespace std;
int n,fa[maxn],d[maxn],w[maxn],ans;
struct data{
	int cnt,max,last;
};
data f[maxn];
int check(int l,int r,int k){
	return (w[k]==w[l]&&(d[k]&1)==(d[l]&1))||(w[k]==w[r]&&(d[k]&1)==(d[r]&1));
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	char a;
	for(int i=1;i<=n;++i){
		cin>>a;
		if(a=='(')
			w[i]=0;
		else
			w[i]=1;	
	}
	fa[1]=0;
	d[1]=1;
	if(!w[1])
		f[1].last=1;
	for(int i=2;i<=n;++i){
		cin>>fa[i];
		d[i]=d[fa[i]]+1;
		f[i]=f[fa[i]];
		if(!w[i])//'('
			f[i].last=i;
		else{//')'
			for(int j=f[fa[i]].last;j;j=f[fa[j]].last){
				if((d[i]-d[j])&1){
					int judge=1,last=i;
					for(int k=fa[i];k!=j;k=fa[k]){
						if(check(j,i,k)&&!check(j,i,fa[k])&&!check(j,i,last)){
							judge=0;
							break;
						}
						last=k;
					}
					
					if(judge)
						if(d[i]-d[j]+1>f[i].max){
							f[i].max=d[i]-d[j]+1;
							f[i].cnt++;
						}
				}
				else{
					int judge=1,last=i;
					for(int k=fa[i];k!=j;k=fa[k]){
					
						if(!check(j,i,k)&&check(j,i,fa[k])&&check(j,i,last)){
							judge=0;
							break;
						}
						last=k;
					}
					if(judge)
						if(d[i]-d[j]+1>f[i].max){
							f[i].max=d[i]-d[j]+1;
							f[i].cnt++;
						}
				}
			}
		}
		ans=(ans)xor(i*f[i].cnt);
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
