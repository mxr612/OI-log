#include<iostream>
#include<cstdio>
using namespace std;
long long k,g[65];
int n;
void f(int a,long long b,int judge){
	if(!a)
		return;
	int side;
	if(b<g[a-1])
		side=0;
	else{
		side=1;
		b-=g[a-1];
	}
	if(side==judge)
		cout<<0;
	else
		cout<<1;
	f(a-1,b,side);
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	g[0]=1;
	for(int i=1;i<=n;++i)
		g[i]=g[i-1]*2;
	f(n,k,0);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
