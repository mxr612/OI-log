#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;

const int maxn=2000+10;

int n,tot;
long long Ans;
char dat[maxn];

int sum[maxn];

int num[maxn];

int f[maxn];

int las[maxn],tov[maxn*2],nex[maxn*2];

int x[maxn],y[maxn];
int p[maxn];

bool bz[maxn];


bool pd(){
	for (int i=1;i<=n;++i){
		if(sum[i]==p[i]) continue;
		return sum[i]>p[i];
	}
}	

void dfs(int t){
	if(t==n){
		if(pd()){
			memcpy(sum,p,sizeof(sum));
		}
		return;
	}
	
	for (int i=1;i<n;++i){
		if(!bz[i]){
			bz[i]=1;
			swap(p[x[i]],p[y[i]]);
			dfs(t+1);
			swap(p[x[i]],p[y[i]]);
			bz[i]=0;
		}
	}
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T;
	scanf("%d",&T);
	
	while(T--){
		scanf("%d",&n);
		int i,j;
		
		for (i=1;i<=n;++i) scanf("%d",&p[i]);
		
		for (i=1;i<n;++i) scanf("%d%d",&x[i],&y[i]);
		
		sum[1]=1e9;
		dfs(1);
		
		for (i=1;i<=n;++i) printf("%d ",sum[i]);
		printf("\n");
	}
}
