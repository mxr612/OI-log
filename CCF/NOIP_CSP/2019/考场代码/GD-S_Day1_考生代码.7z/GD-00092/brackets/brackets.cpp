#include<cstdio>
#include<iostream>
#include<algorithm>
using namespace std;

const int maxn=2e3+10;

int n,tot;
long long Ans;
char dat[maxn];

long long ans[maxn],S[maxn][maxn];

bool bz[maxn][maxn];

long long sum[maxn][maxn];
int num[maxn];

int f[maxn];

int las[maxn],tov[maxn*2],nex[maxn*2];


struct Moon{
	int x,id;	
}a[maxn];

void ins(int x,int y){
	tov[++tot]=y,nex[tot]=las[x],las[x]=tot;
}

bool pd(int p,int x,int y){
	int a=0,b=0;
	for (int i=x;i<=y;++i){
		if(sum[p][i]==1) a++;
		else b++;
		if(a<b) return false; 
	}
	if(a!=b) return false;
	return true;
}

void dfs(int x,int fa){
	memcpy(sum[x],sum[fa],sizeof(sum[x]));
	memcpy(S[x],S[fa],sizeof(S[fa]));
	
	num[x]=num[fa];
	
	sum[x][++num[x]]=(dat[x]=='('?1:-1);
	ans[x]=ans[fa];
	S[x][0]++;

	if(dat[x]==')')
		for (int i=1;i<num[x];++i)
			if(sum[x][i]==1&&(bz[fa][i+1]||i==num[x]-1)) ans[x]+=S[x][i-1]+1,S[x][S[x][0]]++,bz[x][i]=1;
	
	for (int i=las[x];i;i=nex[i]){
		int y=tov[i];
		dfs(y,x);
	}
}

bool cmp(Moon x,Moon y){
	return x.x<y.x;
}

int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	
	scanf("%d",&n);
	int i,j;
	
	scanf("%s",dat+1);
	
	for (i=2;i<=n;++i) scanf("%d",&f[i]),ins(f[i],i);
	
	dfs(1,0);
	
	for (i=1;i<=n;++i) 
		Ans^=(i*ans[i]);
	
	printf("%lld\n",Ans);
}
