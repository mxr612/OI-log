#include<cstdio>
#include<iostream>
#include<cstring>
using namespace std;

const int maxn=64+10;

int n;
long long l,r,mid;
char k[maxn];
char R[maxn][maxn],Mid[maxn][maxn],K[maxn];
int a[maxn],b[maxn],c[maxn];

void dec(char *p,char *x,char *y){
	int lenx=strlen(x+1);
	int leny=strlen(y+1);
	memset(a,0,sizeof(a));
	memset(b,0,sizeof(b));
	for (int i=1;i<=lenx;++i) a[lenx-i+1]=x[i]-'0';
	for (int i=1;i<=leny;++i) b[leny-i+1]=y[i]-'0';
	
	int len=max(lenx,leny);
	for (int i=1;i<=len;++i){
		if(a[i]<b[i]) a[i]+=10,a[i+1]--;
		c[i]=a[i]-b[i];
	}
	while(len>1&&!c[len]) p[len--]='\000';
	for (int i=1;i<=len;++i) p[i]=c[len-i+1]+'0';
}

void add1(char *x){
	int len=strlen(x+1);
	memset(a,0,sizeof(a));
	for (int i=1;i<=len;++i) a[len-i+1]=x[i]-'0';
	a[1]++;
	for (int i=1;i<=len;++i){
		a[i+1]+=a[i]/10;
		a[i]%=10;
	}
	while(a[len+1]) ++len;
	for (int i=1;i<=len;++i) x[i]=a[len-i+1]+'0';
}

void time2(char *x,char *y){
	int len=strlen(y+1);
	memset(a,0,sizeof(a));
	memset(c,0,sizeof(c));
	for (int i=1;i<=len;++i) a[len-i+1]=y[i]-'0';
	for (int i=1;i<=len;++i){
		c[i+1]=(a[i]*2+c[i])/10;
		c[i]=(a[i]*2+c[i])%10;
	}
	while(c[len+1]) ++len;
	for (int i=1;i<=len;++i) x[i]=c[len-i+1]+'0';
}

void div2(char *x,char *y){
	int len=strlen(y+1);
	memset(a,0,sizeof(a));
	memset(c,0,sizeof(c));
	for (int i=1;i<=len;++i) a[i]=y[i]-'0';
	int X=0;c[0]=0;
	for (int i=1;i<=len;++i){
		X=X*10+a[i];
		if(X>=2) c[i]=X/2,X=X%2;
	}
	int l=1;
	while(!c[l]) ++l;
	for (int i=l;i<=len;++i) x[i-l+1]=c[i]+'0';
}

bool Bigger(char *x,char *y){
	int lenx=strlen(x+1);
	int leny=strlen(y+1);
	if(lenx!=leny) return lenx>leny;
	for (int i=1;i<=lenx;++i){
		if(x[i]==y[i]) continue;
		return x[i]>y[i];
	}
	return false;
}

int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	
	scanf("%d%s",&n,K+1);
	int i,j;add1(K);
	
	R[0][1]='1';
	for (i=1;i<=n;++i){
		time2(R[i],R[i-1]);
		div2(Mid[i],R[i]);
	}
	
	for (;n;n--){
		if(Bigger(K,Mid[n])){
			printf("1");
			dec(K,K,Mid[n]);
			dec(K,R[n-1],K);
			add1(K);
		}else printf("0");
	}
}
