#include<cstdio>
#include<iostream>
using namespace std;
int n,k;
int shuzi[70];
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%d",&n,&k);
	int zhong=1;
	for (int i=1;i<n;i++) zhong=zhong*2;
	zhong=zhong-1;
	
	if (k>zhong){
		printf("1");
		k=zhong-(k-1-zhong);
	}
	else printf("0");//
	int x0=0,y0=0,y1=0,x1=0,z0=0,z1=0;
	for (int i=1;i<=k;i++)
	{
		shuzi[1]++;
		for (int j=1;j<n;j++)
		{
			if(shuzi[j]>1){
				shuzi[j]=shuzi[j]-2;
				shuzi[j+1]++;
			}
		}
		if (i==k-1){
			for (int q=1;q<n;q++)
			{
				if (shuzi[q]==0) x0++;
				if (shuzi[q]==1) x1++;
			}
		}
		if (i==k-2){
			for (int q=1;q<n;q++)
			{
				if (shuzi[q]==0) y0++;
				if (shuzi[q]==1) y1++;
			}
		}
		if (i==k){
			for (int q=1;q<n;q++)
			{
				if (shuzi[q]==0) z0++;
				if (shuzi[q]==1) z1++;
			}
		}
	}
	if (k!=0 && k!=1){
		if (x0==y0 && x1==y1){
		shuzi[1]--;
		int i=1;
		while(shuzi[i]<0){
			shuzi[i]=shuzi[i]+2;
			shuzi[i+1]--;
			i++;
		    }
	    }
	    if (x0==z0 && x1==z1){
	    shuzi[1]++;
	    for (int j=1;j<n;j++)
	    if (shuzi[j]>1){
	    	shuzi[j]=shuzi[j]-2;
	    	shuzi[j+1]++;
	    }
	    }
	}
	for (int i=n-1;i>=1;i--) printf("%d",shuzi[i]);
	return 0;
}
