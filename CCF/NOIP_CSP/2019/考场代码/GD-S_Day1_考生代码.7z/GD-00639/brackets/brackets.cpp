#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;
int f[100005];
char tf[100005];
char f2[2000][2000];
int t1[100005];
int t2[2000][2000];
int ans[100005];
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n;
	char c;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf(" %c",&tf[i]);
	}
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&f[i]);
	}
	ans[1]=0;
	int temp;
	int cnt;
	for(int i=2;i<=n;i++)
	{
		temp=i;
		cnt=1;
		while(1)
		{
			f2[i][cnt]=tf[temp];
			if(temp==1) break;
			temp=f[temp];
			cnt++;
		}
		for(int j=cnt;j>=1;j--)
		{
			temp=0;
			for(int k=j;k>=1;k--)
			{
				if(f2[i][k]=='(') temp++;
				if(f2[i][k]==')') temp--;
				if(temp<0) break;
				if(temp==0) ans[i]++;
			}
		}
	}
	for(int i=1;i<=n;i++)
	{
		ans[i]*=i;
	}
	int sum=ans[1];
	for(int i=2;i<=n;i++)
	{
		sum=sum xor ans[i];
	}
	printf("%d",sum);
}
