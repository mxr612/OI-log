#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
using namespace std;
char sq2[70][22];
int n;
char temp[22];
char k[22];
void mi(int x)
{
	for(int i=20;i>=0;i--)
	{
		k[i]-=sq2[x][i];
		if(k[i]<0)
		{
			k[i]+=10;
			k[i-1]--;
		}
	}
}
bool bj(int x)
{
	for(int i=0;i<=20;i++)
	{
		if(k[i]>sq2[x][i]) return 1;
		if(k[i]<sq2[x][i]) return 0;
	}
	return 0;
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	for(int i=0;i<=20;i++)
	{
		temp[i]=k[i]=0;
	}
	for(int i=0;i<=68;i++)
	{
		for(int j=0;j<=20;j++)
		{
			sq2[i][j]=0;
		}
	}
	sq2[0][20]=1;
	scanf("%d",&n);
	scanf("%s",temp);
	int len=-1,t1=20;
	for(int i=21;i>=0;i--)
	{
		if(temp[i]==0) continue;
		if(len==-1) len=i+1;
		k[t1]=temp[i]-'0';
		t1--;
	}
	k[20]++;
	for(int i=20;i>=0;i--)
	{
		if(k[i]>=10)
		{
			k[i]-=10;
			k[i-1]++;
		}
	}
	for(int i=0;i<=n+1;i++)
	{
		for(int j=20;j>=0;j--)
		{
			sq2[i+1][j]+=(sq2[i][j]*2);
			sq2[i+1][j-1]+=sq2[i+1][j]/10;
			sq2[i+1][j]%=10;
		}
	}
	bool tf,t2=1;
	for(int i=n-1;i>=0;i--)
	{
		tf=bj(i);
		if(tf)
		{
			mi(i);
		}
		if(t2&&tf)
		{
			t2=0;
			printf("1");
			continue;
		}
		if(t2&&tf==false)
		{
			printf("0");
			continue;
		}
		if(!t2&&tf)
		{
			printf("0");
			continue;
		}
		if(!tf&&tf==false)
		{
			t2=1;
			printf("1");
			continue;
		}
	}
	return 0;
}
