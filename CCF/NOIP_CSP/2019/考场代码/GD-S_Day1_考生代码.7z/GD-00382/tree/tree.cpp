#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int maxn=2010;
struct Edge{
	int next,to;
	bool flag;
}g[maxn<<1];
int T,tot=-1,n;
int num[maxn],tree[maxn],head[maxn];
bool vis[maxn];
void clear()
{
	tot=-1;
	memset(vis,0,sizeof(vis));
	memset(num,0,sizeof(num));
	memset(tree,0,sizeof(tree));
	memset(head,-1,sizeof(head));
	return;
}
void add(int from,int to)
{
	g[++tot].to=to;
	g[tot].flag=1;
	g[tot].next=head[from];
	head[from]=tot;
	return;
}
int dfs(int u,int pre)
{
	int tmp=tree[u];
	for (int i=head[u];i!=-1;i=g[i].next)
	{
		int j=g[i].to;
		if (j==pre||!g[i].flag||vis[j]) continue;
		tmp=min(tmp,dfs(j,u));
	}
	return tmp;
}
bool DFS(int u,int v,int pre)
{
	if (u==v) return 1;
	for (int i=head[u];i!=-1;i=g[i].next)
	{
		int j=g[i].to;
		if (j==pre||!g[i].flag||vis[j]) continue;
		if (DFS(j,v,u))
		{
			g[i].flag=g[i^1].flag=0;
			swap(tree[u],tree[j]);
			num[tree[u]]=u;
			num[tree[j]]=j;
			return 1;
		}
	}
	return 0;
}
int main()
{
	int x,y;
	//freopen("in.txt","r",stdin);
    freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while (T--)
	{
		clear();
		scanf("%d",&n);
		for (int i=1;i<=n;++i)
		{
			scanf("%d",&num[i]);
			tree[num[i]]=i;
		}
		for (int i=1;i<n;++i) 
		{
			scanf("%d%d",&x,&y);
			add(num[x],num[y]); add(num[y],num[x]);
		}
		for (int i=1;i<=n;++i)
		{
			int tmp=dfs(i,0);
			DFS(i,num[tmp],0);
			vis[i]=1;
		}
		for (int i=1;i<=n;++i) printf("%d ",tree[i]);
		printf("\n");
	}
	return 0;
}
