#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#define ull unsigned long long
using namespace std;
const int maxn=70;
int n;
int ans[maxn];
ull pre[maxn];
ull k;
void getpre()
{
	pre[0]=1;
	for (int i=1;i<=63;++i) pre[i]=pre[i-1]*2;
	return;
}
void dfs(int dep,ull pos)
{
	if (dep==0) return;
	ull mid=pre[dep-1]-1;
	if (pos>mid)
	{
		ans[dep]=1;
		dfs(dep-1,mid-(pos-mid)+1);
	} 
	else
	{
		ans[dep]=0;
		dfs(dep-1,pos);
	}
	return;
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	getpre();
	dfs(n,k);
	for (int i=n;i>=1;--i) printf("%d",ans[i]);
	return 0;
}
