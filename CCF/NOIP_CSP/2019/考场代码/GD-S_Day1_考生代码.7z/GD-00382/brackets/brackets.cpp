#include<iostream>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<stack>
#include<vector>
#define ll long long
using namespace std;
const int maxn=5e5+10;
ll Ans;
int n;
int tree[maxn],fa[maxn],q[maxn],f[maxn];
vector<int> son[maxn];
inline int read1()
{
	int s=0;
	char c=getchar();
	while (c<'0'||c>'9') c=getchar();
	while (c>='0'&&c<='9')
	{
		s=s*10+c-'0';
		c=getchar();
	}
	return s;
}
inline char read2()
{
	char c=getchar();
	while (c!='('&&c!=')') c=getchar();
	return c;
}
void dfs(int u,ll ans,ll cnt,int head)
{
	int tmp;
	bool flag=0;
	if (tree[u]==1)
	{
		flag=1;
		tmp=q[++head];
		q[head]=u;
	}
	else
	if (head)
	{
		if (q[head]==fa[u])
		{
			ans+=cnt+1;
			++cnt;
		}
		else ++ans;
		--head;
	}
	Ans^=(ans*u);
	for (int i=0;i<son[u].size();++i) dfs(son[u][i],ans,cnt,head);
	if (flag) q[head]=tmp;
	return;
}
void solve()
{
	int head=0;
	ll ans=0,cnt=0;
	for (int i=1;i<=n;++i)
	{
		if (tree[i]==1) q[++head]=i;
		else
		if (head)
		{
			if (q[head]==fa[i]) ans+=cnt+1,cnt++;
			else ans++;
			--head;
		}
		Ans^=ans*i;
	}
	return;
}
int main()
{
	bool flag=1;
	char c;
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	n=read1();
	for (int i=1;i<=n;++i)
	{
		c=read2();
		if (c=='(') tree[i]=1;
		else tree[i]=-1;
	}
	fa[1]=0;
	for (int i=2;i<=n;++i)
	{
		fa[i]=read1();
		if (fa[i]!=i-1) flag=0;
		son[fa[i]].push_back(i);
	}
	if (!flag) dfs(1,0,0,0);
	else solve();
	printf("%lld",Ans);
	return 0;
}
