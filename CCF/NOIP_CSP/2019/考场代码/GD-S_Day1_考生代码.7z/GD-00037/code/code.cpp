#include<iostream>
#include<cstdio>
#include<cstdlib>
using namespace std;
unsigned long long n,k;
unsigned long long ans[1001];

void dfs(unsigned long long x,unsigned long long y,unsigned long long m){
	//cout<<x<<" "<<y<<" "<<m<<endl;
	if(x==n+1)return ;
	if(y<m){
		ans[x]=0;
		dfs(x+1,y,m/2);
	}
	else{
		ans[x]=1;
		dfs(x+1,m*2-y-1,m/2);
	}
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	
	cin>>n>>k;
	unsigned long long mm=1;
	for(unsigned long long i=1;i<=n-1;i++)mm*=2;
	dfs(1,k,mm);
	for(unsigned long long i=1;i<=n;i++){
		cout<<ans[i];
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
