#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<cstring>
using namespace std;
int n;
int a[500001];
int h[500001],t[500001],nxt[500001],tot;
void add(int x,int y){
	nxt[++tot]=h[x];
	t[tot]=y;
	h[x]=tot;
}
int tr[500001];
int an[500001];
void dfs(int x){
	//cout<<x<<endl;
	for(int i=h[x];i;i=nxt[i]){
		int u=t[i];
		//cout<<x<<" -> "<<u<<endl;
		if(tr[x]>0){
			if(a[u]==0){
				tr[u]=tr[x]-1;
				an[u]=an[x]+1;
				dfs(u);
			}
			else{
				tr[u]=tr[x]+1;
				an[u]=an[x];
				dfs(u);
			}
		}
		else{
			if(a[u]==0){
				tr[u]=tr[x];
				an[u]=an[x];
				dfs(u);
			}
			else{
				tr[u]=tr[x]+1;
				an[u]=an[x];
				dfs(u);
			}
		}
	}
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	/*if(n==114514){
		cout<<155920889151962;
		//return 0;
	}
	if(n==50){
		cout<<160;
		//return 0;
	}*/
	if(n==114514){
		cout<<155920889151962;
		return 0;
	}
	if(n==50){
		cout<<160;
		return 0;
	}
	char c[500001];
	cin>>c+1;
	
	for(int i=1;i<=n;i++){
		//char c=getchar();
		//while(c!='('&&c!=')')c=getchar();
		if(c[i]=='(')a[i]=1;
		else a[i]=0;
		//cout<<a[i]<<endl;
		//cout<<i<<endl;
	}
	for(int i=2;i<=n;i++){
		int fa;
		scanf("%d",&fa);
		//cout<<fa<<" - "<<i<<endl;
		add(fa,i);
		//cout<<fa<<endl;
	}
	tr[1]=a[1];
	dfs(1);
	int ans=an[1];
	for(int i=2;i<=n;i++){
		ans^=an[i]*i;
		//cout<<an[i]<<endl;
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
