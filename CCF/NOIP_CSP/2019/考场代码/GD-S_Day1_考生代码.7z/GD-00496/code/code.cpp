#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define int unsigned long long
#define N 80
int ans[N],n;
void qu(int l,int r,int k,int p){
	if(l==r) return;
	int len=(r-l+1)>>1,mid=(l+r)>>1;
	if(k>len){
		ans[p]=1;
		qu(mid+1,r,(len<<1)-k+1,p+1);
	}
	else qu(l,mid,k,p+1);
}
signed main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	int m;
	cin>>n>>m;++m;
	qu(1,pow(2,n),m,1);
	for(int i=1;i<=n;++i) cout<<ans[i];
	return 0;
}
