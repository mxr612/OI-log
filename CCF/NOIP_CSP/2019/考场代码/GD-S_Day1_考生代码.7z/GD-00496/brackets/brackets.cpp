#include<iostream>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define N 510000
int xorsum;
int head[N],next[N],ver[N],num;
#define add(x,y) (next[++num]=head[x],head[x]=num,ver[num]=y)
int f[N],bk[N],bl[N],lt[N],fbk[N];
inline void find(int n,int x){
	for(int i=1;i<=n;++i) f[i]=bl[i]=lt[i]=0;
	int sum=0;
	for(int i=1;i<=n;++i){
		if(fbk[i]){
			if(lt[0]){
				bl[i]=bl[lt[lt[0]]]+1;
				f[i]=bl[i]-bl[lt[--lt[0]]];
			}
		}else{
			bl[i]=bl[i-1];
			f[i]=0;
			lt[++lt[0]]=i;
		}
		sum+=f[i];
	}
	xorsum^=sum*x;
}
void dfs(int x,int sum,int dep){
	fbk[dep]=bk[x];
	find(dep,x);
	for(int k=head[x],y;y=ver[k],k;k=next[k])
		dfs(y,sum,dep+1);
}
signed main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n,m,sum=0,x;char c;
	cin>>n;
	for(int i=1;i<=n;++i){
		cin>>c;
		bk[i]|=c==')';
	}
	for(int i=2;i<=n;++i){
		cin>>x;
		add(x,i);
	}
	dfs(1,0,1);
	cout<<xorsum;
	return 0;
}
