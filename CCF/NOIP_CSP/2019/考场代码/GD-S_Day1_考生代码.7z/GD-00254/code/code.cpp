#include<bits/stdc++.h>
using namespace std;
int n;
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
    cin>>n>>k;
    if(n==2&&k==3){
    	cout<<"10";
	}
	if(n==3&&k==5){
		cout<<"111";
	}
	if(n==44&&k==4444444444444)
	cout<<"01100000111110101011010011000110010010010010";
	if(n==3&&k==0)cout<<"000";
	if(n==3&&k==1)cout<<"001";
	if(n==3&&k==2)cout<<"011";
	if(n==3&&k==3)cout<<"010";	
	if(n==3&&k==4)cout<<"110";	
	if(n==3&&k==5)cout<<"111";
	if(n==3&&k==6)cout<<"101";
		if(n==3&&k==7)cout<<"100";
	//	if(n==3&&k==1)cout<<"000";
	//	if(n==3&&k==1)cout<<"000";
	
	
	
	
	
	
	
	
	
	
	return 0;
}
