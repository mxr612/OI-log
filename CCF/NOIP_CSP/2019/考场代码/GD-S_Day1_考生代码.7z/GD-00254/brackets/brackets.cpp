#include<bits/stdc++.h>
using namespace std;
int n;
const int ind=600100;
string a;
int q[ind];
int fa[ind];
int k[ind];
int path[ind];
int top;
int t[ind];
int o;
void ok(int i){
	if(i==0){
		path[o++]=i;
		return ;
	}
    ok(fa[i]);
    path[o++]=i;
	return ;
}
int tot;
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	cin>>a;
	int b;
	for(int i=1;i<n;++i){
		 scanf("%d",&b);
		 fa[i]=b-1;
	}

	for(int i=0;i<n;++i){
		top=0;
		int ans=0;
		o=0;
		ok(i);	
		for(int j=0;j<o;j++){ 
			if(top&&a[path[j]]==')'&&a[q[top]]=='(')
			{
			  
				ans+=t[q[top]]+1;
				if(a[path[j+1]]=='(')
				  t[path[j+1]]=t[q[top]]+1;
				 	top--;
		 	}
			else {
				q[++top]=path[j];
			}
	    }
	    k[i]=ans;
	    tot^=(i+1)*k[i];
	}
	cout<<tot;
	return 0;
}
