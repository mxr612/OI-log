#include<bits/stdc++.h>
using namespace std;
int t,n;
int e[2000][2000];
int a[2001];
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	cin>>t;
	int o,p;
	while(t){
		cin>>n;
		for(int i=1;i<=n;++i){
			cin>>a[i];
		}
		for(int i=1;i<=n-1;++i){
			cin>>o>>p;
			e[o][p]=1;
			e[p][o]=1;
		}
	
	}
	return 0;
}

