#include <cstdio>
#include <vector>
#include <cstring>
using namespace std;

typedef long long ll;
int n,l,r,mi,mx,tot,top;
const int N = 5E5 + 7; char s[N];
struct SGT{ int ls,rs,val; } t[N * 20];
vector < int > to[N],tag[N]; ll ans[N],rest;
int f[N],q[N],sta[N],rt[N],dep[N],tmp[N],val[N];

int min(int x,int y) { return x < y ? x : y; }

int max(int x,int y) { return x > y ? x : y; }

void read(int &x)
{
	char c = getchar(); x = 0;
	while(c < '0' || c > '9') c = getchar();
	for(;c >= '0' && c <= '9';c = getchar()) x = x * 10 + (c ^ '0');
}

void insert(int &o,int last,int l,int r,int x,int y)
{
	t[o = ++tot].val = min(t[last].val,y);
	if(l == r) return;
	int mid = l + r >> 1;
	if(x <= mid) t[o].rs = t[last].rs,
		insert(t[o].ls,t[last].ls,l,mid,x,y);
	else t[o].ls = t[last].ls,
		insert(t[o].rs,t[last].rs,mid + 1,r,x,y);
}

int query(int o,int l,int r,int x)
{
	if(!o) return 0;
	if(l == r) return l;
	int mid = l + r >> 1;
	if(t[t[o].rs].val < x)
		return query(t[o].rs,mid + 1,r,x);
	else return query(t[o].ls,l,mid,x);
}

void build2(int &o,int l,int r)
{
	t[o = ++tot] = (SGT){ 0,0,0 };
	if(l <= 0 && r >= 0) t[o].val = 1;
	if(l == r) return;
	int mid = l + r >> 1;
	build2(t[o].ls,l,mid),
	build2(t[o].rs,mid + 1,r);
}

void insert2(int &o,int last,int l,int r,int x)
{
	t[o = ++tot] = (SGT){ 0,0,0 };
	if(l == r) { t[o].val = t[last].val + 1; return; }
	int mid = l + r >> 1;
	if(x <= mid) t[o].rs = t[last].rs,
		insert2(t[o].ls,t[last].ls,l,mid,x);
	else t[o].ls = t[last].ls,
		insert2(t[o].rs,t[last].rs,mid + 1,r,x);
}

int query2(int o,int l,int r,int x)
{
	if(!o) return 0;
	if(l == r) return t[o].val;
	int mid = l + r >> 1;
	if(x <= mid) return query2(t[o].ls,l,mid,x);
	else return query2(t[o].rs,mid + 1,r,x);
}

int main()
{
	freopen("brackets.in","r",stdin),
	freopen("brackets.out","w",stdout);
	
	scanf("%d %s",&n,s + 1), f[1] = 0;
	for(int i = 2;i <= n; ++ i)
		scanf("%d",f + i), to[f[i]].push_back(i);
	
	val[0] = dep[0] = 0, q[l = r = 1] = 1;
	for(;l <= r; ++ l)
	{
		dep[q[l]] = dep[f[q[l]]] + 1,
		val[q[l]] = val[f[q[l]]] + (s[q[l]] == '(' ? 1 : -1);
		for(int i = 0,x = to[q[l]].size();i < x; ++ i) q[++r] = to[q[l]][i];
	}
	
	memset(ans,mx = 0,sizeof ans), sta[top = 1] = 1;
	t[rt[0] = tot = 0] = (SGT){ 0,0,mi = 0x3f3f3f3f };
	for(int x;top > 0;)
	{
		x = sta[top], --top, tmp[dep[x]] = x,
		insert(rt[x],rt[f[x]],0,n,dep[x],val[x]),
		mi = min(mi,val[x]), mx = max(mx,val[x]);
		tag[tmp[query(rt[x],0,n,val[x])]].push_back(x);
		for(int i = 0,y = to[x].size();i < y; ++ i) sta[++top] = to[x][i];
	}
	
	t[tot = 0] = (SGT){ 0,0,0 }, build2(rt[0],mi,mx);
	for(int i = 1,x;i <= n; ++ i)
	{
		x = q[i], insert2(rt[x],rt[f[x]],mi,mx,val[x]),
		ans[x] += query2(rt[x],mi,mx,val[x]) - 1;
		for(int j = 0,y = tag[x].size();j < y; ++ j)
			ans[tag[x][j]] -= query2(rt[x],mi,mx,val[tag[x][j]]);
	}
	
	rest = 0ll;
	for(int i = 1,x;i <= n; ++ i)
		x = q[i], ans[x] += ans[f[x]], rest ^= ans[x] * x;
	printf("%lld\n",rest);
	
	fclose(stdin), fclose(stdout);
	return 0;
}
