#include <cstdio>
#include <cstring>
using namespace std;

int n; unsigned long long m;

void solve(int n,unsigned long long m)
{
	if(m < (1llu << (n - 1)))
	{
		putchar('0');
		if(n > 1) solve(n - 1,m);
	}
	else
	{
		putchar('1');
		if(n > 1) solve(n - 1,(1llu << (n - 1)) - 1 - m + (1llu << (n - 1)));
	}
	return;
}

int main()
{
	freopen("code.in","r",stdin),
	freopen("code.out","w",stdout);
	
	scanf("%d%llu",&n,&m), solve(n,m);
	
	fclose(stdin), fclose(stdout);
	return 0;
}
