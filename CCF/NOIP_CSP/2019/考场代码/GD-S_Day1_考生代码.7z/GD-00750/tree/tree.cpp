#include <cstdio>
#include <cstring>
using namespace std;

const int N = 2222;
int n,T,tot,root,flag1,flag2,a[N],D[N],fa[N],u[N];
int v[N],bz[N],tag[N],st[N],ans[N],dep[N],pos[N],val[N];
struct EDGE{ int to,next; } g[N * 2];

void swap(int &x,int &y) { x ^= y ^= x ^= y; }

void add(int u,int v)
{ g[++tot] = (EDGE){ v,st[u] }, st[u] = tot, ++D[u]; }

void dfs(int x)
{
	if(x == n)
	{
		int bz = 0;
		for(int i = 1;i <= n; ++ i)
			if(pos[i] < ans[i]) bz = 1;
			else if(pos[i] > ans[i]) break;
		if(bz) for(int i = 1;i <= n; ++ i)
			ans[i] = pos[i];
		return;
	}
	for(int i = 1;i < n; ++ i)
		if(!bz[i])
			bz[i] = 1, a[x] = i, swap(val[u[i]],val[v[i]]),
			pos[val[u[i]]] = u[i], pos[val[v[i]]] = v[i],
			dfs(x + 1), bz[i] = 0, swap(val[u[i]],val[v[i]]),
			pos[val[u[i]]] = u[i], pos[val[v[i]]] = v[i];
}

void brute()
{
	for(int i = 1;i <= n; ++ i) ans[i] = n + 1;
	memset(bz,0,sizeof bz), dfs(1);
	for(int i = 1;i <= n; ++ i) printf("%d ",ans[i]);
	putchar('\n');
}

void update(int x)
{
	for(int i = st[x];i;i = g[i].next)
		if(g[i].to != fa[x])
			dep[g[i].to] = dep[x] + 1,
			fa[g[i].to] = x, update(g[i].to);
}

int main()
{
	freopen("tree.in","r",stdin),
	freopen("tree.out","w",stdout);
	
	for(scanf("%d",&T);T--;)
	{
		memset(st,tot = 0,sizeof st),
		scanf("%d",&n), flag1 = 1, flag2 = 0;
		for(int i = 1;i <= n; ++ i)
			scanf("%d",pos + i), val[pos[i]] = i;
		for(int i = 1;i < n; ++ i)
			scanf("%d%d",u + i,v + i), add(u[i],v[i]), add(v[i],u[i]),
			flag1 &= D[u[i]] <= 2 && D[v[i]] <= 2,
			flag2 |= D[u[i]] == n - 1 || D[v[i]] == n - 1;
		
		if(n <= 10) { brute(); continue; }
		
		if(flag1)
		{
			for(int i = 1;i <= n; ++ i) if(D[i] == 1) root = i;
			dep[root] = 1, fa[root] = 0, update(root);
			
			memset(bz,0,sizeof bz),
			memset(tag,0,sizeof tag);
			for(int i = 1;i <= n; ++ i)
				for(int j = 1,x,y,tmp,p;j <= n; ++ j) if(!bz[j])
				{
					x = pos[j], y = j, p = 1;
					if(dep[x] < dep[y]) swap(x,y);
					for(tmp = x;tmp != y;) p &= !tag[tmp], tmp = fa[tmp];
					if(p)
					{
						bz[j] = 1, printf("%d ",j);
						for(;x != y;)
						{
							tag[x] = 1, swap(val[x],val[fa[x]]),
							pos[val[fa[x]]] = fa[x], pos[val[x]] = x, x = fa[x];
						}
					}
				}
		}
		
	}
	
	fclose(stdin), fclose(stdout);
	return 0;
}
