#include<iostream>
#include<cstring>
#include<cstdio>
#include<vector>
using namespace std;
int n;
int a[5001],rd[5001];
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int round;
	scanf("%d",&round);
	for(int i=1;i<=round;i++)
	{
		memset(a,0,sizeof(a));
		memset(rd,0,sizeof(rd));
		vector<int> s[2001];
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		s[i].push_back(0);
		scanf("%d",&a[i]);
	}
	
	for(int i=1;i<=n-1;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		rd[u]++;rd[v]++;
		s[u].push_back(v);
		s[v].push_back(u);
		
	}
	int minn,maxn;
	maxn=0;minn=0;
	for(int i=1;i<=n;i++)
	{
		if(rd[i]==1)
			minn++;
		if(rd[i]>=maxn)maxn=rd[i];
	}
	
	if(minn<=2&&maxn==2)
	{
		for(int time=1;time<n;time++)
		{
			int minx=3000;int aim;
			for(int i=1;i<=n;i++)
				if(rd[i]!=0&&a[i]<minx)
				{aim=i;minx=a[i];}
			if(minx==3000)break;
				int minx1=2001;int minx2=2001;
				int from=aim;
				for(int j=s[aim][0];j!=0;)
				{
					if(j<minx1&&rd[j]!=0)minx1=j;
					if(rd[j]==1)break;
					if(s[j][0]==from)
					{
						from=j;j=s[j][1];
					}
					else 
					{
						from=j;j=s[j][0];
					}
				}
				from=aim;
				if(rd[aim]==2)
				for(int j=s[aim][1];j!=0;)
				{
					if(j<minx2&&rd[j]!=0)minx2=j;
					if(s[j][0]==from)
					{
						from=j;j=s[j][1];
					}
					else 
					{
						from=j;j=s[j][0];
					}
				}
				if(minx2>minx1)
				{
				from=aim;
				for(int j=s[aim][0];j!=0;)
				{
					if(j>=minx1&&rd[j]!=0)
					{
						int bowl;bowl=a[from];
						a[from]=a[j];a[j]=bowl;
						rd[from]--;rd[j]--;
						
					}
					if(s[j][0]==from)
					{
						from=j;j=s[j][1];
					}
					else 
					{
						from=j;j=s[j][0];
					}
				}
				}
				else
				{
					from=aim;
				for(int j=s[aim][0];j!=0;)
				{
					if(j>=minx1&&rd[j]!=0)
					{
						int bowl;bowl=a[from];
						a[from]=a[j];a[j]=bowl;
						rd[from]--;rd[j]--;
						
					}
					if(s[j][0]==from)
					{
						from=j;j=s[j][1];
					}
					else 
					{
						from=j;j=s[j][0];
					}
				}
				}
		}
	}
	for(int i=1;i<=n;i++)
	printf("%d ",a[i]);
	cout<<endl;
	}
	return 0;
}
