#include<iostream>
#include<cstring>
#include<cstdio>
using namespace std;
long long a[101],place[101];
long long from[101];
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	int n;long long k;
	long long div=1;
	cin>>n>>k;
	int ans[n+1];
	for(int i=1;i<=n-1;i++)div=div*2;
    long long now;
	now=k;bool d[100];
	for(int i=1;i<=n-1;i++)
	{
		if(now/div==1)d[i]=true;
		else d[i]=false;
		if(d[i])
			place[i]=div-((now+1)%div);
		else place[i]=now%div;
		div=div/2;
		now=place[i];
	}
	if(place[n-1]==1)ans[n]=1;
	else ans[n]=0;
	for(int i=n-1;i>=1;i--)
	{
		if(d[i])ans[i]=1;
		else ans[i]=0;
	}
	for(int i=1;i<=n;i++)cout<<ans[i];
	return 0;
}
