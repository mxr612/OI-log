#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<queue>
#include<vector>
#include<set>
#include<map>
#include<bitset>
#include<ctime>
#define LL unsigned long long
#define mp(x,y) make_pair(x,y)
#define pii pair<int,int>
#define pll pair<long long,long long>
using namespace std;
inline LL read()
{
	LL f=1,x=0;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int wsta[20],wtp;
inline void write(int x)
{
	if(x<0){putchar('-');x=-x;}
	if(x==0){putchar('0');return ;}wtp=0;
	while(x)wsta[++wtp]=x%10,x/=10;
	while(wtp)putchar(wsta[wtp--]+'0');
}
inline void pr1(int x){write(x);putchar(' ');}
inline void pr2(int x){write(x);putchar('\n');}
int n;LL K;
void solve(int p,LL num,int o)
{
	LL now=(1LL<<(p-1));
	if(p==0)return ;
	if(num<now)
	{
		if(o==0)putchar('0');
		else putchar('1');
		solve(p-1,num,0);
	}
	else
	{
		if(o==0)putchar('1');
		else putchar('0');
		solve(p-1,num-now,1);
	}
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	n=read();K=read();
	solve(n,K,0);
	return 0;
}

