#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<queue>
#include<vector>
#include<set>
#include<map>
#include<bitset>
#include<ctime>
#define LL long long
#define mp(x,y) make_pair(x,y)
#define pii pair<int,int>
#define pll pair<long long,long long>
using namespace std;
inline int read()
{
	int f=1,x=0;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int wsta[20],wtp;
inline void write(LL x)
{
	if(x<0){putchar('-');x=-x;}
	if(x==0){putchar('0');return ;}wtp=0;
	while(x)wsta[++wtp]=x%10,x/=10;
	while(wtp)putchar(wsta[wtp--]+'0');
}
inline void pr1(LL x){write(x);putchar(' ');}
inline void pr2(LL x){write(x);putchar('\n');}
const int MAXN=500005;
struct edge{int x,y,next;}a[2*MAXN];int len,last[MAXN];
void ins(int x,int y){len++;a[len].x=x;a[len].y=y;a[len].next=last[x];last[x]=len;}
struct segtree
{
	#define lc now<<1
	#define rc now<<1|1
	int mx[MAXN*4],lazy[MAXN*4];
	void down(int now)
	{
		if(!lazy[now])return ;
		mx[lc]+=lazy[now];mx[rc]+=lazy[now];
		lazy[lc]+=lazy[now];lazy[rc]+=lazy[now];
		lazy[now]=0;
	}
	void modify(int now,int l,int r,int ql,int qr,int c)
	{
		if(l==ql&&r==qr){mx[now]+=c;lazy[now]+=c;return ;}down(now);
		int mid=(l+r)/2;
		if(qr<=mid)modify(lc,l,mid,ql,qr,c);
		else if(mid+1<=ql)modify(rc,mid+1,r,ql,qr,c);
		else modify(lc,l,mid,ql,mid,c),modify(rc,mid+1,r,mid+1,qr,c);
		mx[now]=max(mx[lc],mx[rc]);
	}
	int query(int now,int l,int r)
	{
		if(mx[now]<=0)return 0;down(now);
		if(l==r){return l;}int mid=(l+r)/2;
		if(mx[rc]>0)return query(rc,mid+1,r);else return query(lc,l,mid);
	}
}seg;
int n,cal[MAXN];
char st[MAXN];LL val[MAXN];
int in[MAXN],ot[MAXN],dfn;
void init(int x)
{
	in[x]=++dfn;
	for(int k=last[x];k;k=a[k].next)init(a[k].y);
	ot[x]=dfn;
}
const int zero=500005;
vector<int> vec[MAXN*2];
int lim[MAXN*2];
void pushin(int v,int t)
{
	if(lim[v]==vec[v].size())vec[v].push_back(t),++lim[v];
	else vec[v][lim[v]++]=t;
}
void pop(int v){--lim[v];}
int getnum(int v,int lps)
{
	int l=0,r=lim[v]-1,ret=lim[v];
	while(l<=r)
	{
		int mid=(l+r)/2;
		if(vec[v][mid]>=lps)ret=mid,r=mid-1;
		else l=mid+1;
	}return lim[v]-ret;
}
int getval(int v)
{
	int lps=seg.query(1,1,n);
	return getnum(v+zero,lps);
}
void solve(int x,int sum,int tot)
{
	sum+=cal[x];seg.modify(1,1,n,1,tot,cal[x]);
	LL u=getval(sum);
	pushin(sum+zero,tot);
	val[in[x]]+=u;val[ot[x]+1]-=u;
	for(int k=last[x];k;k=a[k].next)solve(a[k].y,sum,tot+1);
	pop(sum+zero);seg.modify(1,1,n,1,tot,-cal[x]);
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	n=read();
	scanf("%s",st+1);
	for(int i=1;i<=n;i++)cal[i]=(st[i]=='('?1:-1);
	for(int i=2;i<=n;i++)ins(read(),i);
	init(1);pushin(0+zero,0);solve(1,0,1);
	for(int i=1;i<=n;i++)val[i]+=val[i-1];
	LL ans=0;
	for(int i=1;i<=n;i++)ans^=(1LL*i*val[in[i]]);
	pr2(ans);
	return 0;
}

