#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<algorithm>
#include<cmath>
#include<queue>
#include<vector>
#include<set>
#include<map>
#include<bitset>
#include<ctime>
#define LL long long
#define mp(x,y) make_pair(x,y)
#define pii pair<int,int>
#define pll pair<long long,long long>
using namespace std;
inline int read()
{
	int f=1,x=0;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int wsta[20],wtp;
inline void write(int x)
{
	if(x<0){putchar('-');x=-x;}
	if(x==0){putchar('0');return ;}wtp=0;
	while(x)wsta[++wtp]=x%10,x/=10;
	while(wtp)putchar(wsta[wtp--]+'0');
}
inline void pr1(int x){write(x);putchar(' ');}
inline void pr2(int x){write(x);putchar('\n');}
const int MAXN=2005;
const int MAXM=165;
const int MAXK=15;
struct edge{int x,y,next;}a[2*MAXN];int len,last[MAXN];
void ins(int x,int y){len++;a[len].x=x;a[len].y=y;a[len].next=last[x];last[x]=len;}
int val[MAXN],val1[MAXN],n;
int du[MAXN];
namespace solve1
{
	int num[MAXK],b[MAXK],vis[MAXK];
	int c[MAXK],d[MAXK];
	void dfs(int k)
	{
		if(k==n)
		{
			for(int i=1;i<=n;i++)b[i]=val1[i];
			for(int i=1;i<n;i++)swap(b[a[2*num[i]].x],b[a[2*num[i]].y]);
			if(c[1]==0)for(int i=1;i<=n;i++)c[b[i]]=i;
			else
			{
				bool tf=true;
				for(int i=1;i<=n;i++)d[b[i]]=i;
				for(int i=1;i<=n;i++)
				{
					if(c[i]<d[i]){tf=false;break;}
					if(c[i]>d[i])break;
				}
				if(tf)for(int i=1;i<=n;i++)c[i]=d[i];
			}return ;
		}
		for(int i=1;i<n;i++)if(!vis[i])
		{
			num[k]=i;vis[i]=1;
			dfs(k+1);vis[i]=0;
		}
	}
	void main()
	{
		memset(c,0,sizeof(c));
		for(int i=1;i<=n;i++)val1[val[i]]=i;
		dfs(1);
		for(int i=1;i<n;i++)pr1(c[i]);pr2(c[n]);
	}
}
bool check1()
{
	for(int i=1;i<=n;i++)if(du[i]==n-1)return true;
	return false;
}
namespace solve_flower
{
	int vis[MAXN],sta[MAXN],tp,vis1[MAXN];
	int c[MAXN],d[MAXN],b[MAXN],vi[MAXN];
	int rt[MAXN],tot[MAXN];
	int findrt(int x){return rt[x]==x?rt[x]:rt[x]=findrt(rt[x]);}
	void merge(int x,int y)
	{
		int p=findrt(x),q=findrt(y);
		if(tot[p]>tot[q])swap(p,q);rt[p]=q;
		tot[q]+=tot[p];
	}
	void main()
	{
		memset(vis,0,sizeof(vis));
		memset(vis1,0,sizeof(vis1));
		memset(c,0,sizeof(c));int now=val[1];
		for(int i=1;i<=n;i++)rt[i]=i,tot[i]=1;
		for(int i=1;i<=n;i++)
		{
			now=val[i];
			for(int j=1;j<=n;j++)if(!vis[j]&&(findrt(now)!=findrt(j)||i==n))
			{
				c[val1[now]]=j;vis[j]=1;merge(now,j);
				break;
			}
		}
		for(int i=1;i<n;i++)pr1(c[i]);pr2(c[n]);
	}
}
namespace solve_chain
{
	void main()
	{
		
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T=read();while(T--)
	{
		len=0;memset(last,0,sizeof(last));
		memset(du,0,sizeof(du));
		n=read();
		for(int i=1;i<=n;i++)val[i]=read();
		for(int i=1;i<=n;i++)val1[val[i]]=i;
		for(int i=1;i<n;i++)
		{
			int x=read(),y=read();
			ins(x,y);ins(y,x);++du[x];++du[y];
		}
		if(n==1){pr2(1);continue;}
		if(n<=10)solve1::main();
		else if(check1())solve_flower::main();
		else solve_chain::main();
	}
	return 0;
}

