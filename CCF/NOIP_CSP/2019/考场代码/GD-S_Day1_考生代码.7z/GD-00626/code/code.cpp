#include <bits/stdc++.h>
using namespace std;
#define ULL unsigned long long
ULL mi[100], n, k;
ULL get(int nn, ULL pos) {
	if (pos == 0)  return 0;
	if (pos == 1)  return 1;
	if (pos <= mi[nn - 1])  return get(nn - 1, pos);
	else  return get(nn - 1, mi[nn] - pos) + mi[nn - 1] + 1;
}
char s[100];
void print(ULL ans) {
	for (ULL i = 1; i <= n; ++i) {
		s[i] = '0';
	}
	int p = n;
	while (ans) {
		if (ans & 1ull)  s[p] = '1';
		ans >>= 1ull;
		--p;
	}
	printf("%s\n", s + 1);
}
int main() {
//	#ifndef LOCAL
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
//	#endif
	mi[0] = 0;
	for (int i = 1; i <= 64; ++i) {
		mi[i] = mi[i - 1] * 2 + 1;
	}
	cin >> n >> k;
	print(get(n, k));
	return 0;
}
