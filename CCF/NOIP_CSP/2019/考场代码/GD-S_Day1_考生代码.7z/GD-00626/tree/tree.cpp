#include <bits/stdc++.h>
using namespace std;
int T, n;
namespace solve1 {
	int w[20], id[20], ans[20], cp[20], pos[20];
	struct edge {
		int u, v;
	} e[20];
	void f() {
		for (int i = 1, tmp; i < n; ++i) {
			tmp = w[e[id[i]].u];
			w[e[id[i]].u] = w[e[id[i]].v];
			w[e[id[i]].v] = tmp;
		}
		for (int i = 1; i <= n; ++i) {
			pos[w[i]] = i;
		}
		#ifdef LOCAL
//		for (int i = 1; i <= n; ++i) {
//			cout << w[i] << " " ;
//		}
//		cout << endl;
		#endif
		for (int i = 1; i <= n; ++i) {
			if (pos[i] > ans[i])  return;
			else if (pos[i] < ans[i])  break;
		}
		for (int i = 1; i <= n; ++i) {
			ans[i] = pos[i];
		}
		return;
	}
	void work() {
		memset(ans, 0x3f, sizeof(ans));
		for (int i = 1, x; i <= n; ++i) {
			scanf("%d", &x);
			w[x] = i;
		}
		for (int i = 1; i < n; ++i) {
			scanf("%d%d", &e[i].u, &e[i].v);
			id[i] = i;
		}
		do {
			for (int i = 1; i <= n; ++i) {
				cp[i] = w[i];
			}
			f();
			for (int i = 1; i <= n; ++i) {
				w[i] = cp[i];
			}
		} while (next_permutation(id + 1, id + n));
		for (int i = 1; i <= n; ++i) {
			cout << ans[i] << " ";
		}
		cout << endl;
	}
}
struct node {
	int num, fa;
} p[2010];
struct edge {
	int to, nxt;
} e[4010];
int head[2010], cnt;
void add(int u, int v) {
	e[++cnt] = (edge){v, head[u]};
	head[u] = cnt;
}
bool vis[2010];
void build(int k) {
	vis[k] = true;
	for (int i = head[k]; i; i = e[i].nxt) {
		if (!vis[e[i].to]) {
			p[e[i].to].fa = k;
			build(e[i].to);
		}
	}
}
void swim(int k) {
	vis[k] = true;
	while (p[k].fa && !vis[p[k].fa]) {
		vis[p[k].fa] = true;
		swap(p[k].num, p[p[k].fa].num);
		k = p[k].fa;
	}
}
int main() {
//	#ifndef LOCAL
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
//	#endif
	scanf("%d", &T);
	while (T--) {
		memset(p, 0, sizeof(node));
		memset(e, 0, sizeof(edge));
		memset(head, 0, sizeof(head));
		memset(vis, 0, sizeof(vis));
		cnt = 0;
		scanf("%d", &n);
		if (n <= 10) { solve1::work(); continue; }
		for (int i = 1, x; i <= n; ++i) {
			scanf("%d", &x);
			p[x].num = i;
		}
		for (int i = 1, u, v; i < n; ++i) {
			scanf("%d%d", &u, &v);
			add(u, v);  add(v, u);
		}
		build(1);
		memset(vis, 0, sizeof(vis));
		for (int i = 1, kk = 0; i <= n; ++i) {
			for (int j = 1; j <= n; ++j) {
				if (p[j].num == i) {
					kk = j;
					break;
				}
			}
			swim(kk);
		}
		for (int i = 1; i <= n; ++i) {
			for (int j = 1; j <= n; ++j) {
				if (p[j].num == i) {
					printf("%d ", j);
					break;
				}
			}
		}
		puts("");
	}
	return 0;
}
