#include <bits/stdc++.h>
using namespace std;
static int n, fa[120100];
static char br[120100];
namespace solve1 {
	static long long p = 0, sum = 0, ans = 0;
	void work() {
		for (register long long i = 2; i <= n; ++i) {
			if (br[i] == '(') { ans = ans ^ (i * p);  continue; }
			sum = -1;
			for (register long long j = i - 1; j >= 1; --j) {
				if (br[j] == '(')  ++sum;
				else  --sum;
				if (sum > 0)  break;
				if (sum == 0)  ++p;
			}
			ans = ans ^ (i * p);
		}
		cout << ans << endl;
		return;
	}
}
namespace solve2 {
	vector<int> son[100100];
	static int tmp[100100], cnt[100100];
	static long long ans = 0;
	inline int calc(const int &l) {
		if (tmp[l] == 1)  return 0;
		int sum = -1, ccnt = 0;
		for (int i = l - 1; i >= 1; --i) {
			sum += tmp[i];
			if (sum > 0)  return ccnt;
			if (sum == 0)  ++ccnt;
		}
		return ccnt;
	}
	void dfs(const int &k, const int &p, const int &dep) {
		int bkk = calc(dep);
//		cout << k << " " << bkk << endl;
		ans = ans ^ (1LL * k * (p + bkk));
		for (register int i = 0, dn = dep + 1; i < cnt[k]; ++i) {
			tmp[dn] = (br[son[k][i]] == '(' ? 1 : -1);
			dfs(son[k][i], p + bkk, dn);
		}
	}
	void work() {
		memset(tmp, 0, sizeof(tmp));
		memset(cnt, 0, sizeof(cnt));
		for (int i = 2; i <= n; ++i) {
			son[fa[i]].insert(son[fa[i]].end(), i);
			++cnt[fa[i]];
		}
		tmp[1] = (br[1] == '(' ? 1 : -1);
		dfs(1, 0, 1);
		cout << ans << endl;
	}
}
int main() {
//	#ifndef LOCAL
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
//	#endif
	scanf("%d", &n);
	scanf("%s", br + 1);
	bool flag = true;
	for (int i = 1; i < n; ++i) {
		scanf("%d", &fa[i + 1]);
		if (fa[i + 1] != i) {
			flag = false;
		}
	}
	if (flag) {
		solve1::work();
	} else {
		solve2::work();
	}
	return 0;
}
