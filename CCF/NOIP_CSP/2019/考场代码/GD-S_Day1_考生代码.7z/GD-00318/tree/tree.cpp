#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

bool vis[2005];
int T,n,x,y,a[2005],b[2005],deg[2005],h[2005],tot=0,root;
struct Edge{
	int x,next,del;
}e[4005];

void add_edge(int x,int y){
	e[++tot].x=y,deg[x]++;
	e[tot].next=h[x],h[x]=tot;
}

//bool dfs1(int s,int t){
//	for(int i=h[s];i;i=e[i].next){
//		int x=e[i].x;
//		while(x!=t){
//			for(int j=h[x];j;j=e[j].next){
//				if(e[j].x==fa||e[j].del)continue;
//				x=e[i].x; goto to;
//			}
//			break; to:;
//		}
//		
//	}
//}

void work1(){
//	for(int i=1;i<=n;i++){
//		int tmp=find(a[i]);
//		dfs1(a[i],a[i],tmp,0);
//	}
}

int get(int x){
	for(int i=1;i<=n;i++)if(!vis[i]&&i!=a[x])return i;
}

void work2(){
	int ans;
	for(int i=1;i<n;i++){
		if(vis[a[i]]&&a[i]!=root)continue;
		int tmp=get(i),k=a[i];
		if(tmp!=root){
			vis[tmp]=true;
			if(root!=k){
				int t=b[root];b[root]=b[tmp],b[tmp]=b[k],b[k]=t,vis[k]=true;
			}else swap(b[root],b[tmp]);
			a[b[root]]=root,a[b[tmp]]=tmp,a[b[k]]=k;
		}else{
			vis[root]=vis[a[i]]=true;
			ans=a[i];
		}
	}
	swap(b[root],b[ans]);
	a[b[root]]=root,a[b[ans]]=ans;
}

int main(){
	scanf("%d",&T);
	while(T--){
		freopen("tree.in","r",stdin);
		freopen("tree.out","w",stdout);
		memset(vis,0,sizeof(vis));
		memset(h,0,sizeof(h)),tot=0;
		memset(deg,0,sizeof(deg));
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",a+i),b[a[i]]=i;
		for(int i=1;i<n;i++){
			scanf("%d%d",&x,&y);
			add_edge(x,y);
			add_edge(y,x);
		}
		bool flag1=true,flag2=false;
		for(int i=1;i<=n;i++){
			if(deg[i]==n-1)flag2=true,root=i;
			if(deg[i]>2)flag1=false;
		}
		if(flag1)work1();
		if(flag2)work2();
		for(int i=1;i<=n;i++)printf("%d ",a[i]);
		printf("\n");
	}
}
