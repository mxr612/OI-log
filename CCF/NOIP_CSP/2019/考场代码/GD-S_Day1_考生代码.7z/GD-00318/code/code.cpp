#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

int a[105];
unsigned long long n,k;

int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%llu%llu",&n,&k);
	while(n){
		if(k<(1LLU<<n-1))a[++a[0]]=0;
		else{
			k=(1LLU<<n)-k-1;
			a[++a[0]]=1;
		}
		n--;
	}
	for(int i=1;i<=a[0];i++)printf("%d",a[i]);
}
