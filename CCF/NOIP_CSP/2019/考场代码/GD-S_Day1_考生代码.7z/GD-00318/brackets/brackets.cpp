#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;

char s[500005];
int n,x,h[500005],ls[500005],tot=0,top=0;
int st[500005],a[500005];
long long ans[500005];
struct Edge{
	int x,next;
}e[1000005];

void add_edge(int x,int y){
	e[++tot].x=y;
	e[tot].next=h[x],h[x]=tot;
}

void work(){
	for(int x=1;x<=n;x++){
		if(s[x]==')'){
		if(st[top]==1){
			ans[x]+=++a[top];
			st[top--]=0;
		}
			else st[++top]=-1;
		}else st[++top]=1;
		ans[x+1]=ans[x];
	}
}

void dfs(int x){
	int t=0;
	if(s[x]==')'){
		if(st[top]==1){
			ans[x]+=++a[top];
			t=a[top+1],a[top+1]=0;
			st[top--]=0;
		}
		else st[++top]=-1;
	}else st[++top]=1;
	for(int i=h[x];i;i=e[i].next){
		ans[e[i].x]=ans[x];
		dfs(e[i].x);
	}
	if(s[x]==')'){
		if(~st[top]){
			st[++top]=1,a[top]--;
			a[top+1]=t;
		}else st[top--]=0;
	}else st[top--]=0;
}

int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	bool flag=true;
	scanf("%d%s",&n,s+1);
	for(int i=2;i<=n;i++){
		scanf("%d",&x);
		if(x!=i-1)flag=false;
		add_edge(x,i);
	}
	if(flag)work();
	else dfs(1);
	for(int i=1;i<=n;i++){
		ans[0]^=i*ans[i];
//		printf("%lld ",ans[i]);
	}
	printf("%lld",ans[0]);
}
