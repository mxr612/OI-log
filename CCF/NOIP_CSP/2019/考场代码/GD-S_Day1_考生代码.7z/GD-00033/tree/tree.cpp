#include<cstdio>
using namespace std;
bool e[1000],n;
int ans[1000],a[1000],x[1000],y[1000],g[1000];
int bl(int p){
	if (p>=n){
		bool c=true;
		for (int i=1;i<=n;i++)
			if (a[i]>ans[i]){
				c=false;
				break;
			}
			else
				if (a[i]<ans[i]) break;
		if (c) 
			for (int i=1;i<=n;i++)
				ans[i]=a[i];
		return 0;
	}
	for (int i=1;i<=n;i++)
		if (e[i]){
			e[i]=false;
			int o;
			o=g[x[i]];
			g[x[i]]=g[y[i]];
			g[y[i]]=o;
			o=a[g[x[i]]];
			a[g[x[i]]]=a[g[y[i]]];
			a[g[y[i]]]=o;
			bl(p+1);
			o=g[x[i]];
			g[x[i]]=g[y[i]];
			g[y[i]]=o;
			o=a[g[x[i]]];
			a[g[x[i]]]=a[g[y[i]]];
			a[g[y[i]]]=o;
			e[i]=true;
		}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T;
	scanf("%d",&T);
	for (int i=1;i<=T;i++){
		scanf("%d",&n);
		bool f=true;
		int u;
		for (int j=1;j<=n;j++){
			scanf("%d",&a[j]);
			g[a[j]]=j;
		}
		for (int j=1;j<n;j++){
			scanf("%d%d",&x[j],&y[j]);
			if (y[j]!=x[j]+1) f=false;
		}
		for (int j=1;j<n;j++)
			e[j]=true;
		for (int j=1;j<=n;j++)
			ans[j]=n+1;
		bl(1);
		for (int i=1;i<=n;i++)
			printf("%d ",ans[i]);
		printf("\n");
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
