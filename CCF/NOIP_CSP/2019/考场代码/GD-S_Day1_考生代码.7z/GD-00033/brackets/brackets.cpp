#include<cstdio>
#include<cstring>
#include<string.h>
using namespace std;
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n;
	int a[200000],ans[200000],sum=0;
	scanf("%d\n",&n);
	char s;
	bool b[10000];
	for (int i=1;i<=n;i++){
		scanf("%c",&s);
		if (s=='(') b[i]=true;
		else b[i]=false;
	}
	for (int i=2;i<=n;i++)
		scanf("%d",&a[i]);
	for (int i=1;i<=n;i++){
		int z=0,y=0;
		for (int j=i;j<=n;j++){
			if (b[j]) z++;
			else y++;
			if (y>z) break;
			if (y>(n-i+1)/2) break;
			if (y==z)
				for (int k=j;k<=n;k++)
					ans[k]++;
		}
	}
	for (int i=2;i<=n;i++)
		sum^=(i*ans[i]);
	printf("%d\n",sum);
	fclose(stdin);fclose(stdout);
	return 0;
}
