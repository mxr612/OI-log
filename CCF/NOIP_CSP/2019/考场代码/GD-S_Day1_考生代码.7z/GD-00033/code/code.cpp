#include<cstdio>
using namespace std;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	int n;
	long long m,ans=1;
	scanf("%d%lld",&n,&m);
	for (int i=1;i<=n-2;i++)
		ans=ans*2;
	ans=ans*2-1;
	bool f=true;
	for (int i=n;i>=1;i--)
	{
		if (m<=ans){
			if (f) printf("0");
			else printf("1");
			f=true;
		}
		else {
			if (f) printf("1");
			else printf("0");
			m=m-ans-1;
			f=false;
		}
		ans=(ans-1)/2;
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
