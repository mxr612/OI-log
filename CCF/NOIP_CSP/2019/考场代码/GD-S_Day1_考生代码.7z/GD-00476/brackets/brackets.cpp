#include <bits/stdc++.h>
using namespace std;
const int maxt = 1e5+20;
struct node
{
	
	bool is_l;
	int nxtl;
	int nxtr;
}tree[maxt];
bool vis[maxt];
stack<bool> stk;
queue<bool> q;
int x;
int n;
long long ans;

void search(int p)
{
	if(p!=1) 
	{
		for(int i = 1;i<=n;i++)
		{
			if(vis[i]) q.push(i);
		}
		
		while(!q.empty())
		{
			if(tree[q.front()].is_l==true) stk.push(1);
			else stk.pop();
		}
		if(stk.empty()) ans++;
		
		
	}
	if(tree[p].nxtl==0&&tree[p].nxtr==0) return;
	if(tree[p].nxtl!=0)
	{
		vis[tree[p].nxtl] = true;
		search(tree[p].nxtl);
		vis[tree[p].nxtl] = false;
	 } 
	if(tree[p].nxtr!=0)
	{
		 vis[tree[p].nxtr] = true;
		 search(tree[p].nxtr);
		 vis[tree[p].nxtr] = false;
	}
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	getchar();
	for(int i = 1;i <= n;i++)
	{
		char tmp;
		tmp = getchar();
		cout<<"tmp = "<<(char)tmp<<endl;
		if(tmp=='(') tree[i].is_l = true;
		else tree[i].is_l = false;
		
	}
	if(tree[1].is_l == false) 
	{
		cout<<0<<endl;
		return 0;
	}
	for(int i = 2;i <= n ;i++)
	{
		cin>>x;
		if(tree[x].nxtl) tree[x].nxtr = i;
		else tree[x].nxtl = i;
		
	}
	search(1);
	cout<<ans<<endl;
	return 0;
}
