#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,k;
struct dat
{
	vector<char> v;
}data[15000];
dat buf[15000];
void work()
{
	for(int i = 2;i <= n;i++)
	{
		for(int j = 1;j <= pow(2,i-1);j++)
		{
			int power = pow(2,i);
			data[j].v.clear();
			data[1+power-j].v.clear();
			for(int k = 0;k < buf[j].v.size();k++)
			{
				data[j].v.push_back(buf[j].v[k]);
				data[1+power-j].v.push_back(buf[j].v[k]);
				
			}
			data[j].v.push_back(0);
			data[1+power - j].v.push_back(1);
			int l = 1;
		}
		for(int j = 1;j <= pow(2,i);j++)
		{
			buf[j].v.clear();
			for(int k = 0;k < data[j].v.size();k++)
			{
				buf[j].v.push_back(data[j].v[k]);
			}
		}
	}
}
int main(int argc, char const *argv[])
{
	 freopen("code.in" ,"r",stdin);
	 freopen("code.out","w",stdout);
	data[1].v.push_back(0);
	data[2].v.push_back(1);
	buf[1].v.push_back(0);
	buf[2].v.push_back(1);
	cin>>n>>k;
	
//	cout<<endl;
	work();


		for(int i = data[k+1].v.size() -1;i >= 0;i--)
		{
		cout<<(int)data[k+1].v[i];
		}

	
	
	return 0;
}
