#include<iostream>
#include<cstdio>
#include<fstream>
#include<cstring>
	using namespace std;
struct Edg
{
	int u,v;
}e[5005];
	int n=0,s[5005],w[5005],t[5005],t1[5005],ans[5005];
	bool book[5005];
void dfs(int x)
{
	if(x>n-1)
	{
		for(int i=1;i<=n;i++) t[i]=w[i];
		for(int i=1;i<=n-1;i++)
			swap(t[e[s[i]].u],t[e[s[i]].v]);
		for(int i=1;i<=n;i++) t1[t[i]]=i;
		bool hhh=false;
		for(int i=1;i<=n;i++)
		{
			if(ans[i]<t1[i]) break;
			if(ans[i]>t1[i]) {hhh=true;break;}
		}
		if(hhh)
			for(int i=1;i<=n;i++) ans[i]=t1[i];
		return;
	}
	for(int i=1;i<=n-1;i++)
	{
		if(book[i]) continue;
		s[x]=i;
		book[i]=true;
		dfs(x+1);
		book[i]=false;
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T=0;
	scanf("%d",&T);
	for(int G=1;G<=T;G++)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++) scanf("%d",&w[i]);
		for(int i=1;i<=n-1;i++)
			scanf("%d%d",&e[i].u,&e[i].v);
		ans[1]=1000000;
		dfs(1);
		for(int i=1;i<=n;i++) printf("%d ",ans[i]);
		printf("\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
