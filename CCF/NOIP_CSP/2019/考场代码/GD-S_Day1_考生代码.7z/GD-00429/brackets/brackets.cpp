#include<iostream>
#include<cstdio>
#include<fstream>
#include<cstring>
	using namespace std;
struct Edg
{
	int lst;
	int ed;
}e[1000005];
	int ne=0,top=0,top0=0,fa[700005];
	int nte[700005],s[700005];
	int sta[700005],sta0[700005];
	char w[700005];
	long long f[700005];
void NewEdg(int u,int v)
{
	ne++;
	e[ne].lst=nte[u];
	e[ne].ed=v;
	nte[u]=ne;
}
void dfs(int x)
{
	for(int i=nte[x];i;i=e[i].lst)
	{
		int k=-1,y=e[i].ed;
		sta[++top]=y;
		f[y]=f[x];
		if(w[y]=='(')
			sta0[++top0]=y,s[y]=0;
		else if(top0>=1)
		{
			k=sta0[top0--];
			s[y]=s[fa[k]]+1;
			f[y]+=s[y];
		}
		dfs(y);
		if(w[y]=='(') top0--;
		if(k!=-1) sta0[++top0]=k;
		top--;
	}
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		w[i]=getchar();
		while(w[i]!='('&&w[i]!=')') w[i]=getchar();
	}
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&fa[i]);
		NewEdg(fa[i],i);
	}
	f[0]=s[0]=0;
	f[1]=s[1]=0;
	sta[++top]=1;
	if(w[1]=='(') sta0[++top0]=1;
	dfs(1);
	long long ans=0;
	for(int i=1;i<=n;i++) ans=(ans^(i*f[i]));
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
