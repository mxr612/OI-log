#include<iostream>
#include<cstdio>
#include<fstream>
	using namespace std;
	unsigned long long top=0,sta[10005],g[10005];
unsigned long long JiSuan1(unsigned long long x,unsigned long long y)
{
	if(x==1) return y;
	unsigned long long mid=((unsigned long long)1<<(x-1));
	if(y<=mid)
	{
		sta[++top]=0;
		return JiSuan1(x-1,y);
	}
	sta[++top]=1;
	return JiSuan1(x-1,(mid<<1)-y+1);
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	unsigned long long n=0,k=0;
	cin>>n>>k; k++;
	unsigned long long ans=JiSuan1(n,k)-1;
	for(unsigned long long i=top;i>=1;i--)
		if(sta[i]==1) ans=ans+((unsigned long long)1<<(top-i+1));
	unsigned long long s=0;
	while(ans)
	{
		g[++s]=(ans&1);
		ans>>=1;
	}
	s=max(s,n);
	for(unsigned long long i=s;i>=1;i--) cout<<g[i];
	fclose(stdin);
	fclose(stdout);
	return 0;
}
