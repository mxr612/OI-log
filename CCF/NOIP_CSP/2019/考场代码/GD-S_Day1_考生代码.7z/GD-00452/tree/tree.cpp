#include<bits/stdc++.h>
#define N 2005
using namespace std;
int T;
int n,val[N],b[N],ax[N],ay[N];
bool vis[N];
string ans;

int ls[N],cnt;
struct node
{
	int v,next;
}a[N*2];
void add(int x,int y)
{
	a[++cnt].v=y;a[cnt].next=ls[x];ls[x]=cnt;
}

void dfs(int lev)
{
	if(lev>=n)
	{
	  int arr[N],ff[N];
	  memcpy(arr,val,sizeof(val));
	  for(int i=1;i<n;i++)
	  {
	  	swap(arr[ax[b[i]]],arr[ay[b[i]]]);
	  }
	  for(int i=1;i<=n;i++)
	   ff[arr[i]]=i;
	  string tmp="";
	  for(int i=1;i<=n;i++)
	   tmp+=ff[i];
	  ans=min(ans,tmp);
	  return;
	}
	for(int i=1;i<n;i++)
	 if(!vis[i])
	 {
	   b[lev]=i;
	   vis[i]=1;
	   dfs(lev+1);
	   vis[i]=0;
	 }
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>T;
	while(T--)
	{
	  memset(ls,0,sizeof(ls));cnt=0;
	  cin>>n;
	  ans="";for(int i=1;i<=n;i++) ans+='z';
	  for(int i=1,x;i<=n;i++) cin>>x,val[x]=i;
	  for(int i=1,x,y;i<n;i++)
	  {
	  	cin>>x>>y;
	  	ax[i]=x;ay[i]=y;
	  	add(x,y),add(y,x);
	  }
	  if(n<=10)
	   dfs(1);
	  for(int i=0;i<ans.size();i++)
	   cout<<(int)ans[i]<<" ";
	  cout<<endl;
	}
	return 0;
}
