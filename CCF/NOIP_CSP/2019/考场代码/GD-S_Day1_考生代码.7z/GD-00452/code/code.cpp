#include<bits/stdc++.h>
#define ll long long
using namespace std;
unsigned ll n,k;
unsigned ll f[70];
void dfs(unsigned ll lev,unsigned ll num)
{
	if(lev<=0) return;
	unsigned ll x,y;
	x=num;
	y=f[lev]-1-num;
	if(x<y) cout<<0;else cout<<1;
	dfs(lev-1,min(x,y));
	return;
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	f[0]=1;
	for(unsigned ll i=1;i<=63;i++) f[i]=f[i-1]*2;
	f[64]=(f[63]-1)*2+1;
	dfs(n,k);
	return 0;
}
