#include<bits/stdc++.h>
#define ll long long
#define N 500005
using namespace std;
int n;
ll ans;
int s[N],last[N],f[N];
char c[N];
bool lian=1;

int ls[N],cnt;
struct node
{
	int v,next;
}a[N*2];
void add(int x,int y)
{
	a[++cnt].v=y;a[cnt].next=ls[x];ls[x]=cnt;
}

void dfs(int x,int lev,int sum)
{
	int ss=0;
	s[lev]=c[x]=='('?1:2;
	if(s[lev]==1) last[lev]=lev;
	else
	{
	  last[lev]=last[lev-1];
	  if(last[lev]!=0)
	  {
	  	ss+=f[last[lev]-1]+1;
		last[lev]=last[last[lev]-1];
		f[lev]=f[last[lev]]+1;
	  }
	}
	ans=ans^(ll)(x*(ll)(ss+sum));
	for(int i=ls[x];i;i=a[i].next)
	{
	  dfs(a[i].v,lev+1,ss+sum);
	}
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++) cin>>c[i];
	for(int i=2,x;i<=n;i++)
	{
	  cin>>x;
	  if(x!=i-1) lian=0;
	  add(x,i);
	}
	if(lian)
	{
	  ll ss=0,sum=0;
	  for(int i=1;i<=n;i++)
	  {
	  	ss=0;
	  	s[i]=c[i]=='('?1:2;
	  	if(s[i]==1) last[i]=i;
		else
		{
	  	  last[i]=last[i-1];
	  	  if(last[i]!=0)
	  	  {
	  	    ss+=f[last[i]-1]+1;
	  	    f[i]=f[last[i]-1]+1;
			last[i]=last[last[i]-1];
	  	  }
		}
	    ans=ans^(ll)(i*(ll)(ss+sum));
	    sum+=ss;
	  }
	}
	else 
	 dfs(1,1,0);
	cout<<ans;
	return 0;
}
