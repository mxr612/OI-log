#include<iostream>
#include<cstdio>
#include<queue>
using namespace std;

struct edge
{
	int v,g;
};

vector<int> G[500010]; 

queue<edge> Q;

long long ans=0;
int n,fa[500010],len[500010];
char tree[500010],key[500010][20];
bool vis[500010]={false};


void bfs()
{
	edge st;
	st.v=1;
	st.g=1;
	//memset(key,sizeof(key));
	vis[1]=true;
	Q.push(st);
	while(!Q.empty())
	{
		edge news=Q.front();
		edge td;
		Q.pop();
		vis[news.v]=true;
		for(int i=0;i<G[news.v].size();i++)
		{
			if(!vis[G[news.v][i]])
			{
				td.v=G[news.v][i];
				td.g=news.g+1;
				len[td.v]=td.g;
				for(int r=1;r<td.g;r++)
				{
					key[td.v][r]=key[news.v][r];
				}
				key[td.v][td.g]=tree[td.v];
				
				Q.push(td);
			}
		}
	}
}
 
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	for(int a=1;a<=n;a++)
	{
		scanf("%c",&tree[a]);
		while(tree[a]!='('&&tree[a]!=')')
		{
			scanf("%c",&tree[a]);
		}
		
	}
	key[1][1]=tree[1];
	len[1]=1;
	for(int a=2;a<=n;a++)
	{
		scanf("%d",&fa[a]);
		G[fa[a]].push_back(a);
	}
	bfs();
	int kl[10];
	for(int a=1;a<=n;a++)
	{
		int x=0,y=0,tot=0,dis=0;
		bool pd=false;
		for(int b=1;b<=len[a];b++)
		{
			if(key[a][b]=='(')
			{
				x++;
			}
			if(key[a][b]==')')
			{
				if(key[a][b-1]=='('&&x!=0)
				{
					tot++;
					pd=true;
					dis=b-1;
				}
				else
				{
					if(pd)
					{
						if(key[a][dis-1]=='(')
						{
							tot++;
							pd=true;
							dis=dis-1;
						}
						else
						{
							dis=0;
							pd=false;
							x=0;
						}
					}
					else
					{
						x=0;
					}		
				}
				y++;
			}
		}
		if(ans==0)
		{
			ans=tot*a;
		}
		else
		{
			ans=ans^(a*tot);
		}
		kl[a]=tot;
	}
	/*for(int a=1;a<=n;a++)
	{
		printf("%d ",kl[a]);
	}*/
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
