#include<iostream>
#include<cstdio>
using namespace std;

int n,len[500000],p=0;
unsigned long long k=1,h=1,mid;

int main()//ע����ʼ��0 
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%lld",&n,&k);
	k=k+n-1;
	while(k!=0)
	{
		int s=k%2;
		p++;
		if(s==0)
		{
			len[p]=0;
		}
		else
		{
			len[p]=1;
		}
		k=k/2;
	}
	if(p<n)
	{
		for(int a=1;a<n-p;a++)
		{
			printf("0");
		}
	}
	for(int a=1;a<=p;a++)
	{
		printf("%d",len[a]);
	}
	printf("\n");
	fclose(stdin);
	fclose(stdout);
	return 0;
}
