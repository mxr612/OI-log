#include<iostream>
#include<cstdio>
#include<vector>
#include<cstring>
using namespace std;


vector<int> G[2010];
int t,n,pt[2010],ans[2010];
long long qt=9999999999999;
bool pd[2010][2010];


void dfs(int k)
{
	if(k==0)
	{
		long long op=0,f=1;
		for(int a=n;a>=1;a--)
		{
			op=op+pt[a]*f;
			f=f*10;
		}
		if(op<qt)
		{
			qt=op;
			for(int a=1;a<=n;a++)
			{
				ans[a]=pt[a];
			}
		}
		return;
	}
	else
	{
		for(int i=1;i<=n;i++)
		{
			/*if(k==4)
			{
				cout<<i<<endl;
			}*/
			for(int j=0;j<G[i].size();j++)
			{
				/*if(k==4)
				{
					cout<<i<<' '<<G[i][j]<<endl;
				}*/
				if(!pd[i][G[i][j]])
				{
					/*if(k==4)
					{
						cout<<"true"<<endl;
					}*/
					int u;
					pd[i][G[i][j]]=true;
					pd[G[i][j]][i]=true;
					u=pt[i];
					pt[i]=pt[G[i][j]];
					pt[G[i][j]]=u;
					dfs(k-1);
					pd[i][G[i][j]]=false;
					pd[G[i][j]][i]=false;
					u=pt[i];
					pt[i]=pt[G[i][j]];
					pt[G[i][j]]=u;
				}
			}
		}
	}
	return;
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	for(int ac=1;ac<=t;ac++)
	{
		memset(pt,0,sizeof(pt));
		qt=9999999999999;
		memset(ans,0,sizeof(ans));
		memset(G,0,sizeof(G));
		scanf("%d",&n);
		for(int a=1;a<=n;a++)
		{
			scanf("%d",&pt[a]);//pt[a]Ϊa���ڱ�� 
		}
		for(int a=1;a<n;a++)
		{
			int x,y;
			scanf("%d%d",&x,&y);
			G[pt[x]].push_back(pt[y]);
			G[pt[y]].push_back(pt[x]);
		}
		dfs(n-1);
		for(int a=1;a<=n;a++)
		{
			printf("%d ",ans[a]);
		}
		printf("\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
