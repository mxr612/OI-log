#include<bits/stdc++.h>

using namespace std;
#define re register

inline long long read(){
	unsigned long long x=0;bool f=1;char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=0;c=getchar();}
	while(c<='9'&&c>='0'){x=(x<<3)+(x<<1)+(c-'0');c=getchar();}
	return f?x:-x;
} 
#define rr read()
unsigned long long f[70];
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	int n=rr;
	unsigned long long k=rr;
	f[0]=1;
	for(int i=1;i<=n;i++){
		f[i]=f[i-1]*2;
	}
	int cnt=0;
	while(n!=0){
		if(cnt%2==0){
			if(k>=f[n-1]){
				cout<<1;
				k-=f[n-1];
				cnt++;
			}
			else{
				cout<<0;
			}
		}
		else{
			if(k>=f[n-1]){
				cout<<0;
				k-=f[n-1];
			}
			else{
				cout<<1;
				cnt++;
			}
		}
		n--;
	}
	return 0;
}
