#include<bits/stdc++.h>

using namespace std;
#define re register

inline long long read(){
	unsigned long long x=0;bool f=1;char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=0;c=getchar();}
	while(c<='9'&&c>='0'){x=(x<<3)+(x<<1)+(c-'0');c=getchar();}
	return f?x:-x;
}
long long ans=0;
struct treepoint{
	int type;//0==(  ,   1==)
	int last;// ǰ�滹�м�����������>��ʱͬ����0; 
	int nan;//now rignt son ans;
	int st;//right start;
}tp[500005];
#define rr read()
vector<int>g[500005];
queue<int> s;
int f[500005];
void bfs(){
	int x=1;
	if(tp[x].type==0)tp[x].last++;
	while(s.size()){
		x=s.front();
		s.pop();
		long long nn=tp[x].nan*x;
		ans=ans^nn;
		int le=g[x].size();
		for(int i=0;i<le;i++){
			if(tp[g[x][i]].type==0){tp[g[x][i]].last=tp[x].last+1;tp[g[x][i]].nan=tp[x].nan;tp[g[x][i]].st=tp[x].st;}
			if(tp[g[x][i]].type==1){
				if(tp[x].last>=1){
					if(tp[x].type==1){
						tp[g[x][i]].last=tp[x].last-1;
						tp[g[x][i]].st=tp[x].st;
						tp[g[x][i]].nan=tp[x].nan+1;
					}
					else{
						int cnt=1;
						int up=g[x][i];
						while(cnt){
							up=f[g[x][i]];
							if(tp[up].type==1)cnt++;
							else{
								cnt--;
							}
						}
						if(up==1){
							tp[g[x][i]].st=1;
							tp[g[x][i]].last=tp[x].last-1;
							tp[g[x][i]].nan=tp[x].nan+1;
						}
						else{
							if(tp[f[up]].type==1){
								tp[g[x][i]].st=tp[f[up]].st+1;
								tp[g[x][i]].nan=tp[x].nan+1+tp[f[up]].st;
								tp[g[x][i]].last=tp[x].last-1;
							}
							else{
								tp[g[x][i]].st=1;
								tp[g[x][i]].nan=tp[x].nan+1;
								tp[g[x][i]].last=tp[x].last-1;
							}
						}
					}
				}
				else{
					tp[g[x][i]].last=0;
					tp[g[x][i]].nan=tp[x].nan;
					tp[g[x][i]].st=0;
				}
			}
			s.push(g[x][i]);
		}
	}
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n=rr;
	char c[500005];
	scanf("%s",c);
	for(re int i=0;i<n;i++){
		if(c[i]=='('){
			tp[i+1].type=0;
		}
		else if(c[i]==')'){
			tp[i+1].type=1;
		}
	}
	re int x=0;
	for(re int i=2;i<=n;i++){
		x=rr;
		f[i]=x;
		g[x].push_back(i);
	}
	s.push(1);
	bfs();
	cout<<ans;
	return 0;
}
//5
//(()()
//1 1 2 2
