#include<bits/stdc++.h>

using namespace std;
#define re register

inline long long read(){
	unsigned long long x=0;bool f=1;char c=getchar();
	while(c>'9'||c<'0'){if(c=='-')f=0;c=getchar();}
	while(c<='9'&&c>='0'){x=(x<<3)+(x<<1)+(c-'0');c=getchar();}
	return f?x:-x;
}
int n;
#define rr read()
int pt[2005];
struct node{
	int u,v,nt;
}edg[2005];
int h[2005],size=0;
string ns;
bool f=0;
void ade(int u,int v){
	size++;
	edg[size].nt=h[u];
	edg[size].v=v;
	edg[size].u=u;
	h[u]=size;	
}
void st(){
	memset(h,-1,sizeof(h));
	size=0;
	f=0;
}
bool used[2005];
void ans(){
	if(f==0){
		string s;
		ns=s;
		for(int i=1;i<=n;i++){
			s=pt[i]-'0';
			ns=ns+s;
		}
	}
	else{
		string s;
		string ss;
		for(int i=1;i<=n;i++){
			s=pt[i]-'0';
			ss=ss+s;
			if(ss>ns)return;
		}
	}
}
void dfs(int x,int y){
	if(y==size){
		swap(pt[edg[x].u],pt[edg[x].v]);
		ans();
		swap(pt[edg[x].u],pt[edg[x].v]);
		return;
	}
	used[x]=1;
	swap(pt[edg[x].u],pt[edg[x].v]);
	for(int i=1;i<=size;i++){
		if(!used[i]){
			dfs(i,y+1);
		}
	}
	swap(pt[edg[x].u],pt[edg[x].v]);
	used[x]=0;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int t=rr;
	for(int iii=1;iii<=t;iii++){
		st();
		n=rr;
		for(int i=1;i<=n;i++){
			int x=rr;
			pt[x]=i;
		}
		for(int i=1;i<n;i++){
			int u=rr,v=rr;
			ade(u,v);
		}
		for(int i=1;i<+size;i++)
			dfs(i,1);
		for(int i=1;i<=n;i++){
			cout<<(ns[i-1]+'0')<<' ';
		}
	}
	return 0;
}

