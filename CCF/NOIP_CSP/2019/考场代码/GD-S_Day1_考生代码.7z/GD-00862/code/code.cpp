#include <cstdio>
#include <cstring>
#include <iostream>
#include <algorithm>
using namespace std;
typedef unsigned long long ull;

const int N=70;
int n;
ull k,power[N];

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	power[0]=1;
	for (int i=1;i<=63;i++)
		power[i]=power[i-1]*2LL;
	cin>>n>>k;
	for (int i=n-1;i>=0;i--)
	{
		if (k>=power[i])
		{
			k=power[i]-1-(k-power[i]);
			putchar(49);
		}
		else putchar(48);
	}
	return 0;
}
