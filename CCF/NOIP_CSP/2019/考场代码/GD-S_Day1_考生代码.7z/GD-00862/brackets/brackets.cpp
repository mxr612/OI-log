#include <stack>
#include <cstdio>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;
typedef long long ll;

const int N=500010,Inf=1e9;
int n,tot,a[N],cnt[N][3],head[N];
ll ans[N],orz;
char ch;
vector<int> pos[N*2];
stack<int> del;

struct edge
{
	int next,to;
}e[N];

void add(int from,int to)
{
	e[++tot].to=to;
	e[tot].next=head[from];
	head[from]=tot;
}

int binary(int x,int tp)
{
	int l=0,r=pos[x].size(),mid,res;
//	for (int i=l;i<r;i++) printf("%d ",pos[x][i]);putchar(10);
	while (l<=r)
	{
		mid=(l+r)>>1;
		if (pos[x][mid]>=tp) r=mid-1,res=mid;
			else l=mid+1;
	}
	return res;
}

void dfs(int x,int fa)
{
	cnt[x][1]=cnt[fa][1]; cnt[x][2]=cnt[fa][2];
	cnt[x][a[x]]++;
	int s=cnt[x][1]-cnt[x][2]+N,pp=-1;
	if (a[x]==1) del.push(x);
	else
	{
		if (del.size()>1)
		{
			pp=del.top();
			del.pop();
		}
		int tp=del.top();
		pos[s].push_back(Inf);
		ans[x]=pos[s].size()-binary(s,tp)-1;
		pos[s].pop_back();
	}
	ans[x]+=ans[fa];
	orz^=1LL*x*ans[x];
	pos[s].push_back(x);
	for (int i=head[x];~i;i=e[i].next)
		dfs(e[i].to,x);
	pos[s].pop_back();
	if (del.top()==x) del.pop();
	if (pp!=-1) del.push(pp);
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	memset(head,-1,sizeof(head));
	scanf("%d",&n);
	for (int i=1;i<=n;i++)
	{
		//while (ch=getchar()) if (ch=='('||ch==')') break;
		while (1)
		{
			ch=getchar();
			if (ch=='('||ch==')') break;
		}
		if (ch=='(') a[i]=1;
			else a[i]=2;
	}
	for (int i=2,x;i<=n;i++)
	{
		scanf("%d",&x);
		add(x,i);
	}
	del.push(-1);pos[N].push_back(0);
	dfs(1,0);
	printf("%lld\n",orz);
//	for (int i=1;i<=n;i++)
//		printf("%lld ",ans[i]);
	return 0;
}
