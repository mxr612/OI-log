#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int N=2010,Inf=1e9;
int T,tot,n,cpy[N],num[N],in[N],head[N],qwq[N],ans[N];
bool used[N];

struct edge
{
	int next,from,to;
}e[N*2];

struct Line
{
	int num,pos;
}line[N];

void add(int from,int to)
{
	e[++tot].to=to;
	e[tot].from=from;
	e[tot].next=head[from];
	head[from]=tot;
}

bool check1()
{
	int cnt=0,pos,k=0;
	for (int i=1;i<=n;i++)
	{
		if (in[i]>2) return 0;
		if (in[i]==1) cnt++,pos=i;
		if (cnt>2) return 0;
	}
	memset(line,0,sizeof(line));
	for (int i=pos,fa=0;;)
	{
		line[++k].num=num[i];
		line[k].pos=i;
		if (in[i]==1 && i!=pos) break;
		for (int j=head[i];~j;j=e[j].next)
			if (e[j].to!=fa)
			{
				fa=i;
				i=e[j].to;
				break;
			}
	}
	return 1;
}

void clac1(int l,int r)
{
	if (l>r) return;
	int minnum=Inf,posnum,minid=Inf,posid;
	for (int i=l;i<=r;i++)
	{
		if (line[i].num<minnum)
		{
			minnum=line[i].num;
			posnum=i;
		}
		if (line[i].pos<minid)
		{
			minid=line[i].pos;
			posid=i;
		}
	}
	if (posnum<=posid)
	{
		for (int i=posnum;i<posid;i++)
			swap(line[i].num,line[i+1].num);
		clac1(l,posnum-1); clac1(posid+1,r);
	}
	else
	{
		for (int i=posnum;i>posid;i--)
			swap(line[i].num,line[i-1].num);
		clac1(l,posid-1); clac1(posnum+1,r);
	}
}

bool check()
{
	for (int i=1;i<=n;i++)
		cpy[num[i]]=i;
	for (int i=1;i<n;i++)
		swap(cpy[e[qwq[i]*2].to],cpy[e[qwq[i]*2].from]);
	for (int i=1;i<=n;i++)
		if (ans[i]<cpy[i]) return 0;
	for (int i=1;i<=n;i++)
		ans[i]=cpy[i];
}

void dfs(int x)
{
	if (x==n)
	{
		check();
		return;
	}
	for (int i=1;i<n;i++)
		if (!used[i])
		{
			used[i]=1;
			qwq[x]=i;
			dfs(x+1);
			used[i]=0;
		}
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while (T--)
	{
		memset(head,-1,sizeof(head));
		memset(in,0,sizeof(in));
		tot=0;
		scanf("%d",&n);
		for (int i=1,x;i<=n;i++)
		{
			scanf("%d",&x);
			num[x]=i;
		}
		for (int i=1,x,y;i<n;i++)
		{
			scanf("%d%d",&x,&y);
			add(x,y); add(y,x);
			in[x]++; in[y]++;
		}
		if (n<=10)
		{
			for (int i=1;i<=n;i++)
				ans[i]=Inf;
			dfs(1);
			for (int i=1;i<=n;i++)
				printf("%d ",num[i]);
			putchar(10);
			continue;
		}
		if (check1()) 
		{
			clac1(1,n);
			for (int i=1;i<=n;i++)
				num[line[i].pos]=line[i].num;
			for (int i=1;i<=n;i++)
				printf("%d ",num[i]);
			putchar(10);
			continue;
		}
	}
}
/*
1 5
3 4 2 1 5
1 2
2 3
3 4
4 5
*/
