#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

struct node
{
	long father;
	char current;
	std::vector<long> sons;
};
std::vector<node> tree;
std::vector<char> target;
long n;

long check(long l, long r)
{
	long t = 0;
	for (long i = r; i >= l; i--)
	{
		if (target[i] == '(')
			t++;
		if (target[i] == ')')
			t--;
		if (t < 0)
			return 0;
	}
	if (t > 0)
		return 0;
	return 1;
}

inline long min(long a, long b)
{
	return a < b ? a : b;
}

int main()
{
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	scanf("%ld", &n);
	char c;
	node temp;
	temp. current = 0;
	for (long i = 0; i < n; i++)
	{
		c = getchar();
		while (c != '(' && c != ')')
			c = getchar();
		temp. current = c;
		tree. push_back(temp);
	}
	tree[0]. father = -1;
	long long ans = 0;
	for (long i = 1; i < n; i++)
	{
		long father, count = 0;
		scanf("%ld", &father);
		father--;
		tree[father]. sons. push_back(i);
		tree[i]. father = father;
		target. clear();
		for (long j = i; j != -1; j = tree[j]. father)
			target. push_back(tree[j]. current);
		for (long j = 0; j < target. size() - 1; j++)
			for (long k = j + 1; k < target. size(); k++)
				count += check(j, k);
		ans ^= count * (i + 1LL);
	}
	std::cout << ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
