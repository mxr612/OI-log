#include <cstring>
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <vector>

struct node
{
	long in, key, per;
	std::vector<long> conn;
}graph[2000];

bool cmp(node x, node y)
{
	return x. key < y. key;
}

int main()
{
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	long t;
	scanf("%ld", &t);
	while (t--)
	{
		long n;
		scanf("%ld", &n);
		for (long i = 0; i < n; i++)
		{
			scanf("%ld", &graph[i]. key);
			graph[i]. per = i;
			graph[i]. conn. clear();
			graph[i]. in = 0;
		}
		for (long i = 0; i < n - 1; i++)
		{
			long x, y;
			scanf("%ld%ld", &x, &y);
			x--;
			y--;
			graph[x]. in++, graph[y]. in++;
			graph[x]. conn. push_back(y);
			graph[y]. conn. push_back(x);
		}
		long max = -1, theone = -1;
		for (long i = 0; i < n; i++)
		{
			if (graph[i]. in == 1)
				theone = i;
			if (graph[i]. in == n-1)
				max = i;
		}
		if (max != -1)
		{
			std::sort(graph, graph + n, cmp);
			for (long i = 0; i < n; i++)
				std::cout << graph[i]. per + 1 << ' ';
			std::cout << std::endl;
			continue;
		}
		if (theone != -1)
		{
			std::vector<std::pair<long, long> > line;
			long previous = -1, i = theone;
			line. push_back(std::make_pair(theone, graph[theone]. key));
			for (long k = 0; k < n - 1; k++)
			{
				long j;
				for (j = 0; j < graph[i]. conn. size(); j++)
				{
					if (graph[i]. conn[j] != previous)
						break;
				}
				previous = i;
				i = graph[i]. conn[j];
				line. push_back(std::make_pair(i, graph[i]. key));
			}
			long ptr = 0;
			previous = -1;
			while (ptr != n)
			{
				for (long i = ptr; i < n; i++)
					if (line[i]. second < line[ptr]. second)
						ptr = i;
				std::cout << graph[line[ptr]. first]. per + 1 << ' ';
				for (long i = previous + 1; i < ptr; i++)
					std::cout << graph[line[i]. first]. per + 1 << ' ';
				previous = ptr;
				ptr++;
			}
			std::cout << std::endl;
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
