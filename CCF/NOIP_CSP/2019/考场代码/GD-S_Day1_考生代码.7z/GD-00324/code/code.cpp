#include <iostream>
#include <cstring>
#include <cstdio>

long code[64], n, ans[64];
unsigned long long k, tmp;

int main()
{
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	std::cin >> n >> k;
	long i = 63;
	tmp = k;
	while (tmp != 0)
	{
		code[i] = tmp % 2;
		tmp /= 2;
		i--;
	}
	for (long i = 63; i > 0; i--)
	{
		if (code[i - 1] == 1)
			ans[i] = 1 - code[i];
		else
			ans[i] = code[i];
	}
	for (long i = 64 - n; i < 64; i++)
		std::cout << ans[i];
	fclose(stdin);
	fclose(stdout);
	return 0;
}
