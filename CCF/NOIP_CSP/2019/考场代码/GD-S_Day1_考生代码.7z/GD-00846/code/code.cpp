#include<cstdio>

using namespace std;

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	
	int n=0;unsigned long long k=0;
	scanf("%d%llu",&n,&k);
	
	for(int i=n-1;i>=0;i--)
	{
		if(k&(1ull<<i))
		{
			putchar('1');
			k^=(1ull<<i);
			k=(1ull<<i)-1-k;
		}
		else
		{
			putchar('0');
		}
	}
	
	return 0;
}
