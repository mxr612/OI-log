#include<cstdio>
#include<cstring>
#include<vector>
#include<algorithm>

using namespace std;

int a[3000],num[3000];
int x[3000],y[3000];
vector<int> ed[3000];

int ans[3000],tmp[3000],tmp_num[3000];
int bf[20];

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	int t=0;scanf("%d",&t);
	while(t--)
	{
		int n=0;scanf("%d",&n);
		memset(a,0,sizeof(a)),memset(num,0,sizeof(num)),
		memset(ans,0,sizeof(ans)),memset(tmp,0,sizeof(tmp)),memset(tmp_num,0,sizeof(tmp_num));
		for(int i=1;i<=n;i++)ed[i].clear();
		
		for(int i=1;i<=n;i++){scanf("%d",&a[i]);num[a[i]]=i;}
		for(int i=1;i<n;i++)
		{
			scanf("%d%d",&x[i],&y[i]);
			ed[x[i]].push_back(y[i]),ed[y[i]].push_back(x[i]);
		}
		if(n<=10)
		{
			for(int i=1;i<n;i++)bf[i]=i;
			do
			{
				for(int i=1;i<=n;i++)tmp_num[i]=num[i];
				for(int i=1;i<n;i++)swap(tmp_num[x[bf[i]]],tmp_num[y[bf[i]]]);
				for(int i=1;i<=n;i++)tmp[tmp_num[i]]=i;
				bool f=false;
				if(ans[1]==0)f=true;
				else
				{
					for(int i=1;i<=n;i++)
					{
						if(ans[i]<tmp[i])break;
						if(ans[i]>tmp[i]){f=true;break;}
					}
				}
				if(f)for(int i=1;i<=n;i++)ans[i]=tmp[i];
			}while(next_permutation(bf+1,bf+n));
			for(int i=1;i<=n;i++)printf("%d ",ans[i]);puts("");continue;
		}
		for(int i=1;i<=n;i++)printf("%d ",i);puts("");
	}
	return 0;
}
