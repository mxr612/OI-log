#include<cstdio>
#include<vector>
#include<queue>

using namespace std;

char brc[600000];

int fa[600000];
vector<int> sons[600000];

int pos[600000];
long long cnt_bk[600000],k[600000];

void calc(int u)
{
	if(brc[u]=='('){pos[u]=cnt_bk[u]=0;}
	else
	{
		int p=fa[u];
		while(p&&brc[p]==')')
		{
			p=fa[pos[p]];
		}
		if(!p){pos[u]=cnt_bk[u]=0;}
		else
		{
			pos[u]=p;
			cnt_bk[u]=cnt_bk[fa[p]]+1;
		}
	}
	k[u]=k[fa[u]]+cnt_bk[u];
}

queue<int> q;
void bfs(int rt)
{
	while(!q.empty())q.pop();
	q.push(rt);
	while(!q.empty())
	{
		int u=q.front();q.pop();
		calc(u);
		for(int i=0;i<sons[u].size();i++)q.push(sons[u][i]);
	}
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	
	int n=0;scanf("%d",&n);
	scanf("%s",brc+1);
	for(int i=2;i<=n;i++){scanf("%d",&fa[i]);sons[fa[i]].push_back(i);}
	
	int rt=1;bfs(rt);
	long long ans=0;
	for(long long i=1;i<=n;i++)ans=ans^(i*k[i]);
	printf("%lld",ans);
	
	return 0;
}
