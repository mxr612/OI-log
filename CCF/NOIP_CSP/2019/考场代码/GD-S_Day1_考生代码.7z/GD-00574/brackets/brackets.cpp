#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int i,j,k,m,n,o,p,l,s,t;
int f[1000005][3],q[500005],ans[500005],kuo[500005],fa[500005],hh[500005];
char ch;
void insert(int x,int y) {f[++t][1]=y,f[t][2]=q[x],q[x]=t;}
long long pr;
void read(int &x)
{
	char ch=getchar();x=0;
	while (ch<'0'||ch>'9') ch=getchar();
	while (ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+ch-48,ch=getchar();
}
void dg(int t,int l,int r,int sum)
{
	if (l<r) sum=0;
	if (t==1) 
	{
		o=p=0;
		if (kuo[t]==0) o=1; else p=1; 
		for (int k=q[t];k;k=f[k][2])
			dg(f[k][1],l+o,r+p,sum);
	} else {
	hh[t]=sum;
	ans[t]+=ans[fa[t]];
	if (kuo[t]&&l>r) ans[t]++;
	if (kuo[t]==0&&kuo[fa[t]]==1) 
	{
		p=sum;if (l!=r) p=0;
		for (int k=q[t];k;k=f[k][2])
			dg(f[k][1],1,0,p);
	} else if (kuo[t]==0&&kuo[fa[t]]==0) {
		for (int k=q[t];k;k=f[k][2])
			dg(f[k][1],l+1,r,sum);
	} else if (kuo[t]==1){ 
		for (int k=q[t];k;k=f[k][2])
			if (!r&&l) dg(f[k][1],l,r+1,sum+1); else dg(f[k][1],l,r+1,sum);
	}
	}
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d\n",&n);
	for (i=1;i<=n;i++) ch=getchar(),kuo[i]=(ch==')');
	for (i=2;i<=n;i++) read(fa[i]),insert(fa[i],i);	
	dg(1,0,0,0);
	pr=ans[1];
	for (i=2;i<=n;i++)
	{
		long long gg=i;gg*=(ans[i]+hh[i]);
		pr=pr^gg;
	}
	printf("%lld\n",pr);
	fclose(stdin);fclose(stdout);
	return 0;
}
