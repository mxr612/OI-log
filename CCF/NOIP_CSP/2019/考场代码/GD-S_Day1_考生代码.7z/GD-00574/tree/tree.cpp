#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
int i,j,k,m,n,o,p,l,s,t,t1,tot,ii;
int f[10005][3],q[5005],d[5005],fa[5005],bz[2005][2005],bz1[2005],ans[2005],dep[2005],bj[2005][2005],ss[2005],fu[2005];
int b[10005][18];
struct node{
	int val,id;
}a[5005];
void read(int &x)
{
	char ch=getchar();x=0;
	while (ch<'0'||ch>'9') ch=getchar();
	while (ch>='0'&&ch<='9') x=(x<<3)+(x<<1)+ch-48,ch=getchar();
}
bool cmp(node x,node y) {return x.val<y.val;}
void insert(int x,int y) {f[++t][1]=y,f[t][2]=q[x],q[x]=t;}
void dg(int t,int faa)
{
	for (int k=q[t];k;k=f[k][2])
	{
		if (f[k][1]!=faa) 
		{
			bj[t][f[k][1]]=++tot;
			b[f[k][1]][0]=fa[f[k][1]]=t;dep[f[k][1]]=dep[t]+1;
			dg(f[k][1],t);
		}
	}
}
int getlca(int x,int y)
{
	if (dep[x]>dep[y]) swap(x,y);
	int k=dep[y]-dep[x];
	for (int i=17;i>=0;i--)
	{
		if (k>=(1<<i)) k-=(1<<i),y=b[y][i];
	}
	if (x==y) return x;
	for (int i=17;i>=0;i--)
		if (b[x][i]!=b[y][i]) x=b[x][i],y=b[y][i];
	return b[x][0];
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	read(t1);
	while (t1--)
	{
		if (t1==2)
		{
			int arga=0;
		}memset(bj,0,sizeof(bj));
		memset(f,0,sizeof(f));memset(q,0,sizeof(q));memset(bz1,0,sizeof(bz1));memset(bz,0,sizeof(bz));memset(b,0,sizeof(b));
		read(n);
		for (i=1;i<=n;i++) read(a[i].val),a[i].id=i;
		sort(a+1,a+n+1,cmp);
		for (i=1;i<=n-1;i++) 
		{
			read(o),read(p);
			insert(o,p),insert(p,o);
		}
		dg(1,0);
		for (i=1;i<=17;i++)	
			for (j=1;j<=n;j++)
				b[j][i]=b[b[j][i-1]][i-1];
		for (i=1;i<=n;i++)
		{
			for (j=1;j<=n;j++)
			{
				if (i==2&&j==3)
				{
					int rysth=0;
				}
				if (bz1[j]) continue;
				int k=a[i].id;int o=j;ss[0]=0;fu[0]=0;
				int lca=getlca(k,j);
				while (k!=lca)
				{
					ss[++ss[0]]=k,k=fa[k];
				} ss[++ss[0]]=lca;
				while (o!=lca)
				{
					fu[++fu[0]]=o;o=fa[o];
				}
				for (int sg=1;sg<=fu[0];sg++) ss[++ss[0]]=fu[fu[0]-sg+1];
				for (ii=1;ii<=ss[0]-2;ii++)
				{
					if (bz[bj[b[ss[ii]][1]][b[ss[ii]][0]]][bj[b[ss[ii]][0]][ss[ii]]]) break;
				}
				if (ss[0]>2&&bz[bj[b[ss[ii]][1]][b[ss[ii]][0]]][bj[b[ss[ii]][0]][ss[ii]]]) continue;
				ans[i]=j,bz1[j]=1;
				for (int ii=1;ii<=ss[0]-2;ii++)
				{
					bz[bj[fa[ii]][ss[ii]]][bj[b[ss[ii]][1]][fa[ii]]]=1;
				}break;
			}
		}
		for (i=1;i<=n;i++) printf("%d ",ans[i]);
		printf("\n");
	}
	return 0;
}
