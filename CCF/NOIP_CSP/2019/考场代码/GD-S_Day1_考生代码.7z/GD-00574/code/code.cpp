#include <cstdio>
#include <cstring>
#include <algorithm>
#include <iostream>
using namespace std;
unsigned long long i,j,k,m,n,o,p,l,s,t;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n;cin>>m;
	if (n==64&&m==18446744073709551615) 
	{
		printf("%d",1);
		for (int i=1;i<=63;i++) printf("%d",0);
		return 0;
	}o=0,s=1;p=n,m++;
	for (i=1;i<=n-1;i++) s*=2;n=s;
	while (m)
	{
		k++;
		if (!o)
		{
			if (m<=n) printf("%d",0);
			else printf("%d",1),m-=n,o=1-o;
		} else {
			if (m<=n) printf("%d",1),o=1-o;
			else printf("%d",0),m-=n;
		}
		if (k==p) break;n/=2;
	}
	fclose(stdin);fclose(stdout);
	return 0; 
}
