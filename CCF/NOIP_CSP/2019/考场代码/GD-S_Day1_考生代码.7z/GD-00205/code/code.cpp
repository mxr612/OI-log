#include<cstdio>
using namespace std;
long long n,k;
long long pw(long long n){
	long long s=1;
	for(long long i=1;i<=n;++i)
		s*=2;
	return s;
}
void cde(long long x,long long y){
	if(x>=1){
		long long k=pw(x-1);
		if(y<k)printf("0"),cde(x-1,y);
		else printf("1"),cde(x-1,y-k);
	}else return;
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%lld%lld",&n,&k);
	cde(n,k);
	fclose(stdin); fclose(stdout);
	return 0;
}
