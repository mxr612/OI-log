#include<cstdio>
#include<iostream>
#include<queue>
using namespace std;
int n,head=0,fa[500001][999],f,cnt[500001];
long long ans=0;
queue<char> q;
char tr[500001];
bool vis[500001]={false};
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;++i)
		cin>>tr[i];
	for(int i=1;i<n;++i){
		scanf("%d",&f);
		fa[f][++cnt[f]]=i+1;
	}
	for(int i=1,j=1;fa[i]!=0,j<=cnt[i];i=fa[i][j],j++){
		if(vis[i]==false){
			vis[i]==true;
			if(tr[i]=='(')
				if(q.front()==')'&&!q.empty()){
					ans++,q.pop();
				}else q.push(tr[i]);
			vis[i]=false;
		}
	}
	printf("%lld",ans);
	fclose(stdin); fclose(stdout);
	return 0;
}
