#include <cstdio>
#include <cstring>
#include <algorithm>
#include <cmath>
#include <iostream>
using namespace std;
long long a[1000];

void dfs(long long n,long long k)
{
	if(n!=1)
	{
		long long x=n-1;
		if(k>=pow(2,n-1)) 
		{
			long long b=pow(2,n)-k-1;
			dfs(x,b);
			a[n]=1;
		}
		else 
		{
			long long c=k;
			dfs(x,c);
			a[n]=0;
		}
	}
	else
	{
		if(k==0) 	a[n]=0;
		else  a[n]=1;
	}
}

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	long long n,k,cnt;
	cin>>n>>k;
	dfs(n,k);
	for(int i=n;i>=1;i--) cout<<a[i];
	fclose(stdin);
	fclose(stdout);
}
