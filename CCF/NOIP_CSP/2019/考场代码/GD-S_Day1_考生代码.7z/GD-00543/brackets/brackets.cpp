#include <cstdio>
#include <cstring>
#include <algorithm>
#include <iostream>
using namespace std;
char s[500005];
long long p[500005];
long long re[500005];
long long sum;
bool flag;
long long cnt;

struct node
{
	long long pre;
	char l[1];	
} t[500005];

void add(long long n,long long u)
{
	cnt++;
	t[cnt].l[0]=s[n];
	t[cnt].pre=p[u-1];
	p[u-1]=cnt;
	re[u-1]++;
}

void dfs(int x,int l,int r)
{
	sum=sum xor min(l,r)*(x+1);
	if(re[x]==0)	return;
	for(int i=p[x];i;i=t[i].pre)
	{
		if(t[i].l[0]=='(') dfs(i,l+1,r); 
		else dfs(i,l,r+1);
	}
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	long long n;
	memset(p,0,sizeof(p));
	memset(re,0,sizeof(re));
	cnt=sum=0;
	flag=true;
	cin>>n;
	for(int i=0;i<n;i++) cin>>s[i];
	for(int i=1;i<n;i++)
	{
		long long x;
		cin>>x;
		add(i,x);
	}	
	if(s[0]=='(') dfs(0,1,0);
	else dfs(0,0,1);
	cout<<sum<<endl;
	fclose(stdin);
	fclose(stdout);
}
