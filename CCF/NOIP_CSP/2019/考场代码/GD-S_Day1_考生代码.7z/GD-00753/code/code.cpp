#include<cstdio>
#include<cstring>
#include<queue>
using namespace std;
int n,m,t1=2,t2=1;
int q[16384][64];
void find()
{
	while(t2!=n)
	{
		for(int a=t1;a<2*t1;a++)
		{
			int x=a,y=2*t1-a-1;
			for(int b=0;b<t2;b++)
			{
				q[x][b]=q[y][b];
			}
			q[a][t2]=1;
		}
		t2++;
		for(int a=0;a<t1;a++)
		{
			q[a][t2]=0;
		}
		t1*=2;
	}
	return;
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%d",&n,&m);
	q[0][0]=0;
	q[1][0]=1;
	find();
	for(int a=n-1;a>=0;a--)
	{
		printf("%d",q[m][a]);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
