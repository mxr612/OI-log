#include <cstdio>
#define N 500010
#define ll long long
#define fo(x, a, b) for (int x = (a); x <= (b); x++)
#define fd(x, a, b) for (int x = (a); x >= (b); x--)
using namespace std;
struct node{int v, fr;}e[N];
int n, a[N], tail[N], cnt = 0;
int fa[N][21], mi[N][21], g[N], can = 0;
ll f[N], ans = 0;

inline int read()
{
	int x = 0; char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

void read_all()
{
	n = 0; char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	while (c >= '0' && c <= '9') n = n * 10 + c - '0', c = getchar();
	while (c != '(' && c != ')') c = getchar();
	fo(i, 1, n) a[i] = (c == '(') ? 1 : -1, c = getchar();
}

inline void add(int u, int v) {e[++cnt] = (node){v, tail[u]}; tail[u] = cnt;}

inline int min(int x, int y) {return x < y ? x : y;}

void dfs(int x)
{
	mi[x][0] = a[x];
	for (int i = 0; fa[x][i]; i++)
	{
		fa[x][i + 1] = fa[fa[x][i]][i];
		mi[x][i + 1] = min(mi[x][i], mi[fa[x][i]][i]);
	}
	for (int p = tail[x], v; p; p = e[p].fr)
		v = e[p].v, a[v] += a[x], dfs(v);
}

void solve()
{
	fo(x, 1, n)
	{
		can = fa[x][0], f[x] = f[can];
		if (a[can] > a[x])
		{
			for (int i = 19; i >= 0; i--)
				if (fa[can][i] && mi[fa[can][0]][i] > a[x]) can = fa[can][i];
			if (a[fa[can][0]] == a[x]) g[x] = g[fa[can][0]] + 1;
			f[x] += g[x];
		}
	}
}

int main()
{
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	read_all();
	fo(i, 2, n) fa[i][0] = read(), add(fa[i][0], i);
	dfs(1);
	solve();
	fo(i, 1, n) ans = ans ^ (i * f[i]);
	printf("%lld\n", ans);
	return 0;
}
