#include <cstdio>
#include <cstring>
#define N 2010
#define mem(x, a) memset(x, a, sizeof x)
#define fo(x, a, b) for (int x = (a); x <= (b); x++)
#define fd(x, a, b) for (int x = (a); x >= (b); x--)
using namespace std;
int T, n, a[N], to[N], b[N][2], c[N], aw[N];
int len[N], rt;
bool bz[N], bj_lian;

inline int read()
{
	int x = 0; char c = getchar();
	while (c < '0' || c > '9') c = getchar();
	while (c >= '0' && c <= '9') x = x * 10 + c - '0', c = getchar();
	return x;
}

inline void swap(int &x, int &y) {int t = x; x = y; y = t;}

void fz() {fo(i, 1, n) aw[i] = c[i]; return;}

void cpr()
{
	fo(i, 1, n) c[a[i]] = i;
	fo(i, 1, n) 
		if (c[i] < aw[i]) {fz(); return;}
		else if (c[i] > aw[i]) return;
}

void dfs(int x)
{
	if (x == n) {cpr(); return;}
	fo(i, 1, n - 1)
	{
		if (bz[i]) continue;
		swap(a[b[i][0]], a[b[i][1]]), bz[i] = 1;
		dfs(x + 1);
		swap(a[b[i][0]], a[b[i][1]]), bz[i] = 0;
	}
}

int main()
{
	freopen("tree2.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	T = read();
	while (T--)
	{
		mem(aw, 10); rt = 0, bj_lian = 1;
		n = read();
		fo(i, 1, n) {to[i] = read(); a[to[i]] = i;}
		fo(i, 1, n - 1)
		{
			b[i][0] = read(), b[i][1] = read();
			len[b[i][0]]++, len[b[i][1]]++;
		}
		if (n <= 10)
		{
			dfs(1);
			fo(i, 1, n) printf("%d ", aw[i]);
			puts("");
			continue;
		}
		fo(i, 1, n)
		{
			if (len[i] == n - 1) {rt = i; break;}
			if (len[i] > 2) bj_lian = 0;
		}
		if (rt)
		{
			bool bzb = 1;
			if (a[1] == 1) bzb = 1;
			fo(i, 1, n)
				swap(a[1], a[to[i]]);
			fo(i, 1, n) c[a[i]] = i;
			if (bzb)
			{
				fo(i, 1, n) printf("%d ", c[i]);
			}
			else fd(i, n, 1) printf("%d ", c[i]);
			puts("");
			continue;
		}
		if (bj_lian)
		{
			dfs(1);
			fo(i, 1, n) printf("%d ", aw[i]);
			puts("");
			continue;
		}
		fo(i, 1, n) printf("%d ", i);puts("");
	}
	return 0;
}
