#include <cstdio>
#define ll unsigned long long
#define fo(x, a, b) for (int x = (a); x <= (b); x++)
#define fd(x, a, b) for (int x = (a); x >= (b); x--)
using namespace std;
int n;
ll K, jc[65];
bool fd = 1, tag = 0;

void read()
{
	char c = getchar(); K = 0;
	while (c < '0' || c > '9') c = getchar();
	while (c >= '0' && c <= '9') K = K * 10 + c - '0', c = getchar();
}

int main()
{
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	scanf("%d", &n); read();
	jc[0] = 1;
	fo(i, 1, n - 1) jc[i] = jc[i - 1] * 2;
	fo(i, 1, n)
	{
		if (K <= jc[n - i])
		{
			if (tag == 0) printf("0");
			else printf("1");
			tag = 0;
		}
		else
		{
			K -= jc[n - i];
			if (tag == 0) printf("1");
			else printf("0");
			tag = 1;
		}
		if (fd == 1) ++K, fd = 0;
	}
	return 0;
}
