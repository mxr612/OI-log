#include <cstdio>
#define reg register 
#define f(i, s, t) for (reg int i = s; i <= t; i++)
#define il inline

typedef long long ll;

il ll read(){
	reg ll x = 0; reg char ch = getchar();
	for (; ch < '0' || ch > '9'; ch = getchar()) ;
	for (; ch >='0' && ch <='9'; ch = getchar()) x = x * 10 + ch - '0';
	return x;
}

int main(){
  freopen("code.in", "r", stdin);
  freopen("code.out", "w", stdout);
	for (reg ll N = read(), K = read(), op = 0; N; N -= 1){
		reg int ans = 0 ^ op;
		if (1LL << (N - 1) <= K) ans = 1 ^ op, op = 1, K -= 1LL << (N - 1);
    else op = 0;
		printf("%d", ans);
	}
  puts("");
  fclose(stdout);
}