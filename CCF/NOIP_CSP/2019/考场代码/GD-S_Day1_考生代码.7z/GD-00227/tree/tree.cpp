#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
#define reg register int
#define f(i, s, t) for (reg i = s; i <= t; i++)
#define il inline
#define ms(a, b) memset(a, b, sizeof(a))

const int SN = 2006;
int N, a[SN], b[SN], minn, c[SN];
int tot, Head[SN], Ver[SN << 1], Next[SN << 1];
bool fl[SN << 1];

il int read(){
	reg x = 0; register char ch = getchar();
	for (; ch < '0' || ch > '9'; ch = getchar()) ;
	for (; ch >='0' && ch <='9'; ch = getchar()) x = x * 10 + ch - '0';
	return x;
}

il void add(int x, int y) {
  Ver[++tot] = y, Next[tot] = Head[x], Head[x] = tot;
}

int dfs1(int x, int fa) {
  reg ans = x;
  for (reg i = Head[x]; i; i = Next[i]){
    reg y = Ver[i];
    if (fl[i] || y == fa) continue;
    reg t = dfs1(y, x);
    if (a[ans] > a[t]) ans = t; 
  }
  return ans;
}

bool dfs2(int x, int fa) {
  if (x == minn) return true;
  for (reg i = Head[x]; i; i = Next[i]){
    reg y = Ver[i];
    if (fl[i] || y == fa) continue;
    if (dfs2(y, x)) {
      swap(a[x], a[y]);
      fl[i] = fl[i ^ 1] = true;
      return true;
    }
  }
  return false;
}

dfs3(int cnt) {
  if (cnt > N - 1) {
    f(i, 1, N) c[a[i]] = i;
    bool f = 0;
    f(i, 1, N) if (b[i] < c[i]) {
      f = 1;
      break;
    }
    if (b[1] == 0 || f) f(i, 1, N) b[i] = c[i];
  }else{
    f(i, 1, N - 1){
      reg t = i << 1;
      if (fl[t]) continue;
      fl[t] = 1;
      swap(a[Ver[i]], a[Ver[i ^ 1]]);
      dfs3(cnt + 1);
      swap(a[Ver[i]], a[Ver[i ^ 1]]);
      fl[t] = 0;
    }
  }
}

il int bf(){
  dfs3(1);
  f(i, 1, N) printf("%d ", c[i]); puts("");
}

int main(){
  freopen("tree.in", "r", stdin);
  freopen("tree.out", "w", stdout);
  reg T = read();
  while (T--){
    ms(Head, 0), ms(fl, 0), tot = 1;
    N = read();
    f(i, 1, N) a[read()] = i;
    f(i, 2, N) {
      reg x = read(), y = read();
      add(x, y), add(y, x);
    }
    /* if (N <= 10) {
      bf(); 
      continue;
    } */
    // puts("");
    f(i, 1, N) {
      minn = dfs1(i, 0);
      // printf("%d %d\n", i, minn);
      dfs2(i, 0);
    }
    // puts("");
    f(i, 1, N) b[a[i]] = i;
    f(i, 1, N) printf("%d ", b[i]); puts("");
  }
}