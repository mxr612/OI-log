#include <cstdio>
#include <vector>
#include <iostream>
using namespace std;
#define reg register int
#define f(i, s, t) for (reg i = s; i <= t; i++)
#define il inline

typedef long long ll;
const int SN = 5e6 + 6;
int N, cnt, nxt[SN], v[SN], tot, Head[SN], Next[SN], Ver[SN];
char ch[SN];
bool f[SN];
ll ans = -1LL;

il int read(){
	reg x = 0; register char ch = getchar();
	for (; ch < '0' || ch > '9'; ch = getchar()) ;
	for (; ch >='0' && ch <='9'; ch = getchar()) x = x * 10 + ch - '0';
	return x;
}

il void add(int x, int y) {
	// printf("%d\n", x);
	Ver[++tot] = y, Next[tot] = Head[x], Head[x] = tot;
}

il int cont(int r) {
	// f(i, 0, v.size() - 1) printf("%c", ch[v[i]]); puts("");
	if (ch[v[cnt - 1]] == '(') return 0;
	reg ans = 0, tmp = 0; f[r] = 0;
	for (reg i = cnt - 2; i >= 0; i--){
		// printf("%d %d\n", i + 1, nxt[i]);
		if (ch[v[i]] == '(') {
			// printf("  1 %d\n", f[r]);
			if (!f[r]) nxt[cnt - 1] = i, f[r] = 1, tmp++;
			else break;
		} else {
			// printf("  2 %d %d\n", f[r], nxt[i]);
			if (f[v[i]] && f[r]) tmp++;
			i = nxt[i];
		}
	}
	return f[r] * tmp; 
}

void dfs(int x, ll sum) {
	// cout << x << endl;
	sum += cont(x);
	// printf("~%d %d %d\n\n", x, t, sum);
	if (ans == -1LL) ans = sum * x;
	else ans ^= sum * x;
	for (reg i = Head[x]; i; i = Next[i]){
		// cout << Ver[i] << endl;
		reg y = Ver[i];
		v[cnt++] = y;
		dfs(y, sum);
		cnt--;
	}
}

int main() {
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	N = read();
	scanf("%s", ch + 1);
	// printf("%c\n", ch[3]);
	f(i, 2, N) add(read(), i);
	v[0] = 1, cnt = 1; 
	dfs(1, 0);
	printf("%lld\n", ans);
}
