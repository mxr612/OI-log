#include<iostream>
#include<cstdio>
#include<queue>
#include<string>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<vector>
using namespace std;

int n;
int s[210],cnt[210],f[210];
string st;

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	
	scanf("%d",&n);
	cin>>st;
	
	for (int i=0; i<n; i++)
      if (st[i]=='(') s[i+1]=0; else s[i+1]=1;
    
    for (int i=2; i<=n; i++) scanf("%d",&f[i]);
    
    for (int i=1; i<=n; i++)
    {
    	for (int j=1; j<=i; j++)
    	{
    		for (int k=j; k<=i; k++)
    		{
    			int t=0;
    			for (int L=j; L<=k; L++)
    			{
    				if (s[L]==0) t++;
    				 else t--;
    				if (t<0) break;
    			}
    			if (t==0) cnt[i]++;
    		}
    	}
    }
	
	int ans=cnt[1];
	for (int i=2; i<=n; i++)
	{
		int tmp=cnt[i]*i;
		ans=(ans^tmp);
	}
	cout<<ans;
	
	return 0;

}


