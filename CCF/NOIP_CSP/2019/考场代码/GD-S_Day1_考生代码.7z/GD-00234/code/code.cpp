#include<iostream>
#include<cstdio>
#include<queue>
#include<string>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<vector>
using namespace std;

long long n,k;
string st;

void find(long long a,long long s)
{
	if (a==1)
	{
		if (s==0) st="0";
		if (s==1) st="1";
		return;
	}
	
	long long mid=1;
	for (int i=1; i<a; i++) mid*=2;
	
	if (s>=mid)
	{
		long long dec=s-mid;
		long long tmp=mid-1-dec;
		find(a-1,tmp);
		st="1"+st;
	}
	
	if (s<mid)
	{
		find(a-1,s);
		st="0"+st;
	}
	
}

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	
	scanf("%lld%lld",&n,&k);
	
	find(n,k);
	
	cout<<st<<endl;
	
	return 0;

}


