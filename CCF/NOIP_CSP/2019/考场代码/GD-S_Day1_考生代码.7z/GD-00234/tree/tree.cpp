#include<iostream>
#include<cstdio>
#include<queue>
#include<string>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<vector>
using namespace std;

int T,n,v,sum;
int ans[2010],val[2010],vis[2010],A[2010],B[2010];
int vis2[2010];

void dfs(int step)
{
	if (step==n)
	{
		int zs[20];
		for (int i=1; i<=n; i++)
		  zs[val[i]]=i;
		int flag=0;
		for (int i=1; i<=n; i++)
		{
			if (zs[i]<ans[i]) {flag=1; break;}
			if (zs[i]>ans[i]) {flag=0; break;}
		}
		
		if (flag==0) return;
		for (int i=1; i<=n; i++)
		  ans[i]=zs[i];
	}
	
	for (int i=1; i<n; i++)
	{
		if (vis[i]==0)
		{
			swap(val[A[i]],val[B[i]]);
			vis[i]=1;
			dfs(step+1);
			vis[i]=0;
			swap(val[A[i]],val[B[i]]);
		}
	}
}

void process1()
{
	ans[1]=n+1;
	dfs(1);
	for (int i=1; i<=n; i++) cout<<ans[i]<<' ';
	cout<<endl;
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	scanf("%d",&T);
	
	while (T>0)
	{
		scanf("%d",&n);
		
		for (int i=1; i<=n; i++)
		{
			scanf("%d",&v);
			val[v]=i;
		}
		
		for (int i=1; i<n; i++)
		{
			scanf("%d%d",&A[i],&B[i]);
			int a=A[i],b=B[i];
		}
		
		if (n<=10) process1();
		
		T--;
	}
	
	
	return 0;

}


