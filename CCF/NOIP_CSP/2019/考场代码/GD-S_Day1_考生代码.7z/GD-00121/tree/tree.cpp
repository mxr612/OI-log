#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
const int N=2010;
int T,n,w[N],ww[N],x,y,xx[N],yy[N];
bool vis[N];int rk[N],tt[N],c[N],_ret[N];
void dfs(int x){
	if(x>=n){
		for(int i=1;i<=n;i++)tt[i]=w[i];
		for(int i=1;i<n;i++) swap(tt[xx[rk[i]]],tt[yy[rk[i]]]);
		for(int i=1;i<=n;i++)c[tt[i]]=i;
		for(int i=1;i<=n;i++)if(c[i]>_ret[i])return;else if(c[i]<_ret[i]){
			for(int j=i;j<=n;j++)_ret[j]=c[j];return;
		}return;
	}
	for(int i=1;i<n;i++)if(!vis[i])rk[x]=i,vis[i]=1,dfs(x+1),vis[i]=0;
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=1;i<=n;i++)scanf("%d",&ww[i]);
		for(int i=1;i<=n;i++)w[ww[i]]=i;
	//	memset(h,0,sizeof(h));
		for(int i=1;i<n;i++){
			scanf("%d%d",&x,&y);xx[i]=x;yy[i]=y;
		}
		if(n<=10){
			for(int i=1;i<=n;i++)_ret[i]=1e9;
			dfs(1);
			for(int i=1;i<=n;i++)printf("%d ",_ret[i]);puts("");
		}
	}
	return 0;
}
