#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
typedef long long ll;
const int N=5e5+10,LOG=20;//!!
int n;char s[N];
struct path{int y,nxt;}g[N];int h[N];
int dep[N],fa[N][LOG],L,R;
int pre[N];
void dfs(int x,int f){pre[x]=pre[f];
	pre[x]+=s[x]=='('?1:-1;L=min(L,pre[x]);R=max(R,pre[x]);
	dep[x]=dep[f]+1;
	fa[x][0]=f;for(int i=1;i<LOG;i++)fa[x][i]=fa[fa[x][i-1]][i-1];
	for(int i=h[x];i;i=g[i].nxt)dfs(g[i].y,x);
}
int up(int x,int d){
	for(int i=LOG-1;~i;i--)if(dep[fa[x][i]]>=d)x=fa[x][i];return x;
}
int rt[N];
namespace TR{
	int lc[N*LOG],rc[N*LOG],ct[N*LOG],tot;
	int nwnode(int k=0){tot++;lc[tot]=lc[k];rc[tot]=rc[k];ct[tot]=ct[k];return tot;}
	void ins(int &o,int k,int l,int r,int pos){
		o=nwnode(k);if(l==r){++ct[o];return;}
		int mid=l+r>>1;if(pos<=mid)ins(lc[o],lc[k],l,mid,pos);
		else ins(rc[o],rc[k],mid+1,r,pos);
	}
	int qry(int o1,int o2,int l,int r,int pos){
		if(l==r)return ct[o1]-ct[o2];int mid=l+r>>1;
		if(pos<=mid)return qry(lc[o1],lc[o2],l,mid,pos);return qry(rc[o1],rc[o2],mid+1,r,pos);
	}
}
int mn[N<<2];
void add(int k,int l,int r,int pos,int x){
	if(l==r){mn[k]=x;return;}
	int mid=l+r>>1;if(pos<=mid)add(k<<1,l,mid,pos,x);else add(k<<1|1,mid+1,r,pos,x);
	mn[k]=min(mn[k<<1],mn[k<<1|1]);
}
int qry(int k,int l,int r,int pos,int x){
	if(mn[k]>=x)return 0;if(l==r)return l;
	int mid=l+r>>1,re=0;
	if(pos>mid)re=qry(k<<1|1,mid+1,r,pos,x);if(re)return re;
	return qry(k<<1,l,mid,pos,x);
}
ll ret;int lstmn,y;
void dp(int x,int f,ll ans){
	TR::ins(rt[x],rt[f],L,R,pre[x]);
	add(1,1,n+1,dep[x],pre[x]);
	lstmn=qry(1,1,n+1,dep[x],pre[x]);
	if(lstmn){
		y=up(x,lstmn);
		ans+=TR::qry(rt[x],rt[y],L,R,pre[x])-1;	
	}
	else ans+=TR::qry(rt[x],0,L,R,pre[x])-1;
	ret^=x*ans;
	for(int i=h[x];i;i=g[i].nxt)
		dp(g[i].y,x,ans);
}
int f;
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d%s",&n,s+1);
	for(int i=2;i<=n;i++){
		scanf("%d",&f);
		g[i]=(path){i,h[f]};h[f]=i;
	}
	L=R=0;dep[0]=1;dfs(1,0);
	TR::ins(rt[0],0,L,R,0);
	dp(1,0,0);
	cout<<ret;
	return 0;
}
