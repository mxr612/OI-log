#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
typedef unsigned long long ull;
const int N=100;
ull n,k,bin[N],ans;
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	bin[0]=1;for(int i=1;i<n;i++)bin[i]=bin[i-1]<<1;
	for(int i=n-1;~i;i--){
		if(k>=bin[i]){
			k=bin[i]-(k-bin[i])-1;printf("1");
		}else printf("0");
	}
	return 0;
}
