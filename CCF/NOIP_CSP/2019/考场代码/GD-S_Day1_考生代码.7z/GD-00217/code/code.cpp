#include<cstdio>
using namespace std;

long long m,zhi=1;	int n;

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	
	scanf("%d %lld",&n,&m);
	
	for(int i=1;i<=n;i++)
	{
		zhi*=2;
	}
	int fan=1; long long jj=zhi;
	m++;
	for(int i=1;i<=n;i++)
	{
		jj/=2;
		if(m<=jj)
		{
			if(fan==1)	printf("0");
			else printf("1"),fan=-fan;
		}
		if(m>jj)
		{
			if(fan==1)	printf("1"),fan=-fan;
			else printf("0");
		}
		m=(m-1)%jj+1;
	}
	return 0;
}
