#include<cstdio>
#include<cstring>
#define N 2005
using namespace std;

int t,n,a[N];
bool p[N];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		memset(p,false,sizeof(p));
		memset(a,0,sizeof(a));
		scanf("%d",&n);
	
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
		}
	
		if(a[1]==1)
		{
			for(int i=1;i<n;i++)
			printf("%d ",a[i+1]);
			printf("%d\n",a[1]);
		}
		
		else
		{
			int x=1,zhi=1;
			while(x<n)
			{
				bool pp=false;
				for(int i=x;i<=n;i++)
				{
					if(p[i]==false)
					pp=true,x=i;
					break;
				}
				if(!pp)	break;
				for(int i=zhi;i<=n;i++)
				{
					p[a[i]]=true;
					if(a[i]==x)
					{
						zhi=x+1;break;	
					}
				}
				
				for(int i=1;i<zhi-1;i++)
					printf("%d ",a[i+1]);
				printf("%d ",a[x]);
			}
			printf("\n");
		}
	}
	return 0;
}
