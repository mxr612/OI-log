#include<cstdio>
#include<queue>
#define ll long long
#define N 500005
using namespace std;

ll tot,head[N],anss;
int n;
struct dian
{
	ll zuok,ans,yans,zhuangt;
}shu[N];

struct tu
{
	int to,nxt;
}e[N];

void add(int x,int y)
{
	e[++tot].to=y;
	e[tot].nxt=head[x];
	head[x]=tot;
}

queue<ll> q;
void topo()
{
	q.push(1);
	
	while(!q.empty())
	{
		ll p=q.front();
		q.pop();
		
		for(ll k=head[p];k;k=e[k].nxt)
		{
			ll to=e[k].to;
			
			if(shu[to].zuok==1)
			{
				shu[to].zuok=shu[p].zuok+1;
				shu[to].ans=shu[p].ans;
				if(shu[p].zhuangt==-1) shu[to].yans=shu[p].yans;
			}
			
			else
			{
				if(shu[p].zuok>=1&&shu[p].zhuangt==1)
				shu[to].zuok=shu[p].zuok-1,shu[to].ans=shu[p].ans+1+shu[p].yans,shu[to].yans=shu[p].yans+1;
				else if(shu[p].zuok>=1&&shu[p].zhuangt==-1)
				shu[to].zuok=shu[p].zuok-1,shu[to].ans=shu[p].ans+1,shu[to].yans=shu[p].yans;
				else shu[to].zuok=0,shu[to].ans=shu[p].ans,shu[to].yans=0;
			}
			q.push(to);
		}
	}
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d\n",&n);
	
	for(int i=1;i<=n;i++)
	{
		char a;
		scanf("%c",&a);
		if(a=='(')	shu[i].zuok=1,shu[i].zhuangt=1;
		else shu[i].zuok=0,shu[i].zhuangt=-1;
	}
	
	for(int i=2;i<=n;i++)
	{
		int x;
		scanf("%d",&x);
		add(x,i);
	}
	
	
	topo();
	

	
	for(int i=1;i<=n;i++)
	{
		anss=anss^(i*shu[i].ans);
	}
	
	printf("%lld",anss);
	return 0;
}
