#include <cstdio>
#include <algorithm>
#define fo(i,a,b) for(int i=a;i<=b;i++)
using namespace std;

const int N=2019;
int T,n,a[N],b[N],u[N],v[N],p[N],P[N],deg[N];
bool us[N];

void dg(int t)
{
	if(t==1) fo(i,1,n) b[a[i]]=i;
	if(t==n)
	{
		fo(i,1,n) p[b[i]]=i;
		fo(i,1,n) if(p[i]^P[i])
		{
			if(p[i]<P[i]) fo(j,1,n) P[j]=p[j];
			break;
		}
		return;
	}
	fo(i,1,n-1) if(!us[i])
	{
		us[i]=1; swap(b[u[i]],b[v[i]]);
		dg(t+1);
		us[i]=0; swap(b[u[i]],b[v[i]]);
	}
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	for(scanf("%d",&T);T--;)
	{
		scanf("%d",&n);
		fo(i,1,n) scanf("%d",&a[i]),P[i]=n,deg[i]=0;
		fo(i,1,n-1) scanf("%d%d",&u[i],&v[i]),deg[u[i]]++,deg[v[i]]++;
		if(n<=10)
		{
			dg(1);
			fo(i,1,n) printf("%d ",P[i]);
			puts("");
			continue;
		}
	}
}
