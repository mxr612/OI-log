#include <vector>
#include <cstdio>
#define min(x,y) (x<y?x:y)
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
#define gc (p1==p2&&(p2=(p1=fr)+fread(fr,1,1<<21,stdin))==p1?EOF:*p1++)
using namespace std;
typedef long long ll;
typedef pair<int,int> P;

const int N=51e4;
int n,dep[N],f[N][19],ne[N],la[N],v[N][19],q[N],cnt[N*2],d[N];
ll sum,ans;
char ch,fr[1<<21],*p1=fr,*p2=fr,s[N];
void rd(int&x)
{
	while((ch=gc)<48|ch>57);x=ch-48;
	while((ch=gc)>47&ch<58) x=ch-48+x*10;
}

vector<P> a[N*2];
void dfs(int x)
{	
	bool bz=1;
	v[x][0]+=(s[x]=='('?1:-1); a[v[x][0]].push_back(P(dep[x],x));
	fo(i,1,18)
	{
		int y=f[x][i-1];
		if(!y) break;
		v[x][i]=min(v[x][i-1],v[y][i-1]);
		f[x][i]=f[y][i-1];
	}
	int z=x;
	fd(i,18,0) if(f[z][i]&&v[z][i]>=v[x][0]&&v[f[z][i]][0]>=v[x][0]) z=f[z][i];
	if(z==1&&v[x][0]<=0) z=0;
	z=lower_bound(a[v[x][0]].begin(),a[v[x][0]].end(),P(dep[z],0))->second;
	q[x]=cnt[v[x][0]]++;
	ans^=1ll*x*(sum+=q[x]-q[z]);
	
/*	int s1=0,ds=0;
	for(int y=x; y; y=f[y][0]) d[dep[x]-ds++]=y;
	fo(i,1,dep[x])
	{
		int c=0;
		fo(j,i,dep[x])
		{
			c+=(s[d[j]]=='('?1:-1);
			if(c<0) break;
			s1+=c==0;
		}
	}
	if(sum^s1)
		x++,x--;*/
	
	for(int y=la[x]; y; y=ne[y])
	v[y][0]=v[x][0], dep[y]=dep[x]+1, dfs(y);
	sum-=q[x]-q[z], cnt[v[x][0]]--; a[v[x][0]].pop_back();
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	rd(n);
	while((s[1]=gc)!='('&s[1]!=')');
	fo(i,2,n) s[i]=gc;
	fo(i,2,n) rd(f[i][0]),ne[i]=la[f[i][0]],la[f[i][0]]=i;
	cnt[v[1][0]=n]=1; a[n].push_back(P(0,0));
	dfs(dep[1]=1);
	printf("%lld",ans);
	return 0;
}
