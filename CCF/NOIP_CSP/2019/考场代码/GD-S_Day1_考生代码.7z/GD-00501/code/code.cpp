#include <cstdio>
#include <iostream>
#define fo(i,a,b) for(int i=a;i<=b;i++)
#define fd(i,a,b) for(int i=a;i>=b;i--)
using namespace std;

int n;
unsigned long long k,x;

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k; x=1;
	fo(i,1,n-1) x*=2;
	fd(i,n,1)
	{
		if(~k&x) putchar('0'); else
		{putchar('1'); k=~k;}
		x/=2;
	}
	return 0;
}
