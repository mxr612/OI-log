#include<bits/stdc++.h>
#define N 2010
using namespace std;
struct data
{
	int x,y;
}a[11];
int n,ans[11],val1[11],val[11],t,x,y,link[N][N],in[N];
bool vis[11];
bool check()
{
	for(int i=1;i<=n;i++)
	{
		if(ans[i]==0)
		{
			return true;
		}
		if(ans[i]<val1[i])
		{
			return false;
		}
		if(ans[i]>val1[i])
		{
			return true;
		}
	}
} 
void dfs(int sum)
{
	if(sum==n-1)
	{
		if(check())
		{
			for(int i=1;i<=n;i++)
			{
				ans[i]=val1[i];
			}
		}
		return;
	}
	for(int i=1;i<n;i++)
	{
		if(!vis[i])
		{
			vis[i]=1;
			swap(val1[val[a[i].x]],val1[val[a[i].y]]);
			swap(val[a[i].x],val[a[i].y]);
			dfs(sum+1);
			swap(val1[val[a[i].x]],val1[val[a[i].y]]);
			swap(val[a[i].x],val[a[i].y]);
			vis[i]=0;
		}
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			scanf("%d",&x);
			val[x]=i;
			val1[i]=x;
		}
		if(n<=10)
		{
			for(int i=1;i<n;i++)
			{
				scanf("%d%d",&x,&y);
			    a[i].x=x;
			    a[i].y=y;
			}
			memset(ans,0,sizeof(ans));
			memset(vis,0,sizeof(vis));
			dfs(0);
			for(int i=1;i<=n;i++)
			{
				printf("%d ",ans[i]);
			} 
			puts("");
			return 0;
		}
		for(int i=1;i<n;i++)
		{
			scanf("%d%d",&x,&y);
			link[x][y]=1;
			link[y][x]=1;
			in[x]++;
			in[y]++;
		}
		for(int i=1;i<=n;i++)
		{
			printf("%d ",i);
		}
		puts("");
	}
	return 0;
}
