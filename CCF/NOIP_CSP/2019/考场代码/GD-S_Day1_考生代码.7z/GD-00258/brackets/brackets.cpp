#include<bits/stdc++.h>
#define N 500010
using namespace std;
int n,x,to[N<<1],nxt[N<<1],head[N],cnt,kuo[N],sum[N],val[N],lenth[N],fa[N][19],len[N],sums[N];
bool is[N];
long long ans;
char ch[N];
void adde(int x,int y)
{
	to[++cnt]=y;
	nxt[cnt]=head[x];
	head[x]=cnt;
}
void dfs1(int u)
{
	for(int i=1;i<=18;i++)
	{
		fa[u][i]=fa[fa[u][i-1]][i-1];
	}
	for(int i=head[u];i;i=nxt[i])
	{
		int v=to[i];
		fa[v][0]=u;
		dfs1(v);
	}
}
int jump(int u,int len)
{
	for(int i=18;i>=0;i--)
	{ 
		if(len>=(1<<i))
		{
			u=fa[u][i];
			len-=(1<<i);
		}
	}
	return u;
}
void dfs(int u)
{
	for(int i=head[u];i;i=nxt[i])
	{
		int v=to[i];
		kuo[v]=kuo[u];
		sum[v]=sum[u];
		if(!val[v])
		{
			kuo[v]++;
			if(val[u]==1&&is[u])
			{
				len[v]=len[u];
				sums[v]=0;
			}
		}else{
			if(kuo[v])
			{
				kuo[v]--;
				int vv=jump(v,sums[u]+1);
				sum[v]+=len[vv]+1;
				len[v]=len[vv]+1;
				is[v]=1;
				sums[v]+=2;
			}else{
				sums[v]=0;
			}
		}
		dfs(v);
	}
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d%s",&n,ch+1);
	for(int i=1;i<=n;i++)
	{
		if(ch[i]=='(')
		{
			val[i]=0;
		}else{
			val[i]=1;
		}
	}
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&x);
		adde(x,i);
	}
	dfs1(1);
	if(val[1]==0)
	{
		kuo[1]++;
	}
	dfs(1);
	ans=0;
	for(int i=1;i<=n;i++)
	{
		ans^=(1ll*sum[i]*i);
	}
	printf("%lld\n",ans);
	return 0;
}
