#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,cnt,a[51],st,ch[51],len,flag;
char s[51];
void chu()
{
	int add=0,sum=0;
	for(int i=0;i<len;i++)
	{
		sum=sum*10+ch[i];
		ch[i]=sum/2;
		sum%=2;
	}
}
void work(int x,int y)
{
	while(x--)
	{
		a[++cnt]=y%2;
		y>>=1;
	}
}
signed main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%lld%s",&n,s);
	len=strlen(s);
	for(int i=0;i<len;i++)
	{
		ch[i]=s[i]-'0';
	}
	a[++cnt]=ch[len-1]%2;
	chu();
	for(int i=0;i<len;i++)
	{
		m=m*10+ch[i];
	}
	work(n-1,m);
	for(int i=cnt;i>=1;i--)
	{
		if(!a[i])
		{
			printf("%lld",st);
			if(st==1)
			{
				st^=1;
			}
		}else{
			printf("%lld",st^1);
			if((st^1)==1)
			{
				st^=1;
			}
		}
	}
	return 0;
}
