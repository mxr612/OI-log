#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

const int N = 2e3;

int T, n;
int val[N + 5];
struct nod {
	int x, y;
}edge[N + 5];
int used[N + 5];
int dfspath[N + 5];
int ans[N + 5], tmp[N + 5];

void dfs (int k) {
	if (k == n) {
		for (int i = 1;i <= n;i++) {
			tmp[val[i]] = i;
		}
		for (int i = 1;i <= n;i++) {
			if (ans[i] == tmp[i]) {
				continue;
			}
			if (ans[i] < tmp[i]) {
				return;
			}
			break;
		}
		for (int i = 1;i <= n;i++) {
			ans[i] = tmp[i];
		}
		return;
	}
	for (int i = 1;i <= n - 1;i++) {
		if (used[i]) {
			continue;
		}
		used[i] = 1;
		dfspath[k] = i;
		swap (val[edge[i].x], val[edge[i].y]);
		dfs (k + 1);
		used[i] = 0;
		dfspath[k] = 0;
		swap (val[edge[i].x], val[edge[i].y]);
	}
	return;
}

int main () {
	freopen ("tree.in", "r", stdin);
	freopen ("tree.out", "w", stdout);
	scanf ("%d", &T);
	while (T--) {
		scanf ("%d", &n);
		for (int i = 1;i <= n;i++) {
			int x; scanf ("%d", &x);
			val[x] = i;
			ans[i] = N + 1;
		}
		for (int i = 1;i <= n - 1;i++) {
			int u, v;
			scanf ("%d %d", &u, &v);
			edge[i].x = u, edge[i].y = v;
		}
		memset (used, 0, sizeof (used));
		dfs (1);
		for (int i = 1;i <= n;i++) {
			printf ("%d ", ans[i]);
		}
		puts ("");
	}
	return 0;
}
