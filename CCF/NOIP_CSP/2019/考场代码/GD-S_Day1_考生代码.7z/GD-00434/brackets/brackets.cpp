#include <cstdio>
#include <cstring>
#define L long long

const L N = 5e5;

L n;
L bas[N + 5];
L fa[N + 5];
L el = 0;
struct nod {
	L x, y, nxt;
}edge[N + 5];
L Edgehead[N + 5];
char st[N + 5];
L f[N + 5], g[N + 5];
L dis[N + 5];
L sum[N + 5];
L sumtot[2 * N + 5], sumnum[2 * N + 5];

void add (L x, L y) {
	el++;
	edge[el].x = x, edge[el].y = y, edge[el].nxt = Edgehead[x], Edgehead[x] = el;
	return;
}

L Getg (L k) {
	L up = k, basnum = bas[k];
	L sum = 0;
	while (up) {
		if (basnum < 0) {
			break;
		}
		if (basnum == 0) {
			sum += g[fa[up]] + 1;
		}
		if (basnum > dis[up]) {
			break;
		}
		up = fa[up];
		basnum += bas[up];
	}
	return sum;
}

void dfs (L k) {
	for (L i = Edgehead[k];i;i = edge[i].nxt) {
		L y = edge[i].y;
		dis[y] = dis[k] + 1;
		g[y] = Getg (y);
		f[y] = f[k] + g[y];
		dfs (y);
	}
	return;
}

void Find (L k) {
	sumtot[sum[k]]++;
	sumnum[sum[k]] += g[k];
//	printf ("start %lld %lld %lld %lld\n", k, sum[k] - N, sumtot[sum[k]], sumnum[sum[k]]);
	for (L i = Edgehead[k];i;i = edge[i].nxt) {
		L y = edge[i].y;
		sum[y] = sum[k] + bas[y];
		dis[y] = dis[k] + 1;
		if (bas[y] == 1) {
			g[y] = sumnum[sum[y]] + sumtot[sum[y]];
//			printf ("%lld %lld\n", y, g[y]);
		}
		f[y] = f[k] + g[y];
		Find (y);
	}
	sumtot[sum[k]]--;
	sumnum[sum[k]] -= g[k];
	return;
}

int main () {
	freopen ("brackets.in", "r", stdin);
	freopen ("brackets.out", "w", stdout);
	memset (Edgehead, 0, sizeof (Edgehead));
	memset (bas, 0, sizeof (bas));
	scanf ("%lld", &n);
	scanf ("%s", st + 1);
	for (L i = 1;i <= n;i++)  {
		if (st[i] == '(') {
			bas[i] = -1;
		}
		else {
			bas[i] = 1;
		}
	}
	fa[1] = 0;
	for (L i = 2;i <= n;i++) {
		scanf ("%lld", &fa[i]);
		add (fa[i], i);
	}
	if (n <= 20000) {
		memset (f, 0, sizeof (f));
		memset (g, 0, sizeof (g));
		memset (dis, 0, sizeof (dis));
		dfs (1);
		L ans = f[1];
		for (L i = 2;i <= n;i++) {
			ans ^= (f[i] * i);
		}
		printf ("%lld", ans);
		return 0;
	}
	memset (f, 0, sizeof (f));
	memset (g, 0, sizeof (g));
	memset (dis, 0, sizeof (dis));
	memset (sum, 0, sizeof (sum));
	memset (sumtot, 0, sizeof (sumtot));
	memset (sumnum, 0, sizeof (sumnum));
	sum[1] = bas[1] + N;
	sumtot[N] = 1;
	sumnum[N] = 0;
	Find (1);
	L ans = f[1];
//	printf ("%lld %lld\n", f[1], g[1]);
	for (L i = 2;i <= n;i++) {
		ans ^= (f[i] * i);
//		printf ("%lld %lld\n", f[i], g[i]);
	}
	printf ("%lld", ans);
	return 0;
}
