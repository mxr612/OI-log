#include <cstdio>
#define UL unsigned long long

UL two[105];

void f (UL n,UL k) {
	if (n == 1) {
		if (k == 1) printf ("0");
		else printf ("1");
		return;
	}
	if (k <= two[n - 1]) {
		printf ("0");
		f (n - 1, k);
	}
	else {
		printf ("1");
		f (n - 1, two[n] - k + 1);
	}
	return;
}

int main () {
	freopen ("code.in", "r", stdin);
	freopen ("code.out", "w", stdout);
	two[0] = 1;
	for (UL i = 1;i <= 64;i++) {
		two[i] = two[i - 1] * 2;
	}
	UL n, k;
	scanf ("%llu %llu", &n, &k);
	k++;
	f (n, k);
	return 0;
}
