#include<iostream>
#include<cstdio>
#include<vector>
#include<map>
#define p1 1000000007
using namespace std;
inline int read()
{
	int ans=0,f=1;char ch=getchar();
	for(;!isdigit(ch);ch=getchar())if(ch=='-')f=-1;
	for(;isdigit(ch);ch=getchar())ans=(ans<<1)+(ans<<3)+(ch^48);
	return ans*f;
}
int n,node[500010],fa[500010],ed[500010],ans,dep[500010];
vector<int>son[500010];
void dfs(int x,int now)
{
	if(now<0)now=-0x7ffffff,ed[x]=-1;
	else if(now==0)ed[x]=1,cout<<"wow";
	for(int i=0;i<son[x].size();i++)
	{
		dep[son[x][i]]=dep[x]+1;
		dfs(son[x][i],now+node[son[x][i]]);
	}
}
map<int,bool>mp;
void dfs1(int x,int now)
{
	if(ed[x]==1){
		if(mp.find(now)==mp.end())mp[now]=1,ans++;
	}
	for(int i=0;i<son[x].size();i++)
	{
		dep[son[x][i]]=dep[x]+1;
		dfs(son[x][i],(now+node[son[x][i]]*dep[son[x][i]])%p1);
	}
}
int main()
{
	//freopen("code.in","r",stdin);\
	freopen("code.out","w",stdout);
	n=read();
	for(int i=1;i<=n;i++)
	{
		char ch=getchar();
		while(ch!='(' and ch!=')')ch=getchar();
		if(ch=='(')node[i]++;
		else node[i]--;
	}
	for(int i=2;i<=n;i++)fa[i]=read(),son[fa[i]].push_back(i);
	if(node[1]<0){
		cout<<0;return 0;
	}
	dfs(1,1);
	dfs1(1,0);
	cout<<ans;
}
