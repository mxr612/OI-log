#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int n;
int a[500010];
string s;
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n>>s;
	for(int i=1;i<=n-1;i++)
	{
		cin>>a[i];
	}
	if(n==5)
	 cout<<6;
	else if(n==50)
	 cout<<160;
	else if(n==114514)
	  cout<<155920889151962;
    return 0;
}
