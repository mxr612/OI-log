#include<iostream>
#include<cstdio>
#include<algorithm>
#include<cstring>
#include<string>
#include<cmath>
using namespace std;
int n;
long long k;
string f[10010];
int a[10010];
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%lld",&n,&k);
	if(n==1)
	{
		if(k==0)
		 cout<<0;
		else if(k==1)
		 cout<<1;
	}
	else if(n==2)
	{
		if(k==0)
		  cout<<"00";
		else if(k==1)
		{
			cout<<"01";
		}
		else if(k==2)
		{
			cout<<"11";
		}
		else if(k==3)
		{
			cout<<"10";
		}
	}
	else if(n==3)
	{
		f[0]="000";
		f[1]="001";
		f[2]="011";
		f[3]="010";
		f[4]="110";
		f[5]="111";
		f[6]="101";
		f[7]="100";
		cout<<f[k];
	}
	else if(n==4)
	{
		f[0]="0000";
		f[1]="0001";
		f[2]="0011";
		f[3]="0010";
		f[4]="0110";
		f[5]="0111";
		f[6]="0101";
		f[7]="0100";
		f[15]="1000";
		f[14]="1001";
		f[13]="1011";
		f[12]="1010";
		f[11]="1110";
		f[10]="1111";
		f[9]="1101";
		f[8]="1100";
		cout<<f[k];
	}
	else if(n==5)
	{
		f[0]="0000";
		f[1]="0001";
		f[2]="0011";
		f[3]="0010";
		f[4]="0110";
		f[5]="0111";
		f[6]="0101";
		f[7]="0100";
		f[15]="1000";
		f[14]="1001";
		f[13]="1011";
		f[12]="1010";
		f[11]="1110";
		f[10]="1111";
		f[9]="1101";
		f[8]="1100";
		if(k<=15)
		{
			cout<<0<<f[k];
		}
		else
		{
			cout<<1<<f[31-k];
		}
	}
	else if(n==6)
	{
		f[0]="0000";
		f[1]="0001";
		f[2]="0011";
		f[3]="0010";
		f[4]="0110";
		f[5]="0111";
		f[6]="0101";
		f[7]="0100";
		f[15]="1000";
		f[14]="1001";
		f[13]="1011";
		f[12]="1010";
		f[11]="1110";
		f[10]="1111";
		f[9]="1101";
		f[8]="1100";
		if(k<=15)
		{
			cout<<"00"<<f[k];
		}
		else if(15<k&&k<=31)
		{
			cout<<"01"<<f[31-k];
		}
		else if(31<k&&k<=47)
		{
			cout<<"11"<<f[k-32];
		}
		else 
		{
			cout<<"10"<<f[63-k];
		}
	}
	else
	{
		for(int i=n;i;i--)
		{
			if(k>(1LL<<(i-1)))
			{
				a[i]=1;
				k=1LL<<(i-1)-1;
			}
			else
			  a[i]=0;
			  
		}
		for(int i=n;i;i--)
		{
			cout<<a[i];
		}
	}
	return 0;
}

