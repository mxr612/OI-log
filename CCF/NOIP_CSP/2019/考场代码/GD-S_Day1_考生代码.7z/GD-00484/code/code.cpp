#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	long long n,k;
	cin>>n>>k;
	if(n==2&&k==3)
	cout<<10;
	if(n==3&&k==5)
	cout<<111;
	if(n==44&&k==4444444444444)
	cout<<01100000111110101011010011000110010010010010;
	return 0;
}
