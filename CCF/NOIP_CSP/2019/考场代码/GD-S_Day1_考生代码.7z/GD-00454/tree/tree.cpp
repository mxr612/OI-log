#include<bits/stdc++.h>
using namespace std;
struct data
{
	int n,m;
}x[100005];
bool cmp(data a,data b)
{
	return a.n<b.n;
}
long long T,n,mmp,ee,x222,y;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>T;
	for(int i=1;i<=T;i++)
	{
		cin>>n;
		for(int j=1;j<=n;j++)
		{
			cin>>mmp;
			x[mmp].n=j;
			if(j==1) ee=mmp;
		}
		for(int j=1;j<=n-1;j++)
		{
			cin>>x222>>y;
		}
		for(int j=ee;j>=2;j--)
		{
			swap(x[j],x[j-1]);
		}
		sort(x+1+ee+1,x+1+n,cmp);
		for(int j=1;j<=n;j++)
		{
			x[j].m=j;
		}
		sort(x+1,x+1+n,cmp);
		for(int j=1;j<=n;j++)
		{
			cout<<x[j].m<<' ';
		}
		cout<<endl;
	}
	return 0;
}
