#include<bits/stdc++.h>
using namespace std;
struct data
{
	int fa;
	char ch;
};
vector <int> u[100000];
string st,st1;
char ps[1000000];
long long s,sss,n,x,xxy[100005];
int fk(int k)
{
	for(int i=0;i<u[k].size();i++)
	{
		st1=st1+ps[u[k][i]];
		if(ps[u[k][i]]==')') xxy[u[k][i]]++;
		if(ps[u[k][i]]=='(') sss++;
		fk(u[k][i]);
		if(ps[u[k][i]]=='(') sss--;
	}
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	cin>>st;
	for(int i=0;i<st.size();i++)
	{
		ps[i+1]=st[i];
	}
	for(int i=1;i<=n-1;i++)	
	{
		cin>>x;
		u[x].push_back(i+1);
	}
	st1=st[0];
	if(st[0]=='(') sss++;
	fk(1);
	for(int i=1;i<=n;i++)
	{
		xxy[i]=xxy[i]*i;
		cout<<xxy[i]<<' ';
	}
	s=xxy[1];
	for(int i=2;i<=n;i++)
	{
		s=s xor xxy[i];
	}
	cout<<s;
	return 0;
}

