#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>
#include<cmath>
using namespace std;
const int c=5e6+10;
int n,k,t;
string s[c],s1[c];
void slove(int k1) {
	int m=(1<<k1)-1;
	for(int i=0;i<=m;++i) {
		if(i<=(m>>1)) {
			s1[i]="0"+s[i];
		}
		else s1[i]="1"+s[m-i];
	}
	for(int i=0;i<=m;++i) {
		s[i]=s1[i];
	}
}
int main() {
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%d",&n,&k);
	s[0]="0";s[1]="1";
	for(int i=2;i<=n;++i) slove(i);
	cout<<s[k];
	fclose(stdin);
	fclose(stdout);
	return 0;
}
