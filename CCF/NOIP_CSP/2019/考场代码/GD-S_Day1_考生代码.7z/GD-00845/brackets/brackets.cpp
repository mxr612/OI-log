#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
const int c=5e5+10;
int head[c],next[c<<1],go[c<<1],num;
int fa[c],cnt[c],ans[c];
void add(int x,int y) {
	next[++num]=head[x];
	go[num]=y;
	head[x]=num;
}
bool check(int u) {
	int qua=0;
	for(int j=fa[u];j;j=fa[j]) {
		if(cnt[j]) qua++;
		else qua--;
		//if(qua<0) return 0;
	}
	if(qua>0) return 0;
	return 1;
}
void dfs(int u) {
	for(int i=head[u];i;i=next[i]) {
		int v=go[i];
		if(cnt[u]==0&&cnt[v]==1) ans[v]=ans[u]+1;
		else if(cnt[u]&&cnt[v]) {
			if(check(v)) ans[v]=ans[u]+1;
			else ans[v]=ans[u];
		}
		dfs(v);
	}
	ans[u]*=u;
}
int main() {
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n;char c;
	scanf("%d",&n);
	for(int i=1;i<=n;++i) {
		cin>>c;
		if(c=='(') cnt[i]=0;
		else cnt[i]=1; 
	}
	for(int i=2,x;i<=n;++i) {
		scanf("%d",&x);
		fa[x]=i;
		add(x,i);
	}
	dfs(1);
	int qua=0;
	for(int i=1;i<=n;++i) {
		qua^=ans[i];
	}
	printf("%d",qua);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
