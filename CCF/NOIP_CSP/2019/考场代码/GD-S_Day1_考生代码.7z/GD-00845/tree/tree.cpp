#include<iostream>
using namespace std;
void slove() {
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;++i) printf("%d ",i);
	printf("\n");
}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int T;
	scanf("%d",&T);
	while(T--) slove();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
