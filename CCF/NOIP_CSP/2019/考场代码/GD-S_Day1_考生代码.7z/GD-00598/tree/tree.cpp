#include<bits/stdc++.h>
using namespace std;

struct XYSbian{
	int a;
	int b;
}xiaoyu10bian[20];

int n,t;
int xiaoyu10dian[20];
bool xiaoyu10shifouhuanbian[20];
int xiaoyu10zuixiaozidianxu[20];

void baoli(int restbian,int bianhao){
	swap(xiaoyu10dian[xiaoyu10bian[bianhao].a],xiaoyu10dian[xiaoyu10bian[bianhao].b]);
	if(restbian==0){
		/*cout<<"f:";
		for(int i=1;i<=n;i++){
				cout<<xiaoyu10dian[i]<<' ';
			}
			cout<<endl;
			char f;
			scanf("%c",&f);*/
		for(int i=1;i<=n;i++){
			if(xiaoyu10dian[i]>xiaoyu10zuixiaozidianxu[i]) break;
			else if(xiaoyu10dian[i]==xiaoyu10zuixiaozidianxu[i]) continue;
			else{
				for(int j=1;j<=n;j++){
					xiaoyu10zuixiaozidianxu[j]=xiaoyu10dian[j];
				}
				break;
			}
		}
		swap(xiaoyu10dian[xiaoyu10bian[bianhao].a],xiaoyu10dian[xiaoyu10bian[bianhao].b]);
		return;
	}else{
		for(int i=1;i<=n;i++){
			if(xiaoyu10shifouhuanbian[i]==0){
				xiaoyu10shifouhuanbian[i]=1;
				baoli(restbian-1,i);
				xiaoyu10shifouhuanbian[i]=0;
			}
		}
		swap(xiaoyu10dian[xiaoyu10bian[bianhao].a],xiaoyu10dian[xiaoyu10bian[bianhao].b]);
		return;
	}
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>t;
	while(t--){
		cin>>n;
		if(n<=10){
			xiaoyu10zuixiaozidianxu[1]=n+1;
			memset(xiaoyu10shifouhuanbian,0,sizeof(xiaoyu10shifouhuanbian));
			for(int i=1;i<=n;i++){
				int tmpp;
				cin>>tmpp;
				xiaoyu10dian[tmpp]=i;
			}
			for(int i=1;i<=n-1;i++){
				XYSbian tmp;
				cin>>tmp.a>>tmp.b;
				xiaoyu10bian[i]=tmp;
			}
			for(int i=1;i<=n;i++){
				baoli(n-1,i);
			}
			for(int i=1;i<=n;i++){
				for(int j=1;j<=n;j++){
					if(xiaoyu10zuixiaozidianxu[j]==i){
						cout<<j<<' ';
						break;
					}
				}
			}
			cout<<endl;
		}
	}
	return 0;
}
