#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	long long k;
	int n;
	bool bj=0;
	cin>>n>>k;
	long long ii=k+1;
	for(int i=1;i<=n;i++){
		if(ii<=pow(2,n-i)){
			if(bj==0) cout<<0;
			else cout<<1;
		}else{
			if(bj==0) cout<<1;
			else cout<<0;
		}
		if(ii>pow(2,n-i)) bj=1;
		else bj=0;
		if(ii>pow(2,n-i)) ii-=pow(2,n-i);
	}
	return 0;
}
