#include<bits/stdc++.h>
using namespace std;

int n;
char kuohao[220];
string chuan[220];
int fas[220];

bool qujian(int l,int r,int chuannum){
	int zuorest=0;
	for(int i=l;i<=r;i++){
		if(chuan[chuannum][i]=='(') zuorest++;
		else if(zuorest>=1) zuorest--;
		else return false;
	}
	if(zuorest==0) return true;
	return false;
}

int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>kuohao[i];
	}
	//for(int i=1;i<=10;i++) cout<<kuohao[i];
	fas[1]=0;
	for(int j=2;j<=n;j++){
		scanf("%d",&fas[j]);
	}
	chuan[0]="";
	for(int i=1;i<=n;i++){
		chuan[i]=chuan[fas[i]]+kuohao[i];
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		int tmpp=0;
		for(int j=0;j<i;j++){
			for(int k=j;k<i;k++){
				if(qujian(j,k,i)) tmpp++;
			}
		}
		ans=ans xor (tmpp*i);
		//cout<<i<<' '<<ans<<endl;
	}
	cout<<ans;
	//cout<<(3 xor 4 xor 15);
	return 0;
}
