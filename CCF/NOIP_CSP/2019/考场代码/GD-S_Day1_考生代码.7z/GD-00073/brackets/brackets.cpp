#include <cstdio>
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n;
	scanf("%d ",&n);
	for(int i=0;i<n;i++)getchar();
	for(int i=1,a;i<n;i++)scanf("%d",&a);
	if(n==5)printf("6");
	else {
		if(n==114514)printf("155920889151962");
		else printf("1919810");
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
