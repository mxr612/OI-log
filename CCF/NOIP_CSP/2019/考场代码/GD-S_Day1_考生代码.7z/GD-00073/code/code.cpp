#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
long long ci[65];
long long cifang(int a){
	if(a==0)return 1;
	if(a==1)return 2;
	if(ci[a]!=0)return ci[a];
	return ci[a]=cifang(a-1)*2;
}
void gelei(long long m,long long b){
	if(m==0)return;
	if(m==1){
		if(b==0)printf("0");
		else printf("1");
		return ;
	}
	if(b>m-1){
		printf("1");
		gelei(m/2,m+m-(b+1));
	}
	else{
		printf("0");
		gelei(m/2,b);
	}
	return;
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
    long long n,k,mid,t;
	scanf("%lld %lld",&n,&k);
	if(n<64){
	mid=cifang(n-1);
	gelei(mid,k);
	}
	else {
		mid=cifang(63)-1;
		if(k<=mid&&k>=0){
			printf("0");
		    gelei(mid/2+1,k);
		}	
		else{
			printf("1");
			mid=cifang(62);
			t=0-k-1;
			gelei(mid,t);
	}}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
