#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;

struct nod1{int x,y,nexxt;}a[10100];
int fir[10100],n,t,len=0,b[10100],bb[10100];
int ans[10100],v[10100],d[10100],w[10100];

void ins(int x,int y)
{
	len++;
	a[len].x=x;
	a[len].y=y;
	a[len].nexxt=fir[x];
	fir[x]=len;
}

void dfs(int x)
{
	if(x==n)
	{
		for(int i=1;i<=n;i++)b[i]=w[i];
		for(int i=1;i<n;i++)
		{
			int x=a[d[i]*2].x,y=a[d[i]*2].y;
			//printf("%d %d\n",x,y);
			swap(b[x],b[y]);
		}
		for(int i=1;i<=n;i++)
			bb[b[i]]=i;
		int fff=0;
		for(int i=1;i<=n;i++)
		{
			if(bb[i]<ans[i])fff=1;
			if(fff==1)ans[i]=bb[i];
			if(fff==0&&bb[i]>ans[i])break;
		}
		return ;
	}
	for(int i=1;i<n;i++)
	{
		if(v[i]==0)
		{
			d[x]=i;
			v[i]=1;
			dfs(x+1);
			v[i]=0;
		}
	}
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d ",&n);
		for(int i=1;i<=n;i++)
		{
			int x;
			scanf("%d",&x);
			w[x]=i;//pos[i]=x;
		}
		for(int i=1;i<=n;i++)
		{
			fir[i]=0;
			ans[i]=0x3f3f3f3f;
			v[i]=0;
		}len=0;
		for(int i=1;i<n;i++)
		{
			int x,y;
			scanf("%d %d",&x,&y);
			ins(x,y);ins(y,x);
			//in[x]++;in[y]++;
		}
		if(n<=10)
		{
			dfs(1);
		}
		for(int i=1;i<=n;i++)
			printf("%d ",ans[i]);
		printf("\n");
	}
	return 0;
}
/*
4
5
2 1 3 5 4
1 3
1 4
2 4
4 5
5
3 4 2 1 5
1 2
2 3
3 4
4 5
5
1 2 5 3 4
1 2
1 3
1 4
1 5
10
1 2 3 4 5 7 8 9 10 6
1 2
1 3
1 4
1 5
5 6
6 7
7 8
8 9
9 10
*/
