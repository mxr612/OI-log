#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
#define ll long long

ll k;
int nn,n,ans[110];
ll sum[110],now;

void pre()
{
	sum[0]=1;
	for(int i=1;i<n;i++)
		sum[i]=sum[i-1]*2;
}

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d %lld",&n,&k);
	pre();
	now=k;nn=n;
	for(int i=1;i<=n;i++)
	{
		//printf("%llu %llu\n",now,sum[nn-1]);
		if(now>=sum[nn-1])
		{
			ans[i]=1;
			now-=sum[nn-1];
			now=sum[nn-1]-1-now;
			nn--;
		}
		else if(now<sum[nn-1])
		{
			ans[i]=0;
			nn--;
		}
	}
	for(int i=1;i<=n;i++)
		printf("%d",ans[i]);
	return 0;
}

