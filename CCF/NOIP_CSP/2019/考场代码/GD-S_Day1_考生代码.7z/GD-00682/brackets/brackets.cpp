#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

char ss[100100];
int ans=0;
int n,tot[100100],cnt[100100];


void work1()
{
	for(int l=1;l<=n;l++)
	{
		for(int r=l;r<=n;r++)
		{
			int fff=0,sum1=0,sum2=0;
			for(int i=l;i<=r;i++)
			{
				if(ss[i]=='(')sum1++;
				else if(ss[i]==')')sum2++;
				if(sum2>sum1)
				{
					fff=1;break;
				}
			}if(sum1!=sum2)fff=1;
			if(fff==0)cnt[r]++;
		}
	}
	for(int i=1;i<=n;i++)
		cnt[i]=cnt[i-1]+cnt[i];
	for(int i=1;i<=n;i++)
	{
		ans=ans^(cnt[i]*i);
		//printf("%d %d\n",i,cnt[i]);
	}
	return ;	
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",ss+1);
	for(int i=2;i<=n;i++)
	{
		int x;
		scanf("%d",&x);
		//ins(x,i);
	}
	work1();
	printf("%d",ans);
	return 0;
}
/*
6
(())()
2 3 4 5 6
*/
/*
7
(()()))
2 3 4 5 6 7
*/
