#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
const int N=2100;
struct node{
	int to,next,num;
}a[N*2];
int T,n,w[N],ls[N],fa[N],pre[N],ans,tot;
bool v[N][N],limst[N];
void addl(int x,int y,int num)
{
	a[++tot].to=y;
	a[tot].next=ls[x];
	a[tot].num=num;
	ls[x]=tot;
}
void dfs(int x,int last)
{
	if(!limst[x])ans=min(ans,x);
	for(int i=ls[x];i;i=a[i].next){
		int y=a[i].to;
		if(y==fa[x]||v[a[i].num][last]) continue;
		fa[y]=x;pre[y]=i;
		dfs(y,a[i].num);
	}
}
int main()
{
	//freopen("tree.in","r",stdin);
	//freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while(T--){
		memset(ls,0,sizeof(ls));
		tot=1;
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			scanf("%d",&w[i]);
		for(int i=1;i<n;i++){
			int x,y;
			scanf("%d%d",&x,&y);
			addl(x,y,i);addl(y,x,i);
		}
		for(int i=1;i<=n;i++){
			ans=n+1;fa[w[i]]=0;
			for(int j=1;j<=n;j++)
				if(w[j]==i){dfs(j,0);break;}
			limst[ans]++;
			printf("%d ",ans);
			int last=0,k=w[i];
			while(ans!=k){
				if(last) v[pre[ans]][last]=1;
				last=pre[ans];swap(w[ans],w[fa[ans]]);
				ans=fa[ans];
			}
		}
		putchar('\n');
	}
}
