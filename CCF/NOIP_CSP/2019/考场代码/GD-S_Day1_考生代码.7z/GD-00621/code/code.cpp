#include<cstdio>
#include<cstring>
#include<algorithm>
#define ull unsigned long long
using namespace std;
ull n,k;
void get_code(ull n,ull k)
{
	if(!n) return;
	if(k<(1ull<<(n-1))) putchar('0'),get_code(n-1,k);
	else putchar('1'),get_code(n-1,(1ull<<n)-1-k);
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%llu%llu",&n,&k);
	get_code(n,k);
}
