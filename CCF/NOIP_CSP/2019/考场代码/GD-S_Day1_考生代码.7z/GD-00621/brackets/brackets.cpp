#include<cstdio>
#include<cstring>
#include<algorithm>
#include<vector>
#define ll long long
using namespace std;
const ll N=5e5+100;
struct node{
	ll next,to;
}a[N];
ll n,fa[N],pre[N],f[N],ls[N],ans,tot;
vector<int> v[2*N];
char c[N];
void addl(ll x,ll y)
{
	a[++tot].to=y;
	a[tot].next=ls[x];
	ls[x]=tot;
}
void dfs(ll x,ll sum)
{
	if(c[x]=='(') v[sum-((c[x]=='(')?1:-1)].push_back(x);
	if(c[x]==')'&&!v[sum].empty()){
		ll k=(v[sum-1].empty())?-1:v[sum-1][v[sum-1].size()-1];
		ll l=0,r=v[sum].size()-1;
		while(l<=r){
			ll mid=(l+r)>>1;
			if(v[sum][mid]>k) r=mid-1;
			else l=mid+1;
		}
		f[x]+=v[sum].size()-l;
	}
	for(ll i=ls[x];i;i=a[i].next)
	{
		ll y=a[i].to;f[y]+=f[x];
		dfs(y,sum+((c[y]=='(')?1:-1));
	}
	if(c[x]=='(') v[sum-((c[x]=='(')?1:-1)].pop_back();
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%lld",&n);
	scanf("%s",c+1);
	for(ll i=2;i<=n;i++){
		ll x;
		scanf("%lld",&x);
		addl(x,i);
	}
	dfs(1,n+((c[1]=='(')?1:-1));
	for(ll i=1;i<=n;i++)
		ans=ans^(i*f[i]);
	printf("%lld",ans);
}
