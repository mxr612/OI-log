#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
typedef unsigned long long ull;
int n; ull k,ans;

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);

	scanf("%d%llu",&n,&k);
	ans=0; int Tag=0,Wait=0; ull now=0;
	for(int i=n;i>=1;i--)
	{
		if(k>=1ull<<(i-1))
		{
			Wait++;
			k-=(1ull<<(i-1));
			now^=1;
		}
		ans=(ans<<1)+now;
		
		if(Tag){now^=1,Tag--;}
		Tag+=Wait,Wait=0;//��ʱ���� 
	}
	for(int i=n;i>=1;i--)
	{
		if(ans&(1ull<<(i-1)))putchar('1');
		else putchar('0');
	}
	putchar('\n');
	return 0;
}
