#include<cstdio>
#include<cstring>
#include<algorithm>
#include<cstdlib>
#define ri register int
using namespace std;
inline void myswap(ri &x,ri &y){x^=y^=x^=y;}
inline int qr()
{
	ri x=0,pd=1; char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')pd=-1; ch=getchar();}
	while('0'<=ch && ch<='9'){x=(x<<1)+(x<<3)+(ch&15); ch=getchar();}
	return x*pd;
}
const int SIZE=2100;
int n,c[SIZE],ys[SIZE];//ע��c����Ķ��壬��i��ʼʱ���ڵĽڵ��� 
struct node
{
	int x,y,next;
}a[SIZE<<1]; int len,last[SIZE<<1];

int d[SIZE];
inline void ins(int x,int y)
{
	len++; a[len]=(node){ x,y,last[x] };
	last[x]=len; d[x]++;
}

int stack[SIZE];
void solve_juhuan(int x)
{
	int top=0;
	for(ri k=last[x];k;k=a[k].next)
	{
		ri y=a[k].y;
		stack[++top]=y;
	}
	sort(stack+1,stack+top+1);
	for(ri i=top;i>=1;i--)
	{
		ri y=stack[i];
		if((y>x && ys[y]<ys[x]) || (y<x && ys[y]>ys[x]))
		{
			myswap(c[ ys[y] ],c[ ys[x] ]);
			myswap(ys[y],ys[x]);
		}
	}
}

int fa[SIZE];
int findfa(int x)
{
	if(fa[x]!=x)fa[x]=findfa(fa[x]);
	return fa[x];
}

int f[SIZE][20],dep[SIZE];
void bt_LCA(int x,int fx)
{
	f[x][0]=fx; dep[x]=dep[fx]+1;
	for(int i=0;i<15 && f[x][i];i++)
		f[x][i+1]=f[ f[x][i] ][i];
	
	for(int k=last[x];k;k=a[k].next)
	{
		int y=a[k].y;
		if(y!=fx)bt_LCA(y,x);
	}
}

int get_LCA(int x,int y)
{
	if(dep[x]<dep[y]){x^=y,y^=x,x^=y;}
	if(dep[x]>dep[y])
	{
		for(int i=15;i>=0;i--)
			if(dep[x]-(1<<i)>=dep[y])
			{
				x=f[x][i];
			}
	}
	if(x==y)return x;
	for(int i=15;i>=0;i--)
		if(f[x][i]!=f[y][i])
		{
			x=f[x][i],
			y=f[y][i];
		}
	return f[x][0];
}

void solve(int num)
{
	ri x=c[num],fx=findfa(x);
	for(ri i=1;i<=n;i++)if(ys[i]>num)
	{
		ri lca=get_LCA(x,i),ci=ys[i],k,y;
		if(fx!=findfa(lca) || findfa(i)!=fa[lca] )continue;
		while(x!=lca)
		{
			fa[x]=x;
			fx=f[x][0];
			myswap(c[ ys[x] ],c[ ys[fx] ]);
			myswap(ys[x],ys[fx]);
			x=fx;
		}
		while(lca!=i)
		{
			for(k=last[lca];k;k=a[k].next)
				if(fa[ a[k].y ]==fa[lca])
					break;
			y=a[k].y;
			myswap(c[ ys[lca] ],c[ ys[y] ]);
			myswap(ys[lca],ys[y]);
			fa[lca]=lca;
			lca=y;
		}
		fa[y]=y;
		return ;
	}
}

int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	
	int T=qr(); bool bk;
	while(T--)
	{
		bk=false;
		len=0; memset(last,0,sizeof(last));
		n=qr();
		for(ri i=1;i<=n;i++)
		{
			c[i]=qr();
			ys[ c[i] ]=i;
		}
		for(ri i=1;i<n;i++)
		{
			ri x=qr(),y=qr();
			ins(x,y), ins(y,x);
		}
		
		for(ri i=1;i<=n;i++)
		{
			if(d[i]>1)
			{
				bk=true;
				solve_juhuan(i);
				for(ri i=1;i<n;i++)printf("%d ",c[i]);
				printf("%d\n",c[n]);
				break;
			}
		}
		if(bk)continue;
		for(ri i=1;i<=n;i++)fa[i]=1;
		memset(f,0,sizeof(f)); dep[1]=1;
		bt_LCA(1,0);
		
		for(ri i=1;i<=n;i++)solve(i);
		for(ri i=1;i<n;i++)printf("%d ",c[i]);
		printf("%d\n",c[n]);
	}
	return 0;
}
