//���� ���ڵ�ı�ţ��ϸ�С���ӽڵ� 
#include<cstdio>
#include<cstring>
#include<algorithm>
#define ri register int
typedef long long ll;
using namespace std;
inline int qr()
{
	ri x=0,pd=1; char ch=getchar();
	while(ch<'0' || '9'<ch){if(ch=='-')pd=-1; ch=getchar();}
	while('0'<=ch && ch<='9'){x=(x<<1)+(x<<3)+(ch&15); ch=getchar();}
	return x*pd;
}
const int SIZE=510000;

int n; ll ans=0;
char s[SIZE];
int fa[SIZE];

struct node
{
	int son,next;
}a[SIZE<<1]; int last[SIZE],len;

inline void ins(int x,int y)
{
	len++; a[len]=(node){ y,last[x] }; last[x]=len;
}

ll tot[SIZE],front[SIZE];
char ns[SIZE]; int stack[SIZE],top;
void dfs(int x,int dep)
{
	int Tag=0;
	
	ns[dep]=s[x];
	tot[x]=tot[ fa[x] ];
	if(ns[dep]==')')
	{
		if(top)
		{
			tot[x]++;
			front[dep]=front[ (Tag=stack[top--]) ];
			tot[x]+=front[dep];
			if(!top)front[dep]++;
		}
		else front[dep]=0;
	}
	else
	{
		Tag=-1;
		if(!top)front[dep]=front[dep-1];
		else front[dep]=0;
		stack[++top]=dep;
	}
	
	for(int k=last[x];k;k=a[k].next)
	{
		int y=a[k].son;
		dfs(y,dep+1);
	}
	
	ans=ans^( (ll)x*tot[x] );
	if(Tag>0)stack[++top]=Tag;
	else if(Tag<0)top--;
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	
	memset(last,0,sizeof(last)); len=0;
	n=qr();
	scanf("%s",s+1);
	
	fa[1]=0;
	for(int i=2;i<=n;i++)
	{
		fa[i]=qr();
		ins(fa[i],i);
	}
	
	top=0; memset(front,0,sizeof(front));
	memset(tot,0,sizeof(tot));
	dfs(1,1);
	printf("%lld\n",ans);
	return 0;
}
