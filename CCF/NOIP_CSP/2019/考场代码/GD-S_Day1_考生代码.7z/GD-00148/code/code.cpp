#include<iostream>
#include<cstdio>
#define ll long long
using namespace std;
ll n,k,i,j,a[100],u=1;
inline ll in(){
	ll x=0;
	char c;
	c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9'){
		x*=10;
		x+=c-48;
		c=getchar();
	}
	return x;
}
inline void out(ll x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		out(x/10);
	}
	putchar(x%10+48);
	return;
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	n=in();
	k=in();
	u<<=n-1;
	for(i=0;i<n;i++){
		a[i]=k/u;
		if(a[i]){
		    k-=u;
			k=u-k-1;
		}
		out(a[i]);
		u>>=1;
	}
	return 0;
}
