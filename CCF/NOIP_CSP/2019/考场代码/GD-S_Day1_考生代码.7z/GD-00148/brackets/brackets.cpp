#include<iostream>
#include<cstdio>
#define ll long long
using namespace std;
ll n,i,son[1000000]={1},nex[1000000]={0},v[1000000]={0},f[1000000]={0},sta[1000000],top=1,ans=0;
char c[1000000];
inline ll in(){
	ll x=0;
	char c;
	c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9'){
		x*=10;
		x+=c-48;
		c=getchar();
	}
	return x;
}
inline void out(ll x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		out(x/10);
	}
	putchar(x%10+48);
	return;
}
void dfs(ll x){
	ll j,now=0;
	v[x]+=v[f[x]];
	if(c[x]=='('){
		sta[top]=-1;
	}
	else{
		sta[top]=1;
		j=top;
		while(now>=0&&j>0){
			now+=sta[j];
			if(now==0)v[x]++;
			j--;
		}
	}
	top++;
	j=son[x];
	while(j){
		dfs(j);
		j=nex[j];
	}
	top--;
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
		n=in();
		for(i=1;i<=n;i++){
			c[i]=getchar();
			while(c[i]!='('&&c[i]!=')')c[i]=getchar();
			f[i]=0;
			son[i]=0;
			nex[i]=0;
			v[i]=0;
		}
		i=2;
		while(i<=n){
			f[i]=in();
		    nex[i]=son[f[i]];
		    son[f[i]]=i;
			i++;
		}
		dfs(1);
		for(i=1;i<=n;i++){
			v[i]*=i;
			ans^=v[i];
		}
		out(ans);
	return 0;
}
