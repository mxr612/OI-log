#include<iostream>
#include<cstdio>
#define ll long long
using namespace std;
ll t,n,i,x,y,v;
inline ll in(){
	ll x=0;
	char c;
	c=getchar();
	while(c<'0'||c>'9')c=getchar();
	while(c>='0'&&c<='9'){
		x*=10;
		x+=c-48;
		c=getchar();
	}
	return x;
}
inline void out(ll x){
	if(x<0){
		x=-x;
		putchar('-');
	}
	if(x>9){
		out(x/10);
	}
	putchar(x%10+48);
	return;
}
int main(){
	freopen("tree.in","r",stdin);
    freopen("tree.out","w",stdout);
	t=in();
	while(t){
		t--;
		n=in();
		for(i=1;i<=n;i++){
			v=in();
		}
		for(i=1;i<n;i++){
			x=in();
			y=in();
		}
		for(i=1;i<=n;i++){
			out(i);
			putchar(' ');
		}
		putchar('\n');
	}
	return 0;
}
