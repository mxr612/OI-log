#include<cstdio>
#include<cstring>
using namespace std;
struct node{int next,last,en;} e[500001];
int n,a[500001],x,tot,b[500001],q[500001],top;
long long p[500001],ans,s;
bool bj=false;
char ch;
void add(int x,int y)
{
	e[++tot].en=y;
	e[tot].next=e[x].last;
	e[x].last=tot;
}
void dg(int x,int k)
{
	s=0;top=0;
	memset(p,0,sizeof(p));
	for (int i=1;i<k;i++)
	{
		q[++top]=b[i];
		if (q[top]&&!q[top-1]&&top>=2)
		{
			p[top-1]=0;
			top-=2;
			p[top]++;
			s+=p[top];
		}
	}
	ans^=s*x;
	for (int i=e[x].last;i;i=e[i].next)
	{
		b[k]=a[e[i].en];
		dg(e[i].en,k+1);
		b[k]=0;
	}
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);getchar();
	for (int i=1;i<=n;i++)
	{
		scanf("%c",&ch);
		if (ch==')') a[i]=1;
	}
	for (int i=2;i<=n;i++)
	{
		scanf("%d",&x);
		if (x!=i-1) bj=true;
		add(x,i);
	}
	if (!bj)
	{
		for (int i=1;i<=n;i++)
		{
			q[++top]=a[i];
			if (q[top]&&!q[top-1]&&top>=2)
			{
				p[top-1]=0;
				top-=2;
				p[top]++;
				s+=p[top];
			}
			ans^=s*i;
		}
		printf("%lld",ans);
		return 0;
	}
	b[1]=a[1];
	dg(1,2);
	printf("%lld",ans);
	return 0;
}
