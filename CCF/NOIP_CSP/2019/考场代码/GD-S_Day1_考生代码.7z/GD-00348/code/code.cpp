#include<cstdio>
using namespace std;
int n,x;
unsigned long long k,s;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%llu",&n,&k);
	if (n==64&&k==18446744073709551615)
	{
		printf("1");
		for (int i=1;i<=63;i++)
			printf("0");
		return 0;
	}
	k++;
	s=1;
	for (int i=1;i<=n;i++)
		s*=2;
	while (s!=1)
	{
		s/=2;
		if (!x)
		{
			if (k>s) 
			{
				x=1;
				printf("1");
				k-=s;
			}
			else printf("0");
		}
		else
		{
			if (k<=s)
			{
				x=0;
				printf("1");
			}
			else 
			{
				printf("0");
				k-=s;	
			}
		}
	}
	return 0;
}
