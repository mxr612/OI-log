#include<cstdio>
#include<cstring>
using namespace std;
struct node{int next,en,last;} e[4001];
int t,n,a[2001],x[2001],y[2001],ru[2001],tot,b[2001],c[2001];
bool bj,bz[4001];
void add(int x,int y)
{
	e[++tot].en=y;
	e[tot].next=e[x].last;
	e[x].last=tot;	
}
void dg(int x,int fa,int y)
{
	if (x==y) 
	{
		bj=true;
		return;
	}
	for (int i=e[x].last;i;i=e[i].next)
	if (!bz[i])
	{
		if (e[i].en==fa) continue;
		int t=a[x];
		a[x]=a[e[i].en];
		a[e[i].en]=t;
		bz[i]=true;
		if (i&1) bz[i+1]=true;
		else bz[i-1]=true;
		dg(e[i].en,x,y);
		if (bj) return;
		t=a[x];
		a[x]=a[e[i].en];
		a[e[i].en]=t;
		bz[i]=false;
		if (i&1) bz[i+1]=false;
		else bz[i-1]=false;
	}
}
void dg2(int k)
{
	if (k==n)
	{
		bj=false;
		for (int i=1;i<=n;i++)
			if (c[i]<b[i]||!b[i]) 
			{
				bj=true;
				break;
			}
			else if (c[i]>b[i]) break;
		if (bj)
		{
			for (int i=1;i<=n;i++)
				b[i]=c[i];
		}
	}
	else
	{
		for (int i=1;i<n;i++)
		if (!bz[i])
		{
			bz[i]=true;
			int t=a[x[i]];
			a[x[i]]=a[y[i]];
			a[y[i]]=t;
			c[a[x[i]]]=x[i];
			c[a[y[i]]]=y[i];
			dg2(k+1);
			t=a[x[i]];
			a[x[i]]=a[y[i]];
			a[y[i]]=t;
			c[a[x[i]]]=x[i];
			c[a[y[i]]]=y[i];
			bz[i]=false;
		}
	}
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while (t--)
	{
		scanf("%d",&n);
		for (int i=1;i<=n;i++)
			scanf("%d",&a[i]);
		memset(ru,0,sizeof(ru));
		memset(e,0,sizeof(e));
		tot=0;
		for (int i=1;i<n;i++)
		{
			scanf("%d%d",&x[i],&y[i]);
			ru[x[i]]++;
			ru[y[i]]++;
			add(x[i],y[i]);
			add(y[i],x[i]);
		}
		int s=0;
		bj=false;
		for (int i=1;i<=n;i++)
			if (ru[i]!=2) 
			{
				if (ru[i]==1) s++;
				else 
				{
					bj=true;
					break;
				}
			}
		memset(bz,0,sizeof(bz));
		if (s==2&&!bj)
		{
			for (int i=1;i<n;i++)
			{
				int min=0x7FFFFFFF,p;
				for (int j=i+1;j<=n;j++)
					if (min>a[j]) min=a[j],p=j;
				bj=false;
				dg(p,0,i);
			}
			for (int i=1;i<=n;i++)
				printf("%d ",a[i]);
			printf("\n");
		}
		else 
		{
			memset(b,0,sizeof(b));
			dg2(1);
			for (int i=1;i<=n;i++)
				printf("%d ",b[i]);
			printf("\n");
		}
	}
	return 0;
}
