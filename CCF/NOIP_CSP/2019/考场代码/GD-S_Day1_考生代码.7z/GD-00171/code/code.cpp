#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <map>

#define ULL unsigned long long

using namespace std;

int main() {
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	int n, pos = 0; ULL b;
	cin >> n >> b;
	for (int i = n - 1; i >= 0; i--) {
		if (b < (1ull << i)) {
			printf("%d", pos);
			pos = 0;
		}
		else {
			printf("%d", (pos ^ 1));
			b -= (1ull << i);
			pos = 1;
		}
	}
	return 0;
}
