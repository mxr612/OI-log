#include <iostream>
#include <cstring>
#include <cstdio>
#include <cmath>

using namespace std;

const int maxn = 2e3 + 5;
int fr[maxn], to[maxn];
int n, num[maxn];
int deg[maxn];

int plan[maxn], used[maxn];
int tmp[maxn], ls[maxn], ans[maxn];

void dfs(int p) {
	if (p == n) {
		for (int i = 1; i <= n; i++) tmp[i] = num[i];
		for (int i = 1; i < n; i++)
			swap(tmp[fr[plan[i]]], tmp[to[plan[i]]]);
		for (int i = 1; i <= n; i++) ls[tmp[i]] = i;
		bool chg = false;
		for (int i = 1; i <= n; i++) {
			if (ls[i] == ans[i]) continue;
			if (ls[i] < ans[i]) { chg = true; break; }
			else break;
		} 
		if (chg) for (int i = 1; i <= n; i++) ans[i] = ls[i];
	}
	for (int i = 1; i < n; i++) if (!used[i]) {
		plan[p] = i, used[i] = true;
		dfs(p + 1);
		used[i] = false;
	}
}

void solve() {
	int mxdeg = 0, p;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) 
		scanf("%d", &num[i]), ans[i] = 99999999;
	for (int i = 1; i < n; i++) {
		int u, v; scanf("%d%d", &u, &v);
		fr[i] = u, to[i] = v;
	}
	dfs(1);
	for (int i = 1; i <= n; i++) printf("%d ", ans[i]);
	putchar('\n');
}
int main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	int T; scanf("%d", &T);
	while (T--)
		solve();
	return 0;
}
