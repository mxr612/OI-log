#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#define LL long long

using namespace std;

const int maxn = 5e5 + 5;

struct Edge {
	int v, nxt;
	Edge(int v = 0, int nxt = 0) : v(v), nxt(nxt) {} 
} E[maxn];
int n;

int hd[maxn], tote;
void adde(int u, int v) {
	E[++tote] = Edge(v, hd[u]), hd[u] = tote;
}

char bra[maxn];
LL f[maxn], ans;
int fa[maxn], cnt[maxn], blg[maxn];
stack<int> bra_l[maxn];

void dfs(int u, int blg) {
	int matp = 0;
	if (bra[u] == '(') {
		bra_l[blg].push(u);
	} else {
		if (bra_l[blg].empty()) {
			blg = u;
		} else {
			matp = bra_l[blg].top();
			cnt[u] = cnt[fa[matp]] + 1;
			bra_l[blg].pop();
		}
	}
	f[u] = f[fa[u]] + cnt[u];
	for (int i = hd[u]; i; i = E[i].nxt)
		if (E[i].v != fa[u]) dfs(E[i].v, blg);
	if (bra[u] == '(') bra_l[blg].pop();
	else if (matp) bra_l[blg].push(matp);
}

int main() {
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	scanf("%d\n", &n);
	scanf("%s", bra + 1);
	blg[0] = 0;
	for (int i = 2; i <= n; i++) {
		scanf("%d", &fa[i]);
		adde(fa[i], i);
	}
	dfs(1, 0);
	for (int i = 1; i <= n; i++) {
		ans ^= i * f[i];
	}
	printf("%lld\n", ans);
	return 0;
}
