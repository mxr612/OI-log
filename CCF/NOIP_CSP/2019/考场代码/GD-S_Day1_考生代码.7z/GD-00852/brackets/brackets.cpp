#include <cstdio>

using namespace std;

#define ll long long

const int maxn = 5e5+3;

int ecnt, to[maxn], las[maxn], head[maxn], fa[maxn];
int n, sum, cnt, sta1[maxn], sta2[maxn];
ll f[maxn], ans;
char str[maxn];

void add_e(int u, int v) {
	to[++ecnt] = v;
	las[ecnt] = head[u];
	head[u] = ecnt;
}

void dfs(int u) {
	if (str[u-1] == '(') {
		cnt++;
		sta1[cnt] = sum;
		sta2[cnt] = u;
		for (int i = head[u]; i; i = las[i]) dfs(to[i]);
		cnt--;
	}
	else{
		if (cnt && str[sta2[cnt]-1] == '(') {
			sum++;
			int t1 = sta1[cnt], t2 = sta2[cnt];
			cnt--;
			f[u] = sum-sta1[cnt];
			for (int i = head[u]; i; i = las[i]) dfs(to[i]);
			sum--;
			cnt++;
			sta1[cnt] = t1;
			sta2[cnt] = t2;
		}else {
			cnt++;
			sta1[cnt] = sum;
			sta2[cnt] = u;
			for (int i = head[u]; i; i = las[i]) dfs(to[i]);
			cnt--;
		}
	}
}

int main() {
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	
	scanf("%d%s", &n, str);
	for (int i = 2; i <= n; i++) {
		scanf("%d", &fa[i]);
		add_e(fa[i], i);
	}
	dfs(1);
	for (int i = 1; i <= n; i++) ans = (ans^(f[i]*i));
	printf("%lld", ans);
	
	return 0;
}
