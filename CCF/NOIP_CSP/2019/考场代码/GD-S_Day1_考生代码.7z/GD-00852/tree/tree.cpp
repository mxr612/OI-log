#include <cstdio>
#include <cstring>

using namespace std;

const int maxn = 50000003;

int T, n,a[maxn], deg[maxn];

int main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		for (int i = 1; i <= n; i++) scanf("%d", &a[i]);
		memset(deg, 0,sizeof(deg));
		for (int i = 1, u, v; i < n; i++) {
			scanf("%d%d", &u, &v);
			deg[u]++;
			deg[v]++;
		}
		for (int i = 1; i <= n; i++)
			if (deg[i] == n-1) {
				int t = i-1;
				for (int j = 1; j <= n; j++)
					if (a[i] < a[t]) t = i;
				swap(a[i], a[t]);
			}
		for (int i = 1; i <= n; i++)
		printf("%d", a[i]);
	}
	
	return 0;	
}
