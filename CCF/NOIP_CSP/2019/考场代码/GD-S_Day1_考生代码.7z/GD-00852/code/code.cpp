#include <iostream>
#include <cstdio>

#define ull unsigned long long

using namespace std;

int n;

void write(ull num) {
	int cnt = 0, b[103];
	if (num == 0) b[++cnt] = 0;
	while (num) {
		b[++cnt] = num&1;
		num >>= 1;
	}
	for (int i = cnt+1; i <= n; i++) cout << 0;
	for (int i = cnt; i > 0; i--) cout << b[i];
}

void solve(int th, ull k, ull l, ull r, int tur) {
	if (l == r) { write(l); return; }
	
	ull mid = (l+r)>>1;
	ull lsiz = (1ull<<(th-1));
	
	if (k <= lsiz-1)
		if (tur) solve(th-1, k, mid+1, r, tur^1);
		else solve(th-1, k, l, mid, tur);
	else
		if (tur) solve(th-1, k-lsiz, l, mid, tur);
		else solve(th-1, k-lsiz, mid+1, r, tur^1);
}

int main() {
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	
	ull k;
	
	cin >> n >> k;
	ull a = 1;
	if (n == 64) a = 18446744073709551615ull;
	else a = (a<<n)-1;
	solve(n, k, 0, a, 0);
	
	return 0;
}
