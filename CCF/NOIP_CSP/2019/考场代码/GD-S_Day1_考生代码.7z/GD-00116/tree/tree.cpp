#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#define maxn 2005
#define mem(a) memset(a,0,sizeof(a))
using namespace std;

int T,n,i,j,k,x,y,a[maxn],b[maxn],w[maxn],E[maxn][2],ans[maxn];
int em,e[maxn*2],nx[maxn*2],ls[maxn],bz[maxn*2],du[maxn];

void insert(int x,int y){
	em++; e[em]=y; nx[em]=ls[x]; ls[x]=em;
	em++; e[em]=x; nx[em]=ls[y]; ls[y]=em;
}

void dg(int c){
	if (c==n){
		for(int i=1;i<=n;i++) b[a[i]]=i;
		if (ans[1]==0) for(int i=1;i<=n;i++) ans[i]=b[i];
		else{
			int i;
			for(i=1;i<=n&&b[i]==ans[i];i++);
			if (i<=n&&b[i]<ans[i]) 
				for(i=1;i<=n;i++) ans[i]=b[i];
		}
	}
	for(int i=1;i<n;i++) if (!bz[i]){
		bz[i]=1,swap(a[E[i][0]],a[E[i][1]]);
		dg(c+1);
		bz[i]=0,swap(a[E[i][0]],a[E[i][1]]);
	}
}

int fa[maxn];
int father(int x){return (fa[x]==x)?x:fa[x]=father(fa[x]);}
void Doit_juhua(){
	for(i=1;i<=n;i++) fa[i]=i;
	for(i=1;i<n;i++){
		for(j=1;j<=n;j++) if (!bz[j]&&father(w[i])!=father(j)) {
			bz[j]=1,ans[i]=j;
			fa[fa[w[i]]]=fa[j];
			break;
		}
	}
	for(i=1;i<=n;i++) if (!bz[i]) ans[n]=i;
	for(i=1;i<=n;i++) printf("%d ",ans[i]);
	printf("\n");
}

int main(){
//	freopen("ceshi.in","r",stdin);
//	freopen("ceshi.out","w",stdout);
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while (T--){
		scanf("%d",&n);
		em=1,mem(ls),mem(bz),mem(du),mem(bz);
		for(i=1;i<=n;i++) scanf("%d",&k),a[k]=i,w[i]=k;
		for(i=1;i<n;i++) scanf("%d%d",&x,&y),insert(x,y),E[i][0]=x,E[i][1]=y,du[x]++,du[y]++;
		mem(ans);
		int tp=0;
		for(i=1;i<=n;i++) if (du[i]==n-1) tp=1;
		if (tp) {
			Doit_juhua();
			continue;
		}
		mem(ans);
		dg(1);
		for(i=1;i<=n;i++) printf("%d ",ans[i]);
		printf("\n");
	}
}

