#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#define maxn 500005
#define maxm 1000005
#define ll long long 
using namespace std;

int n,a[maxn],i,j,k,fa[maxn],d[maxm*2];
int em,e[maxn],nx[maxn],ls[maxn];
ll ans[maxn],sum;
char ch;

void read(int &x){
	x=0; char ch=getchar();
	for(;ch<'0'||ch>'9';ch=getchar());
	for(;ch>='0'&&ch<='9';ch=getchar()) x=x*10+ch-'0';
}

void insert(int x,int y){
	em++; e[em]=y; nx[em]=ls[x]; ls[x]=em;
}

int tag;
void DFS(int x){
	int tmp=0;
	tag+=a[x],d[a[x]-tag+maxm]++;
	tmp=d[-1-tag+maxm],d[-1-tag+maxm]=0;
	
	ans[x]=ans[fa[x]]+d[-tag+maxm];
	for(int i=ls[x];i;i=nx[i]) 
		DFS(e[i]);
	
	d[-1-tag+maxm]=tmp;
	d[a[x]-tag+maxm]--,tag-=a[x];
}

int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	read(n);
	for(ch=getchar();ch!='('&&ch!=')';ch=getchar());
	for(i=1;i<=n;i++,ch=getchar()) a[i]=(ch=='(')?1:-1;
	for(i=2;i<=n;i++) read(fa[i]),insert(fa[i],i);
	DFS(1);
	for(i=1;i<=n;i++) sum^=ans[i]*i;
	printf("%lld",sum);
}


