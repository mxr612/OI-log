#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
#define ll unsigned long long
#define maxn 100
using namespace std;

int i,j,a[maxn];
ll n,k;

int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%llu%llu",&n,&k);
	for(i=0;i<n;i++) a[i]=k&1,k>>=1;
	for(i=n-1;i>=0;i--){
		printf("%d",a[i]);
		if (a[i]) for(j=i-1;j>=0;j--) a[j]^=1;
	}
}

