#include<bits/stdc++.h>
using namespace std;
int now[1001000];
struct node{
	int v,nxt;
}e[100100];
int front[1001000],cnt;
int deg[1001000];
inline void Add(int u,int v){
	e[++cnt].v=v;
	e[cnt].nxt=front[u];
	front[u]=cnt;
}
int dep[1001000];

inline void dfs2(int x,int fa);
int vis[1000100],book[1001000],n;
inline void dfs(int x,int fa,int aim){
	if(vis[x])return;
	if(x==aim){
		dfs2(x,aim);return;
	}
	for(int i=front[x];i;i=e[i].nxt){
		int v=e[i].v;
		if(v!=fa)dfs(v,x,aim);	
	}
}
inline void dfs2(int x,int fa){
	vis[x]=1;
	swap(now[x],now[fa]);
	for(int i=front[x];i;i=e[i].nxt){
		int v=e[i].v;
		if(v!=fa){
			dfs2(v,x);
		}
	}
}
int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		bool s1=false;
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&now[i]);
			book[now[i]]=i;
		}
		for(int i=1;i<n;i++){
			int x,y;
			scanf("%d%d",&x,&y);
			Add(x,y);Add(y,x);
			deg[x]++;deg[y]++;
		}
		for(int i=1;i<=n;i++){
			if(deg[i]>2)break;
			else s1=true;
		}
		if(s1){
			int nt=1;
			for(int i=1;i<=n;i++){
				if(!vis[i]){
					dfs(i,0,book[nt]);
					nt++;
				}
			}
			for(int i=1;i<=n;i++)cout<<now[i]<<" ";
			cout<<endl;
		}
	}
	return 0;
}
