#include<bits/stdc++.h>
using namespace std;
int fa[1001000];
char ch[1000100];
bool pd[1001000];
long long pd2[1001000];
long long pd3[1001000];
bool flag=false;
struct node{
	int v,nxt;
}e[1001000];
int front[1001000],cnt;
inline void Add(int u,int v){
	e[++cnt].v=v;
	e[cnt].nxt=front[u];
	front[u]=cnt;
}
stack<char> s;
long long ans,f[1000100];
inline void dfs(int x){	
	if(ch[x]=='(')pd[x]=true;
	else pd[x]=false;
	bool now=false,now2=false;
	if(!s.empty()){
		if(s.top()=='(' and !pd[x]){
			s.pop();
			if(flag){
				f[x]=f[fa[x]]+pd2[fa[x]]+1ll;
				pd2[x]=pd2[fa[x]]+1ll;
				flag=false;now2=true;
			}
			else{
				f[x]=f[fa[x]]+1ll;
			}
			now=true;
		}
	}
	else{
		f[x]=f[fa[x]];pd2[x]=pd2[fa[x]];
	}
	if(pd[x]){
		s.push('(');
		if(!s.empty() and flag)pd2[x]=0ll;
		flag=true;
	}
//	if(s.empty())return;
	for(int i=front[x];i;i=e[i].nxt){
		int v=e[i].v;
		if(v!=fa[x]){
			dfs(v);
		}	
	}
	if(pd[x] and !s.empty()){
		s.pop();flag=false;
	}
	if(now){
		s.push('(');
		if(now2)flag=true;	
	}
//	ans=ans^((long long)x*f[x]);
}
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	int n;
	scanf("%d",&n);
	scanf("%s",ch+1);
//	for(int i=1;i<=n;i++)scanf(" %c",&ch[i]);
	bool s1=true;
	for(int i=2;i<=n;i++){
		scanf("%d",&fa[i]);
		Add(i,fa[i]);Add(fa[i],i);
		if(i-1!=fa[i])s1=false;
	}
    dfs(1);
	
	for(int i=1;i<=n;i++)ans=ans^((long long)i*f[i]);
	
	printf("%lld",ans);
	return 0;
}
