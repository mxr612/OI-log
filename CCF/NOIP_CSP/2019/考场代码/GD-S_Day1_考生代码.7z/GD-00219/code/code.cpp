#include<bits/stdc++.h>
using namespace std;
//int Log[1001000];
unsigned long long n,k;
unsigned long long qpow[65];
int a[1000100];
std::queue<int>q;
inline void dfs(int step)
{
	if(!step)return;
	if(k>qpow[step-1])q.push(1),k=qpow[step]-k+1;
	else q.push(0);
	dfs(step-1);
}

int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);

	scanf("%llu%llu",&n,&k);
	//Log[0]=-1;
	//for(int i=1;i<=n;i++)Log[i]=Log[i>>1]+1;
	qpow[0]=1ll;
	for(int i=1;i<=64;i++)qpow[i]=qpow[i-1]<<1;
	k++;
	dfs(n);
	//for(int i=1;i<=n;i++)std::cout<<a[i]<<" ";
	while(!q.empty()){
		printf("%d",q.front());
		q.pop();
	}
	return 0;
}
