#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <algorithm>

#define MAX_N (2000 + 5)

using namespace std;

struct Edge
{
	int to;
	int next;
};

int T;
int n;
int a[MAX_N];
int h[MAX_N], tot;
Edge e[MAX_N << 1];
int deg[MAX_N];

inline void AddEdge(int u, int v)
{
	e[++tot].to = v;
	e[tot].next = h[u];
	h[u] = tot;
	return;
}

int main()
{
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	scanf("%d", &T);
	int u, v;
	while (T--)
	{
//			memset(h, 0, sizeof h);
//			tot = 0;
//			for (int i = 1; i < n; ++i)
//			{
//				scanf("%d%d", &u, &v);
//				AddEdge(u, v);
//				AddEdge(v, u);
//				++deg[u];
//				++deg[v];
//			}
		scanf("%d", &n);
		for (int i = 1; i <= n; ++i)
		{
			scanf("%d", &u);
			a[u] = i;
		}
		if (n <= 10)
		{
			int p[15], tu[15], tv[15], ta[15], tq[15], ans[15];
			for (int i = 1; i < n; ++i)
			{
				scanf("%d%d", &tu[i], &tv[i]);
			}
			for (int i = 1; i < n; ++i)
			{
				p[i] = i;
			}
			memset(ans, 0x3f, sizeof ans);
			do
			{
				memcpy(ta, a, sizeof ta);
				for (int i = 1; i < n; ++i)
				{
					swap(ta[tu[p[i]]], ta[tv[p[i]]]);
				}
				for (int i = 1; i <= n; ++i)
				{
					tq[ta[i]] = i;
				}
				for (int i = 1; i <= n; ++i)
				{
					if (tq[i] < ans[i])
					{
						memcpy(ans, tq, sizeof ans);
						break;
					}
					if (tq[i] > ans[i]) break;
				}
			}
			while (next_permutation(p + 1, p + n));
			for (int i = 1; i <= n; ++i)
			{
				printf("%d ", ans[i]);
			}
			printf("\n");
		}
		else if (n <= 160)
		{
			int p[165], tu[165], tv[165], ta[165], tq[165], ans[165];
			int tms = 0;
			for (int i = 1; i < n; ++i)
			{
				scanf("%d%d", &tu[i], &tv[i]);
			}
			for (int i = 1; i < n; ++i)
			{
				p[i] = i;
			}
			memset(ans, 0x3f, sizeof ans);
			while (tms <= 5000)
			{
				memcpy(ta, a, sizeof ta);
				for (int i = 1; i < n; ++i)
				{
					swap(ta[tu[p[i]]], ta[tv[p[i]]]);
				}
				for (int i = 1; i <= n; ++i)
				{
					tq[ta[i]] = i;
				}
				for (int i = 1; i <= n; ++i)
				{
					if (tq[i] < ans[i])
					{
						memcpy(ans, tq, sizeof ans);
						break;
					}
					if (tq[i] > ans[i]) break;
				}
				random_shuffle(p + 1, p + n);
				++tms;
			}
			for (int i = 1; i <= n; ++i)
			{
				printf("%d ", ans[i]);
			}
			printf("\n");
		}
		else
		{
			int p[2005], tu[2005], tv[2005], ta[2005], tq[2005], ans[2005];
			int tms = 0;
			for (int i = 1; i < n; ++i)
			{
				scanf("%d%d", &tu[i], &tv[i]);
			}
			for (int i = 1; i < n; ++i)
			{
				p[i] = i;
			}
			memset(ans, 0x3f, sizeof ans);
			while (tms <= 5000)
			{
				memcpy(ta, a, sizeof ta);
				for (int i = 1; i < n; ++i)
				{
					swap(ta[tu[p[i]]], ta[tv[p[i]]]);
				}
				for (int i = 1; i <= n; ++i)
				{
					tq[ta[i]] = i;
				}
				for (int i = 1; i <= n; ++i)
				{
					if (tq[i] < ans[i])
					{
						memcpy(ans, tq, sizeof ans);
						break;
					}
					if (tq[i] > ans[i]) break;
				}
				random_shuffle(p + 1, p + n);
				++tms;
			}
			for (int i = 1; i <= n; ++i)
			{
				printf("%d ", ans[i]);
			}
			printf("\n");
		}
	}
	return 0;
}
