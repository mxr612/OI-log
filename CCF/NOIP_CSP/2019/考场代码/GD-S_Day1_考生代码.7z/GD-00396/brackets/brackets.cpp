// beifen

#include <iostream>
#include <fstream>
#include <cstdio>

#define MAX_N (500000 + 5)

using namespace std;

struct Edge
{
	int to;
	int next;
};

int n;
int a[MAX_N], sum[MAX_N];
char str[MAX_N];
int par[MAX_N];
int h[MAX_N], tot;
Edge e[MAX_N];

 int cnt[MAX_N << 1];
 const int pls = 500000;
int pos[MAX_N << 1];
long long dp[MAX_N];
long long ans;

inline void AddEdge(int u, int v)
{
	e[++tot].to = v;
	e[tot].next = h[u];
	h[u] = tot;
	return;
}

void DFS(int u)
{
	int v;
	bool fg = 0;
	sum[u] = sum[par[u]] + a[u];
	dp[u] = dp[par[u]];
	v = par[u];
	while (v)
	{
		if (sum[v] < sum[u])
		{
			fg = 1;
			break;
		}
		if (sum[v] == sum[u]) break;
		v = par[v];
	}
	if (fg)
	{
		int tmp = pos[sum[u] + pls];
		pos[sum[u] + pls] = cnt[sum[u] + pls];
		++cnt[sum[u] + pls];
		ans ^= u * dp[u];
		for (int i = h[u]; i; i = e[i].next)
		{
			v = e[i].to;
			DFS(v);
		}
		--cnt[sum[u] + pls];
		pos[sum[u] + pls] = tmp;
	}
	else
	{
		dp[u] += cnt[sum[u] + pls] - pos[sum[u] + pls];
		++cnt[sum[u] + pls];
		ans ^= u * dp[u];
		for (int i = h[u]; i; i = e[i].next)
		{
			v = e[i].to;
			DFS(v);
		}
		--cnt[sum[u] + pls];
	}
//	printf("%d %lld\n", u, dp[u]);
	return;
}

int main()
{
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	scanf("%d%s", &n, str + 1);
	for (int i = 1; i <= n; ++i)
	{
		a[i] = (str[i] == '(' ? 1 : -1);
	}
	for (int i = 2; i <= n; ++i)
	{
		scanf("%d", &par[i]);
		AddEdge(par[i], i);
	}
	cnt[0 + pls] = 1;
	DFS(1);
	printf("%lld", ans);
	return 0;
}


//#include <iostream>
//#include <fstream>
//#include <cstdio>
//
//#define MAX_N (500000 + 5)
//
//using namespace std;
//
//struct Edge
//{
//	int to;
//	int next;
//};
//
//int n;
//int a[MAX_N], sum[MAX_N];
//char str[MAX_N];
//int par[MAX_N];
//int h[MAX_N], tot;
//Edge e[MAX_N];
//
//// int cnt[MAX_N << 1];
//// const int pls = 500000;
//long long dp[MAX_N];
//long long ans;
//
//inline void AddEdge(int u, int v)
//{
//	e[++tot].to = v;
//	e[tot].next = h[u];
//	h[u] = tot;
//	return;
//}
//
//void DFS(int u)
//{
//	int v, tmp = 0;
//	sum[u] = sum[par[u]] + a[u];
//	dp[u] = dp[par[u]];
//	v = par[u];
//	while (v)
//	{
//		if (sum[v] < sum[u]) break;
//		if (sum[v] == sum[u]) ++tmp;
//		v = par[v];
//	}
//	if (!v && !sum[u]) ++tmp;
//	dp[u] += tmp;
////	printf("%d %lld\n", u, dp[u]);
//	ans ^= u * dp[u];
//	for (int i = h[u]; i; i = e[i].next)
//	{
//		v = e[i].to;
//		DFS(v);
//	}
//	return;
//}
//
//int main()
//{
//	freopen("brackets.in", "r", stdin);
//	freopen("brackets.out", "w", stdout);
//	scanf("%d%s", &n, str + 1);
//	for (int i = 1; i <= n; ++i)
//	{
//		a[i] = (str[i] == '(' ? 1 : -1);
//	}
//	for (int i = 2; i <= n; ++i)
//	{
//		scanf("%d", &par[i]);
//		AddEdge(par[i], i);
//	}
//	DFS(1);
//	printf("%lld", ans);
//	return 0;
//}
