#include <iostream>
#include <fstream>
#include <cstdio>

using namespace std;

int n;
unsigned long long K;
int ans[100];

void DFS(int now, unsigned long long rk)
{
	if (!now) return;
//	cout << now << " " << rk << "\n";
	unsigned long long tmp = 1ull << now - 1;
	if (rk < tmp) ans[now] = 0;
	else ans[now] = 1, rk = tmp - (rk - tmp) - 1;
	DFS(now - 1, rk);
	return;
}

int main()
{
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	cin >> n >> K;
	DFS(n, K);
	for (int i = n; i; --i)
	{
		cout << ans[i];
	}
	return 0;
}
