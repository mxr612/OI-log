#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <string>
#include <cstring>
#include <queue>
#include <vector>
using namespace std;
int n,x,y,len,b[500005],sum,f[500005],g[1000005];
string st;
long long ans;
char a[500005];
void dfs(int s)
{
	if (s==b[s]) return;
	dfs(b[s]);
	st+=a[s];
}
int ddd(string st)
{
	int ans=0;
	int len=st.size();
	for (int i=0;i<len;i++)
	{
		int q=0,p=0;
		for (int j=i;j<len;j++)
		{
			if (st[j]=='(') q++; else p++;
			if (p>q) break;
			if (q==p) ans++;
		}
	}
	return ans;
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	cin>>st;
	for (int i=1;i<=n;i++) a[i]=st[i-1];
	b[1]=1;
	for (int i=1;i<n;i++) 
	{
		scanf("%d",&x);
		b[i+1]=x;
	}
	for (int i=2;i<=n;i++)
	{
		st=a[1]; x=0; y=0; sum=0;
		dfs(i);
		len=st.size();
		sum=ddd(st);
		ans=ans^(i*sum);
	}
	cout<<ans;
	return 0;
}
		
			
		
