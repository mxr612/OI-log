#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <string>
#include <cstring>
#include <queue>
#include <vector>
using namespace std;
int t,n,s,w,a[2005],d[2005],c[2005],b[2005],minn;
void done(int x,int y)
{
	if (x==y) { printf("%d",d[x]); return; }
	w=0; s=0;
	minn=2147483647;
	for (int i=x;i<=y;i++)
	{
		if (minn>d[i]) { minn=d[i]; w=i; }
	}
	cout<<minn<<" ";
	for (int i=x;i<w-1;i++) printf("%d ",d[i]);
	d[w]=d[w-1];
	if (w==x) done(w+1,y); else 
	done(w,y);
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	while (t--)
	{
		scanf("%d",&n);
		for (int i=1;i<=n;i++)
		{
			scanf("%d",&a[i]);
			d[i]=a[i];
		}
		for (int i=1;i<n;i++) 
		{
			scanf("%d%d",&b[i],&c[i]);
		}
		done(1,n);
		cout<<endl;
	}
	return 0;
}
		
		
			
		 
		
		
