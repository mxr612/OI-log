#include <iostream>
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <string>
#include <cstring>
#include <queue>
#include <vector>
using namespace std;
int n,w,c[105],s;
long long k,m,a[105],b[105],ans;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k; m=k;
	a[0]=1; a[1]=2; a[2]=4;
	for (int i=2;i<=n;i++) a[i]=a[i-1]<<1;
	for (int i=n;i>=1;i--)
		if (a[i]/2<=m) { w++; c[w]=1; m=a[i]-m-1; } 
		 else { w++; c[w]=0; } 
	for (int i=1;i<=w;i++) printf("%d",c[i]);
	return 0;
}
		
		
	
	
		
	
