#include<cstdio>
#include<string>
using namespace std;
int n,c[500005],ans=0,k,top,tail,f;
char a[500005],b[500005];
int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf(" %c",&a[i]);
	}
	for(int i=2;i<=n;i++){
		scanf("%d",&f);
	}
	for(int i=2;i<=n;i++){
		k=0;top=tail=1;
//		while(){
			
//		}��ȡ�Ӵ�
//		for(int j=0;j<=i;j++)printf("%c",zs[j]);
//		printf("\n");
		int kk=0;
		for(int j=1;j<=i;j++){
			b[tail]=a[j];
			while(b[top]+1==b[tail]){
				if(b[top-1]==')')
				k+=2;
				else k++;
				top++;tail--;
			}
			tail++;
		}
//		while(kk<=i){
//			if(c[kk+1]==c[kk])kk++;
//			if(c[kk+1]==c[kk]+1)l++;
//			k+=(l+1)*l/2;
//			kk++;
////			printf("%d",k);
//		}
		printf("%d\n",k);
		ans=(ans)xor(i*k);
	}
//	for(int i=1;i<=n;i++){
//		printf("%d ",a[i]);
//	}
//	for(int i=1;i<=n;i++){
//		printf("%d ",c[i]);
//	}
	printf("%d",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
