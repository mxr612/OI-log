#include<cstdio>
#include<algorithm>
using namespace std;
int a[2005],n,nn,lx,ly,minn;
bool map[2005][2005],k[2005];
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	int t;
	scanf("%d",&t);
	while(t--){
		minn=1;
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d",&a[i]);
		}
		for(int i=1;i<=n-1;i++){
			int x,y;
			scanf("%d %d",&x,&y);
			k[x]=y;k[y]=x;
			if(x=lx)nn=x;else if(y=ly)nn=y;
			map[x][y]=map[y][x]=1;
		}
		if(nn=0){
			for(int i=1;i<=n-1;i++){
				while(k[a[i]]<a[i]&&map[a[i]][k[a[i]]]){
					int t=a[i];a[i]=k[a[i]];k[a[i]]=t;
					map[a[i]][k[a[i]]]=map[k[a[i]]][a[i]]=0;
				}
			}
		}
//		sort(a+1,a+1+n);
		for(int i=1;i<=n;i++){
			printf("%d ",a[i]);
		}
		printf("\n");
	}
	return 0;
}
