#include<cstdio>
#include<cmath>
using namespace std;
int a[1005];
long long n,k,mid,z,l,r,lr=1;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%lld %lld",&n,&k);
	z=pow(2,n);r=z;
	int c=1;
	while(c<=n){
//		printf("%d %d %d %d\n",lr,mid,a[c],c);
		mid=(l+r+1)>>1;
		if(mid>k)a[c]=lr*(-1),r=mid,lr=1;
		else a[c]=lr*1,l=mid,lr=-1;
//		printf("%d %d %d %d\n",lr,mid,a[c],c);
		c=c+1;
	}
//		printf("%d %d %d %d\n",lr,mid,a[c],c);
	for(int i=1;i<=n;i++){
		if(a[i]==1)
		printf("1");
		else 
		printf("0");
	}
//	fclose(stdin);fclose(stdout);
	return 0;
}
