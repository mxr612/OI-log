#include <cstdio>
#include <vector>
#include <cstring>

void solve();

int main()
{
#ifndef DEBUG
    freopen("tree.in", "r", stdin);
    freopen("tree.out", "w", stdout);
#endif

    int T;
    scanf("%d", &T);
    while (T--)
        solve();

    return 0;
}

const int MaxN = 2000 + 7;

int n;
int num[MaxN], pmap[MaxN];
std::pair<int, int> edge[MaxN];
int parent[MaxN];
int deg[MaxN];

struct
{
    struct Edge
    {
        int dst;
        Edge *next;
    };
    Edge eset[MaxN * 2];
    Edge *via[MaxN];
    int emax;
    void addedge(int src, int dst)
    {
        eset[++emax].next = via[src];
        via[src] = eset + emax;
        eset[emax].dst = dst;
    }
    bool used[MaxN];
    void dfs(int now)
    {
        used[now] = true;
        for (Edge *ed = via[now]; ed; ed = ed->next)
            if (!used[ed->dst])
            {
                parent[ed->dst] = now;
                dfs(ed->dst);
            }
    }
    void operator()()
    {
        for (int i = 1; i < n; ++i)
        {
            addedge(edge[i].first, edge[i].second);
            addedge(edge[i].second, edge[i].first);
        }
        memset(used, false, sizeof(used));
        memset(via, 0, sizeof(via));
        dfs(1);
    }
} totree;

void solve()
{
    scanf("%d", &n);
    for (int i = 1; i <= n; ++i)
    {
        scanf("%d", num + i);
        pmap[num[i]] = i;
    }
    for (int i = 1; i < n; ++i)
    {
        scanf("%d %d", &edge[i].first, &edge[i].second);
        ++deg[edge[i].first];
        ++deg[edge[i].second];
    }
            for (int i = 1; i <= n; ++i)
                printf("%d ", i);
            return;

    totree();
}

