#include <cstdio>
#include <vector>

const int MaxN = 5e5 + 7;

typedef long long i64t;

int n;
char brak[MaxN];
int parent[MaxN];
std::vector<int> child[MaxN];
i64t rest[MaxN], prev[MaxN];
int cont[MaxN];

i64t dfs(int now)
{
    prev[now] = prev[parent[now]];
    rest[now] = rest[parent[now]];

    if (brak[now] == '(')
    {
        ++rest[now];
        cont[now] = cont[parent[now]];
    }
    else
    {
        if (rest[now])
        {
            --rest[now];
            ++prev[now];
            if (rest[now] == 0)
            {
                cont[now] = cont[parent[now]] + 1;
                prev[now] += cont[now] - 1;
            }
        }
        else
        {
            cont[now] = 0;
        }
    }

    i64t ans = now * prev[now];
    for (int i = 0; i < child[now].size(); ++i)
        ans ^= dfs(child[now][i]);
    return ans;
}

int main()
{
#ifndef DEBUG
    freopen("brackets.in", "r", stdin);
    freopen("brackets.out", "w", stdout);
#endif

    scanf("%d", &n);
    scanf("%s", brak + 1);
    for (int i = 2; i <= n; ++i)
    {
        scanf("%d", parent + i);
        child[parent[i]].push_back(i);
    }
    printf("%lld\n", dfs(1));

    return 0;
}

