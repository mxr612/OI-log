#include <cstdio>
typedef unsigned long long i64t;

i64t n, k;

int main()
{
#ifndef DEBUG
    freopen("code.in", "r", stdin);
    freopen("code.out", "w", stdout);
#endif
    scanf("%llu %llu", &n, &k);

    // 000 001 011 010 110 111 101 100
    i64t base = 1ll << (n - 1);
    bool rev = false, out = false;
    for (; base; base >>= 1)
    {
        if (k >= base)
        {
            k -= base;
            printf("%d", rev ? 0 : 1);
            rev = true;
        }
        else
        {
            printf("%d", rev ? 1 : 0);
            rev = false;
        }
    }
    printf("\n");

    return 0;
}

