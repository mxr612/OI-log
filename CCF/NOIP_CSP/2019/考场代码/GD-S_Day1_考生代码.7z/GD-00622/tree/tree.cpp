#include <bits/stdc++.h>
using namespace std;
const int N = 2e3 + 10;
int final[N] , nex[N * 2], to[N * 2], tot, ban[N], used[N];
int n, a[N], T;
void link(int x, int y) {
	to[++tot] = y, nex[tot] = final[x], final[x] = tot;
	ban[tot] = 0;
}

int ans[N], g[N];
int e[N][2], b[N];
int num[N];

void dfs(int x) {
	if (x == n) {
		for(int i=1;i<=n;i++)num[a[i]]=i;
		for(int i=1;i<n;i++){
			swap(num[e[b[i]][0]], num[e[b[i]][1]]);
		}
		for(int i=1;i<=n;i++)g[num[i]]=i;
		if (ans[1]==0) memcpy(ans,g,(n + 5)*4);
		else{
			for(int i=1;i<=n;i++)if(ans[i]!=g[i]){
				if(ans[i]<g[i])return;
				else break;	
			}
			memcpy(ans,g,(n + 5)*4);
		}
		return;
	}
	for(int i = 1; i < n; i ++) if (used[i] == 0) {
		used[i] = 1;
		b[x] = i;
		dfs(x + 1);
		used[i] = 0;
	}
}

int deg[N];
int f[N];
int sz[N];

//void divide(int l, int r) {
//	if (l > r) return;
//	if (l == r) {
//		sz[l] = num[f[l]];
//		return;
//	}
//	
//	int mi=l;
//	for(int i=l;i<=r;i++)if(num[f[l]] <= num[f[mi]]){
//		l=mi;
//	}
//	int goal=l;
//	for(int i=l;i<=r;i++)if(i!=mi && f[goal]<f[i])
//		goal=i;
//	if (goal<=mi) {
//		
//	} else {
//		
//	}
//}

//void getline(int x, int from) {
//	f[++f[0]]=x;
//	for(int i=final[x];i;i=nex[i]){
//		int y=to[i];if(y!=from){
//			getline(y,x);
//		}
//	}
//}
int main() {
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	for(cin>>T;T;T--){
		memset(final,0,sizeof final);
		memset(ans,0,sizeof ans);
//		memset(deg,0,sizeof deg);
		tot = 1;
		cin>>n;
		for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
		int mx=0;
		for(int i = 1; i < n; i++) {
			int u, v; scanf("%d %d", &u, &v);
			e[i][0] = u, e[i][1] = v;
			link(u, v), link(v, u);
//			deg[u]++,deg[v]++;
//			mx=max(mx,deg[u]);
//			mx=max(mx,deg[v]);
		}
//		if(mx<=2){
//			f[0]=0;
//			for (int i = 1; i <= n; i++) if(deg[i]==0){
//				getline(i,0);break;
//			}
//			for(int i=1;i<=n;i++)num[a[i]]=i;
//			divide(1,n);
//		} else {
			dfs(1);
//		}
		for(int i=1;i<=n;i++)printf("%d ",ans[i]);
		printf("\n");
	}
}
