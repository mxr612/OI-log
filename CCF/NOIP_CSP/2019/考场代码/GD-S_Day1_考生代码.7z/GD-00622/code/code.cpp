#include <bits/stdc++.h>
using namespace std;
const int N = 70;
typedef unsigned long long ll;
ll n, k;
int main() {
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin >> n >> k;
	ll mi = 1;
	for(int i=1;i<n;i++)mi<<=1;
	for(int i = 1; i <= n; i++, mi >>= 1) {
		if (k & mi) {
			cout<<1;
			k-=mi;
			k=mi-1-k;
		}else{
			cout<<0;
		}
	}
	printf("\n");
}
