#include <bits/stdc++.h>
using namespace std;
const int N = 5e5 + 10;
typedef long long ll;
ll ans;
int n,final[N],nex[N],to[N],tot;
ll S[N];
ll pre[N];

char s[N];
void link(int x, int y) {
	to[++tot] = y, nex[tot] = final[x], final[x] = tot;
}

void dfs(int x) {
	ll td = -1, sp = -1;
	if (s[x] == '(') {
		S[++S[0]] = 0;
	} else {
		if (S[0] > 1) {
			td = S[S[0]];
			S[0]--;
			S[S[0]]++;
			pre[x] += S[S[0]];
		} else {
			sp = S[1];
			S[1] = 0;
		}
	}
	ans ^= x * pre[x];
	for(int i = final[x]; i; i = nex[i]) {
		int y = to[i];
		pre[y] = pre[x];
		dfs(y);
	}
	if (s[x] == '(') {
		S[0]--;
	} else {
		if (td != -1) {
			S[S[0]]--;
			S[++S[0]] = td;
		} else if (sp != -1) {
			S[1] = sp;
		}
	}
}

int main() {
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	scanf("%s",s+1);
	for(int i = 2; i <= n; i++) {
		int u; scanf("%d", &u);
		link(u, i);
	}
	S[++S[0]] = 0;
	dfs(1);
	cout<<ans<<endl;
}
