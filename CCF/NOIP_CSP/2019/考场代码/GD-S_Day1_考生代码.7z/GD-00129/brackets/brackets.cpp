#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
const int size=5*1e5+5;
int head[size],tot,n,left[size],ans,tol[size],lian[size];
char c[size];
struct node
{
	int to,nxt;
}h[size];
void add(int x,int y)
{
	h[++tot].to=y;
	h[tot].nxt=head[x];
	head[x]=tot;
}
void dfs(int x)
{
	for(int i=head[x];i;i=h[i].nxt)
	{
		int y=h[i].to;
		if(c[y]=='(')
		{
			if(c[x]==')') left[y]=1;
			else left[y]=left[x]+1;
			tol[y]=tol[x];
		}
		else
		{
			if(left[x])
			{
				left[y]=left[x]-1;
				tol[y]=tol[x]+1;
			}
			else tol[y]=tol[x];
		}
		ans=ans^(y*tol[y]);
		dfs(y);
	}
	return;
}
bool check(int l,int r)
{
	int now=0;	
	char last;
	for(int i=l;i<=r;i++)
	{
		if((!now&&c[i]==')')||(c[i-1]==')'&&now>0&&c[i]=='(')) return 0;
		if(c[i]=='(') now++;
		if(c[i]==')') now--;
	}
	if(now) return 0;
	else return 1;
}
int cnt(int x)
{
	int zhong=0;
	for(int i=1;i<x;i++) if(check(i,x)) zhong++;
	return zhong;
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	scanf("%s",c+1);
	bool flag=0;
	for(int i=2,x;i<=n;i++)
	{
		scanf("%d",&x);
		if(x!=i-1) flag=1;
		add(x,i);
	}
	if(!flag) 
	{
		for(int i=1;i<=n;i++) 
		{
			tol[i]=tol[i-1]+cnt(i);
			ans=ans^(tol[i]*i);
		}
		printf("%d",ans);
		return 0;
	}
	else
	{
		if(c[1]=='(') left[1]++;
		ans=0;
		dfs(1);
		printf("%d",ans);
		return 0;
	}
}
