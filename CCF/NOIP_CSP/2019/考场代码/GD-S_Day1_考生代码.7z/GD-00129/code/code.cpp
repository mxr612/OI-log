#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
long long k;
int n,tot,code[1005];
long long qpow(int x)
{
	long long base=2,ans=1;
	while(x>0)
	{
		if(x&1) ans=ans*base;
		base=base*base;
		x=x>>1;
	}
	return ans;
}
void up(int ceng,long long now)
{
	if(ceng==1) 
	{
		if(now==0) 
		{
			code[++tot]=0;
			return;
		}
		else 
		{
			code[++tot]=1;
			return;
		}
	}
	if(now<qpow(ceng-1)) 
	{
		up(ceng-1,now);
		code[++tot]=0;
	}
	else 
	{
		long long dnow=qpow(ceng)-now-1;
		up(ceng-1,dnow);
		code[++tot]=1;
	}
	return;
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d %lld",&n,&k);
	up(n,k);
	for(int i=n;i>0;i--) printf("%d",code[i]);
	return 0;
}
