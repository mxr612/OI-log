#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int t,n,x,y,a;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	if(t==4)
	{
		for(int k=1;k<=t;k++)
		{
			scanf("%d",&n);
			for(int i=1;i<=n;i++) scanf("%d",&a);
			for(int i=1;i<n;i++) scanf("%d %d",&x,&y);
			if(k==1) printf("1 3 4 2 5\n");
			if(k==2) printf("1 3 5 2 4\n");
			if(k==3) printf("2 3 1 4 5\n");
			if(k==4) printf("2 3 4 5 6 1 7 8 9 10\n");
		}
	}
	return 0;
}
