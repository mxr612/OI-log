#include<algorithm>
#include<iostream>
#include<cstring>
#include<fstream>
#include<cstdio>
#include<vector>
#include<cmath>
#include<stack>
#include<queue>
#include<deque>
#include<list>
#include<map>
using namespace std;
struct bl{
	int a;
	int c;
	int key;
}dp[100001];
int lj,sum,n;
string st;
stack<int> l;
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	cin>>st;
	for(int i=n-1;i>=0;i--)
	{
		dp[i].a+=dp[i+1].a;
		if(st[i]==')') l.push(dp[i+1].c);
		if(st[i]=='('&&(!l.empty()))
		{
			dp[i].c=l.top()+1;
			dp[i].a+=l.top()+1;
			l.pop();
		}
		lj=lj^dp[i].a;
	}
	for(int i=0;i<n;i++)
		cout<<dp[i].a<<' '<<dp[i].c<<endl;
	cout<<lj;
	return 0;
}
