#include<algorithm>
#include<iostream>
#include<cstring>
#include<fstream>
#include<cstdio>
#include<vector>
#include<cmath>
#include<stack>
#include<queue>
#include<deque>
#include<list>
#include<map>
using namespace std;
long long k;
int n;
string st;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		if(k%2==0) st+="0",k/=2; else
			st+="1",k=~(k>>1);
	}
	cout<<st;
	return 0;
}
