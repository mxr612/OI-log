#include<algorithm>
#include<iostream>
#include<cstring>
#include<fstream>
#include<cstdio>
#include<vector>
#include<cmath>
#include<stack>
#include<queue>
#include<deque>
#include<list>
#include<map>
using namespace std;
int G,n,sum;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>G;
	while(G--)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
			cin>>sum;
		for(int i=1;i<n;i++)
			cin>>sum>>sum;
		for(int i=1;i<=n;i++)
			cout<<i<<' ';
		cout<<endl;
	}
	return 0;
}
