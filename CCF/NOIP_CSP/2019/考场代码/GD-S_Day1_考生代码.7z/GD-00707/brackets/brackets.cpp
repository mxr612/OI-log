//@HelloElwin-20191116
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
char a[500005];
int ghd, hd[500005];
int fa[500005], f[500005];
int n, spt, S2[500005]; char S1[500005];
bool subtask = true;
long long ans, ansss;

struct Edge {
	int u, v, nxt;
}g[500005];

void AddEdge (int u, int v) {
	g[ghd] = (Edge){u, v, hd[u]};
	hd[u] = ghd++;
}

void Dfs (int u, int sum) {
	char s1; int s2;
	if (spt && S1[spt - 1] == '(' && a[u] == ')') {
		f[u] = f[fa[S2[spt - 1]]] + 1;
		spt--; s1 = S1[spt]; s2 = S2[spt];
		for (int i = hd[u]; ~i; i = g[i].nxt) {
			int v = g[i].v;
			Dfs(v, sum + f[u]);
		}
		S1[spt] = s1, S2[spt] = s2; spt++;
	} else { 
		f[u] = 0;
		S1[spt] = a[u];
		S2[spt] = u; spt++;
		for (int i = hd[u]; ~i; i = g[i].nxt) {
			int v = g[i].v;
			Dfs(v, sum + f[u]);
		}
		spt--;
	}
	sum += f[u];
	ans = ans ^ (u * sum);
}

int main() {
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout); 

	memset(hd, -1, sizeof(hd));

	scanf("%d", &n);
	
	for (int i = 1; i <= n; i++) scanf(" %c", &a[i]);
	for (int i = 2; i <= n; i++) {
		scanf("%d", &fa[i]);
		AddEdge(fa[i], i);
		if (fa[i] != i - 1) subtask = false;
	}
	
	if (subtask) {
		S1[spt++] = a[1]; S2[spt - 1] = 1;
		for (int i = 2; i <= n; i++) {
			if (spt && S1[spt - 1] == '(' && a[i] == ')') {
				f[i] = f[S2[spt - 1] - 1] + 1;
				spt--;
			} else { 
				f[i] = 0;
				S1[spt] = a[i];
				S2[spt] = i; spt++;
			}
			ansss += f[i];
			ans = ans ^ ((long long)ansss * (long long)i);
		}
		printf("%lld", ans);
		return 0;
	} else {
		Dfs(1, 0);
		printf("%lld", ans);
	}
	
	return 0;
}
