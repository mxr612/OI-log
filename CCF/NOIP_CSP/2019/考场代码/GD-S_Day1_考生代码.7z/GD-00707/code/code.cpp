//@HelloElwin-20191116
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
typedef unsigned long long ull;
ull ans[1001];
ull n, k;

void Gray (ull n, ull k) {
	if (n == 1) {
		if (k == 0) ans[n - 1] = (ull)0;
		else ans[n - 1] = (ull)1;
		return;
	}
	if (k <= ((ull)1 << (n - 1)) - (ull)1) {
		Gray(n - 1, k);
		ans[n - 1] = (ull)0;
	} else {
		Gray(n - 1, ((ull)1 << (n - 1)) - (k - ((ull)1 << (n - 1))) - (ull)1);
		ans[n - 1] = (ull)1;
	}
}

int main() {
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	
	scanf("%llu %llu", &n, &k);
	
	Gray(n, k);

	for (int i = n - 1; i >= 0; i--) printf("%llu", ans[i]);

}
