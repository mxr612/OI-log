//@HelloElwin-20191116
#include <algorithm>
#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
int T, n, num2id[2005], id2num[2005];
int de[2005];
int ghd, hd[2005];
bool used[2005][2005];
bool vis[2005];
int au;

struct Edge {
	int u, v, nxt;
}g[5005];

void AddEdge (int u, int v) {
	g[ghd] = (Edge){u, v, hd[u]};
	hd[u] = ghd++;
}

int Dfsfind (int u, int minnum) {
	vis[u] = true;
	for (int i = hd[u]; ~i; i = g[i].nxt) {
		int v = g[i].v;
		if (used[u][v]) continue;
		if (vis[v]) continue;
		if (minnum == n + 1) minnum = v;
		if (id2num[v] < id2num[minnum]) minnum = v;
		int x = Dfsfind(v, minnum);
		if (id2num[x] < id2num[minnum]) minnum = x;
	}
	return minnum;
}

bool Dfsdel (int u, int tar) {
//	cerr<<u<<" "<<tar<<endl;
	vis[u] = true;
	if (u == tar) return true;
	for (int i = hd[u]; ~i; i = g[i].nxt) {
		int v = g[i].v;
		if (used[u][v]) continue;
		if (vis[v]) continue;
		if (Dfsdel(v, tar)) {
			au++;
			swap(id2num[u], id2num[v]);
			swap(num2id[id2num[u]], num2id[id2num[v]]);
			used[u][v] = used[v][u] = true;
			return true;
		}
	}
	return false;
}

int main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	
	scanf("%d", &T);
	
	while (T--) {
		
		au = 0;
		memset(de,  0,  sizeof(de));
		memset(hd, -1,  sizeof(hd));
		memset(used,0,sizeof(used));
		
		scanf("%d", &n);
		for (int i = 1; i <= n; i++) { scanf("%d", &num2id[i]); id2num[num2id[i]] = i; }
		for (int i = 2; i <= n; i++) {
			int x, y;
			scanf("%d %d", &x, &y);
			AddEdge(x, y);
			AddEdge(y, x);
			de[x]++;de[y]++;
		}
		
		bool flg1 = true; int maxi = 1; 
		
		for (int i = 1; i <= n; i++) if (de[i] > 2) flg1 = false, maxi = de[i] > de[maxi] ? i : maxi;
		
		if (flg1) {
			while (au < n - 1) {
				int minid = n + 1, minnum = n + 1;
				for (int i = 0; i < ghd; i++) {
					int u = g[i].u, v = g[i].v;
					if (used[u][v]) continue;
					if (minid == n + 1) minid = u;
					minid = min(minid, min(u, v));
				}
				int u = minid;
				memset(vis, 0, sizeof(vis));
				minnum = Dfsfind(u, id2num[u]);
				if (minid != num2id[minnum]) {	
					memset(vis, 0, sizeof(vis));
					Dfsdel(u, minnum);
				}
				for (int i = 0; i < ghd; i++) {
					int u = g[i].u, v = g[i].v;
					if (u == minid || v == minid) used[u][v] = used[v][u] = true, au++;
				}
			}
			for (int i = 1; i <= n; i++) printf("%d ", num2id[i]);
			printf("\n");
		}
		
		if (de[maxi] == n - 1) {
			while (au < n - 1) {
				int minnum = n + 1, minid = n + 1;
				for (int i = 0; i < ghd; i++) {
					int u = g[i].u, v = g[i].v;
					if (used[u][v]) continue;
					if (minnum == n + 1) minnum = id2num[u];
					minid = min(minid, min(u, v));
					if (id2num[minnum] > id2num[u]) minnum = u;
					if (id2num[minnum] > id2num[v]) minnum = v;
				}
				for (int i = 0; i < ghd; i++) {
					int u = g[i].u, v = g[i].v;
					if (used[u][v]) continue;
					if (u == minnum || u == minid || v == minnum || v == minid) used[u][v] = used[v][u] = true, au++;
				}
			}
			for (int i = 1; i <= n; i++) printf("%d ", num2id[i]);
			printf("\n");
		}
			
	}
	
	return 0;
}
