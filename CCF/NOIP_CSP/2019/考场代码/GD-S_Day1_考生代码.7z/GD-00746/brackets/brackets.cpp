#include <cstddef>
#include <cstdio>
#include <cstring>
#include <vector>
#ifdef DEBUG
#include <cassert>
#endif
std::FILE *in, *out;
namespace
{
	class FileIO
	{
		public:
			FileIO()
			{
				in = std::fopen("brackets.in", "r");
				out = std::fopen("brackets.out", "w");
#ifdef DEBUG
				assert(in != NULL && out != NULL);
#endif
			}
			~FileIO()
			{
				std::fclose(in);
				std::fclose(out);
			}
	}
	fileIO;
}
const unsigned long n_MAX = 500000L;
char ch[n_MAX + 2UL];
unsigned long a[n_MAX + 1UL], dep, f[n_MAX + 1UL], n;
unsigned long long k[n_MAX + 1UL];
std::vector<unsigned long> children[n_MAX + 1UL];
void Dfs(unsigned long x, unsigned long dep)
{
	long tmp = 0L;
#ifdef DEBUG
	assert((ch[x] == '(') || (ch[x] == ')'));
#endif
	switch (ch[x])
	{
		case '(':
			a[dep] = 1L;
			break;
		case ')':
			a[dep] = -1L;
			break;
	}
	k[x] = k[f[x]];
	for (unsigned long i = dep; i; --i)
	{
		tmp += a[i];
		if (tmp > 0L)
			break;
		if (tmp == 0L)
			++k[x];
	}
	++dep;
	for (std::vector<unsigned long>::iterator iter = children[x].begin(); iter != children[x].end(); ++iter)
		Dfs(*iter, dep);
}
int main()
{
	unsigned long long ans = 0;
	std::fscanf(in, "%lu%s", &n, ch + static_cast<std::ptrdiff_t>(1));
	for (unsigned long i = 2; i <= n; ++i)
	{
		std::fscanf(in, "%lu", f + static_cast<std::ptrdiff_t>(i));
		children[f[i]].push_back(i);
	}
	Dfs(1UL, 1UL);
	for (unsigned long i = 1; i <= n; ++i)
		ans ^= (static_cast<unsigned long long>(i) * k[i]);
	std::fprintf(out, "%llu\n", ans);
	return 0;
}
