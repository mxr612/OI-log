#include <cstddef>
#include <cstdio>
#include <algorithm>
#include <vector>
#ifdef DEBUG
#include <cassert>
#endif
std::FILE *in, *out;
namespace
{
	class FileIO
	{
		public:
			FileIO()
			{
				in = std::fopen("tree.in", "r");
				out = std::fopen("tree.out", "w");
	#ifdef DEBUG
				assert(in != NULL && out != NULL);
	#endif
			}
			~FileIO()
			{
				std::fclose(in);
				std::fclose(out);
			}
	}
	fileIO;
}
const unsigned int n_MAX = 2000;
bool b[n_MAX];
unsigned int n, num[n_MAX + 1U], a[n_MAX + 1U], P[n_MAX + 1U], x[n_MAX], y[n_MAX];
std::vector<unsigned int> edg[n_MAX + 1U];
void Dfs(unsigned int k)
{
	if (!k)
	{
		bool flag = false;
		for (unsigned int i = 1; i <= n; ++i)
		{
			if (a[i] > P[i])
				break;
			if (a[i] < P[i])
			{
				flag = true;
				break;
			}
		}
		if (flag)
		{
			for (unsigned int i = 1; i <= n; ++i)
				P[i] = a[i];
		}
		return;
	}
	for (int i = 1; i < n; ++i)
	{
		if (b[i])
			continue;
		b[i] = true;
		std::swap(num[x[i]], num[y[i]]);
		std::swap(a[num[x[i]]], a[num[y[i]]]);
		Dfs(k - 1U);
		b[i] = false;
		std::swap(num[x[i]], num[y[i]]);
		std::swap(a[num[x[i]]], a[num[y[i]]]);
	}
}
int main()
{
	unsigned int T, p;
	std::fscanf(in, "%u", &T);
	while (T--)
	{
		std::fscanf(in, "%u", &n);
		for (unsigned int i = 1; i <= n; ++i)
		{
			edg[i].clear();
			std::fscanf(in, "%u", P + static_cast<std::ptrdiff_t>(i));
			a[i] = P[i];
			num[P[i]] = i;
		}
		for (unsigned int i = 1; i < n; ++i)
		{
			std::fscanf(in, "%u%u", x + static_cast<std::ptrdiff_t>(i), y + static_cast<std::ptrdiff_t>(i));
			edg[x[i]].push_back(y[i]);
			edg[y[i]].push_back(x[i]);
		}
		if (n <= 10U)
			Dfs(n - 1U);
		for (unsigned int i = 1; i <= n; ++i)
			std::fprintf(out, (i == n) ? "%u\n" : "%u ", P[i]);
	}
}
