#include <cstdio>
#include <string>
#ifdef DEBUG
#include <cassert>
#endif
std::FILE *in, *out;
namespace
{
	class FileIO
	{
		public:
			FileIO()
			{
				in = std::fopen("code.in", "r");
				out = std::fopen("code.out", "w");
#ifdef DEBUG
				assert(in != NULL && out != NULL);
#endif
			}
			~FileIO()
			{
				std::fclose(in);
				std::fclose(out);
			}
	}
	fileIO;
}
std::string code(unsigned int n, unsigned long long k)
{
#ifdef DEBUG
	assert(n > 0U);
	assert(k < (1ULL << n));
#endif
	if (n == 1U)
        return (k ? "1" : "0");
	return ((k < (1ULL << (n - 1U))) ? ("0" + code(n - 1U, k)) : ("1" + code(n - 1U, (((1ULL << (n - 1U)) - 1ULL) | (1ULL << (n - 1U))) - k)));
}
int main()
{
	unsigned int n;
	unsigned long long k;
	std::fscanf(in, "%u%llu", &n, &k);
	std::fprintf(out, "%s\n", code(n, k).c_str());
	return 0;
}
