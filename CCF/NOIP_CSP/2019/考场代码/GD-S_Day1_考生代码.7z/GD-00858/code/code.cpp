#include <cstdio>
#include <cstring>
#include <iostream>
#define ll long long
using namespace std;
ll n,k;
string S,S1,s;
ll ksm(ll a,ll b){ ll r=1; for (;b;b>>=1,a=a*a) if (b&1) r=r*a; return r; }
void work(ll x,ll y)
{
	if (x==0) return; 
	ll sum=ksm(2,x-1)-1;
	if (y<=sum) printf("0"),work(x-1,y); else printf("1"),work(x-1,sum-y+sum+1);
}
bool pd(string a,string b)
{
	int len1=a.length(),len2=b.length();
	if (len1<len2) return 1;
	if (len1>len2) return 0;
	for (int i=1;i<=len1;i++) if (a[i]<b[i]) return 1; else return 0;
	return 1;
}
ll change(string s)
{
	ll r=0;
	for (int i=1;i<=s.length();i++) r=r*10+s[i]-48;
	return r;
}
ll calc()
{
	ll r=0,num=1;
	int len1=S1.length(),len2=s.length(),p=0,g=0;
	for (int i=len2;i<len1;i++) s="0"+s; 
	for (int i=len1-1;i>=1;i--)
	{
		g=(S1[i]-48)-(s[i]-48)-p+g;
		if (g<0) g+=10,p=1; else p=0;
		r=r+1ll*g%10*num,g=g/10,num=num*10;
	}
	return r;
}
int main()
{
	freopen("code.in","r",stdin),freopen("code.out","w",stdout);
	scanf("%lld",&n);
	if (n==64)
	{
		S="9223372036854775807",S1="018446744073709551615";
		cin>>s;
		if (pd(s,S)) printf("0"),work(63,change(s)); else printf("1"),work(63,calc());
		return 0;
	}
	scanf("%lld",&k);
	work(n,k);
	fclose(stdin),fclose(stdout);
	return 0;
}
