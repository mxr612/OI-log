#include <cstdio>
#include <cstring>
#include <iostream>
#define ll long long
using namespace std;
const ll N=5e5+10;
struct edge{ ll to,from; }e[N];
ll n,cnt,last=1,dp[N],fa[N],head[N],f[N],now,num,ans;
char k[N];
bool p[N];
void insert(ll x,ll y){ e[++cnt].to=y,e[cnt].from=head[x],head[x]=cnt; }
void dfs(ll x)
{
	f[x]=f[fa[x]]+(k[x]=='('?1:-1);
	if (f[x]<0) f[x]=0,p[x]=1; else if (k[x]==')')
	{
		num=0;
		for (ll j=fa[x];j!=-1&&p[j]!=1;j=fa[j]) 
		if (f[j]==f[x]) num++;
		dp[x]=num;
	}
	dp[x]+=dp[fa[x]];
	for (ll i=head[x];i;i=e[i].from) if (e[i].to!=fa[x]) dfs(e[i].to);
}
int main()
{
	freopen("brackets.in","r",stdin),freopen("brackets.out","w",stdout);
	scanf("%lld",&n);
	scanf("%s",k+1),fa[1]=0,fa[0]=-1;
	for (ll i=2,x;i<=n;i++) scanf("%lld",&fa[i]),insert(fa[i],i);
	dfs(1);
	for (ll i=1;i<=n;i++) ans=ans^(i*dp[i]);
	printf("%lld",ans);
	fclose(stdin),fclose(stdout);
	return 0;
}
