#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
const int N=2010;
struct edge{ int x,y; }e[N];
int T,n,o,v[N],ans[N];
bool bz[N];
bool pd()
{
	for (int i=1;i<=n;i++) if (ans[i]<v[i]) return 0; else if (ans[i]>v[i]) return 1;
	return 0;
}
void dfs(int x)
{
	if (x==n-1)
	{
		if (pd()) memcpy(ans,v,sizeof(ans));
		return;
	}
	for (int i=1;i<n;i++) if (!bz[i])
	{
		int t=v[e[i].x]; v[e[i].x]=v[e[i].y],v[e[i].y]=t,bz[i]=1;
		dfs(x+1);
		t=v[e[i].x],v[e[i].x]=v[e[i].y],v[e[i].y]=t,bz[i]=0;
	}
}
int main()
{
	freopen("tree.in","r",stdin),freopen("tree.out","w",stdout);
	scanf("%d",&T);
	while (T--)
	{
		memset(bz,0,sizeof(bz));
		scanf("%d",&n),o=0;
		for (int i=1;i<=n;i++) ans[i]=n;
		for (int i=1,x;i<=n;i++) scanf("%d",&x),v[i]=x;
		for (int i=1,x,y;i<n;i++) scanf("%d%d",&e[i].x,&e[i].y);
		if (n<=8) dfs(0); else{ for (int j=1;j<=n;j++) printf("%lld ",ans[n-j+1]); printf("\n"); continue;}
		for (int i=1;i<=n;i++) printf("%d ",ans[i]); printf("\n");
	}
	fclose(stdin),fclose(stdout);
	return 0;
}
