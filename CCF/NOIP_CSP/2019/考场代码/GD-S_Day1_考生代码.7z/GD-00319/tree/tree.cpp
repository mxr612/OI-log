#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
#include<cmath>
using namespace std;
int t,n,x[2000],y,z;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>t;
	for(int i=0;i<t;i++)
	{
		cin>>n;
		for(int j=0;j<n;j++)
		{
			cin>>x[j];
		}
		for(int j=0;j<n-1;j++)
		{
			cin>>y>>z;
		}
		for(int k=n;k>0;k--)
		{
			cin>>x[k];
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
