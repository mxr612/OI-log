#include<iostream>
#include<algorithm>
#include<cstring>
#include<cstdio>
#include<cmath>
using namespace std;
int a[1000];
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	long long n,k,i,l=1;
	cin>>n>>k;
	while(n>=1)
	{
		long long y=2;
		for(i=1;i<n-1;i++)
		y=y*2;
		if(n==1&&k==0)
		{
			a[l]=0;
			n--;
			break;
		}
		if(n==1&&k==1)
		{
			a[l]=1;
			n--;
			break;
		}
		if(k<y)
		{
			n--;
			a[l]=0;
			l++;
			continue;		
		}
		if(k>=y)
		{
			n--;
			k=y*2-1-k;
			a[l]=1;
			l++;
			continue;
		}
	}
	for(i=1;i<=l;i++)
	cout<<a[i];
	fclose(stdin);
	fclose(stdout);
	return 0;
}
