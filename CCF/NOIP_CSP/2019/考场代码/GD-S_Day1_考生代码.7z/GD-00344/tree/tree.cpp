#include <iostream>
#include <fstream>
#include <cstring>
#include <cmath>
#include <cstdio>
using namespace std;
struct qxx{
	int t;
	int next;
}a[4005];
int head[4005],fa[4005];
int MLE[2005][2005];
int id,vis[4005],v[4005],p[2005][2005],t,n,x,y,l[4005];
void hb(int x,int y) {
	id++;
	a[id].t=y;
	a[id].next=head[x];
	head[x]=id;
	return ;
}
void _cut(int x,int y) {
//	cout<<x<<" "<<y<<endl;
	if (p[x][0]>p[y][0]) swap(x,y);
	for (int i=p[y][0]-1;i>=1;i--) {
		//cout<<v[p[y][i]]<<" "<<y<<endl;
		MLE[p[y][i]][p[y][i+1]]=0;
		MLE[p[y][i+1]][p[y][i]]=0;
		if (i==x) return;
	}
	for (int i=p[x][0]-1;i>=1;i--) {
		MLE[v[p[x][i]]][v[p[x][i+1]]]=0;
		MLE[v[p[x][i+1]]][v[p[x][i]]]=0;
	}
}
int _find(int x) {
	vis[x]=1;
	int minn=0x3c3c3c3c,k;
	for (int i=head[x];i!=0;i=a[i].next) {
		if (vis[a[i].t]==1) continue;
		if (MLE[a[i].t][x]==0) continue;
		int num=_find(a[i].t);
		if (v[num]<minn) {
			minn=v[num]; k=num;
		}
	}
	if (v[x]<minn) {
		minn=v[x];k=x;
	}
	return k;
}
void _get(int x){
	vis[x]=1;
	int minn=0x3c3c3c3c,k;
	for (int i=head[x];i!=0;i=a[i].next) {
		if (vis[a[i].t]==1) continue;
		if (MLE[a[i].t][x]==0) continue;
		int num=_find(a[i].t);
		if (v[num]<minn) {
			minn=v[num]; k=num;
		}
	}	
	if (v[x]<minn) {
		minn=v[x];k=x;
	}
	cout<<minn<<" ";
	_cut(x,k);
	return;
}
void dy(int x,int l[],int len) {
	p[x][0]=len;
	for (int i=1;i<=len;i++)
		p[x][i]=l[i];
}
void ff(int x,int l[],int len){
	vis[x]=1;
	//cout<<x<<" "<<len<<endl;
	for (int i=head[x];i!=0;i=a[i].next) {
	
		if (vis[a[i].t]==1) continue;	
		len++;
		l[len]=a[i].t;
		ff(a[i].t,l,len);
		l[len]=0;
		len--;
	}
	dy(x,l,len);
}
int main(){
//	freopen("tree.in","r",stdin);
//	freopen("tree.out","w",stdout);
	scanf("%d",&t);
	for (int i1=1;i1<=t;i1++){
		scanf("%d",&n);
		id=0;
		memset(MLE,0,sizeof(MLE));
		memset(p,0,sizeof(p));
		memset(head,0,sizeof(head));
		for (int i=1;i<=n;i++) {
			scanf("%d",&v[i]);
		}
		for (int i=1;i<n;i++) {
			scanf("%d%d",&x,&y);
			hb(x,y);
			hb(y,x);
			MLE[x][y]=1;
			MLE[y][x]=1;
		}
		memset(vis,0,sizeof(vis));
		l[1]=1;
		ff(1,l,1);
		for (int i=1;i<=n;i++) {
		//	for(int j=1;j<=n;j++) {
	//			for (int k=1;k<=n;k++)
	//				cout<<MLE[j][k]<<" ";
	//				cout<<endl;
	//		}cout<<endl;
			memset(vis,0,sizeof(vis));
			_get(i);
		}
	}
	return 0;
}
