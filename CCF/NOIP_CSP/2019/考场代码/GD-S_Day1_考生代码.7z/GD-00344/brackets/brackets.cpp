#include <iostream>
#include <fstream>
#include <cstring>
#include <cmath>
using namespace std;
long long n;
char c[1000005];
long long ans,k,aa,u[1000005],ans1;
long long f[1000005],a1[2000005],id;
struct qxx{
	long long t;
	long long next;
}a[1000005];
long long head[1000005];
void hb(long long x,long long y) {
	id++;
	a[id].t=y;
	a[id].next=head[x];
	head[x]=id;
	return ;
}
void dfs(long long now,long long a1[],long long k,long long minn){
	if (c[now]=='(') aa=1; else aa=-1;
		f[now]+=f[u[now]];
		k+=aa;
		if (k>=0) {
		if (aa==-1) {
		a1[k+1]=0;	
		if (k>=minn){
		a1[k]++;
		f[now]+=a1[k];} else minn=k;}
		}
		ans=ans^(now*f[now]);
		ans1+=f[now];
		for (long long i=head[now];i!=0;i=a[i].next) {
			dfs(a[i].t,a1,k,minn);
		}
}

int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	for (long long i=1;i<=n;i++){
		cin>>c[i];}
	for (long long i=2;i<=n;i++){
		cin>>u[i];
		hb(u[i],i);
	}
	dfs(1,a1,1000000,1000000);
	cout<<ans;
	return 0;
}
