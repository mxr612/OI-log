#include <iostream>
#include <fstream>
#include <cstring>
#include <cmath>
using namespace std;
long long n;
unsigned long long k;
void _code(long long n,long long k,long long t) {
	if (n==0) return;
	if (t==0) {
	if (k<(long long)pow(2,n-1)) {cout<<t;_code(n-1,k,t);} else 
		{cout<<t+1;_code(n-1,k-(long long)pow(2,n-1),t+1);}
	}
	if (t==1) {
	if (k<(long long)pow(2,n-1)) {cout<<t;_code(n-1,k,(t+1)%2);} else 
		{cout<<(t+1)%2;_code(n-1,k-(long long)pow(2,n-1),t);}
	}	return;
}
int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	_code(n,k,0);
	return 0;
}
