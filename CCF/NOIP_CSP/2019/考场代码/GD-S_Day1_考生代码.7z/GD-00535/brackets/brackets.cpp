#include <iostream>
#include <cstdio>
#include <cstring>
#include <cassert>
typedef long long lint;
const int N=5e5+5;
int n,mx;
char str[N];

namespace utils{
	template <class T> inline void apn(T &x,const T y){x=x<y?x:y;}
	template <class T> inline void apx(T &x,const T y){x=x<y?y:x;}
	inline int nxi(){
		int x=0;
		char c;
		while(((c=getchar())>'9'||c<'0')&&c!='-');
		const bool f=c=='-'&&(c=getchar());
		while(x=x*10-48+c,(c=getchar())>='0'&&c<='9');
		return f?-x:x;
	}
}
using namespace utils;

namespace T{
	int x,v;
	struct node{
		int dlt,min,ncnt;
		inline void getpsh(const int d){
			dlt+=d,min+=d;
		}
	}tr[N<<1];

	inline int idx(const int l,const int r){
		return (l+r)|(l!=r);
	}

	inline void upd(const int l,const int r){
		const int mid=(l+r)>>1;
		node &k=tr[idx(l,r)],ls=tr[idx(l,mid)],rs=tr[idx(mid+1,r)];
		k.min=std::min(ls.min,rs.min);
		k.ncnt=0;
		if(ls.min==k.min) k.ncnt+=ls.ncnt;
		if(rs.min==k.min) k.ncnt+=rs.ncnt;
	}

	inline void psh(const int l,const int r){
		int &d=tr[idx(l,r)].dlt,mid=(l+r)>>1;
		if(!d||l==r) return;
		tr[idx(l,mid)].getpsh(d);
		tr[idx(mid+1,r)].getpsh(d);
		d=0;
	}

	void init(const int l,const int r){
		tr[idx(l,r)].ncnt=r-l+1;
		if(l==r) return;
		const int mid=(l+r)>>1;
		init(l,mid);
		init(mid+1,r);
	}

	void add_t(const int l,const int r){
		if(r<=x){
			tr[idx(l,r)].getpsh(v);
			return;
		}
		psh(l,r);
		const int mid=(l+r)>>1;
		add_t(l,mid);
		if(x>mid) add_t(mid+1,r);
		upd(l,r);
	}

	int ask_t(const int l,const int r){
		const int k=idx(l,r),mid=(l+r)>>1;
		if(tr[k].min>0) return 0;
		if(r<=x&&tr[k].min>=0) return (tr[k].min==0)*tr[k].ncnt;
		if(l==r&&tr[k].min<0) return 0;
		psh(l,r);
		int ans=0;
		if(x>mid) ans+=ask_t(mid+1,r);
		if(tr[idx(mid+1,r)].min>=0) ans+=ask_t(l,mid);
		return ans;
	}

	inline void add(const int x,const int v){
		assert(x);
		T::x=x,T::v=v;
		add_t(1,mx);
	}

	inline int ask(const int x){
		T::x=x;
		return ask_t(1,mx);
	}
}

namespace G{
	int cnt,fir[N],fa[N],dep[N];
	lint ans[N];
	struct edge{
		int to,nx;
	}eg[N<<1];

	inline void add(const int a,const int b){
		eg[++cnt]=(edge){b,fir[a]};
		fir[a]=cnt;
	}

	void dfs(const int x){
		T::add(dep[x],str[x]==')'?1:-1);
		ans[x]=ans[fa[x]]+T::ask(dep[x]);
		for(int i=fir[x]; i; i=eg[i].nx){
			dfs(eg[i].to);
		}
		T::add(dep[x],str[x]==')'?-1:1);
	}

	inline lint get_ans(){
		lint res=0;
		for(int i=1; i<=n; ++i){
			res^=i*ans[i];
		}
		return res;
	}
}

int main(){
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	n=nxi();
	scanf("%s",str+1);
	G::dep[1]=1;
	for(int i=2; i<=n; ++i){
		G::fa[i]=nxi();
		apx(mx,G::dep[i]=G::dep[G::fa[i]]+1);
		G::add(G::fa[i],i);
	}
	T::init(1,mx);
	G::dfs(1);
	printf("%lld\n",G::get_ans());
	return 0;
}
