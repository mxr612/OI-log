#include <iostream>
#include <cstdio>
#include <cstring>
#include <cassert>
typedef long long lint;
const int N=12;
int n,pos[N],que[N],ans[N];
struct edge{
	int x,y;
}eg[N];

namespace utils{
	template <class T> inline void apn(T &x,const T y){x=x<y?x:y;}
	template <class T> inline void apx(T &x,const T y){x=x<y?y:x;}
	inline int nxi(){
		int x=0;
		char c;
		while(((c=getchar())>'9'||c<'0')&&c!='-');
		const bool f=c=='-'&&(c=getchar());
		while(x=x*10-48+c,(c=getchar())>='0'&&c<='9');
		return f?-x:x;
	}
}
using namespace utils;

void dfs(int t){
	static int stk[N],val[N],cur[N];
	static bool vis[N];
	if(t==n){
		bool f=ans[1]==0;
		for(int i=1; i<=n; ++i){
			val[pos[i]]=i;
		}
		for(int i=2; i<=n; ++i){
			std::swap(val[eg[stk[i]].x],val[eg[stk[i]].y]);
		}
		for(int i=1; i<=n; ++i){
			cur[val[i]]=i;
		}
		for(int i=1; !f&&i<=n; ++i){
			if(ans[i]!=cur[i]){
				if(ans[i]>cur[i]) f=1;
				else break;
			}
		}
		if(!f) return;
		memcpy(ans+1,cur+1,n*sizeof(ans[0]));
	}
	for(int i=1; i<n; ++i){
		if(vis[i]) continue;
		vis[i]=1;
		stk[t+1]=i;
		dfs(t+1);
		vis[i]=0;
	}
}

int main(){
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	for(int T=nxi(); T; --T){
		n=nxi();
		memset(ans,0,sizeof(ans));
		for(int i=1; i<=n; ++i){
			pos[i]=nxi();
		}
		for(int i=1; i<n; ++i){
			eg[i]=(edge){nxi(),nxi()};
		}
		dfs(1);
		for(int i=1; i<=n; ++i){
			printf("%d ",ans[i]);
		}
		puts("");
	}
	return 0;
}
