#include <iostream>
#include <cstdio>
#include <cstring>
#include <cassert>
typedef long long lint;

namespace utils{
	template <class T> inline void apn(T &x,const T y){x=x<y?x:y;}
	template <class T> inline void apx(T &x,const T y){x=x<y?y:x;}
	inline lint nxi(){
		lint x=0;
		char c;
		while(((c=getchar())>'9'||c<'0')&&c!='-');
		const bool f=c=='-'&&(c=getchar());
		while(x=x*10-48+c,(c=getchar())>='0'&&c<='9');
		return f?-x:x;
	}
}
using namespace utils;

void qry(const int p,lint q){
	if(p==0) return;
	if(q>=(1ll<<(p-1))){
		putchar('1');
		q-=(1ll<<(p-1));
		qry(p-1,(1ll<<(p-1))-1-q);
	}
	else{
		putchar('0');
		qry(p-1,q);
	}
}

int main(){
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	lint n=nxi(),q=nxi();
	qry(n,q);
	puts("");
	return 0;
}
