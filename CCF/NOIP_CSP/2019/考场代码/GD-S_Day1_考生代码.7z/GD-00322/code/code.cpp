#include<iostream>
#include<cmath>
#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
int n,j;
long long k,num=1;
int a[1000];
void find(long long k,long long num)
{
	if (num==1)
	 {
	 	if (k==0)
	 	 {
	 	 	j++;
	 	 	a[j]=0;
		  } else
		  {
		  	j++;
		  	a[j]=1;
		  }
		return;
	 }
	long long mid=num/2+1;
	if (k<mid)
	 {
	 	j++;
	 	a[j]=0;
	 	find(k,num/2);
	 } else
	 {
	 	j++;
	 	a[j]=1;
	 	find(mid-1-k+mid,num/2);
	 }
	 return;
}
int main()
{
	freopen("code.in","r",stdin);
 	freopen("code.out","w",stdout);
	scanf("%d%lld",&n,&k);
	for(int i=1;i<=n-1;i++)
	 num=num*2;
	num=num-1+num;
	j=0;
	find(k,num);
	for(int i=1;i<=j;i++)
	 printf("%d",a[i]);
	return 0;
 } 
