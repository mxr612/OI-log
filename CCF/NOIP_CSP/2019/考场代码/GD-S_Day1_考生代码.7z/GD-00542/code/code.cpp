#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

int n, k[101], temp[101], len, a[101][101];
char c;

bool xiaoyudengyu(int y) {
	for (int i = 99; i >= 0; i--) {
		if (k[i] == a[y][i]) continue;
		if (k[i] < a[y][i]) return 1;
		return 0;
	}
	return 1;
}

void jian(int y) {
	for (int i = 0; i <= 100; i++) {
		k[i] -= a[y][i];
		if (k[i] < 0) {
			k[i + 1] -= 1;
			k[i] += 10;
		}
	}
}

void dfs(int x, bool yes) {
	if (x == 0) return ; 
	if (!yes) {
		if (xiaoyudengyu(x - 1)) {
			putchar('0');
			dfs(x - 1, 0);
		}
		else {
			putchar('1');
			jian(x - 1);
			dfs(x - 1, 1);
		}
	}
	else {
		if (xiaoyudengyu(x - 1)) {
			putchar('1');
			dfs(x - 1, 0);
		}
		else {
			putchar('0');
			jian(x - 1);
			dfs(x - 1, 1);
		}
	}
}

int main() {
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	
	scanf("%d", &n);
	c = getchar();
	while (c < '0' || c > '9') c = getchar();
	while (c >= '0' && c <= '9') {
		k[len++] = c - 48;
		c = getchar();
	}
	
	for (int i = 0; i < len; i++)
		temp[i] = k[i];
	for (int i = len - 1; i >= 0; i--)
		k[i] = temp[len - i - 1];
	k[0] += 1;
	
	a[0][0] = 1;
	for (int i = 1; i <= n; i++) {
		for (int j = 0; j < 100; j++) {
			a[i][j] += a[i - 1][j] * 2;
			a[i][j + 1] += a[i][j] / 10;
			a[i][j] %= 10;
		}
	}
	
	dfs(n, 0);
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
