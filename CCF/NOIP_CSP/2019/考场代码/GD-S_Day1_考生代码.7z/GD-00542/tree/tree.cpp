#include<cstdio>
#include<cstring>
#include<algorithm>

using namespace std;

int t, n, a[2001];

int main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	
	scanf("%d", &t);
	
	for (int i = 1; i <= t; i++) {
		for (int i = 1; i <= n; i++)
			scanf("%d %d", &a[1], &a[2]);
		
		memset(a, 0, sizeof(a));
		
		scanf("%d", &n);
		for (int i = 1; i <= n; i++)
			scanf("%d", &a[i]);
			
		sort(a + 1, a + n + 1);
		
		for (int i = 1; i <= n; i++)
			printf("%d ", a[i]);
		putchar('\n');
	}
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
