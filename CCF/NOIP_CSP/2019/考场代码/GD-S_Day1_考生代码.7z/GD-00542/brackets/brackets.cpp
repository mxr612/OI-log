#include<cstdio>
#include<iostream>

using namespace std;

int n, a[50001], f[50001], son[50001][501], ans[50001];
int an[101], maxn, answer, lleft, rright;
char c;

void dfss(int now, int x) {
	if (a[now] == 1) lleft++;
		else rright++;
	if (lleft > rright) return ;
	if (lleft == rright && a[now] == 1) ans[x]++;
	if (now != 1) dfss(f[now], x);
}

void work(int x) {
	if (a[x] == 2) {
		lleft = 0;
		rright = 1;
		dfss(f[x], x);
	}
	ans[x] += ans[f[x]];
}

void dfs(int x) {
	if (x != 1) work(x);
	for (int i = 1; i <= son[x][0]; i++)
		dfs(son[x][i]);
}

int main() {
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> c;
		if (c == '(') a[i] = 1;
			else a[i] = 2;
	}
	for (int i = 2; i <= n; i++) {
		cin >> f[i];
		son[f[i]][++son[f[i]][0]] = i;
	}
	
	dfs(1);
	
	for (int i = 1; i <= n; i++) {
		ans[i] *= i;
		int len = 1;
		while ((1 << len) <= ans[i])
			len++;
		maxn = max(maxn, len);
		for (int j = len; j >= 0; j--)
			if (1 << j <= ans[i]) {
				an[j] = (an[j] + 1) % 2;
				ans[i] -= 1 << j;
			}
	}
	
	for (int i = 0; i <= maxn; i++)
		if (an[i])
			answer += 1 << i;
	
	printf("%d", answer);
	
	return 0;
}
