#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
#include<stdlib.h>
using namespace std;
unsigned long long n,k,lg[100]={0,2};
inline unsigned long long read()
{
	unsigned long long x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
void deal(unsigned long long n,unsigned long long k)
{
	if(n==1&&k==1){printf("0");return;}
	if(n==1&&k==2){printf("1");return;}
	if(k<=lg[n-1]){printf("0");deal(n-1,k);return;}
	else {printf("1");deal(n-1,-k+2*lg[n-1]+1);return;}
}
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	n=read();k=read()+1;
	for(unsigned long long i=2;i<=64;i++)lg[i]=lg[i-1]<<1;
	deal(n,k);
	printf("\n");
	return 0;
}
