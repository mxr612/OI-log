#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
#include<stdlib.h>
using namespace std;
const int N=50024,INF=0x3f3f3f3f;
int t,n,a[N];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	t=read();
	while(t--)
	{
		n=read();
		for(int i=1;i<=n;i++)a[read()]=i;
		for(int i=n;i>1;i--)
		if(a[i]<a[i-1])swap(a[i],a[i-1]);
		for(int i=1;i<=n;i++)
		printf("%d ",a[i]);
		printf("\n")
	}
	return 0;
}
