#include<iostream>
#include<cstdio>
#include<cmath>
#include<cstring>
#include<string>
#include<stdlib.h>
using namespace std;
const int N=50024,INF=0x3f3f3f3f;
//struct EDGE
//{
//	int to,next,w;
//}edge[N]
//int head[N],cnt;

int dp[N],f[N],c[N],chengfayuanli[N],n,ans;
bool v[N];
inline int read()
{
	int x=0,f=1;
	char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+ch-'0';ch=getchar();}
	return x*f;
}
//inline add(int x,int y,int z)
//{
//	edge[++cnt].next=head[x];
//	edge[cnt].to=y;
//	edge[cnt].w=z;
//	head[x]=cnt;
//} 
//void ILOVENYQ(int now)
//{
//	if(now==1)return;
//	if(!v[f[now]])ILOVENYQ(f[now]);
//	dp[now].c=dp[f[now]].c+c[now]; 
//	dp[now].num=dp[f[now]].num;
//	if(dp[now].c<0){dp[now].c=0;return;}
//	if(/*(dp[f[now]].c<0&&dp[now].c>dp[f[now]].c)||*/(dp[f[now]].c>0&&dp[now].c<dp[f[now]].c))
//	{
//		dp[now].last=max(dp[f[now]].last,dp[f[f[now]]].last)+1;
//		dp[now].num-=chengfayuanli[max(dp[f[now]].last,dp[f[f[now]]].last)];
//		dp[now].num+=chengfayuanli[dp[now].last];
//	}
//	else dp[now].last=0;
//}
int find(int now)
{
	if(now==0)return 0;
	if(v[now])return dp[now];
//	if(!v[f[now]])dp[now]+=find(f[now]);
	int tot=0,num=0,i=now,ex=0;
	while(tot<=0&&i!=0)
	{	
		int cntL=0,cntR=0,ok1=0,ok2=0;
		while(c[i]==-1&&i!=0)
		{
			cntR++;
			tot+=c[i];
			i=f[i];
			ok1=1;
		}
		while(c[i]==1&&i!=0){cntL++;tot+=c[i];i=f[i];ok2=1;}
		if(ok1&&ok2)
		{
			num++;ex+=max(cntL,cntR)-1;
		}
		
		if(min(cntL,cntR)==0&&cntL>0)ex+=cntL;
	}
	dp[now]+=chengfayuanli[num];
	if(tot==0)dp[now]+=ex;
	dp[now]+=find(i);
	v[now]=1;
	return dp[now];
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	n=read();
	for(register int i=1;i<=n;++i)
	{
		register char ch=getchar();
		if(ch=='(')c[i]=1;
		else c[i]=-1;
//		if(ch=='(')dp[i][1].c=1;
//		else dp[i][1].c=-1;
	}
//	dp[1].c=c[1];v[1]=1;
	for(register int i=2;i<=n;++i)f[i]=read();
	for(int i=1;i<=n;++i)chengfayuanli[i]=chengfayuanli[i-1]+i;
	for(int i=1;i<=n;++i)
	if(!v[i])find(i);
//	for(int i=1;i<=n;i++)printf("%d ",chengfayuanli[i]);

//	for(int i=1;i<=n;i++)printf("%d ",dp[i]);
//	printf("\n");
	ans=dp[1];
	for(int i=2;i<=n;i++)
	ans=ans^(i*dp[i]);
	printf("%d\n",ans);
	return 0;
}
