#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
const int MAXN = 64 + 5;
template<typename T> void chkmin(T &x, T y) { x = min(x, y); }
template<typename T> void chkmax(T &x, T y) { x = max(x, y); }
template<typename T> void read(T &x) {
	x = 0; char c; int f = 1;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -f;
	for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
	x *= f;
}
template<typename T> void write(T x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}
template<typename T> void writeln(T x) { write(x); putchar('\n'); }
int n, ans[MAXN]; ull k, p[MAXN];
void solve(int pos, ull rst) {
	if (pos == 0) return; 
	if (rst < p[pos - 1]) {
		ans[pos] = 0;
		solve(pos - 1, rst);
	}
	else {
		ans[pos] = 1;
		solve(pos - 1, p[pos] - 1ll - rst);
	}
}
int main() {
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	read(n); read(k);
	p[0] = 1;
	for (int i = 1; i <= n; ++i) p[i] = p[i - 1] * 2ll;
	solve(n, k);
	for (int i = n; i; --i) write(ans[i]); putchar('\n');
	return 0;
}

