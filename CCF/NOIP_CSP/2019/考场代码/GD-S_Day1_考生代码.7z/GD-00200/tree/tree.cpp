#include <bits/stdc++.h>
using namespace std;
const int MAXN = 2000 + 5;
template<typename T> void chkmin(T &x, T y) { x = min(x, y); }
template<typename T> void chkmax(T &x, T y) { x = max(x, y); }
template<typename T> void read(T &x) {
	x = 0; char c; int f = 1;
	for (c = getchar(); !isdigit(c); c = getchar()) if (c == '-') f = -f;
	for (; isdigit(c); c = getchar()) x = x * 10 + c - '0';
	x *= f;
}
template<typename T> void write(T x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}
template<typename T> void writeln(T x) { write(x); putchar('\n'); }
int n, np[MAXN], pn[MAXN], tmp[MAXN], ans[MAXN], flag;
int x[MAXN], y[MAXN], vis[MAXN];
void solve(int cnt) {
	if (cnt == n - 1) {
		if (flag) {
			for (int i = 1; i <= n; ++i)
				if (np[i] > ans[i]) return;
				else if (np[i] < ans[i]) break;
		}
		flag = 1;
		for (int i = 1; i <= n; ++i) ans[i] = np[i];
		return;
	}
	for (int i = 1; i < n; ++i) {
		if (vis[i]) continue;
		vis[i] = 1;
		swap(pn[x[i]], pn[y[i]]);
		np[pn[x[i]]] = x[i]; np[pn[y[i]]] = y[i];
		solve(cnt + 1);
		vis[i] = 0;
		swap(pn[x[i]], pn[y[i]]);
		np[pn[x[i]]] = x[i]; np[pn[y[i]]] = y[i];
	}
}
void solve() {
	flag = 0;
	read(n);
	for (int i = 1; i <= n; ++i) read(np[i]), pn[np[i]] = i;
	for (int i = 1; i < n; ++i) read(x[i]), read(y[i]);
	solve(0);
	for (int i = 1; i < n; ++i) write(ans[i]), putchar(' '); writeln(ans[n]);
}
int main() {
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	int T;
	read(T);
	for (; T; --T) solve();
	return 0;
}

