#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
const int MAXN = 500000 + 5;
int head[MAXN], ver[MAXN << 1], nxt[MAXN << 1], tot = 1;
void add(int x, int y) {
	ver[++tot] = y; nxt[tot] = head[x]; head[x] = tot;
	ver[++tot] = x; nxt[tot] = head[y]; head[y] = tot;
}
int n, tp;
ull ans, sum[MAXN];
char c[MAXN], st[MAXN];
void solve(int x, int fa, ull res) {
	int flag = 0; char tmp; ull tmp2; 
	if (tp && st[tp] == '(' && c[x] == ')') {
		flag = 1; tmp = st[tp]; tmp2 = sum[tp + 1];
		sum[tp + 1] = 0; res += sum[tp] + 1; ++sum[tp]; --tp;
	}
	else st[++tp] = c[x];
	ans = ans ^ (1ll * res * x);
//	printf("%d : %llu\n", x, res);
	for (int i = head[x]; i; i = nxt[i]) {
		if (ver[i] == fa) continue;
		solve(ver[i], x, res);
	}
	if (flag) st[++tp] = tmp, sum[tp + 1] = tmp2, sum[tp]--;
	else --tp;
}
int main() {
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	scanf("%d", &n);
	scanf("%s", c + 1);
	for (int i = 2; i <= n; ++i) {
		int fa;
		scanf("%d", &fa);
		add(fa, i);
	}
	solve(1, 0, 0);
	printf("%llu\n", ans);
	return 0;
}


