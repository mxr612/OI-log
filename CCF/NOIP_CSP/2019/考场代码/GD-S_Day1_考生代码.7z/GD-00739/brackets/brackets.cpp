#include<cstdio>
#include<iostream>
using namespace std;
int to[100005], tail[100005], last[100005], edgecnt;
int N, fa[100005], jmp[100005], dep[100005]; string str;
long long ans[100005], final;
void addedge(int S, int T){
	to[++edgecnt] = T;
	last[edgecnt] = tail[S];
	tail[S] = edgecnt;
}
bool check(int S, int T){
	if(jmp[S] == -1) return true;
	int left_count = 0;
	while(S != -1 && dep[S] >= dep[T]){
		while(jmp[S] != -1 && dep[jmp[S]] >= dep[T])
			S = jmp[S];
		if(str[S - 1] == ')'){
			left_count++;
		}else{
			left_count--;
			if(left_count < 0) return false;
		}
		S = fa[S];
	}
	if(left_count != 0) return false;
	return true;
}
void dfs(int nod){
	if(fa[nod] > 0){
		if(str[nod - 1] == ')'){
			int tmp = nod, far = 0;
			while(fa[tmp] > 0){
				tmp = fa[tmp];
				if(str[tmp - 1] == '('){
					bool result = check(nod, tmp);
					if(result) {
						far = tmp;
						ans[nod] += 1LL;
					}
				}
			}
			jmp[nod] = fa[far];
		}
		ans[nod] += ans[fa[nod]];
	}
	for(int i = tail[nod]; i; i = last[i]){
		dep[to[i]] = dep[nod] + 1;
		dfs(to[i]);
	}
}
int main(){
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	fa[1] = -1;
	cin >> N;
	cin >> str;
	for(int i = 2; i <= N; i++){
		cin >> fa[i];
		addedge(fa[i], i);
	}
	dfs(1);
	for(int i = 1; i <= N; i++)
		final ^= 1LL * i * ans[i];
	cout << final;
	return 0;
}
