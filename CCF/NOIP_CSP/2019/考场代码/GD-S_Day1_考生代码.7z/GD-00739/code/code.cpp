#include<cstdio>
#include<iostream>
using namespace std;
unsigned long long N, K, L, R;
string Ans;
int main(){
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	cin >> N >> K;
	L = 0LL; R = (1LL << N) - 1LL;
	while(L < R){
		if(K <= ((L + R) / 2LL)){
			Ans = Ans + "0";
			R = ((L + R) / 2LL);
		}else{
			Ans = Ans + "1";
			L = ((L + R) / 2LL) + 1;
			K = R - (K - L);
		}
	}
	cout << Ans;
	return 0;
}
