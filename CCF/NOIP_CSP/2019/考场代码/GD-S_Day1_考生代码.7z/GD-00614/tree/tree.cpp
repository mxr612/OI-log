#include<iostream>
#include<stdio.h>
#include<memory.h>
#include<algorithm>
using namespace std;

int Read()
{
	char ch=getchar();
	int num=0;
	while (ch<'0'||ch>'9')
		ch=getchar();
	while (ch>='0'&&ch<='9')
	{
		num=num*10+ch-'0';
		ch=getchar();
	}
	return num;
}

bool used[3000]= {0};
pair <int,int> edge[3000];
int ans[3000];
int num[3000];
int n,m;
int record[3000];

void myswap(int &a,int &b)
{
	int tmp=a;
	a=b;
	b=tmp;
}

pair<int,int> tmp[3000];
void solve1(int step)
{
	int i;
	if (step==m-1)
	{
		bool flag=false;
		for (i=0; i<m; i++)
			tmp[i].first=num[i],tmp[i].second=i;
		sort(tmp,tmp+m);
		for (i=0; i<m; i++)
		{
			if (tmp[i].second<ans[i])
			{
				flag=true;
				break;
			}
			if (tmp[i].second>ans[i])
			{
				break;
			}
		}
		if (flag)
			for (i=0; i<m; i++)
				ans[i]=tmp[i].second;
		return;
	}
	for (i=0; i<m-1; i++)
	{
		if (used[i]) continue;
		used[i]=true;
		myswap(num[edge[i].first],num[edge[i].second]);
		record[step]=i;
		solve1(step+1);
		used[i]=false;
		myswap(num[edge[i].first],num[edge[i].second]);
	}
}

int main()
{
	int i,j;
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);

	n=Read();
	for (i=0; i<n; i++)
	{
		memset(edge,0,sizeof(edge));
		memset(used,0,sizeof(used));
		memset(ans,0x3f,sizeof(ans));

		m=Read();
		for (j=0; j<m; j++)
			num[j]=Read();
		for (j=0; j<m-1; j++)
			edge[j].first=Read()-1,edge[j].second=Read()-1;
		solve1(0);
		for (j=0; j<m; j++)
			printf("%d ",ans[j]+1);
		printf("\n");
	}

	fclose(stdin);
	fclose(stdout);
	return 0;
}
