#include<iostream>
#include<stdio.h>
#include<vector>
using namespace std;

bool bracket[1000000];
vector <int> son[1000000];
int father[1000000];
bool brecord[1000000];
long long ans=0;

int Readnum()
{
	char ch=getchar();
	int num=0;
	while (ch<'0'||ch>'9')
		ch=getchar();
	while (ch>='0'&&ch<='9')
	{
		num=num*10+ch-'0';
		ch=getchar();
	}
	return num;
}

bool Readbracket()
{
	char ch='?';
	int num=0;
	while (ch!='('&&ch!=')')
		ch=getchar();
	return ch==')';
}

void solve(int pos,int step)
{
	int i,j,k;
	brecord[step]=bracket[pos];
	long long sum=0;
	for (i=0; i<=step-1; i++)
		for (j=i+1; j<=step; j++)
		{
			int tmp=0;
			bool flag=true;
			for (k=i; k<=j; k++)
			{
				tmp+=!brecord[k];
				tmp-=brecord[k];
				if (tmp<0)
					flag=false;
			}
			if (tmp>0)
				flag=false;
			if (flag)
				sum++;
		}
	ans=ans^(sum*(pos+1));
	for (i=0; i<son[pos].size(); i++)
	{
		int next=son[pos][i];
		solve(next,step+1);
	}
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);

	int n=Readnum();
	int i;

	for (i=0; i<n; i++)
		bracket[i]=Readbracket();
	for (i=1; i<n; i++)
	{
		int tmp;
		tmp=Readnum();
		tmp--;
		father[i]=tmp;
		son[tmp].push_back(i);
	}
	solve(0,0);
	cout<<ans<<endl;

	fclose(stdin);
	fclose(stdout);
	return 0;
}
