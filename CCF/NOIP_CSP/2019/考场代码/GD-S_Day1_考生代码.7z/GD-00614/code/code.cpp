#include<iostream>
#include<stdio.h>
#include<string>
#include<cmath>
using namespace std;

string solve(unsigned long long quest,int times,unsigned long long l,unsigned long long r)
{
	if (times==0)
		return "";
	unsigned long long mid=pow(2,times-1)+l;
	//cout<<l<<"-"<<mid<<"-"<<r<<"?"<<quest<<endl;
	if (quest<mid)
	{
		return "0"+solve(quest,times-1,l,mid-1);
	}
	else
	{
		return "1"+solve(r-(quest-mid),times-1,mid,r);
	}
}

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	
	unsigned long long n,m;
	cin>>n>>m;
	cout<<solve(m,n,0,pow(2,n)-1)<<endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
