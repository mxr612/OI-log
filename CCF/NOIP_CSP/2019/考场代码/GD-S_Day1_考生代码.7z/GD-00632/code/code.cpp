#include<cstdio>
#include<cstring>
#include<iostream>

using namespace std;
const int maxn = 5*1000000 + 50;
long long a[maxn];
int f[maxn];
long long n, k;

int main()
{
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	memset(a,0,sizeof(a));
	cin >> n >> k;
	k = k + 1;
	a[1] = 0; a[2] = 1;
	for(int i=2; i<=n; i++)
	{
		long long st = 1<<(i-1)|1, ed = (1<<i), t = ed+1;
		long long add = 1<<(i-1);
		for(long long j=st; j<=ed; j++)
			a[j] = a[t-j] + add;
	}
	int cnt = n;
	long long x = a[k];
	memset(f, 0, sizeof(f));
	while(x>0)
	{
		f[cnt--] = x & 1;
		x = x >> 1;
	}
	for(int i=1; i<=n; i++)
		printf("%d", f[i]);
	return 0;
}



