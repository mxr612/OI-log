#include<cstdio>
#include<map>
#include<string>
#include<cstring>
#include<iostream>

using namespace std;
const int maxn = 500000+50;
int n;
int ans = 0;
long long tot = 0;
char a[maxn];
int f[maxn];
int top2[maxn], t2[maxn], t02[maxn], ans2[maxn];

struct edge{
	int to;
	edge()
	{
		to = 0;
	}
} e[maxn*2];
int head[maxn], net[maxn*2];
int e_num = -1;

void e_add(int x, int y)
{
	net[++e_num] = head[x];
	head[x] = e_num;
	e[e_num].to = y;
}
void dfs(int x, int fa)
{
	t2[x] = t2[fa];
	t02[x] = t02[fa];
	top2[x] = top2[fa];
	ans2[x] = ans2[fa];
	int u = x-1; //��Ӧ�ַ����� 
	if(a[u] == '(')
		top2[x]++;
	if(a[u] == ')')
	{
		if(top2[x] > 1)
		{
			t2[x]++;
			top2[x]--;
		} else
		if(top2[x] == 1)
		{
			t02[x]++;
			ans2[x] += t02[x] + t2[x];
			t2[x] = 0;	
			top2[x]--;		 
		}
	}
	f[x] = ans2[x] + t2[x];
	for(int i=head[x]; i!=-1; i=net[i])
	{
		int y = e[i].to;
		if(y == fa) continue;
		dfs(y, x);
	}
}

int main()
{
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	memset(head,-1,sizeof(head));
	memset(f, 0, sizeof(f));
	scanf("%d", &n);
	scanf("%s", a);
	bool flag = 1;
	for(int i=2; i<=n; i++)
	{
		int fa;
		scanf("%d", &fa);
		if(fa != i-1) flag = 0;
		e_add(fa, i); e_add(i, fa);
	}
	if(flag)
	{
		int top = 0, t0 = 0, t = 0;
		for(int i=0; i<n; i++)
		{
			if(a[i] == '(')
				top++;
			if(a[i] == ')')
			{
				if(top == 0) continue;
				if(top > 1)
				{
					t++;
					top--;
				} else
				if(top == 1)
				{
					t0++;
					ans += t0 + t;
					t = 0;	
					top--;		 
				}
			}
			f[i+1] = ans + t;
		}
		ans = ans + t;
	}
	else
	{
		memset(top2,0,sizeof(top2));
		memset(t2,0,sizeof(t2));
		memset(t02,0,sizeof(t02));
		memset(ans2,0,sizeof(ans2));
		dfs(1, 1);
	}
	for(int i=1; i<=n; i++)
	{
		tot = tot^((long long )i*f[i]);
	}
	cout << tot;
	return 0;
}



