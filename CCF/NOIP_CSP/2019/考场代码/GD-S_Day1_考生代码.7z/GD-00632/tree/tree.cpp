#include<cstdio>
#include<queue>
#include<cstring>
#include<algorithm>

using namespace std;
const int maxn = 2050;
int T, n;
int w[maxn], v[maxn];
bool g[maxn][maxn];

void change_(int x, int y)
{
	if(x == y) return;
	if(g[y-1][y])
	{
		swap(v[y-1], v[y]);
		w[v[y-1]] = y;
		w[v[y]] = y-1;
		g[y-1][y] = g[y][y-1] = 0;
		change_(x, y-1);
	}
}
int main()
{
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	scanf("%d", &T);
	while(T--)
	{
		memset(w,0,sizeof(w));
		memset(v,0,sizeof(v));
		memset(g, 0, sizeof(g));
		scanf("%d", &n);
		for(int j=1; j<=n; j++)
		{
			int x;
			scanf("%d", &x);
			w[j] = x;
			v[x] = j;
		}
		for(int j=1; j<n; j++)
		{
			int y, z;
			scanf("%d %d", &y, &z);
			g[y][z] = g[z][y] = 1;
		}
		for(int i=1; i<=n; i++)
		{
			int sit = w[i];
			change_(1,sit);
		}
		for(int i=1; i<=n; i++)
		{
			for(int j=1; j<=n; j++)
			{
				if(v[j] == i) printf("%d ", j);
			}
		}
		printf("\n");
	}
	return 0;
}
