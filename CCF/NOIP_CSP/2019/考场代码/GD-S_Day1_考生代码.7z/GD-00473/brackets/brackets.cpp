#include<cstdio>
#include<algorithm>
long long n,f[500001],b[500001],tot,t[500001],en[1000001],next[1000001],last[1000001];
long long a[500001],sum;
char s[500001];
void add(long long x,long long y)
{
	en[++tot]=y;
	next[tot]=last[x];
	last[x]=tot;
}
void dg(long long x,long long y)
{
	long long p=last[x],v,g;
	while (p>0)
	{
		v=en[p],a[v]=a[x],g=y;
		long long e=t[y],q=t[y-1];
		if(b[v]==1) g++;
		else if(g>0)
		{
			t[g]=0;
			a[v]+=t[--g]+1;
			t[g]++;
		}
		dg(v,g);
		if(y>0&&b[v]==-1)
			t[y]=e,t[y-1]=q;
		p=next[p];
	}
}
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%lld\n",&n);
	for (int i=1;i<=n;i++)
	{
		scanf("%c",&s[i]);
		if(s[i]=='(') b[i]=1;
		else b[i]=-1;
	}
	tot=0;
	for (int i=2;i<=n;i++)
	{
		scanf("%lld",&f[i]);
		add(f[i],i);
	}
	dg(1,b[1]);
	sum=0;
	for (int i=2;i<=n;i++)
		sum=sum^(i*a[i]);
	printf("%lld\n",sum);
	return 0;
}
