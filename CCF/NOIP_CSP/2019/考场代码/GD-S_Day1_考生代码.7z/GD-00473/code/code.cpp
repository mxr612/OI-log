#include<cstdio>
#include<algorithm>
using namespace std;
unsigned long long n,k,t;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%llu %llu",&n,&k);
	t=1;
	for (unsigned long long i=1;i<n;i++) t=t*2;
	while (t>0)
	{
		if(k<t) printf("0");
		else printf("1"),k=t*2-k-1;
		t=t/2;
	}
	return 0;
}
