#include<map>
#include<list>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
char s[500005];
long long f[500005];
long long a[500005];
long long g[500005];
long long d[500005];
int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	long long n,ans=0;
	scanf("%lld\n%s",&n,s+1);
	if(s[1]=='(')g[1]++;
	for(long long i=2;i<=n;i++)
	{
		scanf("%lld",&f[i]);
		a[i]=a[f[i]];g[i]=g[f[i]];
		d[i]=d[f[i]];
		if(s[i]==')'&&g[i])
		{
			g[i]--;
			a[i]++;
			if(!g[i])
			{
				a[i]+=d[i];
				d[i]++;
			}
		}
		else if(s[i]==')'&&!g[i])d[i]=0;
		else if(s[i]=='(')g[i]++;
	}
	for(long long i=1;i<=n;i++)ans^=a[i]*i;
	printf("%lld",ans);
}
