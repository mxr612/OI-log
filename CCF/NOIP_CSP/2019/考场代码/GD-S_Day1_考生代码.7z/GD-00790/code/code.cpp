#include<map>
#include<list>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
int ans[70];
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	long long n,k;
	scanf("%lld%lld",&n,&k);
	k++;
	for(long long i=n;i;i--)
	{
		if(k>(1ll<<(i-1)))ans[i]=1,k=(1ll<<i)-k+1;
		else ans[i]=0;
	}
	for(int i=n;i;i--)printf("%d",ans[i]);
}
