#include<map>
#include<list>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;
inline int read()
{
	int x=0;char ch=getchar();
	while(ch<'0'||ch>'9')ch=getchar();
	for(;ch>='0'&&ch<='9';ch=getchar())x=(x<<1)+(x<<3)+(ch^48);
	return x;
}
int g[2005][2005];
bool vis[2005];
bool t[2005];
int a[2005];
int b[2005];
int f[2005];
int find_mn(int v,int u,int n)
{
//55'555	cout<<u<<endl;
	int mn=(t[u]||(u==v))?0x7fffffff:u;
	vis[u]=1;
	for(int i=1;i<=n;i++)if((~g[u][i])&&(!f[g[u][i]])&&(!vis[i]))
	{
		if(g[u][i])f[g[u][i]]=1;
		mn=min(mn,find_mn(v,i,n));
		if(g[u][i])f[g[u][i]]=0;
	}
	return mn;
}
bool set_pth(int x,int u,int mn,int n)
{
	//cout<<u<<endl;
	if(u==mn)return 1;
	bool fg=0;
	vis[u]=1;
	for(int i=1;i<=n;i++)if((~g[u][i])&&(!vis[i]))//&&(!f[g[u][i]])
	{
	//	cout<<i<<" ";
		fg=set_pth(x,i,mn,n);
		if(fg)
		{
			if(!g[u][i])
			{
				g[u][i]=-1;
				g[i][u]=x;
			}
			else g[u][i]=-1;
			return 1;
		}
	}
	return 0;
}
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	for(int T=read();T;T--)
	{
		memset(g,-1,sizeof(g));
		memset(t,0,sizeof(t));
		int n=read();
		for(int i=1;i<=n;i++)b[a[i]=read()]=i;
		for(int i=1;i<n;i++)
		{
			int u=read(),v=read();
			g[u][v]=g[v][u]=0;
		}
		for(int i=1;i<=n;i++)
		{
//			cout<<i<<": __"<<endl;
			memset(vis,0,sizeof(vis));
			int mn=find_mn(a[i],a[i],n);
			t[mn]=1;
			
			memset(vis,0,sizeof(vis));
			set_pth(i,a[i],mn,n);
			//cout<<mn<<endl;
//			for(int j=1;j<=n;j++)
//			{
//				for(int k=1;k<=n;k++)cout<<g[j][k]<<" ";
//				cout<<endl;
//			}
			cout<<mn<<" ";
//			cout<<endl;
		}
		cout<<endl;
	}
}
