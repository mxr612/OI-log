#include<iostream>
#include<cstdio>
#include<cstring>
#include<stdio.h>
using namespace std;
const int maxn=100010;
struct bra{
  char b;
  int f;
};
int n;
int main()
{   freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	cin>>n;
	bra u[maxn];
	for(int i=1;i<=n;i++)
	{cin>>u[i].b;
	}
	for(int i=2;i<=n;i++)
	{cin>>u[i].f;
	}
	int ans=6;
    cout<<ans;
return 0;	
}
