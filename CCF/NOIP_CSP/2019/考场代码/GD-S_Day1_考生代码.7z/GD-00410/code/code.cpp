#include<iostream>
#include<cstdio>
int n,k,h=1;
using namespace std;
int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	cin>>n>>k;
	unsigned long long cmp=0;
	for(unsigned long long i=1;i<=n;i++)
	{
	 h*=2;
	}
	k=k+1;
	while(h>1)
	{if(cmp==0){if(k>h/2) cout<<1,k=k-h/2,cmp=1;else cout<<0,cmp=0;}
	 else{if(k>h/2) cout<<0,k=k-h/2,cmp=1;else cout<<1,cmp=0;}
	 h=h/2;
	}
	return 0;
}
