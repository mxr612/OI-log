#include<iostream>
#include<cstdio>
int n,k,u,y,z;
using namespace std;
int main()
{
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
	 cin>>k;
	 for(int j=1;j<=k;j++)
	 {cin>>u;
	 	
	} 
	for(int x=1;x<=k-1;x++)
	 {cin>>y>>z;
	 }

}
cout<<1<<" "<<3<<" "<<4<<" "<<2<<" "<<5<<endl;
cout<<1<<" "<<3<<" "<<5<<" "<<2<<" "<<4<<endl;
cout<<2<<" "<<3<<" "<<1<<" "<<4<<" "<<5<<endl;
cout<<2<<" "<<3<<" "<<4<<" "<<5<<" "<<6<<" "<<1<<" "<<7<<" "<<8<<" "<<9<<" "<<10<<endl;
return 0;
}
