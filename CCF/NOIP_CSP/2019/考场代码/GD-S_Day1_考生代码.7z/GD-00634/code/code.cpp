#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;

int n;
unsigned long long k;
unsigned long long power[65];

int main()
{
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	
	power[0] = 1;
	for (int i = 1; i <= 64; i ++) power[i] = power[i - 1] << 1;
	scanf("%d %lld", &n, &k);
	for (int i = n; i > 0; i --)
	{
		if (k / power[i] % 2)
			if (k % power[i] >= power[i - 1]) 
				printf("0");
			else
				printf("1");
		else
			if (k % power[i] >= power[i - 1]) 
				printf("1");
			else
				printf("0");
	}
	return 0;
}
