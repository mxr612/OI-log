#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;

#define N 500005

int n, tot;
long long ans;
long long f[N];
int to[N], nx[N], ls[N], stk[N], s[N];
bool p[N], flag[N];

void add(int u, int v)
{
	to[++ tot] = v;
	nx[tot] = ls[u];
	ls[u] = tot;
}

inline void sum(int l)
{
	int t = 0;
	long long res = 0;
	for (register int i = 0; i <= l; i ++) f[i] = stk[i] = 0;
	for (register int i = 1; i <= l; i ++)
	{
		if (p[s[i]])
		{
			if (t > 0) 
			{
				res += f[t] + 1;
				f[t] = f[t - 1] + 1;
				f[t + 1] = 0;
				-- t;
			}
		}
		else
			++ t;
		if (! flag[s[i]]) 
		{
			ans = ans ^ (s[i] * res);
			flag[s[i]] = true;
		}
	}
}

void dfs(int x, int l)
{
	s[l] = x;
	for (register int i = ls[x]; i; i = nx[i]) dfs(to[i], l + 1);
	if (! ls[x]) sum(l);
}

int main()
{
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	scanf("%d", &n);
	for (int i = 1; i <= n; i ++)
	{
		char ch;
		scanf("%c", &ch);
		while (ch != '(' && ch != ')') scanf("%c", &ch);
		p[i] = (ch == '(' ? false : true);
	}
	for (int i = 2; i <= n; i ++)
	{
		int x;
		scanf("%d", &x);
		add(x, i);
	}
	dfs(1, 1);
	printf("%d", ans);
	return 0;
}
