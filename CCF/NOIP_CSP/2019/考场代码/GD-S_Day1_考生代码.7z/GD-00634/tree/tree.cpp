#include<iostream>
#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;

#define N 2005

int T, n, r;
int rev[N], seg[N], rd[N], f[N][N], rev2[N], seg2[N];
bool flag[N];

void nswap(int x, int y)
{
	int temp = rev[x];
	rev[x] = rev[y];
	rev[y] = temp;
	seg[rev[x]] = x;
	seg[rev[y]] = y;
}

void mswap(int x, int y)
{
	int temp = rev2[x];
	rev2[x] = rev2[y];
	rev2[y] = temp;
	seg2[rev2[x]] = x;
	seg2[rev2[y]] = y;
}

int main()
{
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	
	scanf("%d", &T);
	while (T --)
	{
		scanf("%d", &n);
		for (int i = 1; i <= n; i ++) scanf("%d", &seg[i]), rev[seg[i]] = i;
		for (int i = 1; i <= n; i ++) seg2[i] = seg[i], rev2[i] = rev[i];
		for (int i = 1; i < n; i ++)
		{
			int x, y;
			scanf("%d %d", &x, &y);
			f[x][y] = f[y][x] = true;
			rd[x] ++, rd[y] ++;
		}
		for (int i = 1; i <= n; i ++) if (rd[i] == n - 1) r = i;
		for (int i = 1; i < n; i ++)
		{
			if (seg[i] == i) continue;
			if (f[seg[i]][i])
			{
				nswap(seg[i], i);
				flag[i] = true;
			}
			else
			{
				nswap(seg[i], r);
				flag[seg[i]] = true;
				for (int j = i; j <= n; j ++)
					if (! flag[j])
					{
						nswap(r, j);
						flag[j] = true;
						break;
					}
			}
		}

		for (int i = 1; i <= n; i ++) printf("%d ", seg[i]);
				printf("\n");
	}
	return 0;
}
