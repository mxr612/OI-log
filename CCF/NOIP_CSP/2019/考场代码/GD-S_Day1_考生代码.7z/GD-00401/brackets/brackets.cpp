#include<bits/stdc++.h>
using namespace std;
int n,b,f[10000],stk[100000],top,tot,ff;
long long ans;
char a[100000];

int find(int x)
{
	if(x!=f[x])
	int fn=find(f[x]);
	if(a[x]=='(')
	stk[++top]=1;
	else
	stk[++top]=2;
	if(x==f[x]) return x;
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	f[i]=i;
	cin>>a+1;
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&b);
		f[i]=b;
	}
	for(int i=2;i<=n;i++)
	{
		memset(stk,0,sizeof(stk));
		top=tot=ff=0;
		int o=find(i);
		for(int j=1;j<=top;j++)
		{
			if(stk[j]==1) ff++;
			else if(ff&&stk[j]==2) ff--,tot++;
		}
		ans=(tot*i)^ans;
	}
	printf("%lld",ans);
	return 0;
}
