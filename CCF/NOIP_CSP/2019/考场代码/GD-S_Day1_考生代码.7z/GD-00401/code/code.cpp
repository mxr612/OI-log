#include<cstdio>
using namespace std;
int n,k,d[65],tot,g[1000000];
long long ans,c[65];

int ksm(int a,int b)
{
	int r=1,base=a;
	while(b)
	{
		if(b&1) r*=base;
		base*=base;
		b>>=1;
	}
	return r;
}

void find(int n,int k)
{
	if(n==1)
	{
		ans=k-1;
		return;
	}
	if(k>ksm(2,n)/2)
	{
		c[++tot]=ksm(2,n-1);
		d[tot]=n;
		find(n-1,ksm(2,n)-k+1);
	}
	else
	find(n-1,k);
	if(d[tot]==n)
	{
		ans+=c[tot];
		tot--;
	}
}

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%d",&n,&k);
	find(n,k+1);
	long long m;
	while(ans)
	{
		g[++m]=ans%2;
		ans/=2;
	}
	for(long long i=m;i>=2;i--)
	printf("%d",g[i]);
	return 0;
}
