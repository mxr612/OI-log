#include <bits/stdc++.h>
using namespace std;

struct dt{ int num, val;} ans[2005], b[2005];

int c[2005];

int G;
int n, w, a[2005];
int u[2005], v[2005];
int p[2005], vis[2005];

bool cmp(dt a, dt b) { return a.val < b.val;}

void dfs(int k)
{
	if (k == n)
	{
		for (int i = 1; i <= n; i ++) b[i].val = a[i];
		for (int i = 1; i < n; i ++)
			swap(b[u[p[i]]], b[v[p[i]]]);
		
		for (int i = 1; i <= n; i ++) b[i].num = i;
		sort(b + 1, b + 1 + n, cmp);
		bool flag = false;
		for (int i = 1; i <= n; i ++)
		{
			if (b[i].num < ans[i].num)
			{
				flag = true;
				break;
			}
			if (b[i].num > ans[i].num) break;
		}
		if (flag)
			for (int i = 1; i <= n; i ++) ans[i] = b[i];
		
		return;
	}
	
	for (int i = 1; i < n; i ++)
		if (!vis[i])
		{
			vis[i] = 1;
			p[k] = i;
			dfs(k + 1);
			vis[i] = 0;
			p[k] = 0;
		}
}

int main()
{
	freopen("tree.in", "r", stdin);
	freopen("tree.out", "w", stdout);
	
	scanf("%d", &G);
	while (G --)
	{
		scanf("%d", &n);
		for (int i = 1; i <= n; i ++) { scanf("%d", &c[i]); a[c[i]] = i;}
		for (int i = 1; i < n; i ++)
			scanf("%d%d", &u[i], &v[i]);
		
		if (n <= 10)
		{
			for (int i = 1; i <= n; i ++) ans[i].val = ans[i].num = n + 1;
			
			dfs(1);
			
			for (int i = 1; i <= n; i ++) printf("%d ", ans[i]);
			cout << endl;
			continue;
		}
		/*
		for (int i = 1; i < n; i ++)
		{
			degree[u[i]] ++;
			degree[v[i]] ++;
		}
		flag = 0; L = 0;
		for (int i = 1; i <= n; i ++)
			if (degree[i] == n - 1)
			{
				L = i;
				flag = 1;
				break;
			}
		if (flag)
		{
			if (L == 1)
			{
				
			}
			continue;
		}*/
		/*
		flag = 0;
		for (int i = 1; i <= n; i ++)
			if (degree[i] != 2)
			{
				flag ++;
				break;
			}
		if (flag == 2)
		{
			for (int i = 1; i < n; i ++) { add(u, v, i); add(v, u, i);}
			
			for (int i = 1, cnt = 0; i <= n; i ++)
			{
				now = c[i];
				vis[now] = 1;
				
				while (cnt < n)
				{
					for (int i = head[now]; i; i = E[i].next)
					{
						to = E[i].to;
						if (vis[to]) continue;
						now = to;
					}
				}
			}
			
			continue;
		}*/
		
	}
	
	return 0;
}
