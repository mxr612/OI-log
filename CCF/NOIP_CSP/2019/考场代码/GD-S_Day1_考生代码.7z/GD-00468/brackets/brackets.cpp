#include <bits/stdc++.h>
using namespace std;

int n;
char ch;
int a[500005], fa[500005];
long long f[500005], g[500005];
stack<int> s;
long long ans, cnt;

int main()
{
	freopen("brackets.in", "r", stdin);
	freopen("brackets.out", "w", stdout);
	
	scanf("%d\n", &n);
	for (int i = 1; i <= n; i ++)
	{
		ch = getchar();
		if (ch == '(') a[i] = 0;
		if (ch == ')') a[i] = 1;
	}
	
	bool flag = true;
	for (int i = 2; i <= n; i ++)
	{
		scanf("%d", &fa[i]);
		if (fa[i] != i - 1) flag = false;
	}
	if (!flag) goto next;
	
	if (n <= 100)
	{
		for (int i = 1; i <= n; i ++)
		{
			cnt = 0;
			for (int L = 1; L <= i; L ++)
				for (int R = L; R <= i; R ++)
				{
					flag = false;
					for (int j = L; j <= R; j ++)
					{
						if (a[j] == 1 && s.empty()) { flag = true; break;}
						if (a[j] == 0) s.push(1);
						if (a[j] == 1) s.pop();
					}
					if (!flag && s.empty()) cnt ++;
					while (!s.empty()) s.pop();
				}
			ans ^= i * cnt;
		}
		
		cout << ans << endl;
		
		return 0;
	}
	
	
	for (int i = n; i >= 1; i --)
	{
		cnt = 0;
		for (int j = i; j >= 1; j --)
		{
			if (a[j] == 1) cnt ++;
			if (a[j] == 0) cnt --;
			if (cnt < 0) break;
			if (a[j] == 0 && cnt == 0) {g[i] ++; continue;}
		}
	}
	
	for (int i = 1; i <= n; i ++)
	{
		if (a[i] == 0) f[i] = f[i - 1];
		if (a[i] == 1)
		{
			cnt = 0;
			for (int j = i - 1; j >= 1; j --)
			{
				if (cnt < 0) break;
				if (a[j] == 0 && cnt == 0) { f[i] += f[j] + g[j] + 1;}
				if (a[j] == 0) cnt --;
				if (a[j] == 1) cnt ++;
			}
		}
	}
	
	cnt = 0;
	for (int i = 1; i <= n; i ++) {cnt += f[i]; ans = ans ^ (i * cnt);}
	cout << ans << endl;
	
	return 0;
	
	next:;
	
	return 0;
}
