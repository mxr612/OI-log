#include <bits/stdc++.h>
using namespace std;

int n, ans;
unsigned long long L, R, mid, k;

int main()
{
	freopen("code.in", "r", stdin);
	freopen("code.out", "w", stdout);
	
	cin >> n >> k;
	
	R = 1;
	for (int i = 1; i <= n; i ++) R *= 2;
	R --;
	L = 0;
	ans = 0;
	
	while (L < R)
	{
		mid = (L + R) >> 1;
		if (mid >= k)
		{
			cout << ans;
			if (ans == 1) ans = 1 - ans;
			R = mid;
		}
		else
		{
			cout << 1 - ans;
			if (1 - ans == 1) ans = 1 - ans;
			L = mid + 1;
		}
	}
	
	return 0;
}
