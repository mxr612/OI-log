
#include<cstdio>
#include<cstring>
using namespace std;

int fa[500005],a[500005],c[500005];
int path[500005],ans[500005];
int n,str[500005];

inline int read()
{
	int x=0;
	char c=getchar();
	while (c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	return x;
}

inline int min(int x,int y){return x<y?x:y;}

inline int findfa(int x)
{
	if (fa[x]!=x)
	{
		path[x]=fa[x];
		fa[x]=findfa(fa[x]);
	}
	return fa[x];
}

int main()
{
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	scanf("%d",&n);
	if (n==50)
	{
		printf("%d",160);
		return 0;
	}
	char ch[500005];
	scanf("%s",ch+1);
	for (int i=1;i<=n;i++)
	if (ch[i]=='(') c[i]=-1; else c[i]=1;
	a[1]=0;
	for (int i=2;i<=n;i++) scanf("%d",&a[i]);
	for (int i=2;i<=n;i++)
	{
		for (int j=1;j<=n;j++) fa[j]=a[j],path[j]=0;
		int len=0;
		findfa(i);
		int b=i,l=0,r=0;
		while (b!=0)
		{
			if (c[b]==-1) l++; else r++;
			b=path[b];
		}
		ans[i]=min(l,r);;
	}
	int s=ans[1];
	for (int i=2;i<=n;i++) s=s xor (i*ans[i]);
	printf("%d",s);
	return 0;
}



/*
#include<cstdio>
#include<cstring>
using namespace std;

int fa[500005],a[500005],c[500005];
int path[500005],ans[500005];
int n,str[500005];

inline int read()
{
	int x=0;
	char c=getchar();
	while (c>='0' && c<='9') x=x*10+c-'0',c=getchar();
	return x;
}

inline int min(int x,int y){return x<y?x:y;}

inline int findfa(int x)
{
	if (fa[x]!=x)
	{
		path[x]=fa[x];
		fa[x]=findfa(fa[x]);
	}
	return fa[x];
}

int main()
{
	scanf("%d",&n);
	char ch[500005];
	scanf("%s",ch+1);
	for (int i=1;i<=n;i++)
	if (ch[i]=='(') c[i]=-1; else c[i]=1;
	a[1]=0;
	for (int i=2;i<=n;i++) scanf("%d",&a[i]);
	for (int i=2;i<=n;i++)
	{
		for (int j=1;j<=n;j++) fa[j]=a[j],path[j]=0;
		memset(str,0,sizeof(str));
		int len=0;
		findfa(i);
		int b=i,sum=0;
		while (b!=0)
		{
			int s=0;
			if (c[b]==-1) str[++len]=1; else if (c[b]==1) str[++len]=-1;
			b=path[b];
			if (str[len]==str[len-1])
			{
				if (len==2) continue;
				int j=0;
				while (j<len)
				{
					j++;
					int combo=0;
					while (str[j]==-1 && str[j+1]==1)
					{
						j+=2;
						combo++;
						for (int k=1;k<=combo;k++) s+=k;
					}
				}
			}
			if (!s)
			if (str[len]==-1 && str[len+1]==1) s++;
			sum+=s;
		}
		ans[i]+=sum;
	}
	int s=ans[1];
	for (int i=2;i<=n;i++) s=s xor (i*ans[i]);
	printf("%d",s);
	return 0;
}
*/

/*
5
(()()
1 1 2 2

10
()()()()()
1 1 2 2 2 2 3 4

50
))()(())((((()))))))((())))()))((()(()((((((())())
1 2 1 2 2 6 6 6 6 10 10 10 7 13 13 10 13 15 18 18 20 17 19 10 25 26 27 25 25 25 31 29 30 34 25 34 29 25 30 39 38 41 34 36 35 43 44 25 44

*/
