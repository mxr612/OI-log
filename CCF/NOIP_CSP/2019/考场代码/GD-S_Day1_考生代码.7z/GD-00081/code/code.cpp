#include<cstdio>
#include<cstring>
using namespace std;
typedef unsigned long long LLU;

char s[70],ch[3]={'0','1'};
int n,len,flag=-1;
unsigned long long k;

inline unsigned long long pow(LLU a,LLU b)
{
	LLU ans=1;
	while (b)
	{
		if (b&1) ans=ans*a;
		b>>=1; a=a*a;
	}
	return ans;
}

int main()
{
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	scanf("%d%llu",&n,&k);
	LLU lu=(LLU)n,kk=k;
	if (!kk)
	{
		for (int i=1;i<=n;i++) putchar('0');
		return 0;
	}
	LLU i=lu;
	while (i>1)
	{
		i--;
		if (flag==-1)
		{
			if (k<pow(2,i) || k<=0) putchar('0'),flag=0;
			else putchar('1'),flag=1,k-=pow(2,i);
		} else if (flag==0)
		{
			if (k<pow(2,i) || k<=0) putchar('0'),flag=0;
			else putchar('1'),flag=1,k-=pow(2,i);
		} else if (flag==1)
		{
			if (k<pow(2,i) || k<=0) putchar('1'),flag=0;
			else putchar('0'),flag=1,k-=pow(2,i);;
		}
		
	}
	if (kk%4==1 || kk%4==2) putchar('1'); else putchar('0');
	return 0;
}
