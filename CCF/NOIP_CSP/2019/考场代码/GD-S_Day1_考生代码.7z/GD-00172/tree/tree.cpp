#include<bits/stdc++.h>
//#define CESHI true
using namespace std;

typedef pair<int,int> bian;
int T,n,num[2005],dot[2005],du[2005],cdu=0,juhua_pre[2005],juhuadot,t;
bian bians[2005];
int vis[2005];
bool fst=true;
int storeans[2005];
int juhua=false;

void cmpans(){
		for (register int i=1;i<=n;i++){
			if (storeans[i]>num[i]){
				for (register int i=1;i<=n;i++){
					storeans[i]=num[i];
				}
				return;
			}else if(storeans[i]<num[i]){
				return;
			}
		}	
}

void baoli10p(int cs){
	if (cs==0){
		cmpans();
		return;
	}
	int x,y;
	for (register int i=1;i<=n-1;i++){
		if (!vis[i]){
			vis[i]=1;
			x=bians[i].first;y=bians[i].second;
			swap(dot[x],dot[y]);
			swap(num[dot[x]],num[dot[y]]);
			baoli10p(cs-1);
			swap(num[dot[x]],num[dot[y]]);
			swap(dot[x],dot[y]);
			vis[i]=0;
		}
	}
}

int main(){
	#ifndef CESHI
	freopen("tree.in","r",stdin);
	freopen("tree.out","w",stdout);
	#endif
	scanf("%d",&T);
	int tmp1,tmp2;
	memset(vis,0,sizeof(vis));
	
	while (T--){
		scanf("%d",&n);
		juhua=false;cdu=0;
		memset(storeans,1,sizeof(storeans));
		memset(du,0,sizeof(du));
		
		for (register int i=1;i<=n;i++) {
			scanf("%d",&tmp1);
			num[i]=tmp1;
			dot[tmp1]=i;
		}
		
		for (register int i=1;i<=n-1;i++){
			scanf("%d%d",&tmp1,&tmp2);
			bians[i]=bian(tmp1,tmp2);
			if (++du[tmp1]>cdu){
				cdu=du[tmp1];
				juhuadot=tmp1;
			}
			if (++du[tmp2]>cdu){
				cdu=du[tmp2];
				juhuadot=tmp2;
			}
		}
		
		if (cdu==n-1){
			juhua=true;
			for (register int i=1;i<=n-1;i++){
				if (bians[i].first!=juhuadot) juhua_pre[bians[i].first]=i;
				else juhua_pre[bians[i].second]=i;
			}
		}
		
		if (n<=10||true){
			baoli10p(n-1);
			for (register int i=1;i<=n;i++){
				printf("%d ",storeans[i]);
			}
		}else if(juhua){
			/*
			t=n-1;
			while(t){
				for (int i=1;i<=n;i++){
					if (num[i]>)
				}
			}*/
		}
		
		printf("\n");
	}
	return 0;
}
