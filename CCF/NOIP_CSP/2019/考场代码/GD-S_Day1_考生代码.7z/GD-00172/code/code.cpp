#include<bits/stdc++.h>
//#define CESHI 1
using namespace std;

int main(){
	#ifndef CESHI
	freopen("code.in","r",stdin);
	freopen("code.out","w",stdout);
	#endif
	int n;
	unsigned long long k;
	cin>>n>>k;
	while (n){
		if ((k)&((unsigned long long)pow(2,n-1))){
			putchar('1');
			k=~(k|(~(((unsigned long long)pow(2,n))-1)));
		}else putchar('0');
		n--;
	}
	return 0;
}
