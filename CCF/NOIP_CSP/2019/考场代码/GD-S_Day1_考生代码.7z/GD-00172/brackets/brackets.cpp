#include<bits/stdc++.h>
//#define CESHI true
using namespace std;

int n;
char kh[500005];
int ans[500005];
int dp[2005][2005];
bool lian=true;

bool judge(int st,int ed){
	if (dp[st][ed]!=-1) return dp[st][ed];
	int zuo=0,you=0;
	for (register int i=st;i<=ed;i++){
		if (kh[i]=='(') zuo++;
		else you++;
		if (zuo<you) return dp[st][ed]=0;
	}
	if (zuo!=you) return dp[st][ed]=0;
	return dp[st][ed]=1;
}

int main(){
	#ifndef CESHI
	freopen("brackets.in","r",stdin);
	freopen("brackets.out","w",stdout);
	#endif
	scanf("%d\n",&n);
	memset(dp,-1,sizeof(dp));
	for (register int i=1;i<=n;i++) scanf("%c",&kh[i]);
	int tmp,opt=0;
	for (register int i=2;i<=n;i++){
		scanf("%d",&tmp);
		if (tmp!=i-1) lian=false;
	}
	if (n<=8||lian){
		ans[1]=0;
		for (int i=2;i<=n;i++){
			ans[i]=ans[i-1];
			for (int j=1;j<=i-1;j++){
				if (judge(j,i)) ans[i]++;
			}
		}
		for (int i=1;i<=n;i++){
			opt = opt xor (i*ans[i]);
		}
	}
	printf("%d\n",opt);
	return 0;
}
