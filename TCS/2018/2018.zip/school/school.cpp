// school.in

#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

int n, k;

int peoV[101], qzh[100];

bool V[101] = {false};
struct edge {
	int vl, id;
} E[101][101];

struct _CmpPQ {
	bool operator()(edge m, edge n) {
		return m.vl > n.vl;
	}
};
priority_queue<edge, vector<edge>, _CmpPQ>pq;

int ans[100], sum = 0;

int main() {
	freopen("school.in", "r", stdin);
	freopen("school.out","w",stdout);

	cin >> n >> k;
	for (int i = 1; i <= n; i++)
		cin >> peoV[i];
	for (int i = 1; i < n; i++)
		cin >> qzh[i], qzh[i] += qzh[i - 1];

	for (int i = 1; i <= n; i++)
		for (int j = i; j <= n; j++)
			E[i][j].vl = E[j][i].vl = qzh[j - 1] - qzh[i - 1];
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= n; j++)
			E[i][j].vl *= peoV[i], E[i][j].id = j;

	V[1] = true;
	for (int i = 1; i <= n; i++)
		pq.push(E[1][i]);
	for (int c = 1; c < n; c++) {
		while (V[pq.top().id] || pq.top().vl == 0)pq.pop();
		edge TOP=pq.top();
		pq.pop();
		ans[c]=TOP.vl;
		V[TOP.id]=true;
		for(int i=1;i<=n;i++)
			pq.push(E[TOP.id][i]);
	}

	sort(&ans[1],&ans[n]);
	for(int i=1;i<=n-k;i++)
		sum+=ans[i];

	cout<<sum;

	return 0;
}