#include <cstdio>
#include <cstdlib>
#include <ctime>
#define rr register
using namespace std;
typedef unsigned uit;
const uit N=2000000;
inline void print(uit ans){
	if (ans>9) print(ans/10);
	putchar(ans%10+48); 
}
inline uit Get(){
	return (rand()+1)*(rand()+2)*(rand()+3);
}
signed main(){
	freopen("data.in","w",stdout);
	srand((unsigned)time(0));
	print(N),putchar(32),print(N),putchar(10);
	for (rr uit i=1;i<=N;++i) print(Get()),putchar(i==N?10:32);
	for (rr uit i=1;i<=N;++i,putchar(10)){
		rr uit z=(Get()+i*(i*i+1))&3,l=Get()%N+1,r=Get()%N+1;
		while (l==r) l=Get()%N+1;
		if (l>r) l^=r,r^=l,l^=r;
		print(z),putchar(32),print(l),putchar(32),print(r);
		if (!z) putchar(32),print(Get());
	}
	return 0;
}
