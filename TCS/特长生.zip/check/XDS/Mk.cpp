#include <cstdio>
#include <ctime>
#include <cstdlib>
#define rr register
using namespace std;
signed main(){
	freopen("Answer.in","w",stdout);
	for (rr int T=1;T<361;++T){
		system("E:\\check\\XDS\\Rand.exe");
		rr double st=clock();
		system("E:\\check\\XDS\\P1.exe");
		rr double et=clock();
		system("E:\\check\\XDS\\P2.exe");
		rr double ed=clock();
		printf("AC! Data #%d: P1:%.lfms; P2:%.lfms\n",T,et-st,ed-et);
	}
	return 0;
}
