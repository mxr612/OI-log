#include <cstdio>
#include <cctype>
#include <cmath>
#define rr register
using namespace std;
typedef unsigned uit; 
const uit N = 2000011;
uit a[N], n, Q, mn[N << 2], lazy[N << 2], mx[N << 2], w[N << 2];
inline uit iut() {
    rr uit ans = 0;
    rr char c = getchar();
    while (!isdigit(c)) c = getchar();
    while (isdigit(c)) ans = (ans << 3) + (ans << 1) + (c ^ 48), c = getchar();
    return ans;
}
inline uit min(uit a, uit b) { return a < b ? a : b; }
inline uit max(uit a, uit b) { return a > b ? a : b; }
inline void pup(uit k) {
    w[k] = w[k << 1] + w[k << 1 | 1], mn[k] = min(mn[k << 1], mn[k << 1 | 1]),
    mx[k] = max(mx[k << 1], mx[k << 1 | 1]);
}
inline void pdown(uit k, uit l, uit r) {
    rr uit mid = (l + r) >> 1, t = lazy[k];
    lazy[k] = 0;
    w[k << 1] += t * (mid - l + 1), w[k << 1 | 1] += t * (r - mid), mn[k << 1] += t, mn[k << 1 | 1] += t,
        mx[k << 1] += t, mx[k << 1 | 1] += t, lazy[k << 1] += t, lazy[k << 1 | 1] += t;
}
inline void build(uit k, uit l, uit r) {
    if (l == r) {
        w[k] = mn[k] = mx[k] = a[l];
        return;
    }
    rr uit mid = (l + r) >> 1;
    build(k << 1, l, mid);
    build(k << 1 | 1, mid + 1, r);
    pup(k);
}
inline void update(uit k, uit l, uit r, uit x, uit y, uit z) {
    if (l == x && r == y) {
        w[k] += (r - l + 1) * z, lazy[k] += z, mn[k] += z, mx[k] += z;
        return;
    }
    if (lazy[k])
        pdown(k, l, r);
    rr uit mid = (l + r) >> 1;
    if (y <= mid)
        update(k << 1, l, mid, x, y, z);
    else if (x > mid)
        update(k << 1 | 1, mid + 1, r, x, y, z);
    else
        update(k << 1, l, mid, x, mid, z), update(k << 1 | 1, mid + 1, r, mid + 1, y, z);
    pup(k);
}
inline uit query1(uit k, uit l, uit r, uit x, uit y) {
    if (l == x && r == y)
        return w[k];
    if (lazy[k])
        pdown(k, l, r);
    rr uit mid = (l + r) >> 1;
    if (y <= mid)
        return query1(k << 1, l, mid, x, y);
    else if (x > mid)
        return query1(k << 1 | 1, mid + 1, r, x, y);
    else
        return query1(k << 1, l, mid, x, mid) + query1(k << 1 | 1, mid + 1, r, mid + 1, y);
}
inline uit query2(uit k, uit l, uit r, uit x, uit y) {
    if (l == x && r == y)
        return mn[k];
    if (lazy[k])
        pdown(k, l, r);
    rr uit mid = (l + r) >> 1;
    if (y <= mid)
        return query2(k << 1, l, mid, x, y);
    else if (x > mid)
        return query2(k << 1 | 1, mid + 1, r, x, y);
    else
        return min(query2(k << 1, l, mid, x, mid), query2(k << 1 | 1, mid + 1, r, mid + 1, y));
}
inline uit query3(uit k, uit l, uit r, uit x, uit y) {
    if (l == x && r == y)
        return mx[k];
    if (lazy[k])
        pdown(k, l, r);
    rr uit mid = (l + r) >> 1;
    if (y <= mid)
        return query3(k << 1, l, mid, x, y);
    else if (x > mid)
        return query3(k << 1 | 1, mid + 1, r, x, y);
    else
        return max(query3(k << 1, l, mid, x, mid), query3(k << 1 | 1, mid + 1, r, mid + 1, y));
}
signed main() {
	freopen("data.in","r",stdin);
    n = iut();
    Q = iut();
    for (rr uit i = 1; i <= n; ++i) a[i] = iut();
    build(1, 1, n);
    for (rr uit i = 1; i <= Q; ++i) {
        rr uit z = iut(), l = iut(), r = iut();
        switch (z) {
            case 0: {
                update(1, 1, n, l, r, iut());
                break;
            }
            case 1: {
                query3(1, 1, n, l, r);
                break;
            }
            case 2: {
                query2(1, 1, n, l, r);
                break;
            }
            case 3: {
                query1(1, 1, n, l, r);
                break;
            }
        }
    }
    return 0;
}
