#include <cstdio>
#define rr register
using namespace std;
int n=0,k; double s;
signed main(){
	freopen("minnum.in","r",stdin);
	freopen("minnum.out","w",stdout);
	for (scanf("%d",&k);s<=k;)
	    s+=1.0/(++n);
	return !printf("%d",n);
}
